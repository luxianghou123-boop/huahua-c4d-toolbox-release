(function () {
  const CONFIG = window.HH_PLUGIN_CONFIG || {};
  const CURRENT_VERSION = CONFIG.PLUGIN_VERSION || "28.284";
  const API_BASE_URL = CONFIG.API_BASE_URL || "http://43.155.144.82";
  const PLUGIN_CODE = CONFIG.PLUGIN_CODE || "hh_ai_c4d";
  const CLIENT_CODE = CONFIG.CLIENT_CODE || "ai_to_c4d_panel";
  const AUTH_BYPASS_FOR_LOCAL_TEST = CONFIG.AUTH_BYPASS_FOR_LOCAL_TEST === true;
  const AUTH_REFRESH_INTERVAL_MS = 10 * 60 * 1000;
  const HEARTBEAT_INTERVAL_MS = 10 * 60 * 1000;
  const OFFLINE_GRACE_MS = 24 * 60 * 60 * 1000;
  const STATUS_POLL_INTERVAL_MS = 1000;
  const AUTO_STATUS_SCAN_LIMIT = 20;
  const STATUS_AUTO_POLL_ENABLED = false;
  const AUTH_REJECT_STATUSES = [
    "license_disabled",
    "license_expired",
    "user_disabled",
    "plugin_disabled",
    "device_limit_exceeded",
    "session_replaced",
    "machine_replaced",
    "unauthorized",
    "forbidden",
    "token_invalid",
    "no_license",
    "plugin_not_found"
  ];
  const UPDATE_CHECK_PATH = "/api/plugin/check-update";
  const cs = new CSInterface();
  const state = {
    mode: "both",
    format: "png",
    updateInfo: null,
    exporting: false,
    hostTaskRunning: false,
    hostTaskCount: 0,
    auth: {
      token: "",
      user: null,
      license: null,
      authorized: false,
      offline: false,
      message: "未登录",
      currentDevices: null,
      maxDevices: null,
      heartbeatTimer: null
    },
    cdkRedeeming: false
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.prototype.slice.call(document.querySelectorAll(selector));
  let shadowPreviewTimer = null;
  let statusPollTimer = null;
  let statusRefreshInFlight = false;
  let lastStatusRefreshAt = 0;
  let refreshStatusSoonTimer = null;
  let hostLoaded = false;
  const statusSkipLogAt = {};
  const STATUS_READ_ACTIONS = {
    check_status: true,
    read_stroke_thickness_depth_info: true,
    get_craft_marker: true
  };

  function jsxString(value) {
    return JSON.stringify(String(value || ""));
  }

  function evalScript(script, callback) {
    cs.evalScript(script, function (result) {
      if (callback) callback(result);
    });
  }

  function loadHost() {
    const root = cs.getSystemPath(SystemPath.EXTENSION);
    const hostPath = root + "/jsx/host.jsx";
    evalScript("$.evalFile(" + jsxString(hostPath) + ")", function () {
      hostLoaded = true;
      refreshStatusSafe("host-loaded", "full");
    });
  }

  function beginHostTask(label) {
    state.hostTaskCount += 1;
    state.hostTaskRunning = true;
    try { console.log("[Host Task] started", label || "host", "count=" + state.hostTaskCount); } catch (error) {}
  }

  function endHostTask(label) {
    state.hostTaskCount = Math.max(0, state.hostTaskCount - 1);
    state.hostTaskRunning = state.hostTaskCount > 0;
    try { console.log("[Host Task] finished", label || "host", "count=" + state.hostTaskCount); } catch (error) {}
    if (!state.hostTaskRunning) refreshStatusSoon("after-" + (label || "host-task"), 300, "after-action");
  }

  function callHost(action, params, callback) {
    const script = "HH_execute(" + JSON.stringify(action) + "," + JSON.stringify(params || {}) + ")";
    const isStatusRead = STATUS_READ_ACTIONS[action] === true;
    if (!isStatusRead) beginHostTask(action);
    evalScript(script, function (result) {
      try {
        if (callback) callback(result);
      } finally {
        if (!isStatusRead) {
          endHostTask(action);
        }
      }
    });
  }

  function selectedValue(name) {
    const active = $('.segmented[data-name="' + name + '"] button.active');
    return active ? active.dataset.value : "";
  }

  function buildContourPosterMask(distances, width, height, tolerance) {
    const count = width * height;
    const visited = new Uint8Array(count), queue = new Uint32Array(count);
    const alpha = new Uint8Array(count);
    let head = 0, tail = 0;
    function addBackground(p) {
      if (!visited[p] && distances[p] <= tolerance) {
        visited[p] = 1; queue[tail++] = p;
      }
    }
    for (let x = 0; x < width; x++) { addBackground(x); addBackground((height - 1) * width + x); }
    for (let y = 0; y < height; y++) { addBackground(y * width); addBackground(y * width + width - 1); }
    // Only edge-connected background is transparent; enclosed background belongs to the sticker.
    while (head < tail) {
      const p = queue[head++], x = p % width;
      if (x) addBackground(p - 1);
      if (x + 1 < width) addBackground(p + 1);
      if (p >= width) addBackground(p - width);
      if (p + width < count) addBackground(p + width);
    }
    const externalBackgroundPixels = tail;
    let internalBackgroundFilled = 0, foreground = count - tail;
    for (let p = 0; p < count; p++) {
      if (!visited[p]) {
        alpha[p] = 255;
        if (distances[p] <= tolerance) internalBackgroundFilled++;
      }
    }
    return { alpha: alpha, foregroundRatio: foreground / count,
      externalBackgroundPixels: externalBackgroundPixels, internalBackgroundFilled: internalBackgroundFilled };
  }

  function runContourMask() {
    if (state.hostTaskRunning || state.exporting) return;
    beginHostTask("contour-mask");
    let finished = false;
    let timer = null;
    function finish(message) {
      if (finished) return;
      finished = true;
      window.clearTimeout(timer);
      callHost("contour_mask_cleanup", {}, function () {
        endHostTask("contour-mask");
        window.alert(message);
      });
    }
    callHost("contour_mask_prepare", {}, function (raw) {
      let job;
      try { job = JSON.parse(raw); } catch (error) {
        finish("巡边剪切蒙版失败：无法读取图片"); return;
      }
      if (!job.ok) { finish(job.message); return; }
      const image = new Image();
      timer = window.setTimeout(function () { finish("巡边剪切蒙版失败：读取图片超时"); }, 30000);
      image.onerror = function () { finish("巡边剪切蒙版失败：无法读取图片"); };
      image.onload = function () {
        if (finished) return;
        window.clearTimeout(timer);
        try {
          const canvas = document.createElement("canvas");
          canvas.width = image.naturalWidth;
          canvas.height = image.naturalHeight;
          const ctx = canvas.getContext("2d");
          ctx.drawImage(image, 0, 0);
          const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
          let transparent = 0;
          let opaque = 0;
          const alpha = new Uint8Array(canvas.width * canvas.height);
          for (let i = 0; i < pixels.data.length; i += 4) {
            alpha[i / 4] = pixels.data[i + 3];
            const visible = pixels.data[i + 3] >= 16;
            if (visible) opaque += 1; else transparent += 1;
          }
          if (!opaque) throw new Error("图片没有可见内容");
          const backgroundMode = !transparent;
          console.log("[TraceMask] image alpha usable=" + !backgroundMode);
          console.log("[TraceMask] mode=" + (backgroundMode ? "background keepHoles=false" : "alpha keepHoles=true"));
          let backgroundDistances = null;
          if (backgroundMode) {
            const w = canvas.width, h = canvas.height;
            const positions = [[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]];
            for (let s = 0; s < 16; s++) {
              const x = Math.round((s + 0.5) * (w - 1) / 16);
              const y = Math.round((s + 0.5) * (h - 1) / 16);
              positions.push([x, 0], [x, h - 1], [0, y], [w - 1, y]);
            }
            function distance(a, b) {
              return Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1]), Math.abs(a[2] - b[2]));
            }
            // Patch medians avoid making JPEG ringing or a single noisy corner pixel the background.
            const samples = positions.map(function (pos) {
              const channels = [[], [], []];
              for (let y = Math.max(0, pos[1] - 2); y <= Math.min(h - 1, pos[1] + 2); y++) {
                for (let x = Math.max(0, pos[0] - 2); x <= Math.min(w - 1, pos[0] + 2); x++) {
                  for (let c = 0; c < 3; c++) channels[c].push(pixels.data[(y * w + x) * 4 + c]);
                }
              }
              return channels.map(function (values) {
                values.sort(function (a, b) { return a - b; });
                return values[Math.floor(values.length / 2)];
              });
            });
            // Keep the cluster radius narrow even when later mask tolerances increase.
            // This prevents a broad fallback from treating a multi-color border as one background.
            let bestMembers = [], bg = null;
            samples.forEach(function (seed) {
              const neighbors = samples.filter(function (s) { return distance(s, seed) <= job.bgTolerance; });
              const center = [0, 1, 2].map(function (c) {
                const values = neighbors.map(function (s) { return s[c]; }).sort(function (a, b) { return a - b; });
                return values[Math.floor(values.length / 2)];
              });
              const members = samples.filter(function (s) { return distance(s, center) <= job.bgTolerance; });
              if (members.length > bestMembers.length) { bestMembers = members; bg = center; }
            });
            const clusterRatio = bestMembers.length / samples.length;
            console.log("[TraceMask] bg sample count=" + samples.length + ", bg cluster ratio=" + clusterRatio + ", bg color=" + JSON.stringify(bg));
            if (clusterRatio < 0.55) {
              console.log("[TraceMask] reject reason=no dominant background cluster");
              throw new Error("背景颜色不够统一，无法自动识别主体（已恢复原图）");
            }
            backgroundDistances = new Uint8Array(alpha.length);
            for (let p = 0; p < alpha.length; p++) {
              const i = p * 4;
              const delta = Math.max(Math.abs(pixels.data[i] - bg[0]), Math.abs(pixels.data[i + 1] - bg[1]), Math.abs(pixels.data[i + 2] - bg[2]));
              backgroundDistances[p] = delta;
            }
          }
          const thresholds = backgroundMode ? [job.bgTolerance, job.bgToleranceFallback, 64, 80] : [job.alphaThreshold, 40, 10];
          const insets = [job.insetPx, job.insetPx / 2, 0];
          let thresholdIndex = 0, insetIndex = -1;
          let foregroundRatio = 0;
          let posterMask = null, posterTolerance = null;
          function rejected() {
            if (insetIndex < 0 || insetIndex === insets.length - 1) {
              thresholdIndex++; insetIndex = -1;
            } else { insetIndex++; }
            if (thresholdIndex >= thresholds.length) {
              finish(backgroundMode ? "巡边剪切蒙版失败：主体轮廓识别异常，已恢复原图" : "巡边剪切蒙版失败：去白边处理后轮廓异常，已恢复原图"); return;
            }
            console.log("[TraceMask] fallback", { mode: backgroundMode ? "background" : "alpha", threshold: thresholds[thresholdIndex], insetPx: insetIndex < 0 ? 0 : insets[insetIndex] });
            attempt();
          }
          function attempt() {
            if (finished) return;
            const insetPx = insetIndex < 0 ? 0 : insets[insetIndex];
            console.log("[TraceMask] " + (backgroundMode ? "bg tolerance tried=" : "alpha threshold=") + thresholds[thresholdIndex] + ", inset px=" + insetPx);
            if (backgroundMode) {
              if (posterTolerance !== thresholds[thresholdIndex]) {
                posterTolerance = thresholds[thresholdIndex];
                posterMask = buildContourPosterMask(backgroundDistances, canvas.width, canvas.height, posterTolerance);
                console.log("[TraceMask] bg flood fill external background pixels=" + posterMask.externalBackgroundPixels + ", internal background filled=" + posterMask.internalBackgroundFilled);
              }
              alpha.set(posterMask.alpha);
              foregroundRatio = posterMask.foregroundRatio;
              console.log("[TraceMask] foreground ratio=" + foregroundRatio);
              if (foregroundRatio < 0.01 || foregroundRatio > 0.94) {
                console.log("[TraceMask] poster mode accepted=false, reject reason=" + (foregroundRatio < 0.01 ? "foreground ratio too low" : "foreground ratio too high"));
                insetIndex = -1; rejected(); return;
              }
            }
            for (let p = 0; p < alpha.length; p++) {
              const value = alpha[p] >= (backgroundMode ? 1 : thresholds[thresholdIndex]) ? 0 : 255;
              pixels.data[p * 4] = pixels.data[p * 4 + 1] = pixels.data[p * 4 + 2] = value;
              pixels.data[p * 4 + 3] = 255;
            }
            ctx.putImageData(pixels, 0, 0);
            require("fs").writeFileSync(job.maskPath, Buffer.from(canvas.toDataURL("image/png").split(",")[1], "base64"));
            callHost("contour_mask_finish", { insetPx: insetPx, mode: backgroundMode ? "background" : "alpha" }, function (result) {
              try {
                const candidate = JSON.parse(result);
                if (!candidate.ok) {
                  console.log("[TraceMask] poster mode accepted=false, reject reason=" + (candidate.rejectReason || candidate.message));
                  if (candidate.retryable) rejected(); else finish(candidate.message);
                  return;
                }
                if (backgroundMode) {
                  console.log("[TraceMask] raw trace path count=" + candidate.rawTracePathCount + ", kept path count=" + candidate.keptPathCount + ", removed tiny path count=" + candidate.removedTinyPathCount);
                  console.log("[TraceMask] outer path count=" + candidate.outerPathCount + ", hole path count ignored=" + candidate.ignoredHolePathCount);
                  console.log("[TraceMask] clip bounds ratio=" + candidate.boundsRatio + ", largest area ratio=" + candidate.largestAreaRatio);
                  if (candidate.pathCount === 1 && candidate.boundsRatio >= 0.98 && candidate.largestAreaRatio >= 0.98) {
                    console.log("[TraceMask] poster mode accepted=false, reject reason=bounds looks rectangular: single near-full-area path");
                    rejected(); return;
                  }
                }
                const preview = new Image();
                timer = window.setTimeout(function () { finish("巡边剪切蒙版失败：轮廓校验超时，已恢复原图"); }, 30000);
                preview.onerror = function () { finish("巡边剪切蒙版失败：无法校验轮廓，已恢复原图"); };
                preview.onload = function () {
                  if (finished) return;
                  window.clearTimeout(timer);
                  try {
                    if (preview.naturalWidth !== canvas.width || preview.naturalHeight !== canvas.height) throw new Error("轮廓尺寸不匹配");
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.drawImage(preview, 0, 0);
                    const actual = ctx.getImageData(0, 0, canvas.width, canvas.height).data;
                    let expected = 0, retained = 0, backgroundCount = 0, backgroundRetained = 0;
                    const tiles = {};
                    for (let p = 0; p < alpha.length; p++) {
                      if (alpha[p] < 32) {
                        if (backgroundMode) {
                          backgroundCount++;
                          if (actual[p * 4 + 3] >= 32) backgroundRetained++;
                        }
                        continue;
                      }
                      // Ignore only the two-pixel antialiased edge when checking local loss.
                      const x = p % canvas.width, y = Math.floor(p / canvas.width);
                      const interior = x >= 2 && y >= 2 && x < canvas.width - 2 && y < canvas.height - 2 &&
                        alpha[p - 2] >= 32 && alpha[p + 2] >= 32 &&
                        alpha[p - 2 * canvas.width] >= 32 && alpha[p + 2 * canvas.width] >= 32;
                      const key = Math.floor((p % canvas.width) / 32) + ":" + Math.floor(p / canvas.width / 32);
                      const tile = tiles[key] || (tiles[key] = [0, 0]);
                      expected++; if (interior) tile[0]++;
                      if (actual[p * 4 + 3] >= alpha[p] * 0.75) { retained++; if (interior) tile[1]++; }
                    }
                    const coverage = expected ? retained / expected : 0;
                    const missingRegion = Object.keys(tiles).some(function (key) {
                      return tiles[key][0] >= 64 && tiles[key][1] / tiles[key][0] < 0.85;
                    });
                    // A rectangular/full-image mask can retain all foreground; also require background removal.
                    const backgroundLeak = backgroundCount ? backgroundRetained / backgroundCount : 0;
                    console.log("[TraceMask] validation", { coverage: coverage, missingRegion: missingRegion, backgroundLeak: backgroundLeak });
                    console.log("[TraceMask] coverage " + (insetIndex < 0 ? "before" : "after") + " inset=" + coverage);
                    if (coverage < job.minCoverage || missingRegion || (backgroundMode && backgroundLeak > 0.03)) {
                      const reasons = [];
                      if (coverage < job.minCoverage) reasons.push("coverage too low");
                      if (missingRegion) reasons.push("local foreground loss");
                      if (backgroundMode && backgroundLeak > 0.03) reasons.push("background residue too high");
                      console.log("[TraceMask] poster mode accepted=false, reject reason=" + reasons.join(", "));
                      rejected(); return;
                    }
                    console.log("[TraceMask] validation passed");
                    if (backgroundMode) console.log("[TraceMask] poster mode accepted=true");
                    if (insetIndex < 0) { insetIndex = 0; attempt(); return; }
                    if (!insetPx) console.log("[TraceMask] inset skipped: preserving verified original contour");
                    else console.log("[TraceMask] fringe fix passed");
                    callHost("contour_mask_commit", { coveragePassed: true }, function (raw) {
                      try { finish(JSON.parse(raw).message); }
                      catch (error) { finish("巡边剪切蒙版失败：无法确认处理结果"); }
                    });
                  } catch (error) { finish("巡边剪切蒙版失败：" + error.message + "，已恢复原图"); }
                };
                preview.src = "data:image/png;base64," + require("fs").readFileSync(candidate.resultPath).toString("base64");
              } catch (error) { finish("巡边剪切蒙版失败：无法生成轮廓"); }
            });
          }
          attempt();
        } catch (error) { finish("巡边剪切蒙版失败：" + error.message); }
      };
      try { image.src = "data:image/png;base64," + require("fs").readFileSync(job.imagePath).toString("base64"); }
      catch (error) { finish("巡边剪切蒙版失败：无法读取图片"); }
    });
  }

  function normalizeVersion(version) {
    return String(version || "").replace(/^v/i, "").split(".").map(function (part) {
      const value = parseInt(part, 10);
      return Number.isNaN(value) ? 0 : value;
    });
  }

  function compareVersions(left, right) {
    const a = normalizeVersion(left);
    const b = normalizeVersion(right);
    const size = Math.max(a.length, b.length);
    for (let i = 0; i < size; i += 1) {
      const av = a[i] || 0;
      const bv = b[i] || 0;
      if (av > bv) return 1;
      if (av < bv) return -1;
    }
    return 0;
  }

  function setUpdateStatus(message, isNotice) {
    const el = $("#updateStatus");
    if (!el) return;
    el.textContent = message || "";
    el.classList.toggle("show", !!message);
    const button = $("#checkUpdateBtn");
    if (button) button.classList.toggle("has-update", !!isNotice);
  }

  function currentPlatformKey() {
    const platform = String(navigator.platform || navigator.userAgent || "").toLowerCase();
    return platform.indexOf("win") >= 0 ? "windows" : "mac";
  }

  function updatePlatformKey() {
    return currentPlatformKey() === "windows" ? "win" : "mac";
  }

  function unwrapUpdatePayload(data) {
    if (data && data.data && typeof data.data === "object") return data.data;
    if (data && data.result && typeof data.result === "object") return data.result;
    return data || {};
  }

  function asArrayNotes(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    return String(value).split(/\r?\n/).filter(Boolean);
  }

  function formatFileSize(size) {
    if (typeof size === "string" && /[a-zA-Z\u4e00-\u9fa5]/.test(size)) return size;
    const value = Number(size || 0);
    if (!value || Number.isNaN(value)) return "";
    if (value >= 1024 * 1024) return (value / 1024 / 1024).toFixed(1) + " MB";
    if (value >= 1024) return Math.round(value / 1024) + " KB";
    return value + " B";
  }

  function downloadSourceLabel(url) {
    const text = String(url || "");
    if (!text) return "";
    let host = "";
    try { host = new URL(text).host; } catch (error) { host = text.replace(/^https?:\/\//i, "").split("/")[0]; }
    if (text.indexOf("43.155.144.82") >= 0 || text.indexOf("/downloads/") >= 0) return "下载来源：服务器镜像下载，推荐";
    return "下载来源：后台下载地址" + (host ? "（" + host + "）" : "");
  }

  function normalizeUpdateInfo(data) {
    const payload = unwrapUpdatePayload(data);
    const latestVersion = payload.latestVersion || payload.version || payload.newVersion || "";
    const hasUpdateValue = payload.hasUpdate;
    const updateAvailableValue = payload.updateAvailable;
    let hasUpdate = false;
    if (typeof hasUpdateValue === "boolean") hasUpdate = hasUpdateValue;
    else if (typeof updateAvailableValue === "boolean") hasUpdate = updateAvailableValue;
    else hasUpdate = compareVersions(latestVersion, CURRENT_VERSION) > 0;

    const downloads = payload.downloads || {};
    const platformDownload = downloads[updatePlatformKey()] || downloads[currentPlatformKey()] || downloads.mac || downloads.macos || downloads.windows || {};
    const downloadUrl = payload.downloadUrl || platformDownload.downloadUrl || platformDownload.url || payload.mirrorDownloadUrl || platformDownload.mirrorDownloadUrl || "";
    const fallbackUrl = payload.fallbackUrl || payload.originalDownloadUrl || platformDownload.fallbackUrl || platformDownload.originalDownloadUrl || "";
    const notes = payload.releaseNotes || payload.notes || payload.changelog || payload.changes || [];
    return {
      success: payload.success,
      hasUpdate: hasUpdate,
      currentVersion: payload.currentVersion || CURRENT_VERSION,
      latestVersion: latestVersion,
      title: payload.title || ("花花智能建模-AI端 v" + (latestVersion || CURRENT_VERSION)),
      notes: asArrayNotes(notes),
      downloadUrl: downloadUrl,
      fallbackUrl: fallbackUrl,
      fileSize: payload.fileSize || payload.size || platformDownload.fileSize || platformDownload.size || "",
      sha256: payload.sha256 || payload.hash || platformDownload.sha256 || platformDownload.hash || "",
      forceUpdate: !!payload.forceUpdate,
      source: downloadSourceLabel(downloadUrl),
      raw: payload
    };
  }

  function requestBackendUpdateInfo(callback) {
    const info = platformInfo();
    authRequest("POST", UPDATE_CHECK_PATH, {
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      currentVersion: CURRENT_VERSION,
      version: CURRENT_VERSION,
      platform: updatePlatformKey(),
      os: info.os,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      app: "illustrator"
    }, state.auth.token || "", function (error, data) {
      if (error || !data) {
        callback(error || new Error("empty response"));
        return;
      }
      if (data.success === false) {
        callback(new Error(data.message || "check-update failed"), data);
        return;
      }
      callback(null, normalizeUpdateInfo(data));
    });
  }

  function openExternalUrl(url) {
    if (!url) return;
    try {
      if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
        window.cep.util.openURLInDefaultBrowser(url);
        return;
      }
    } catch (error) {}
    window.open(url, "_blank");
  }

  function showUpdateDialog(info) {
    state.updateInfo = info;
    $("#updateLatest").textContent = "v" + (info.latestVersion || "");
    $("#updateTitle").textContent = info.title || "花花智能建模-AI端新版";
    $("#updateNotes").textContent = (info.notes || []).join("\n");
    const meta = [];
    meta.push("当前版本：v" + (info.currentVersion || CURRENT_VERSION));
    if (info.latestVersion) meta.push("最新版本：v" + info.latestVersion);
    if (info.source) meta.push(info.source);
    if (info.fileSize) meta.push("文件大小：" + formatFileSize(info.fileSize));
    if (info.forceUpdate) meta.push("强制更新");
    $("#updateSource").textContent = meta.join(" · ");
    $("#updateSha").textContent = info.sha256 ? "SHA256: " + info.sha256 : "";
    const fallbackBtn = $("#fallbackDownloadBtn");
    if (fallbackBtn) fallbackBtn.style.display = info.fallbackUrl ? "" : "none";
    $("#updateModal").classList.add("open");
    $("#updateModal").setAttribute("aria-hidden", "false");
  }

  function closeUpdateDialog() {
    $("#updateModal").classList.remove("open");
    $("#updateModal").setAttribute("aria-hidden", "true");
  }

  function checkForUpdates(manual) {
    setUpdateStatus("正在检查更新...", false);
    requestBackendUpdateInfo(function (error, info) {
      if (error || !info) {
        setUpdateStatus(manual ? "检查失败，请稍后重试" : "", false);
        if (manual) window.alert("检查更新失败，请稍后重试");
        return;
      }
      if (info.hasUpdate && compareVersions(info.latestVersion, CURRENT_VERSION) > 0) {
        setUpdateStatus("发现新版本 v" + info.latestVersion, true);
        showUpdateDialog(info);
        return;
      }
      setUpdateStatus(manual ? "当前已是最新版本 v" + CURRENT_VERSION : "", false);
      if (manual) window.alert("当前已是最新版本");
    });
  }


  const AUTH_STORAGE_KEY = "hhAiC4dAuthState";
  const DEVICE_STORAGE_KEY = "hhAiC4dDeviceId";
  const MACHINE_STORAGE_KEY = "hhMachineId";
  const CORE_BUTTON_IDS = [
    "halftoneBtn", "halftoneApply",
    "generateTableBtn", "generateTableApply",
    "textColumnsBtn", "textColumnsApply",
    "selectSameBtn", "selectSame_appearance", "selectSame_appearance_attributes", "selectSame_blending", "selectSame_fill_stroke", "selectSame_fill", "selectSame_opacity", "selectSame_stroke", "selectSame_weight", "selectSame_style", "selectSame_symbol", "selectSame_linked", "selectSame_font", "selectSame_font_style", "selectSame_font_size",
    "contourMaskBtn",
    "exportBtn", "hotUpdateBtn",
    "markFallbackBtn", "clearFallbackBtn", "previewFallbackBtn", "clearFallbackPreviewBtn", "markFallbackReverseBtn", "clearFallbackReverseBtn",
    "filterMissingBtn", "clearThicknessBtn", "customThicknessBtn",
    "readStrokeThicknessBtn", "previewStrokeThicknessBtn", "clearStrokeThicknessPreviewBtn", "markStrokeThicknessExportBtn", "clearStrokeThicknessExportBtn",
    "strokeThicknessDepth3mmBtn", "strokeThicknessDepth5mmBtn", "strokeThicknessDepth1cmBtn", "strokeThicknessDepth2cmBtn", "strokeThicknessDepth4cmBtn", "strokeThicknessDepth5cmBtn", "strokeThicknessDepth8cmBtn", "strokeThicknessDepth10cmBtn", "strokeThicknessDepth15cmBtn", "strokeThicknessDepth20cmBtn", "applyStrokeThicknessDepthBtn",
    "quickUnionCompoundExpandBtn", "outlineStrokeBtn", "offsetPathBtn", "simplifyPathBtn", "createTextOutlinesBtn", "dropShadowBtn", "applyShadowBtn",
    "renameArtboardsBtn", "createArtboardsBtn", "exportPdfBtn", "exportImagesBtn", "applyPdfExportBtn", "applyImageExportBtn",
    "cutBtn", "dimBoxBtn", "curveLenBtn", "labelBtn",
    "craftNoneBtn", "craftBacklitBtn", "craftFrontlitBtn", "craftCrystalBtn", "craftDualLitBtn", "craftClearBtn"
  ];

  const CRAFT_PRESETS = {
    none: {},
    acrylic_slot: { depthCm: 0.3, direction: "Z+", deleteSides: ["top"], openSides: ["top"], shellCm: 0.3 },
    sign_backlit: { frontThicknessMm: 30, backThicknessMm: 10, color: "#ff0000" },
    sign_frontlit: { frontThicknessMm: 5, backThicknessMm: 30, color: "#ff0000" },
    sign_crystal: { frontThicknessMm: 3, backThicknessMm: 10, color: "#ffffff" },
    sign_dual_lit: { frontThicknessMm: 5, backThicknessMm: 30, color: "#ff0000" }
  };

  let cachedMachineId = "";

  function storageGet(key) {
    try { return window.localStorage.getItem(key) || ""; } catch (error) { return ""; }
  }

  function storageSet(key, value) {
    try { window.localStorage.setItem(key, value); } catch (error) {}
  }

  function storageRemove(key) {
    try { window.localStorage.removeItem(key); } catch (error) {}
  }

  function generateUuid() {
    if (window.crypto && window.crypto.getRandomValues) {
      const bytes = new Uint8Array(16);
      window.crypto.getRandomValues(bytes);
      bytes[6] = (bytes[6] & 0x0f) | 0x40;
      bytes[8] = (bytes[8] & 0x3f) | 0x80;
      const hex = Array.prototype.map.call(bytes, b => ("00" + b.toString(16)).slice(-2));
      return hex.slice(0,4).join("") + "-" + hex.slice(4,6).join("") + "-" + hex.slice(6,8).join("") + "-" + hex.slice(8,10).join("") + "-" + hex.slice(10).join("");
    }
    return "dev-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  }

  function getDeviceId() {
    let id = storageGet(DEVICE_STORAGE_KEY);
    if (!id) {
      id = generateUuid();
      storageSet(DEVICE_STORAGE_KEY, id);
    }
    return id;
  }

  function validId(value) {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value || ""));
  }

  function machineIdFileInfo() {
    try {
      if (typeof require !== "function") return null;
      const path = require("path");
      const os = require("os");
      const rawPlatform = String(navigator.platform || navigator.userAgent || "").toLowerCase();
      const isWin = rawPlatform.indexOf("win") >= 0;
      const appDataDir = (typeof process !== "undefined" && process.env && process.env.APPDATA) ? process.env.APPDATA : "";
      const baseDir = isWin
        ? path.join(appDataDir || os.homedir(), "HuahuaPlugin")
        : path.join(os.homedir(), ".huahua_plugin");
      return {
        dir: baseDir,
        file: path.join(baseDir, "machine_id.json")
      };
    } catch (error) {
      return null;
    }
  }

  function readMachineIdFile() {
    try {
      if (typeof require !== "function") return "";
      const fs = require("fs");
      const info = machineIdFileInfo();
      if (!info || !fs.existsSync(info.file)) return "";
      const raw = fs.readFileSync(info.file, "utf8");
      const data = JSON.parse(raw || "{}");
      return validId(data.machineId) ? data.machineId : "";
    } catch (error) {
      return "";
    }
  }

  function writeMachineIdFile(machineId) {
    try {
      if (typeof require !== "function") return false;
      const fs = require("fs");
      const info = machineIdFileInfo();
      if (!info) return false;
      if (!fs.existsSync(info.dir)) fs.mkdirSync(info.dir, { recursive: true });
      fs.writeFileSync(info.file, JSON.stringify({
        machineId: machineId,
        createdAt: new Date().toISOString()
      }, null, 2), "utf8");
      return true;
    } catch (error) {
      return false;
    }
  }

  function getOrCreateMachineId() {
    if (validId(cachedMachineId)) return cachedMachineId;
    let machineId = readMachineIdFile();
    if (!machineId) {
      machineId = storageGet(MACHINE_STORAGE_KEY);
      if (!validId(machineId)) machineId = generateUuid();
      writeMachineIdFile(machineId);
    }
    cachedMachineId = machineId;
    storageSet(MACHINE_STORAGE_KEY, machineId);
    return machineId;
  }

  function machineIdShort() {
    return getOrCreateMachineId().slice(0, 8);
  }

  function platformInfo() {
    const raw = String(navigator.platform || navigator.userAgent || "").toLowerCase();
    const isWin = raw.indexOf("win") >= 0;
    const isMac = raw.indexOf("mac") >= 0;
    return {
      platform: isWin ? "windows" : "mac",
      os: isWin ? "Windows" : (isMac ? "macOS" : navigator.platform || "unknown"),
      deviceName: (isWin ? "Windows" : "Mac") + " - " + getDeviceId().slice(0, 8)
    };
  }

  function loadAuthStore() {
    try {
      const raw = storageGet(AUTH_STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (error) { return {}; }
  }

  function saveAuthStore(extra) {
    const info = platformInfo();
    const data = Object.assign({}, loadAuthStore(), extra || {}, {
      API_BASE_URL: API_BASE_URL,
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      deviceName: info.deviceName,
      platform: info.platform,
      os: info.os
    });
    storageSet(AUTH_STORAGE_KEY, JSON.stringify(data));
    return data;
  }

  function clearAuthStore() {
    storageRemove(AUTH_STORAGE_KEY);
  }

  function nodeAuthRequest(method, path, body, token, callback) {
    try {
      if (typeof require !== "function") return false;
      const url = require("url");
      const http = require("http");
      const https = require("https");
      const endpoint = url.parse(API_BASE_URL.replace(/\/$/, "") + path);
      const transport = endpoint.protocol === "https:" ? https : http;
      const payload = body ? JSON.stringify(body) : "";
      const headers = {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(payload)
      };
      if (token) headers.Authorization = "Bearer " + token;
      const req = transport.request({
        hostname: endpoint.hostname,
        port: endpoint.port || (endpoint.protocol === "https:" ? 443 : 80),
        path: endpoint.path,
        method: method,
        headers: headers
      }, function (res) {
        let text = "";
        res.setEncoding("utf8");
        res.on("data", function (chunk) { text += chunk; });
        res.on("end", function () {
          let data = {};
          try { data = text ? JSON.parse(text) : {}; } catch (error) { data = { message: text || "响应解析失败" }; }
          data.httpStatus = res.statusCode;
          if (res.statusCode >= 200 && res.statusCode < 300) callback(null, data);
          else {
            const error = new Error((data && data.message) || ("HTTP " + res.statusCode));
            error.statusCode = res.statusCode;
            callback(error, data);
          }
        });
      });
      req.on("error", function (error) { callback(error); });
      req.setTimeout(8000, function () {
        req.destroy(new Error("timeout"));
      });
      req.write(payload);
      req.end();
      return true;
    } catch (error) {
      return false;
    }
  }

  function authRequest(method, path, body, token, callback) {
    const xhr = new XMLHttpRequest();
    let completed = false;
    function finish(error, data) {
      if (completed) return;
      completed = true;
      callback(error, data);
    }
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4 || completed) return;
      let data = null;
      try { data = xhr.responseText ? JSON.parse(xhr.responseText) : {}; } catch (error) { data = { message: xhr.responseText || "响应解析失败" }; }
      if (xhr.status === 0 && nodeAuthRequest(method, path, body, token, finish)) return;
      data.httpStatus = xhr.status;
      if (xhr.status >= 200 && xhr.status < 300) finish(null, data);
      else {
        const error = new Error((data && data.message) || ("HTTP " + xhr.status));
        error.statusCode = xhr.status;
        finish(error, data);
      }
    };
    try {
      xhr.open(method, API_BASE_URL.replace(/\/$/, "") + path, true);
      xhr.timeout = 8000;
      xhr.setRequestHeader("Content-Type", "application/json");
      if (token) xhr.setRequestHeader("Authorization", "Bearer " + token);
      xhr.ontimeout = function () {
        if (nodeAuthRequest(method, path, body, token, finish)) return;
        finish(new Error("timeout"), {});
      };
      xhr.send(body ? JSON.stringify(body) : null);
    } catch (error) {
      if (nodeAuthRequest(method, path, body, token, finish)) return;
      finish(error, {});
    }
  }

  function accountName(user) {
    if (!user) return "未登录";
    return user.nickname || user.email || user.phone || user.id || "已登录";
  }

  function authRejectStatus(data) {
    const body = authResultBody(data);
    const raw = String((body && (body.reason || body.status || body.code)) || (data && (data.reason || data.status || data.code)) || "").toLowerCase();
    const message = String((body && body.message) || (data && data.message) || "");
    if (raw) return raw;
    if (/machine_replaced|账号已在其他电脑登录|其他电脑登录/i.test(message)) return "machine_replaced";
    if (/session_replaced|账号已在其他设备登录|其他设备登录/i.test(message)) return "session_replaced";
    if (/token.*invalid|token 无效|登录已失效/i.test(message)) return "token_invalid";
    return "";
  }

  function authRejectMessage(data, fallback) {
    const status = authRejectStatus(data);
    if (status === "no_license") return "当前账号暂无授权，请联系管理员开通。";
    if (status === "license_expired") return "授权已到期，请联系管理员续费。";
    if (status === "license_disabled") return "授权已被禁用，请联系管理员。";
    if (status === "user_disabled") return "账号已被禁用，请联系管理员。";
    if (status === "plugin_disabled") return "插件服务已被禁用，请联系管理员。";
    if (status === "machine_replaced") return "账号已在其他电脑登录，请重新登录。";
    if (status === "session_replaced") return "账号已在其他设备登录，请重新登录。";
    if (status === "unauthorized" || status === "token_invalid" || status === "forbidden") return "登录已失效，请重新登录。";
    if (status === "device_limit_exceeded") return "设备数量限制，请联系管理员。";
    const body = authResultBody(data);
    return (body && body.message) || (data && data.message) || fallback || "授权不可用";
  }

  function cdkRejectMessage(data, error) {
    const body = authResultBody(data);
    const raw = String((body && (body.reason || body.status || body.code)) || (data && (data.reason || data.status || data.code)) || "").toLowerCase();
    const httpStatus = (body && body.httpStatus) || (data && data.httpStatus) || (error && error.statusCode);
    if (httpStatus === 401 || httpStatus === 403 || raw === "unauthorized" || raw === "forbidden" || raw === "token_invalid") return "登录已失效，请重新登录。";
    if (raw === "cdk_not_found") return "兑换码不存在。";
    if (raw === "cdk_used") return "兑换码已被使用。";
    if (raw === "cdk_disabled") return "兑换码已被禁用，请联系管理员。";
    if (raw === "cdk_expired") return "兑换码已过期，请联系管理员。";
    if (raw === "user_disabled") return "账号不可用，请联系管理员。";
    if (raw === "no_license") return "兑换失败，请联系管理员。";
    if (raw === "unknown") return "兑换失败，请稍后重试。";
    return (body && body.message) || (data && data.message) || (error && error.message) || "兑换失败，请稍后重试。";
  }

  function authResultBody(data) {
    if (data && data.data && typeof data.data === "object") return data.data;
    return data || {};
  }

  function isExplicitAuthRejection(data, error) {
    const body = authResultBody(data);
    const status = authRejectStatus(data);
    const message = String((body && body.message) || (data && data.message) || "");
    const httpStatus = (body && body.httpStatus) || (data && data.httpStatus) || (error && error.statusCode);
    if (httpStatus === 401 || httpStatus === 403) return true;
    if (AUTH_REJECT_STATUSES.indexOf(status) >= 0) return true;
    if (/machine_replaced|账号已在其他电脑登录|其他电脑登录/i.test(message)) return true;
    if (/session_replaced|账号已在其他设备登录|其他设备登录/i.test(message)) return true;
    if (data && data.success === false) return true;
    if (body && body.allowed === false) return true;
    if (data && data.allowed === false) return true;
    return false;
  }

  function lastVerifiedAgeMs() {
    const saved = loadAuthStore();
    const ts = Date.parse(saved.lastVerifiedAt || "");
    if (!Number.isFinite(ts)) return Infinity;
    return Date.now() - ts;
  }

  function offlineGraceAvailable() {
    const saved = loadAuthStore();
    return !!saved.token && !!saved.license && lastVerifiedAgeMs() <= OFFLINE_GRACE_MS;
  }

  function applyOfflineGrace(message) {
    if (!offlineGraceAvailable()) {
      applyAuthFailure(message || "无法连接授权后台，请联网验证", false);
      return false;
    }
    const saved = loadAuthStore();
    state.auth.token = saved.token || state.auth.token;
    state.auth.user = saved.user || state.auth.user;
    state.auth.license = saved.license || state.auth.license;
    state.auth.authorized = true;
    state.auth.offline = true;
    setAuthMessage("离线授权中：网络异常，使用最近一次授权");
    updateAuthUi();
    startHeartbeat();
    return true;
  }

  function handleAuthFailure(data, error, fallbackMessage) {
    if (isExplicitAuthRejection(data, error)) {
      const status = authRejectStatus(data);
      applyAuthFailure(authRejectMessage(data, fallbackMessage || "授权已失效"), status === "machine_replaced" || status === "session_replaced" || status === "unauthorized" || status === "token_invalid" || status === "forbidden");
      saveAuthStore({ licenseInvalidAt: new Date().toISOString() });
      return false;
    }
    return applyOfflineGrace((error && error.message) || fallbackMessage || "网络异常，无法连接授权后台");
  }

  function formatDate(value) {
    if (!value) return "-";
    try { return new Date(value).toLocaleString(); } catch (error) { return String(value); }
  }

  function setCoreEnabled(enabled, reason) {
    if (AUTH_BYPASS_FOR_LOCAL_TEST) {
      enabled = true;
      reason = "本地测试模式，已跳过授权限制";
    }
    const shouldDisable = !enabled;
    CORE_BUTTON_IDS.forEach(function (id) {
      const el = document.getElementById(id);
      if (!el) return;
      el.disabled = shouldDisable;
      el.classList.toggle("auth-locked", shouldDisable);
      if (shouldDisable) el.setAttribute("title", reason || "请先登录并完成授权校验");
      else el.removeAttribute("title");
    });
    $$('[data-thick]').forEach(function (el) {
      el.disabled = shouldDisable;
      el.classList.toggle("auth-locked", shouldDisable);
      if (shouldDisable) el.setAttribute("title", reason || "请先登录并完成授权校验");
      else el.removeAttribute("title");
    });
  }

  function setAuthMessage(message) {
    state.auth.message = message || "";
    const el = $("#authMessage");
    if (el) el.textContent = state.auth.message || "";
  }

  function updateAuthUi() {
    const cfg = CONFIG || {};
    const user = state.auth.user;
    const license = state.auth.license || {};
    const authorized = !!state.auth.authorized;
    const offline = authorized && !!state.auth.offline;
    const accountBtn = $("#accountBtn");
    if (accountBtn) {
      accountBtn.classList.toggle("authorized", authorized);
      accountBtn.classList.toggle("denied", !!state.auth.token && !authorized);
    }
    if ($("#accountBtnLabel")) $("#accountBtnLabel").textContent = offline ? "离线授权" : (authorized ? "已授权" : (state.auth.token ? "未授权" : "账号"));
    if ($("#authApiBase")) $("#authApiBase").textContent = API_BASE_URL;
    if ($("#authModalVersion")) $("#authModalVersion").textContent = cfg.VERSION_LABEL || ("v" + CURRENT_VERSION);
    if ($("#authCurrentUser")) $("#authCurrentUser").textContent = accountName(user);
    if ($("#authLicenseStatus")) $("#authLicenseStatus").textContent = offline ? "离线授权" : (authorized ? "已授权" : (state.auth.token ? "授权失败" : "未授权"));
    if ($("#authDeviceInfo")) $("#authDeviceInfo").textContent = platformInfo().deviceName;
    if ($("#authMachineId")) $("#authMachineId").textContent = machineIdShort();
    if ($("#authPlan")) $("#authPlan").textContent = license.plan || "-";
    if ($("#authExpiresAt")) $("#authExpiresAt").textContent = formatDate(license.expiresAt);
    if ($("#authDeviceCount")) {
      const cur = state.auth.currentDevices == null ? "-" : state.auth.currentDevices;
      $("#authDeviceCount").textContent = cur;
    }
    if ($("#authLastVerified")) $("#authLastVerified").textContent = formatDate(loadAuthStore().lastVerifiedAt);
    if ($("#authRedeemCdkBtn")) {
      const canRedeem = !!state.auth.token && !state.cdkRedeeming;
      $("#authRedeemCdkBtn").disabled = !canRedeem;
      $("#authRedeemCdkBtn").setAttribute("title", canRedeem ? "兑换 CDK" : "请先登录后兑换 CDK");
    }
    const loginPanel = $("#authLoginPanel");
    const registerPanel = $("#authRegisterPanel");
    const infoPanel = $("#authInfoPanel");
    if (loginPanel && state.auth.token) loginPanel.style.display = "none";
    if (loginPanel && !state.auth.token && (!registerPanel || registerPanel.style.display !== "grid")) loginPanel.style.display = "grid";
    if (registerPanel && state.auth.token) registerPanel.style.display = "none";
    if (infoPanel) infoPanel.style.display = state.auth.token ? "grid" : "none";
    setCoreEnabled(authorized, state.auth.message || "请先登录并完成授权校验");
    if (AUTH_BYPASS_FOR_LOCAL_TEST && $("#authMessage")) {
      $("#authMessage").textContent = "本地测试模式：已跳过授权限制";
    }
  }

  function applyAuthSuccess(token, user, license, registerInfo, message) {
    state.auth.token = token;
    state.auth.user = user || state.auth.user;
    state.auth.license = license || state.auth.license;
    state.auth.authorized = true;
    state.auth.offline = false;
    state.auth.currentDevices = registerInfo && registerInfo.currentDevices != null ? registerInfo.currentDevices : state.auth.currentDevices;
    state.auth.maxDevices = registerInfo && registerInfo.maxDevices != null ? registerInfo.maxDevices : (license && license.maxDevices != null ? license.maxDevices : state.auth.maxDevices);
    saveAuthStore({ token: token, user: state.auth.user, license: state.auth.license, lastVerifiedAt: new Date().toISOString() });
    setAuthMessage(message || "授权有效");
    updateAuthUi();
    startHeartbeat();
  }

  function applyAuthFailure(message, clearToken) {
    if (state.auth.heartbeatTimer) window.clearInterval(state.auth.heartbeatTimer);
    state.auth.heartbeatTimer = null;
    state.auth.authorized = false;
    state.auth.offline = false;
    state.auth.license = clearToken ? null : state.auth.license;
    if (clearToken) {
      state.auth.token = "";
      state.auth.user = null;
      clearAuthStore();
    }
    setAuthMessage(message || "授权不可用");
    updateAuthUi();
  }

  function showAuthLoginPanel(message) {
    const loginPanel = $("#authLoginPanel");
    const registerPanel = $("#authRegisterPanel");
    if (registerPanel) registerPanel.style.display = "none";
    if (loginPanel) loginPanel.style.display = "grid";
    if (message) setAuthMessage(message);
  }

  function showAuthRegisterPanel() {
    const loginPanel = $("#authLoginPanel");
    const registerPanel = $("#authRegisterPanel");
    if (loginPanel) loginPanel.style.display = "none";
    if (registerPanel) registerPanel.style.display = "grid";
    setAuthMessage("请填写邮箱和密码注册账号");
  }

  function verifyLicenseFlow(token, user, done) {
    const info = platformInfo();
    const basePayload = {
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      version: CURRENT_VERSION,
      platform: info.platform,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      deviceName: info.deviceName,
      os: info.os
    };
    setAuthMessage("正在校验授权...");
    authRequest("POST", "/api/plugin/check-license", basePayload, token, function (licenseErr, licenseData) {
      if (licenseErr || !licenseData || licenseData.allowed !== true) {
        const allowedByGrace = handleAuthFailure(licenseData, licenseErr, "授权校验失败");
        if (done) done(allowedByGrace, licenseData);
        return;
      }
      setAuthMessage("正在绑定设备...");
      authRequest("POST", "/api/plugin/register-device", basePayload, token, function (regErr, regData) {
        if (regErr || !regData || regData.allowed === false || regData.success === false) {
          const allowedByGrace = handleAuthFailure(regData, regErr, "设备绑定失败");
          if (done) done(allowedByGrace, regData);
          return;
        }
        state.auth.token = token;
        state.auth.user = user || state.auth.user;
        state.auth.license = licenseData;
        sendHeartbeat(token, function (heartbeatOk, heartbeatData) {
          if (!heartbeatOk && isExplicitAuthRejection(heartbeatData)) {
            return;
          }
          applyAuthSuccess(token, user, licenseData, regData, regData.message || licenseData.message || "授权有效");
          if (done) done(true, { license: licenseData, register: regData });
        });
      });
    });
  }

  function ensureFreshAuth(done) {
    if (AUTH_BYPASS_FOR_LOCAL_TEST) {
      done(true);
      return;
    }
    if (!state.auth.token) {
      applyAuthFailure("未登录，请先登录后台账号", false);
      done(false);
      return;
    }
    if (state.auth.authorized && lastVerifiedAgeMs() <= AUTH_REFRESH_INTERVAL_MS) {
      done(true);
      return;
    }
    setAuthMessage("正在刷新授权...");
    verifyLicenseFlow(state.auth.token, state.auth.user, function (allowed) {
      done(!!allowed);
    });
  }

  function fetchCurrentUserThenVerify(token, fallbackUser) {
    setAuthMessage("正在读取账号信息...");
    authRequest("GET", "/api/auth/me", null, token, function (meErr, meData) {
      if (meErr) {
        if (isExplicitAuthRejection(meData, meErr)) {
          applyAuthFailure("登录已失效，请重新登录", true);
          return;
        }
        const allowedByGrace = applyOfflineGrace("网络异常，使用最近一次授权");
        if (!allowedByGrace) applyAuthFailure("无法读取账号信息，请联网验证", false);
        return;
      }
      const user = meData && (meData.user || meData.data || meData);
      state.auth.user = user || fallbackUser || null;
      saveAuthStore({ token: token, user: state.auth.user, lastLoginAt: new Date().toISOString() });
      verifyLicenseFlow(token, state.auth.user);
    });
  }

  function bindCoreFreshnessGuard() {
    CORE_BUTTON_IDS.forEach(function (id) {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener("click", function (event) {
        if (AUTH_BYPASS_FOR_LOCAL_TEST || el.dataset.authFreshBypass === "1") return;
        if (state.auth.authorized && lastVerifiedAgeMs() <= AUTH_REFRESH_INTERVAL_MS) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        ensureFreshAuth(function (allowed) {
          if (!allowed) {
            window.alert(state.auth.message || "当前未授权，无法使用核心功能。");
            return;
          }
          el.dataset.authFreshBypass = "1";
          el.click();
          window.setTimeout(function () { delete el.dataset.authFreshBypass; }, 0);
        });
      }, true);
    });
  }

  function loginAuth() {
    const account = String($("#authAccountInput").value || "").trim();
    const password = String($("#authPasswordInput").value || "");
    if (!account || !password) {
      setAuthMessage("请输入账号和密码");
      return;
    }
    setAuthMessage("正在登录...");
    authRequest("POST", "/api/auth/login", { account: account, password: password, machineId: getOrCreateMachineId(), clientCode: CLIENT_CODE, pluginCode: PLUGIN_CODE }, "", function (err, data) {
      if (err || !data || data.success !== true || !data.token) {
        applyAuthFailure((data && data.message) || (err && err.message) || "登录失败", true);
        return;
      }
      saveAuthStore({ token: data.token, user: data.user || null, lastLoginAt: new Date().toISOString() });
      state.auth.token = data.token;
      state.auth.user = data.user || null;
      fetchCurrentUserThenVerify(data.token, data.user || null);
    });
  }

  function registerAuth() {
    const email = String($("#authRegisterEmailInput").value || "").trim();
    const nickname = String($("#authRegisterNicknameInput").value || "").trim();
    const password = String($("#authRegisterPasswordInput").value || "");
    const confirm = String($("#authRegisterConfirmInput").value || "");
    if (!email || !password) {
      setAuthMessage("请输入邮箱和密码");
      return;
    }
    if (password !== confirm) {
      setAuthMessage("两次输入的密码不一致");
      return;
    }
    setAuthMessage("正在注册...");
    authRequest("POST", "/api/auth/register", {
      email: email,
      password: password,
      confirmPassword: confirm,
      passwordConfirm: confirm,
      machineId: getOrCreateMachineId(),
      nickname: nickname,
      name: nickname
    }, "", function (err, data) {
      if (err || !data || data.success !== true) {
        setAuthMessage((data && data.message) || (err && err.message) || "注册失败");
        return;
      }
      if ($("#authRegisterPasswordInput")) $("#authRegisterPasswordInput").value = "";
      if ($("#authRegisterConfirmInput")) $("#authRegisterConfirmInput").value = "";
      if ($("#authAccountInput")) $("#authAccountInput").value = email;
      showAuthLoginPanel("注册成功，请登录");
    });
  }

  function setCdkRedeemMessage(message, visible) {
    const el = $("#cdkRedeemMessage");
    if (!el) return;
    el.textContent = message || "";
    el.classList.toggle("show", !!visible && !!message);
  }

  function setCdkRedeemLoading(loading) {
    state.cdkRedeeming = !!loading;
    const input = $("#cdkRedeemInput");
    const submit = $("#cdkRedeemSubmitBtn");
    const cancel = $("#cdkRedeemCancelBtn");
    if (input) input.disabled = !!loading;
    if (submit) {
      submit.disabled = !!loading;
      submit.textContent = loading ? "兑换中..." : "立即兑换";
    }
    if (cancel) cancel.disabled = !!loading;
    updateAuthUi();
  }

  function clearCdkRedeemForm() {
    if ($("#cdkRedeemInput")) $("#cdkRedeemInput").value = "";
    setCdkRedeemMessage("", false);
    setCdkRedeemLoading(false);
  }

  function openCdkRedeemModal() {
    if (!state.auth.token) {
      setAuthMessage("请先登录后兑换 CDK");
      updateAuthUi();
      return;
    }
    clearCdkRedeemForm();
    if ($("#cdkRedeemModal")) {
      $("#cdkRedeemModal").classList.add("open");
      $("#cdkRedeemModal").setAttribute("aria-hidden", "false");
    }
    window.setTimeout(function () {
      try { if ($("#cdkRedeemInput")) $("#cdkRedeemInput").focus(); } catch (error) {}
    }, 0);
  }

  function closeCdkRedeemModal() {
    if (state.cdkRedeeming) return;
    if ($("#cdkRedeemModal")) {
      $("#cdkRedeemModal").classList.remove("open");
      $("#cdkRedeemModal").setAttribute("aria-hidden", "true");
    }
    clearCdkRedeemForm();
  }

  function redeemCdk() {
    if (state.cdkRedeeming) return;
    if (!state.auth.token) {
      setCdkRedeemMessage("请先登录后兑换 CDK", true);
      setAuthMessage("请先登录后兑换 CDK");
      updateAuthUi();
      return;
    }
    const code = String(($("#cdkRedeemInput") && $("#cdkRedeemInput").value) || "").trim();
    if (!code) {
      setCdkRedeemMessage("请输入 CDK 兑换码", true);
      return;
    }
    setCdkRedeemMessage("正在兑换...", true);
    setCdkRedeemLoading(true);
    authRequest("POST", "/api/cdk/redeem", {
      code: code,
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE
    }, state.auth.token, function (err, data) {
      setCdkRedeemLoading(false);
      if (err || !data || data.success !== true) {
        const httpStatus = (data && data.httpStatus) || (err && err.statusCode);
        const message = cdkRejectMessage(data, err);
        setCdkRedeemMessage(message, true);
        setAuthMessage(message);
        if (httpStatus === 401 || httpStatus === 403 || /登录已失效/.test(message)) {
          applyAuthFailure("登录已失效，请重新登录。", true);
          closeCdkRedeemModal();
        } else {
          updateAuthUi();
        }
        return;
      }
      closeCdkRedeemModal();
      setAuthMessage("兑换成功，正在刷新授权状态。");
      window.alert("兑换成功，正在刷新授权状态。");
      verifyLicenseFlow(state.auth.token, state.auth.user, function (allowed) {
        if (allowed) setAuthMessage("兑换成功，授权状态已刷新。");
        else setAuthMessage(state.auth.message || "兑换成功，请重新校验授权。");
        updateAuthUi();
      });
    });
  }

  function autoVerifyAuth() {
    const saved = loadAuthStore();
    if (authStoreNeedsCloudReset(saved)) {
      clearAuthStore();
      state.auth.token = "";
      state.auth.user = null;
      state.auth.license = null;
      state.auth.authorized = false;
      state.auth.offline = false;
      applyAuthFailure("后台地址或插件授权标识已切换，请重新登录", false);
      return;
    }
    const token = saved.token || "";
    state.auth.token = token;
    state.auth.user = saved.user || null;
    state.auth.license = saved.license || null;
    if (!token) {
      applyAuthFailure("未登录，请先登录后台账号", false);
      return;
    }
    setAuthMessage("正在恢复登录状态...");
    authRequest("GET", "/api/auth/me", null, token, function (err, data) {
      if (err) {
        if (isExplicitAuthRejection(data, err)) {
          applyAuthFailure("登录已失效，请重新登录", true);
        } else {
          applyOfflineGrace("网络异常，使用最近一次授权");
        }
        return;
      }
      const user = data && (data.user || data.data || data);
      state.auth.user = user || saved.user || null;
      verifyLicenseFlow(token, state.auth.user);
    });
  }

  function authStoreNeedsCloudReset(saved) {
    if (!saved || !saved.token) return false;
    const savedBase = String(saved.API_BASE_URL || "");
    if (!savedBase) return true;
    if (/localhost|127\.0\.0\.1/i.test(savedBase)) return true;
    if (savedBase !== API_BASE_URL) return true;
    if (saved.pluginCode && saved.pluginCode !== PLUGIN_CODE) return true;
    if (saved.clientCode && saved.clientCode !== CLIENT_CODE) return true;
    return false;
  }

  function sendHeartbeat(token, callback) {
    const info = platformInfo();
    authRequest("POST", "/api/plugin/heartbeat", {
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      version: CURRENT_VERSION,
      platform: info.platform
    }, token || state.auth.token, function (err, data) {
      if (err) {
        handleAuthFailure(data, err, "heartbeat 失败");
        if (callback) callback(false, data);
        return;
      }
      if (isExplicitAuthRejection(data, err)) {
        handleAuthFailure(data, null, "授权已失效");
        if (callback) callback(false, data);
        return;
      }
      saveAuthStore({ lastHeartbeatAt: new Date().toISOString() });
      if (callback) callback(true, data);
    });
  }

  function startHeartbeat() {
    if (state.auth.heartbeatTimer) window.clearInterval(state.auth.heartbeatTimer);
    state.auth.heartbeatTimer = window.setInterval(function () {
      if (state.auth.authorized && state.auth.token) sendHeartbeat(state.auth.token);
    }, HEARTBEAT_INTERVAL_MS);
  }

  function logoutAuth() {
    if (state.auth.heartbeatTimer) window.clearInterval(state.auth.heartbeatTimer);
    state.auth.heartbeatTimer = null;
    state.auth.token = "";
    state.auth.user = null;
    state.auth.license = null;
    state.auth.authorized = false;
    state.auth.offline = false;
    state.auth.currentDevices = null;
    state.auth.maxDevices = null;
    clearAuthStore();
    setAuthMessage("已退出登录");
    updateAuthUi();
  }

  function openAuthModal() {
    updateAuthUi();
    $("#authModal").classList.add("open");
    $("#authModal").setAttribute("aria-hidden", "false");
  }

  function closeAuthModal() {
    $("#authModal").classList.remove("open");
    $("#authModal").setAttribute("aria-hidden", "true");
  }

  function bindAuth() {
    if ($("#accountBtn")) $("#accountBtn").addEventListener("click", openAuthModal);
    if ($("#authCloseBtn")) $("#authCloseBtn").addEventListener("click", closeAuthModal);
    if ($("#authModal")) $("#authModal").addEventListener("click", function (event) { if (event.target === $("#authModal")) closeAuthModal(); });
    if ($("#authLoginBtn")) $("#authLoginBtn").addEventListener("click", loginAuth);
    if ($("#authPasswordInput")) $("#authPasswordInput").addEventListener("keydown", function (event) { if (event.key === "Enter") loginAuth(); });
    if ($("#authShowRegisterBtn")) $("#authShowRegisterBtn").addEventListener("click", showAuthRegisterPanel);
    if ($("#authBackLoginBtn")) $("#authBackLoginBtn").addEventListener("click", function () { showAuthLoginPanel("请输入后台账号密码"); });
    if ($("#authRegisterBtn")) $("#authRegisterBtn").addEventListener("click", registerAuth);
    if ($("#authRegisterConfirmInput")) $("#authRegisterConfirmInput").addEventListener("keydown", function (event) { if (event.key === "Enter") registerAuth(); });
    if ($("#authRedeemCdkBtn")) $("#authRedeemCdkBtn").addEventListener("click", openCdkRedeemModal);
    if ($("#cdkRedeemSubmitBtn")) $("#cdkRedeemSubmitBtn").addEventListener("click", redeemCdk);
    if ($("#cdkRedeemCancelBtn")) $("#cdkRedeemCancelBtn").addEventListener("click", closeCdkRedeemModal);
    if ($("#cdkRedeemInput")) $("#cdkRedeemInput").addEventListener("keydown", function (event) { if (event.key === "Enter") redeemCdk(); });
    if ($("#cdkRedeemModal")) $("#cdkRedeemModal").addEventListener("click", function (event) { if (event.target === $("#cdkRedeemModal")) closeCdkRedeemModal(); });
    if ($("#authRecheckBtn")) $("#authRecheckBtn").addEventListener("click", function () {
      if (!state.auth.token) { setAuthMessage("请先登录"); updateAuthUi(); return; }
      verifyLicenseFlow(state.auth.token, state.auth.user);
    });
    if ($("#authLogoutBtn")) $("#authLogoutBtn").addEventListener("click", logoutAuth);
  }

  function exportOptions() {
    return {
      mode: selectedValue("mode") || state.mode,
      dpi: parseInt($("#dpiSelect").value, 10) || 300,
      format: selectedValue("format") || state.format
    };
  }

  function setExportButtonsEnabled(enabled) {
    const exportBtn = $("#exportBtn");
    const hotUpdateBtn = $("#hotUpdateBtn");
    const coreAllowed = AUTH_BYPASS_FOR_LOCAL_TEST || !!state.auth.authorized;
    if (exportBtn) exportBtn.disabled = !enabled || !coreAllowed;
    if (hotUpdateBtn) hotUpdateBtn.disabled = !enabled || !coreAllowed;
  }

  function finishExportUiState(options) {
    const shouldRefresh = !!(options && options.refresh);
    state.exporting = false;
    setExportButtonsEnabled(true);
    try { console.log("[Export Cleanup] ui busy=false"); } catch (logErr) {}
    if (shouldRefresh) {
      refreshStatusSoon("after-export", 120, "after-action");
    }
  }

  function runExportWithProgress(forceChooseDir) {
    if (state.exporting) return;
    const options = exportOptions();
    setExportButtonsEnabled(false);
    const beginExport = function () {
      state.exporting = true;
      setExportButtonsEnabled(false);
      const script = "HH_exportC4DJsonWithSaveDialog(" +
        JSON.stringify(options.mode) + "," +
        options.dpi + "," +
        JSON.stringify(options.format) + ")";
      evalScript(script, function (message) {
        let shouldRefresh = false;
        try {
          const text = String(message || "");
          if (text.indexOf('"cancelled":true') >= 0 || text.indexOf("已取消导出") >= 0) {
            $("#statusText").textContent = "已取消导出";
            return;
          }
          if (text.indexOf("ERROR:") === 0) {
            $("#statusText").textContent = text.replace(/^ERROR:/, "");
            return;
          }
          shouldRefresh = true;
        } finally {
          finishExportUiState({ refresh: shouldRefresh });
        }
      });
    };
    refreshStatus(function () {
      window.setTimeout(beginExport, 80);
    }, "before-export");
  }

  function statusScanParams(mode) {
    const full = mode === "manual" || mode === "full" || mode === "after-action" || mode === "before-export";
    return {
      statusScanMode: full ? "full" : "auto",
      statusScanLimit: full ? 0 : AUTO_STATUS_SCAN_LIMIT
    };
  }

  function refreshStatus(done, mode) {
    let completed = false;
    let baseStatusMessage = "";
    const scanParams = statusScanParams(mode || "auto");
    const isFullScan = scanParams.statusScanMode === "full";
    function finish() {
      if (completed) return;
      completed = true;
      if (done) done();
    }
    callHost("check_status", scanParams, function (message) {
      if (!message || message === "CEP_NOT_AVAILABLE") {
        $("#statusText").textContent = "等待 Illustrator CEP 环境";
        finish();
        return;
      }
      const cleanMessage = String(message).replace(/^STATUS:/, "");
      baseStatusMessage = cleanMessage;
      $("#statusText").textContent = cleanMessage;
      if (cleanMessage.indexOf("✅ 选中") >= 0) {
        if (state.exporting || state.hostTaskRunning) {
          finish();
          return;
        }
        refreshStrokeThicknessDepthInfo(function () {
          if (state.exporting || state.hostTaskRunning) {
            finish();
            return;
          }
          refreshCraftMarkerInfo(function (craftMessage) {
            const craftLabel = craftStatusLabel(craftMessage);
            $("#statusText").textContent = baseStatusMessage + " | 工艺：" + craftLabel;
            finish();
          }, scanParams);
        }, scanParams);
      } else {
        setStrokeThicknessDepthInfo("描边厚度导出厚度：未设置");
        setCraftMarkerInfo("当前工艺：普通对象");
        finish();
      }
    });
  }

  function logStatusSkip(reason) {
    const key = reason || "unknown";
    const now = Date.now();
    if (now - (statusSkipLogAt[key] || 0) < 10000) return;
    statusSkipLogAt[key] = now;
    try { console.log("[Status Poll] skip: " + key); } catch (error) {}
  }

  function refreshStatusSafe(reason, mode) {
    if (document.hidden) {
      logStatusSkip("panel hidden");
      return;
    }
    if (statusRefreshInFlight) {
      logStatusSkip("in flight");
      return;
    }
    if (state.exporting || state.hostTaskRunning) {
      logStatusSkip("host busy");
      return;
    }
    statusRefreshInFlight = true;
    lastStatusRefreshAt = Date.now();
    try {
      refreshStatus(function () {
        const duration = Date.now() - lastStatusRefreshAt;
        statusRefreshInFlight = false;
        if (duration >= 1000) {
          try { console.log("[Status Poll] done duration=" + duration + "ms reason=" + (reason || "manual")); } catch (error) {}
        }
      }, mode || (reason === "manual" ? "manual" : "auto"));
    } catch (error) {
      statusRefreshInFlight = false;
      try { console.log("[Status Poll] failed", error && error.message ? error.message : error); } catch (logError) {}
    }
  }

  function refreshStatusSoon(reason, delay, mode) {
    if (refreshStatusSoonTimer) window.clearTimeout(refreshStatusSoonTimer);
    refreshStatusSoonTimer = window.setTimeout(function () {
      refreshStatusSoonTimer = null;
      refreshStatusSafe(reason || "soon", mode);
    }, delay === undefined ? 300 : delay);
  }

  function startStatusPolling() {
    if (!STATUS_AUTO_POLL_ENABLED) {
      try { console.log("[Status Poll] disabled; using event/manual refresh"); } catch (error) {}
      return;
    }
    if (!hostLoaded || statusPollTimer || document.hidden) return;
    statusPollTimer = window.setInterval(function () {
      refreshStatusSafe("poll");
    }, STATUS_POLL_INTERVAL_MS);
    try { console.log("[Status Poll] started interval=" + STATUS_POLL_INTERVAL_MS); } catch (error) {}
  }

  function stopStatusPolling() {
    if (!statusPollTimer) return;
    window.clearInterval(statusPollTimer);
    statusPollTimer = null;
    try { console.log("[Status Poll] stopped"); } catch (error) {}
  }

  function setStrokeThicknessInfo(message) {
    const info = $("#strokeThicknessInfo");
    if (!info) return;
    info.textContent = message || "未读取描边信息";
  }

  function setStrokeThicknessDepthInfo(message) {
    const info = $("#strokeThicknessDepthInfo");
    if (!info) return;
    info.textContent = message || "描边厚度导出厚度：未设置";
  }

  function refreshStrokeThicknessDepthInfo(done, scanParams) {
    if (!$("#strokeThicknessDepthInfo")) {
      if (done) done();
      return;
    }
    callHost("read_stroke_thickness_depth_info", scanParams || statusScanParams("full"), function (message) {
      setStrokeThicknessDepthInfo(String(message || "").replace(/^STROKE_DEPTH_INFO:/, ""));
      if (done) done();
    });
  }

  function setCraftMarkerInfo(message) {
    const info = $("#craftMarkerInfo");
    if (!info) return;
    info.textContent = message || "当前工艺：普通对象";
  }

  function craftStatusLabel(message) {
    const text = String(message || "").replace(/^CRAFT_INFO:/, "");
    const match = text.match(/(?:当前工艺|已标注)[:：]\s*([^\s|]+)/);
    if (match && match[1]) return match[1];
    if (text.indexOf("多个对象工艺不一致") >= 0) return "多个";
    if (text.indexOf("请先选中") >= 0) return "未设置";
    return "普通对象";
  }

  function refreshCraftMarkerInfo(done, scanParams) {
    if (!$("#craftMarkerInfo")) {
      if (done) done();
      return;
    }
    callHost("get_craft_marker", scanParams || statusScanParams("full"), function (message) {
      const cleanMessage = String(message || "").replace(/^CRAFT_INFO:/, "");
      setCraftMarkerInfo(cleanMessage);
      if (done) done(cleanMessage);
    });
  }

  function setCraftMarker(type) {
    callHost("set_craft_marker", {
      craftType: type,
      craftParams: CRAFT_PRESETS[type] || {}
    }, function (message) {
      setCraftMarkerInfo(String(message || "").replace(/^CRAFT_INFO:/, ""));
      refreshStatusSoon("after-craft-marker", 300, "after-action");
    });
  }

  function clearCraftMarker() {
    callHost("clear_craft_marker", {}, function (message) {
      setCraftMarkerInfo(String(message || "").replace(/^CRAFT_INFO:/, ""));
      refreshStatusSoon("after-clear-craft-marker", 300, "after-action");
    });
  }

  function setStrokeThicknessDepth(depthMm) {
    callHost("set_stroke_thickness_depth", { depthMm: depthMm }, function (message) {
      setStrokeThicknessDepthInfo(String(message || "").replace(/^STROKE_DEPTH_INFO:/, ""));
      refreshStatusSoon("after-stroke-depth", 300, "after-action");
    });
  }

  function applyTheme(theme) {
    const next = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("theme-light", next === "light");
    document.body.classList.toggle("theme-dark", next !== "light");
    const glyph = $("#themeToggle .theme-glyph");
    const label = $("#themeLabel");
    if (glyph) glyph.textContent = next === "light" ? "☀" : "☾";
    if (label) label.textContent = next === "light" ? "明亮" : "暗黑";
    try {
      window.localStorage.setItem("hhTheme", next);
    } catch (error) {}
  }

  function bindTheme() {
    let saved = "dark";
    try {
      saved = window.localStorage.getItem("hhTheme") || "dark";
    } catch (error) {}
    applyTheme(saved);
    $("#themeToggle").addEventListener("click", () => {
      applyTheme(document.body.classList.contains("theme-light") ? "dark" : "light");
    });
  }

  function dimParams() {
    return {
      offset: parseFloat($("#dimOffset").value) || 20,
      fontSize: parseFloat($("#fontSize").value) || 40,
      scale: parseFloat($("#scaleValue").value) || 1,
      unit: $("#unitSelect").value,
      isRound: $("#roundDim").checked,
      decimal: 1,
      showW: $("#showW").checked,
      showH: $("#showH").checked,
      lineWeight: 2,
      tickLen: 20,
      sizeNote: $("#sizeNote").value,
      mat: $("#matNote").value,
      proc: $("#procNote").value,
      thick: $("#thickNote").value
    };
  }

  function openDropShadowModal() {
    $("#dropShadowModal").classList.add("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "false");
    if ($("#shadowPreview").checked) {
      requestDropShadowPreview();
    }
  }

  function closeDropShadowModal() {
    $("#dropShadowModal").classList.remove("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "true");
  }

  function cancelDropShadowModal() {
    if (shadowPreviewTimer) {
      window.clearTimeout(shadowPreviewTimer);
      shadowPreviewTimer = null;
    }
    callHost("drop_shadow_native_cancel", {}, function () {
      closeDropShadowModal();
      refreshStatusSoon("after-shadow-cancel");
    });
  }

  function openModal(selector) {
    $(selector).classList.add("open");
    $(selector).setAttribute("aria-hidden", "false");
  }

  function closeModal(selector) {
    $(selector).classList.remove("open");
    $(selector).setAttribute("aria-hidden", "true");
  }

  function readNumber(selector, fallback) {
    const raw = String($(selector).value || "").trim();
    if (!raw) return fallback;
    const value = parseFloat(raw);
    return Number.isNaN(value) ? fallback : value;
  }

  function shadowParams(silent) {
    const params = {
      offsetXmm: readNumber("#shadowX", 2),
      offsetYmm: readNumber("#shadowY", 2),
      blurMm: readNumber("#shadowBlur", 2),
      opacity: readNumber("#shadowOpacity", 40),
      colorHex: String($("#shadowColor").value || "#000000"),
      blendMode: String($("#shadowBlend").value || "multiply")
    };
    const colorOk = /^#[0-9a-fA-F]{6}$/.test(params.colorHex);
    if (params.blurMm < 0 || params.opacity < 0 || params.opacity > 100 || !colorOk) {
      if (!silent) window.alert("请检查投影参数");
      return null;
    }
    return params;
  }

  function artboardRangeValue(selector) {
    const value = String($(selector).value || "全部").trim();
    return value || "全部";
  }

  function isArtboardRangeInput(value) {
    return value === "全部" || value.toLowerCase() === "all" || /^[0-9]+(?:\s*-\s*[0-9]+)?(?:\s*,\s*[0-9]+(?:\s*-\s*[0-9]+)?)*$/.test(value);
  }

  function readImageDpi() {
    const preset = $("#imageDpi").value;
    const raw = preset === "custom" ? $("#imageDpiCustom").value : preset;
    const dpi = parseFloat(raw);
    if (Number.isNaN(dpi) || dpi <= 0) {
      window.alert("分辨率请输入正数");
      return null;
    }
    return dpi;
  }

  function readPdfDpi() {
    const preset = $("#pdfDpi").value;
    const raw = preset === "custom" ? $("#pdfDpiCustom").value : preset;
    const dpi = parseFloat(raw);
    if (Number.isNaN(dpi) || dpi <= 0) {
      window.alert("分辨率请输入正数");
      return null;
    }
    return dpi;
  }

  function readImageScale() {
    const preset = $("#imageScale").value;
    const raw = preset === "custom" ? $("#imageScaleCustom").value : preset;
    const match = String(raw || "").trim().match(/^1\s*:\s*([0-9]+(?:\.[0-9]+)?)$/);
    if (!match) {
      window.alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
      return null;
    }
    const scale = parseFloat(match[1]);
    if (Number.isNaN(scale) || scale <= 0) {
      window.alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
      return null;
    }
    return raw;
  }

  function pdfExportParams() {
    const range = artboardRangeValue("#pdfArtboardRange");
    const dpi = readPdfDpi();
    if (dpi === null) return null;
    if (!isArtboardRangeInput(range)) {
      window.alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
      return null;
    }
    return { range, dpi };
  }

  function imageExportParams() {
    const range = artboardRangeValue("#imageArtboardRange");
    const dpi = readImageDpi();
    const scale = readImageScale();
    if (dpi === null || scale === null) return null;
    if ($("#imageExportMode").value === "artboards" && !isArtboardRangeInput(range)) {
      window.alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
      return null;
    }
    return {
      mode: $("#imageExportMode").value,
      format: $("#imageFormat").value,
      colorMode: $("#imageColorMode").value,
      dpi: dpi,
      scale: scale,
      range: range
    };
  }

  function requestDropShadowPreview() {
    const params = shadowParams(true);
    if (!params) return;
    callHost("drop_shadow_native_preview", params, refreshStatus);
  }

  function scheduleDropShadowPreview() {
    if (!$("#shadowPreview").checked) return;
    if (shadowPreviewTimer) window.clearTimeout(shadowPreviewTimer);
    shadowPreviewTimer = window.setTimeout(function () {
      shadowPreviewTimer = null;
      requestDropShadowPreview();
    }, 300);
  }

  function bindTabs() {
    $$(".tab").forEach((button) => {
      button.addEventListener("click", () => {
        $$(".tab").forEach((item) => item.classList.remove("active"));
        $$(".view").forEach((view) => view.classList.remove("active"));
        button.classList.add("active");
        $("#tab-" + button.dataset.tab).classList.add("active");
        refreshStatusSafe("tab-change");
      });
    });
  }

  function bindSegmented() {
    $$(".segmented").forEach((group) => {
      group.querySelectorAll("button").forEach((button) => {
        button.addEventListener("click", () => {
          group.querySelectorAll("button").forEach((item) => item.classList.remove("active"));
          button.classList.add("active");
          state[group.dataset.name] = button.dataset.value;
        });
      });
    });
  }

  function bindNotePresets() {
    $$(".note-select").forEach((select) => {
      select.addEventListener("change", () => {
        const target = document.getElementById(select.dataset.target);
        if (target) target.value = select.value;
      });
    });
  }

  function bindActions() {
    $("#exportBtn").addEventListener("click", () => {
      runExportWithProgress(false);
    });

    $("#hotUpdateBtn").addEventListener("click", () => {
      const options = exportOptions();
      beginHostTask("hot-update");
      evalScript("HH_hotUpdate(" + JSON.stringify(options.mode) + "," + options.dpi + "," + JSON.stringify(options.format) + ")", function () {
        endHostTask("hot-update");
      });
    });

    const refreshStatusBtn = $("#refreshStatusBtn");
    if (refreshStatusBtn) refreshStatusBtn.addEventListener("click", () => {
      refreshStatusSafe("manual", "manual");
    });

    $("#markFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: true }));
    $("#clearFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: false }));
    const previewFallbackBtn = $("#previewFallbackBtn");
    if (previewFallbackBtn) previewFallbackBtn.addEventListener("click", () => callHost("preview_fallback_export", {}));
    const clearFallbackPreviewBtn = $("#clearFallbackPreviewBtn");
    if (clearFallbackPreviewBtn) clearFallbackPreviewBtn.addEventListener("click", () => callHost("clear_fallback_preview", {}));
    const markFallbackReverseBtn = $("#markFallbackReverseBtn");
    if (markFallbackReverseBtn) markFallbackReverseBtn.addEventListener("click", () => callHost("set_fallback_reverse", { enabled: true }));
    const clearFallbackReverseBtn = $("#clearFallbackReverseBtn");
    if (clearFallbackReverseBtn) clearFallbackReverseBtn.addEventListener("click", () => callHost("set_fallback_reverse", { enabled: false }));
    $("#filterMissingBtn").addEventListener("click", () => callHost("filter_missing", {}));
    const clearThicknessBtn = $("#clearThicknessBtn");
    if (clearThicknessBtn) clearThicknessBtn.addEventListener("click", () => callHost("clear_thickness", {}, function () {
      refreshStatusSoon("after-clear-thickness", 300, "after-action");
    }));
    const readStrokeThicknessBtn = $("#readStrokeThicknessBtn");
    if (readStrokeThicknessBtn) {
      readStrokeThicknessBtn.addEventListener("click", () => {
        callHost("read_stroke_thickness_info", {}, function (message) {
          setStrokeThicknessInfo(String(message || "").replace(/^STROKE_INFO:/, ""));
          refreshStatusSoon("after-read-stroke-info");
        });
      });
    }
    const previewStrokeThicknessBtn = $("#previewStrokeThicknessBtn");
    if (previewStrokeThicknessBtn) previewStrokeThicknessBtn.addEventListener("click", () => callHost("preview_stroke_thickness", {}));
    const clearStrokeThicknessPreviewBtn = $("#clearStrokeThicknessPreviewBtn");
    if (clearStrokeThicknessPreviewBtn) clearStrokeThicknessPreviewBtn.addEventListener("click", () => callHost("clear_stroke_thickness_preview", {}));
    const markStrokeThicknessExportBtn = $("#markStrokeThicknessExportBtn");
    if (markStrokeThicknessExportBtn) markStrokeThicknessExportBtn.addEventListener("click", () => callHost("set_stroke_thickness_export", { enabled: true }, function () {
      refreshStatusSoon("after-set-stroke-export", 300, "after-action");
    }));
    const clearStrokeThicknessExportBtn = $("#clearStrokeThicknessExportBtn");
    if (clearStrokeThicknessExportBtn) clearStrokeThicknessExportBtn.addEventListener("click", () => callHost("set_stroke_thickness_export", { enabled: false }, function () {
      setStrokeThicknessDepthInfo("描边厚度导出厚度：未设置");
      setStrokeThicknessInfo("未设置描边厚度");
      refreshStatusSoon("after-clear-stroke-export", 300, "after-action");
    }));
    const strokeDepthButtons = [
      ["#strokeThicknessDepth3mmBtn", 3],
      ["#strokeThicknessDepth5mmBtn", 5],
      ["#strokeThicknessDepth1cmBtn", 10],
      ["#strokeThicknessDepth2cmBtn", 20],
      ["#strokeThicknessDepth4cmBtn", 40],
      ["#strokeThicknessDepth5cmBtn", 50],
      ["#strokeThicknessDepth8cmBtn", 80],
      ["#strokeThicknessDepth10cmBtn", 100],
      ["#strokeThicknessDepth15cmBtn", 150],
      ["#strokeThicknessDepth20cmBtn", 200]
    ];
    strokeDepthButtons.forEach(([selector, depthMm]) => {
      const button = $(selector);
      if (button) button.addEventListener("click", () => setStrokeThicknessDepth(depthMm));
    });
    const applyStrokeThicknessDepthBtn = $("#applyStrokeThicknessDepthBtn");
    if (applyStrokeThicknessDepthBtn) {
      applyStrokeThicknessDepthBtn.addEventListener("click", () => {
        const valueCm = parseFloat($("#strokeThicknessCustomDepthInput").value);
        if (!Number.isFinite(valueCm) || valueCm <= 0) {
          window.alert("请输入有效的自定义厚度 cm");
          return;
        }
        setStrokeThicknessDepth(Math.round(valueCm * 10 * 100) / 100);
      });
    }

    $$("[data-thick]").forEach((button) => {
      button.addEventListener("click", () => callHost("set_thickness", { val: parseInt(button.dataset.thick, 10) }, function () {
        refreshStatusSoon("after-set-thickness", 300, "after-action");
      }));
    });

    $("#customThicknessBtn").addEventListener("click", () => {
      const value = parseFloat($("#customThickness").value);
      if (Number.isNaN(value)) return;
      callHost("set_thickness", { val: Math.round(value * 10) }, function () {
        refreshStatusSoon("after-set-thickness", 300, "after-action");
      });
    });

    $("#cutBtn").addEventListener("click", () => {
      callHost("cut", {
        sides: {
          top: $("#sideTop").checked,
          bottom: $("#sideBottom").checked,
          left: $("#sideLeft").checked,
          right: $("#sideRight").checked
        },
        radius: parseFloat($("#slotRadius").value) || 5
      });
    });

    const craftBindings = [
      ["#craftNoneBtn", "none"],
      ["#craftBacklitBtn", "sign_backlit"],
      ["#craftFrontlitBtn", "sign_frontlit"],
      ["#craftCrystalBtn", "sign_crystal"],
      ["#craftDualLitBtn", "sign_dual_lit"]
    ];
    craftBindings.forEach(([selector, type]) => {
      const button = $(selector);
      if (button) button.addEventListener("click", () => setCraftMarker(type));
    });
    const craftClearBtn = $("#craftClearBtn");
    if (craftClearBtn) craftClearBtn.addEventListener("click", clearCraftMarker);

    $("#quickUnionCompoundExpandBtn").addEventListener("click", () => callHost("quick_union_compound_expand", {}));
    $("#outlineStrokeBtn").addEventListener("click", () => callHost("outline_stroke", {}));
    $("#contourMaskBtn").addEventListener("click", runContourMask);
    window.HHTextColumns.init(callHost, function () { return state.hostTaskRunning || state.exporting; });
    window.HHTableGenerator.init(callHost, function () { return state.hostTaskRunning || state.exporting; });
    window.HHHalftone.init(callHost, function () { return state.hostTaskRunning || state.exporting; });
    const sameControl = $("#selectSameControl"), sameTrigger = $("#selectSameBtn"), sameMenu = $("#selectSameMenu");
    function closeSameMenu(restoreFocus) {
      sameMenu.hidden = true;
      sameTrigger.setAttribute("aria-expanded", "false");
      if (restoreFocus) sameTrigger.focus();
    }
    sameTrigger.addEventListener("click", function () {
      if (state.hostTaskRunning || state.exporting) return;
      sameMenu.hidden = !sameMenu.hidden;
      sameTrigger.setAttribute("aria-expanded", String(!sameMenu.hidden));
      if (!sameMenu.hidden) {
        const first = sameMenu.querySelector("button:not(:disabled)");
        if (first) first.focus();
      }
    });
    sameMenu.querySelectorAll("[data-same]").forEach(function (button) {
      button.addEventListener("click", function () {
        closeSameMenu(true);
        if (sameTrigger.disabled || state.hostTaskRunning || state.exporting) return;
        callHost("select_same", { criterion: button.dataset.same });
      });
    });
    sameControl.addEventListener("keydown", function (event) {
      if (event.key === "Escape") { closeSameMenu(true); event.preventDefault(); }
      if (sameMenu.hidden) return;
      const buttons = Array.from(sameMenu.querySelectorAll("button:not(:disabled)"));
      if (!buttons.length) return;
      const index = buttons.indexOf(document.activeElement);
      let next = -1;
      if (event.key === "ArrowDown") next = (index + 1) % buttons.length;
      if (event.key === "ArrowUp") next = (index + buttons.length - 1) % buttons.length;
      if (event.key === "Home") next = 0;
      if (event.key === "End") next = buttons.length - 1;
      if (next >= 0) { event.preventDefault(); buttons[next].focus(); }
    });
    document.addEventListener("click", function (event) {
      if (!sameControl.contains(event.target)) closeSameMenu(false);
    });
    sameControl.addEventListener("focusout", function () {
      window.setTimeout(function () {
        if (!sameControl.contains(document.activeElement)) closeSameMenu(false);
      }, 0);
    });
    $("#offsetPathBtn").addEventListener("click", () => callHost("offset_path", {}));
    $("#simplifyPathBtn").addEventListener("click", () => callHost("simplify_path", {}));
    $("#createTextOutlinesBtn").addEventListener("click", () => callHost("create_text_outlines", {}));
    $("#dropShadowBtn").addEventListener("click", function () {
      if (state.hostTaskRunning || state.exporting) return;
      callHost("drop_shadow_dialog", {});
    });
    $("#renameArtboardsBtn").addEventListener("click", () => callHost("rename_artboards", {}));
    $("#createArtboardsBtn").addEventListener("click", () => callHost("create_artboards_from_selection", {}));
    $("#exportPdfBtn").addEventListener("click", () => openModal("#pdfExportModal"));
    $("#exportImagesBtn").addEventListener("click", () => openModal("#imageExportModal"));
    $("#cancelPdfExportBtn").addEventListener("click", () => closeModal("#pdfExportModal"));
    $("#cancelImageExportBtn").addEventListener("click", () => closeModal("#imageExportModal"));
    $("#pdfExportModal").addEventListener("click", (event) => {
      if (event.target === $("#pdfExportModal")) closeModal("#pdfExportModal");
    });
    $("#imageExportModal").addEventListener("click", (event) => {
      if (event.target === $("#imageExportModal")) closeModal("#imageExportModal");
    });
    $("#applyPdfExportBtn").addEventListener("click", () => {
      const params = pdfExportParams();
      if (!params) return;
      callHost("export_pdf_by_artboards", params, function (message) {
        closeModal("#pdfExportModal");
        refreshStatusSoon("after-pdf-export");
      });
    });
    $("#applyImageExportBtn").addEventListener("click", () => {
      const params = imageExportParams();
      if (!params) return;
      callHost("export_images", params, function (message) {
        closeModal("#imageExportModal");
        refreshStatusSoon("after-image-export");
      });
    });
    $("#checkUpdateBtn").addEventListener("click", () => checkForUpdates(true));
    $("#closeUpdateBtn").addEventListener("click", closeUpdateDialog);
    $("#downloadUpdateBtn").addEventListener("click", () => {
      const url = state.updateInfo && state.updateInfo.downloadUrl;
      if (!url) {
        window.alert("暂无可用下载地址，请联系管理员。");
        return;
      }
      openExternalUrl(url);
    });
    $("#fallbackDownloadBtn").addEventListener("click", () => {
      const url = state.updateInfo && state.updateInfo.fallbackUrl;
      if (!url) {
        window.alert("备用下载地址不可用，请联系管理员。");
        return;
      }
      openExternalUrl(url);
    });
    $("#updateModal").addEventListener("click", (event) => {
      if (event.target === $("#updateModal")) closeUpdateDialog();
    });
    $("#cancelShadowBtn").addEventListener("click", cancelDropShadowModal);
    $("#dropShadowModal").addEventListener("click", (event) => {
      if (event.target === $("#dropShadowModal")) cancelDropShadowModal();
    });
    ["#shadowX", "#shadowY", "#shadowBlur", "#shadowOpacity", "#shadowColor", "#shadowBlend"].forEach((selector) => {
      const input = $(selector);
      input.addEventListener("input", scheduleDropShadowPreview);
      input.addEventListener("change", scheduleDropShadowPreview);
    });
    $("#shadowPreview").addEventListener("change", () => {
      if ($("#shadowPreview").checked) {
        requestDropShadowPreview();
      } else {
        callHost("drop_shadow_native_cancel", {}, function () {
          refreshStatusSoon("after-shadow-preview-off");
        });
      }
    });
    $("#applyShadowBtn").addEventListener("click", () => {
      const params = shadowParams();
      if (!params) return;
      if (shadowPreviewTimer) {
        window.clearTimeout(shadowPreviewTimer);
        shadowPreviewTimer = null;
      }
      callHost("drop_shadow_native_apply", params, function () {
        closeDropShadowModal();
        refreshStatusSoon("after-shadow-apply");
      });
    });

    $("#dimBoxBtn").addEventListener("click", () => callHost("dim_box", dimParams()));
    $("#curveLenBtn").addEventListener("click", () => callHost("dim_curve_text_below", dimParams()));
    $("#labelBtn").addEventListener("click", () => callHost("label_material", dimParams()));
  }

  bindTabs();
  bindSegmented();
  bindNotePresets();
  bindTheme();
  bindAuth();
  updateAuthUi();
  bindActions();
  bindCoreFreshnessGuard();
  autoVerifyAuth();
  loadHost();
  document.addEventListener("visibilitychange", function () {
    try {
      if (document.hidden) {
        stopStatusPolling();
      } else {
        refreshStatusSafe("visible", "full");
      }
    } catch (error) {}
  });
  window.addEventListener("unload", function () {
    stopStatusPolling();
    if (refreshStatusSoonTimer) window.clearTimeout(refreshStatusSoonTimer);
    refreshStatusSoonTimer = null;
  });
  window.setTimeout(function () {
    checkForUpdates(false);
  }, 1400);
}());
