(function () {
  "use strict";
  function parseTable(text, limits) {
    limits = limits || {rows:60, cols:6};
    const rows = []; let row = [], cell = "", quoted = false;
    text = String(text).replace(/\r\n?/g, "\n");
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (c === '"' && (quoted || !cell)) {
        if (quoted && text[i + 1] === '"') { cell += '"'; i++; }
        else quoted = !quoted;
      } else if (!quoted && (c === "\t" || c === "\n")) {
        row.push(cell); cell = "";
        if (c === "\n") { rows.push(row); row = []; }
      } else cell += c;
    }
    if (quoted) throw new Error("内容中的引号未闭合。");
    row.push(cell); rows.push(row);
    while (rows.length > 1 && rows[rows.length - 1].every(c => !c)) rows.pop();
    if (rows.some(r => r.some(c => /[\r\n\t]/.test(c)))) throw new Error("暂不支持单元格内换行或 Tab。");
    if (rows.length > limits.rows || rows.some(r => r.length > limits.cols)) throw new Error("每次最多 " + limits.rows + " 行、" + limits.cols + " 列。");
    const count = Math.max(...rows.map(r => r.length));
    return rows.map(r => Array.from({ length: count }, (_, i) => r[i] || ""));
  }
  function init(callHost, busy) {
    const $ = id => document.getElementById(id);
    let mode = "columns", sourceToken = "", pending = false, returnFocus, selectedRows = null, alignments = [], replaceContent = false, wordTables = [];
    function acceptRows(rows) {
      selectedRows = rows; replaceContent = !!sourceToken;
      $("textColumnsPasteInput").value = rows.map(r => r.join("\t")).join("\n");
      $("textColumnsPasteInput").hidden = true;
      renderColumns(); message(sourceToken ? "已读入表格，应用后替换原文字内容" : "已读入表格");
    }
    $("textColumnsWord").onclick = () => {
      if (pending || busy()) return;
      // CEP's native picker may apply only the first extension in an accept list.
      // Validate the selected file in readTable instead of filtering the dialog.
      $("textColumnsWordFile").removeAttribute("accept");
      $("textColumnsWordFile").click();
    };
    $("textColumnsWordFile").onchange = async () => {
      const file = $("textColumnsWordFile").files[0]; $("textColumnsWordFile").value = "";
      if (!file || pending || busy()) return;
      pending = true; $("textColumnsApply").disabled = true; message("正在读取表格…");
      try {
        wordTables = await HHTableImport.readTable(file);
        const select = $("textColumnsWordTable"); select.textContent = "";
        wordTables.forEach((t, i) => { const o = document.createElement("option"); o.value = String(i); o.textContent = t.label; select.appendChild(o); });
        select.hidden = wordTables.length < 2;
        if (wordTables[0].error) throw new Error(wordTables[0].error);
        acceptRows(wordTables[0].rows);
      } catch (e) { message(e.message || "表格读取失败", true); }
      finally { pending = false; $("textColumnsApply").disabled = $("textColumnsPasteInput").readOnly && !sourceToken; }
    };
    $("textColumnsWordTable").onchange = () => {
      if (pending) return;
      const t = wordTables[Number($("textColumnsWordTable").value)];
      if (t.error) { message(t.error, true); return; } acceptRows(t.rows);
    };
    $("textColumnsPaste").onclick = () => {
      if (pending || busy() || ($("textColumnsPasteInput").readOnly && !sourceToken)) return;
      $("textColumnsPasteInput").hidden = false; $("textColumnsPasteInput").readOnly = false;
      $("textColumnsPasteInput").focus(); $("textColumnsPasteInput").select();
      message("请在输入框粘贴表格（Ctrl+V / ⌘V）");
    };
    $("textColumnsPasteInput").addEventListener("paste", e => {
      if (pending || $("textColumnsPasteInput").readOnly || !e.clipboardData) return;
      e.preventDefault();
      try { acceptRows(HHTableImport.clipboard(e.clipboardData.getData("text/html"), e.clipboardData.getData("text/plain"))); }
      catch (error) { message(error.message, true); }
    });
    function message(text, error) { $("textColumnsMessage").textContent = text; $("textColumnsMessage").dataset.error = String(!!error); }
    function renderColumns() {
      const table = $("textColumnsTable"); table.textContent = "";
      let rows;
      try { rows = selectedRows || parseTable($("textColumnsPasteInput").value); }
      catch (e) { $("textColumnsTableWrap").hidden = true; message(e.message, true); return; }
      $("textColumnsTableWrap").hidden = !rows || !rows.some(r => r.some(Boolean));
      if ($("textColumnsTableWrap").hidden) return;
      alignments = rows[0].map((_, i) => alignments[i] || "left");
      const head = table.createTHead().insertRow();
      alignments.forEach((alignment, i) => {
        const th = document.createElement("th"), title = document.createElement("span"), select = document.createElement("select");
        title.textContent = "第 " + (i + 1) + " 列"; th.appendChild(title);
        [["left", "左对齐"], ["center", "居中"], ["right", "右对齐"]].forEach(pair => {
          const option = document.createElement("option"); option.value = pair[0]; option.textContent = pair[1]; select.appendChild(option);
        });
        select.setAttribute("aria-label", "第 " + (i + 1) + " 列对齐");
        select.value = mode === "directory" ? (i ? "right" : "left") : alignment;
        select.disabled = mode === "directory";
        select.onchange = () => {
          alignments[i] = select.value;
          Array.from(table.tBodies[0].rows).forEach(row => { row.cells[i].style.textAlign = select.value; });
        };
        th.appendChild(select); head.appendChild(th);
      });
      const body = table.createTBody();
      rows.forEach(row => {
        const tr = body.insertRow();
        row.forEach((text, i) => { const td = tr.insertCell(); td.textContent = text; td.style.textAlign = mode === "directory" ? (i ? "right" : "left") : alignments[i]; });
      });
    }
    function request(action, params, done) {
      if (pending || busy()) { message("Illustrator 正忙，请稍后再试。", true); return; }
      pending = true; $("textColumnsApply").disabled = true;
      callHost(action, params, result => {
        pending = false;
        try { const data = JSON.parse(result); if (!data.ok) throw new Error(data.error || "操作未完成"); done(data); }
        catch (e) { message(e.message || "Illustrator 返回异常", true); }
        $("textColumnsApply").disabled = $("textColumnsPasteInput").readOnly && !sourceToken;
      });
    }
    function close() {
      if (pending) return;
      $("textColumnsModal").classList.remove("open"); $("textColumnsModal").setAttribute("aria-hidden", "true");
      if (returnFocus) returnFocus.focus();
    }
    $("textColumnsBtn").onclick = () => {
      if (pending || busy()) return;
      returnFocus = document.activeElement; sourceToken = ""; selectedRows = null; alignments = []; replaceContent = false; wordTables = [];
      $("textColumnsWordTable").hidden = true;
      $("textColumnsPasteInput").value = ""; $("textColumnsPasteInput").readOnly = true;
      $("textColumnsPasteInput").hidden = false; $("textColumnsTableWrap").hidden = true;
      $("textColumnsApply").textContent = "生成文字";
      $("textColumnsModal").classList.add("open"); $("textColumnsModal").setAttribute("aria-hidden", "false");
      message("正在读取选区…"); $("textColumnsClose").focus();
      request("text_columns_read", { allowEmpty: true }, data => {
        if (data.empty) { $("textColumnsPasteInput").readOnly = false; message(""); return; }
        const lines = data.contents.replace(/\r\n?/g, "\n").split("\n");
        const count = Math.max(...lines.map(line => line.split("\t").length));
        selectedRows = lines.map(line => { const cells = line.split("\t"); return Array.from({length: count}, (_, i) => cells[i] || ""); });
        sourceToken = data.token;
        $("textColumnsPasteInput").value = data.contents;
        $("textColumnsPasteInput").hidden = true;
        if (data.alignments) alignments = data.alignments.split(",");
        renderColumns();
        $("textColumnsLeading").value = Math.round(data.leading * 25.4 / 72 * 100) / 100;
        $("textColumnsApply").textContent = "应用到选中文字";
        message("已选中文字");
      });
    };
    $("textColumnsClose").onclick = close; $("textColumnsCancel").onclick = close;
    $("textColumnsModal").addEventListener("keydown", e => {
      if (e.key === "Escape") { e.stopPropagation(); close(); }
      if (e.key === "Tab") {
        const items = Array.from($("textColumnsModal").querySelectorAll("button,input,textarea,select")).filter(el => !el.disabled && el.offsetParent !== null);
        const first = items[0], last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    });
    $("textColumnsModes").querySelectorAll("button").forEach(button => { button.onclick = () => {
      if (pending) return;
      mode = button.dataset.mode;
      $("textColumnsModes").querySelectorAll("button").forEach(b => { b.classList.toggle("active", b === button); b.setAttribute("aria-pressed", String(b === button)); });
      renderColumns();
    }; });
    $("textColumnsPasteInput").addEventListener("input", () => {
      try { selectedRows = parseTable($("textColumnsPasteInput").value); replaceContent = !!sourceToken; renderColumns(); }
      catch (e) { message(e.message, true); }
    });
    $("textColumnsApply").onclick = () => {
      try {
        const rows = selectedRows || parseTable($("textColumnsPasteInput").value);
        if (mode === "directory" && rows[0].length !== 2) throw new Error("目录需要两列：标题和页码，以 Tab 分隔。");
        request("text_columns_apply", { rows: rows, replaceContent: replaceContent, mode: mode, sourceToken: sourceToken, alignments: rows[0].map((_, i) => alignments[i] || "left"),
          gapMm: Number($("textColumnsGap").value), leading: Number($("textColumnsLeading").value) * 72 / 25.4
        }, data => { message(data.updated ? "已调整原文字" : "已生成文字"); });
      } catch (e) { message(e.message, true); }
    };
  }
  window.HHTextColumns = { init: init, parseTable: parseTable };
})();
