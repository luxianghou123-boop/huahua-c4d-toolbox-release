(function () {
  "use strict";
  const W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
  function validate(rows, limits) {
    limits = limits || {rows:60, cols:6};
    if (!rows.length || rows.length > limits.rows || rows.some(r => !r.length || r.length > limits.cols)) throw new Error("每次最多 " + limits.rows + " 行、" + limits.cols + " 列。");
    const count = Math.max(...rows.map(r => r.length));
    rows = rows.map(r => Array.from({length: count}, (_, i) => String(r[i] == null ? "" : r[i]).replace(/[\r\n\t]+/g, " ").trim()));
    const size = rows.reduce((n, r) => n + r.join("").length, 0);
    if (!size || size > 12000) throw new Error("表格不能为空，且最多 12000 字符。");
    return rows;
  }
  function parseWord(xml, limits) {
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    if (doc.querySelector("parsererror")) throw new Error("Word 文档格式损坏。");
    const tables = Array.from(doc.getElementsByTagNameNS(W, "tbl"));
    if (!tables.length) throw new Error("Word 文档中没有表格。");
    if (tables.length > 100) throw new Error("表格数量过多，请拆分文档。");
    return tables.filter(t => !t.parentNode.closest || !t.parentNode.closest("tbl")).map((table, index) => {
      try {
        if (table.getElementsByTagNameNS(W, "tbl").length) throw new Error("暂不支持嵌套表格。");
        if (["gridSpan", "vMerge", "hMerge", "gridBefore", "gridAfter"].some(k => table.getElementsByTagNameNS(W, k).length)) throw new Error("暂不支持合并单元格，请先拆分单元格。");
        const children = (el, name) => Array.from(el.children).filter(c => c.namespaceURI === W && c.localName === name);
        const rows = children(table, "tr").map(row => children(row, "tc").map(cell => children(cell, "p").map(p => Array.from(p.getElementsByTagNameNS(W, "t")).map(t => t.textContent).join("")).join(" ")));
        return {label: "表格 " + (index + 1) + "（" + rows.length + " 行）", rows: validate(rows, limits)};
      } catch (e) { return {label: "表格 " + (index + 1), error: e.message}; }
    });
  }
  async function readWord(file, limits) {
    if (!file || !/\.docx$/i.test(file.name)) throw new Error("请选择 .docx 文件；旧版 .doc 请另存为 .docx 或复制表格粘贴。");
    if (file.size > 20 * 1024 * 1024) throw new Error("Word 文件不能超过 20 MB。");
    let Zip = window.JSZip;
    if (!Zip && typeof require === "function") {
      const script = document.querySelector('script[src$="jszip-3.10.1.min.js"]');
      let path = decodeURIComponent(new URL(script.src).pathname);
      if (/^\/[A-Za-z]:\//.test(path)) path = path.slice(1);
      Zip = require(path);
    }
    if (!Zip) throw new Error("Word 读取组件未加载，请重新打开插件。");
    const zip = await Zip.loadAsync(await file.arrayBuffer());
    const entry = zip.file("word/document.xml");
    if (!entry) throw new Error("不是有效的 Word 文档。");
    // Bound decompression before materializing XML, including highly compressed inputs.
    let size = 0, chunks = [];
    const xml = await new Promise((resolve, reject) => {
      const stream = entry.internalStream("string");
      stream.on("data", chunk => {
        size += chunk.length;
        if (size > 4 * 1024 * 1024) { stream.pause(); chunks = []; reject(new Error("表格文档内容过大，请拆分后读取。")); return; }
        chunks.push(chunk);
      }).on("error", reject).on("end", () => resolve(chunks.join(""))).resume();
    });
    return parseWord(xml, limits);
  }
  async function readTable(file, limits) {
    limits = limits || {rows:60, cols:6};
    if (file && /\.docx$/i.test(file.name)) return readWord(file, limits);
    if (!file || !/\.xlsx$/i.test(file.name)) throw new Error("请选择 .docx 或 .xlsx；旧格式请另存或复制粘贴。");
    if (file.size > 10 * 1024 * 1024) throw new Error("Excel 文件不能超过 10 MB，请拆分后读取。");
    let Excel = window.XLSX;
    // In CEP, the UMD bundle can leave window.XLSX empty while exporting to Node.
    const nodeRequire = window.cep_node && typeof window.cep_node.require === "function" ? window.cep_node.require : (typeof require === "function" ? require : null);
    if ((!Excel || typeof Excel.read !== "function") && nodeRequire) {
      const script = document.querySelector('script[src$="xlsx-0.20.3.min.js"]');
      let path = decodeURIComponent(new URL(script.src).pathname);
      if (/^\/[A-Za-z]:\//.test(path)) path = path.slice(1);
      Excel = nodeRequire(path);
    }
    if (!Excel || typeof Excel.read !== "function" || !Excel.utils) throw new Error("Excel 读取组件未正确加载，请关闭并重新打开插件。");
    const book = Excel.read(await file.arrayBuffer(), {type: "array", cellText: true, cellFormula: true, sheetRows: limits.rows + 1});
    if (!book.SheetNames.length) throw new Error("文件中没有工作表。");
    if (book.SheetNames.length > 100) throw new Error("工作表过多，请拆分文件。");
    return book.SheetNames.map(name => {
      try {
        const sheet = book.Sheets[name];
        if (!sheet || !sheet['!ref']) throw new Error("工作表为空。");
        if ((sheet['!merges'] || []).length) throw new Error("暂不支持合并单元格，请先拆分单元格。");
        const range = Excel.utils.decode_range(sheet['!fullref'] || sheet['!ref']);
        if (range.e.r - range.s.r >= limits.rows || range.e.c - range.s.c >= limits.cols) throw new Error("每张表最多 " + limits.rows + " 行、" + limits.cols + " 列，请拆分内容。");
        const rows = [];
        for (let r = range.s.r; r <= range.e.r; r++) {
          const row = [];
          for (let c = range.s.c; c <= range.e.c; c++) {
            const cell = sheet[Excel.utils.encode_cell({r:r,c:c})];
            if (cell && cell.t === 'e') throw new Error("表格含公式错误，请修正后读取。");
            if (cell && cell.f && cell.v == null) throw new Error("公式没有已保存结果，请在 Excel/WPS 中计算并保存后读取。");
            row.push(cell ? Excel.utils.format_cell(cell) : "");
          }
          rows.push(row);
        }
        return {label: name + "（" + rows.length + " 行）", rows: validate(rows, limits)};
      } catch (e) { return {label: name, error: e.message}; }
    });
  }
  function clipboard(html, plain, limits) {
    if (html) {
      const doc = new DOMParser().parseFromString(html, "text/html"), tables = doc.querySelectorAll("table");
      if (tables.length > 1) throw new Error("请一次只复制一张表格，不支持嵌套表格。");
      if (tables.length) {
        const rows = Array.from(tables[0].rows).map(row => Array.from(row.cells).map(cell => {
          if (cell.rowSpan !== 1 || cell.colSpan !== 1) throw new Error("暂不支持合并单元格，请先拆分单元格。");
          cell.querySelectorAll("script,style").forEach(n => n.remove());
          return cell.textContent;
        }));
        return validate(rows, limits);
      }
    }
    return validate(window.HHTextColumns.parseTable(plain, limits), limits);
  }
  window.HHTableImport = {readWord: readWord, readTable: readTable, parseWord: parseWord, clipboard: clipboard};
})();
