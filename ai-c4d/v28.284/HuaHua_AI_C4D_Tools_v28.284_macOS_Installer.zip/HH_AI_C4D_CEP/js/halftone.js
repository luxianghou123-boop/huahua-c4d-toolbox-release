(function () {
  "use strict";
  function gradientPoints(options) {
    const g=options.gradient;
    if(g&&['x1','y1','x2','y2'].every(k=>typeof g[k]==='number'&&isFinite(g[k])&&g[k]>=-2&&g[k]<=3)&&Math.hypot(g.x2-g.x1,g.y2-g.y1)>0.01)return g;
    const presets={horizontal:[0,.5,1,.5],left:[1,.5,0,.5],vertical:[.5,0,.5,1],up:[.5,1,.5,0],diagonal:[0,0,1,1],diagonalReverse:[1,0,0,1],radial:[.5,.5,1,.5],inward:[.5,.5,1,.5],ring:[.5,.5,1,.5],band:[0,.5,1,.5]};
    const p=presets[options.direction]||(['spiral','arcs','ripple','diamond','starburst','petals'].indexOf(options.direction)>=0?[.5,.5,1,.5]:presets.horizontal);return {x1:p[0],y1:p[1],x2:p[2],y2:p[3]};
  }
  function build(pixels, w, h, width, height, options) {
    const step = Number(options.spacing) * 72 / 25.4, scale = Number(options.size), contrast = Number(options.contrast);
    if (!(step > 0 && scale > 0 && scale <= 1 && contrast > 0)) throw new Error("半调参数无效");
    const angle = Number(options.angle) * Math.PI / 180, co = Math.cos(angle), si = Math.sin(angle);
    if (!isFinite(angle) || !isFinite(contrast) || contrast > 3 || !/^#[0-9a-f]{6}$/i.test(options.color1) || !/^#[0-9a-f]{6}$/i.test(options.color2)) throw new Error("颜色或角度参数无效");
    const radius = Math.sqrt(width * width + height * height) / 2;
    const n = Math.ceil(radius / step);
    if ((2*n+1)*(2*n+1) > 30000) throw new Error("网点过密，请增大间距");
    const dots = [];
    const shape = options.effect === 'shape';
    const g=gradientPoints(options),dx=g.x2-g.x1,dy=g.y2-g.y1;
    // Row prefixes reject dots crossing transparent pixels, including small holes.
    let mask=null;
    if(shape){mask=new Uint32Array((w+1)*h);for(let yy=0;yy<h;yy++)for(let xx=0;xx<w;xx++)mask[yy*(w+1)+xx+1]=mask[yy*(w+1)+xx]+(pixels[(yy*w+xx)*4+3]<128?1:0);}
    function fitsShape(x,y,r){
      const cx=x/width*w,cy=y/height*h,rx=r/width*w,ry=r/height*h;
      for(let yy=Math.max(0,Math.floor(cy-ry));yy<=Math.min(h-1,Math.ceil(cy+ry));yy++){
        const dy=Math.max(0,Math.abs(yy+0.5-cy)-0.5),span=rx*Math.sqrt(Math.max(0,1-dy*dy/(ry*ry)));
        const left=Math.max(0,Math.floor(cx-span)),right=Math.min(w,Math.ceil(cx+span));
        if(mask[yy*(w+1)+right]-mask[yy*(w+1)+left])return false;
      }return true;
    }
    for(let j=-n;j<=n;j++) for(let i=-n;i<=n;i++) {
      let x=width/2+(i*co-j*si)*step, y=height/2+(i*si+j*co)*step;
      if(shape&&(options.direction==='spiral'||options.direction==='arcs')){
        if(j<=0||i<0)continue;
        const rr=j*step, count=Math.max(8,Math.floor(2*Math.PI*rr/step));
        // One full ring per row; normalized sector count stays within the grid budget.
        const sectors=Math.min(n+1,count);if(i>=sectors)continue;
        const turn=2*Math.PI*i/sectors+angle+Math.atan2(dy*height,dx*width)+(options.direction==='spiral'?j*.15:0);
        x=g.x1*width+rr*Math.cos(turn);y=g.y1*height+rr*Math.sin(turn);
      }
      if(x<0 || y<0 || x>=width || y>=height) continue;
      const at=(Math.min(h-1,Math.floor(y/height*h))*w+Math.min(w-1,Math.floor(x/width*w)))*4;
      const rgb=[pixels[at],pixels[at+1],pixels[at+2]], alpha=pixels[at+3]/255;
      let ink=Math.max(0,Math.min(1,((1-(rgb[0]*0.2126+rgb[1]*0.7152+rgb[2]*0.0722)/255)-0.5)*contrast+0.5));
      if(shape){
        const radial=['radial','inward','ring'].indexOf(options.direction)>=0;
        let t=radial?Math.hypot(x/width-g.x1,y/height-g.y1)/Math.hypot(dx,dy):((x/width-g.x1)*dx+(y/height-g.y1)*dy)/(dx*dx+dy*dy);
        if(options.direction==='inward')t=1-t;
        if(options.direction==='ring'||options.direction==='band')t=Math.abs(2*t-1);
        const u=((x/width-g.x1)*dx+(y/height-g.y1)*dy)/(dx*dx+dy*dy);
        const v=(-(x/width-g.x1)*dy+(y/height-g.y1)*dx)/(dx*dx+dy*dy);
        const rr=Math.hypot(u,v),theta=Math.atan2(v,u);
        if(options.direction==='wave')t=Math.min(1,Math.abs(v-.22*Math.sin(u*Math.PI*2))/.22);
        if(options.direction==='cloud')t=Math.max(0,Math.min(1,.5+.22*Math.sin(u*9+Math.sin(v*5))+.22*Math.cos(v*11+u*3)+.12*Math.sin(u*19-v*13)));
        if(options.direction==='ripple')t=.5-.5*Math.cos(rr*Math.PI*6);
        if(options.direction==='spiral')t=Math.max(0,Math.min(1,1-(.2+.8*Math.pow(.5+.5*Math.cos(theta*2-rr*7),2))*Math.min(1,rr*4)));
        if(options.direction==='arcs')t=Math.max(0,Math.min(1,Math.abs(rr-.8)/.7+.25*Math.sin(theta)));
        if(options.direction==='diamond')t=Math.abs(u)+Math.abs(v);
        if(options.direction==='starburst')t=1-Math.max(0,1-rr)*Math.pow(.5+.5*Math.cos(theta*8),2);
        if(options.direction==='petals')t=rr/(.55+.3*Math.cos(theta*5));
        if(options.direction==='woven')t=1-Math.pow(Math.abs(Math.sin(u*Math.PI*4+Math.sin(v*5))*Math.sin(v*Math.PI*4+Math.sin(u*5))),.6);
        if(options.direction==='doubleWave')t=Math.min(Math.abs(v-.24*Math.sin(u*Math.PI*2)),Math.abs(v+.24*Math.sin(u*Math.PI*2)))/.12;
        ink=Math.max(0,Math.min(1,((1-t)-0.5)*contrast+0.5));
      }
      if(options.invert) ink=1-ink;
      const r=step*0.5*scale*Math.sqrt(ink*alpha);
      if(r<0.1 || x-r<0 || y-r<0 || x+r>width || y+r>height) continue;
      if(shape&&!fitsShape(x,y,r))continue;
      let color=rgb;
      if(options.mode==='mono') color=hex(options.color1);
      if(options.mode==='duo') { const a=hex(options.color1), b=hex(options.color2); color=a.map((c,k)=>Math.round(c*ink+b[k]*(1-ink))); }
      dots.push({x:x,y:y,r:r,color:color});
      if(dots.length>5000) throw new Error("圆点超过 5000 个，请增大间距");
    }
    return dots;
  }
  function hex(s) { return [1,3,5].map(i=>parseInt(s.substr(i,2),16)); }
  function init(callHost,busy) {
    const $=n=>document.getElementById('halftone'+n);
    let job=null,pixels=null,dots=[],pending=false;
    let gradient=null,drag=null,frame=0;
    const names=['Effect','Direction','Spacing','Size','Angle','Contrast','Mode','Color1','Color2','Invert'];
    function density(){if(!job||$('Density').value==='custom')return;const count={fine:60,medium:36,coarse:20}[$('Density').value];$('Spacing').value=String(Math.max(0.01,Math.round(Math.max(job.width,job.height)/count*25.4/72*1000)/1000));}
    function clearPreview(){['Original','Preview'].forEach(n=>{const c=$(n);c.width=400;c.height=320;});}
    function options(){return {gradient:gradient,effect:$('Effect').value,direction:$('Direction').value,spacing:+$('Spacing').value,size:+$('Size').value,angle:+$('Angle').value,contrast:+$('Contrast').value,mode:$('Mode').value,color1:$('Color1').value,color2:$('Color2').value,invert:$('Invert').checked};}
    function previewGeometry(){const s=Math.min(400/job.width,320/job.height);return {w:job.width*s,h:job.height*s,x:(400-job.width*s)/2,y:(320-job.height*s)/2};}
    function lock(value){pending=value;$('Modal').querySelectorAll('button,input,select').forEach(el=>el.disabled=value);}
    function preview(){
      const shape=$('Effect').value==='shape';$('DirectionField').hidden=!shape;
      $('Preview').style.cursor=shape?'crosshair':'default';
      $('Preview').title=shape?'按下并拖出新的渐变线；端点可微调；双击重置':'';
      $('Mode').querySelector('[value="original"]').disabled=shape;
      if(shape&&$('Mode').value==='original')$('Mode').value='duo';
      $('Color1Field').hidden=$('Mode').value==='original';$('Color2Field').hidden=$('Mode').value!=='duo';
      $('SizeValue').textContent=Math.round(+$('Size').value*100)+'%';
      if(!pixels||pending)return;
      const canvas=$('Preview');
      if(canvas.width!==400)canvas.width=400;if(canvas.height!==320)canvas.height=320;
      canvas.getContext('2d').clearRect(0,0,400,320);
      try{dots=build(pixels.data,pixels.width,pixels.height,job.width,job.height,options());
        const factor=Math.min(400/job.width,320/job.height),ox=(400-job.width*factor)/2,oy=(320-job.height*factor)/2;
        const ctx=canvas.getContext('2d');ctx.clearRect(0,0,canvas.width,canvas.height);
        dots.forEach(d=>{ctx.fillStyle='rgb('+d.color.join(',')+')';ctx.beginPath();ctx.arc(ox+d.x*factor,oy+d.y*factor,d.r*factor,0,Math.PI*2);ctx.fill();});
        if(shape){const g=gradientPoints(options()),v=previewGeometry(),a={x:v.x+g.x1*v.w,y:v.y+g.y1*v.h},b={x:v.x+g.x2*v.w,y:v.y+g.y2*v.h};
          ctx.save();ctx.lineWidth=2;ctx.strokeStyle='#1778dc';ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke();ctx.setLineDash([]);
          [a,b].forEach((p,i)=>{const x=Math.max(8,Math.min(392,p.x)),y=Math.max(8,Math.min(312,p.y));ctx.fillStyle=i?'#1778dc':'#fff';ctx.beginPath();ctx.arc(x,y,7,0,Math.PI*2);ctx.fill();ctx.stroke();});ctx.restore();}
        let message=dots.length+' 个圆点';
        if(!dots.length){let visible=0,dark=0;for(let p=0;p<pixels.data.length;p+=4){if(pixels.data[p+3]>0){visible++;if(Math.min(pixels.data[p],pixels.data[p+1],pixels.data[p+2])<250)dark++;}}
          message=!visible?'源对象预览完全透明，未生成圆点':!shape&&!dark?'源对象接近纯白，当前参数未生成圆点':'当前可见范围或参数下没有有效圆点';}
        $('Message').textContent=message;$('Apply').disabled=!dots.length;
      }catch(e){dots=[];$('Apply').disabled=true;$('Message').textContent=e.message;}
    }
    function stopDrag(){drag=null;if(frame){cancelAnimationFrame(frame);frame=0;}}
    function close(){if(pending)return;stopDrag();lock(true);callHost('halftone_cancel',{},()=>{job=pixels=null;dots=[];lock(false);$('Modal').classList.remove('open');});}
    $('Close').onclick=close;$('Cancel').onclick=close;
    $('Modal').addEventListener('keydown',e=>{if(e.key==='Escape'){e.stopPropagation();close();}});
    window.addEventListener('beforeunload',()=>{if(job)callHost('halftone_cancel',{},function(){});});
    names.forEach(n=>$(n).onchange=()=>{if(n==='Spacing')$('Density').value='custom';if(n==='Direction')gradient=null;preview();});
    const canvas=$('Preview');canvas.style.touchAction='none';canvas.style.userSelect='none';canvas.style.webkitUserSelect='none';
    function pointer(e){const r=canvas.getBoundingClientRect();return {x:(e.clientX-r.left)*400/r.width,y:(e.clientY-r.top)*320/r.height};}
    // CEP mouse tracking does not rely on PointerEvent capture support.
    canvas.onmousedown=e=>{
      if(e.button!==0||pending||!pixels||$('Effect').value!=='shape')return;
      const p=pointer(e),v=previewGeometry(),g=gradientPoints(options());
      const rect=canvas.getBoundingClientRect();
      const distance=(x,y)=>Math.hypot((p.x-Math.max(8,Math.min(392,v.x+x*v.w)))*rect.width/400,(p.y-Math.max(8,Math.min(312,v.y+y*v.h)))*rect.height/320);
      const d1=distance(g.x1,g.y1),d2=distance(g.x2,g.y2);
      gradient={x1:g.x1,y1:g.y1,x2:g.x2,y2:g.y2};
      drag={point:Math.min(d1,d2)<=10?(d1<=d2?1:2):0,start:p};
      canvas.style.cursor='crosshair';e.preventDefault();e.stopPropagation();
    };
    document.addEventListener('mousemove',e=>{
      if(!drag||pending||!job)return;const p=pointer(e),v=previewGeometry(),next=Object.assign({},gradient);
      e.preventDefault();
      if(drag.point){next['x'+drag.point]=Math.max(-2,Math.min(3,(p.x-v.x)/v.w));next['y'+drag.point]=Math.max(-2,Math.min(3,(p.y-v.y)/v.h));}
      else {
        next.x1=Math.max(-2,Math.min(3,(drag.start.x-v.x)/v.w));next.y1=Math.max(-2,Math.min(3,(drag.start.y-v.y)/v.h));
        next.x2=Math.max(-2,Math.min(3,(p.x-v.x)/v.w));next.y2=Math.max(-2,Math.min(3,(p.y-v.y)/v.h));
      }
      if(Math.hypot((next.x2-next.x1)*v.w,(next.y2-next.y1)*v.h)<8)return;
      gradient=next;if(!frame)frame=requestAnimationFrame(()=>{frame=0;preview();});
    },true);
    function finishDrag(){if(!drag)return;stopDrag();preview();}
    document.addEventListener('mouseup',finishDrag,true);
    window.addEventListener('blur',finishDrag);
    canvas.ondblclick=()=>{if(pending||!pixels||$('Effect').value!=='shape')return;stopDrag();gradient=null;preview();};
    ['Size','Color1','Color2'].forEach(n=>$(n).oninput=preview);
    $('Density').onchange=()=>{density();preview();};
    $('Btn').onclick=()=>{
      if(busy()||pending)return;
      stopDrag();gradient=null;job=pixels=null;dots=[];clearPreview();$('Advanced').open=false;
      $('Modal').classList.add('open');$('Message').textContent='正在读取对象…';lock(true);
      callHost('halftone_prepare',{},raw=>{
        try {job=JSON.parse(raw);if(!job.ok)throw Error(job.error);
          $('Apply').textContent=job.saved?'更新半调':'生成半调';
          const saved=job.saved?JSON.parse(job.saved):{effect:'shape',direction:'horizontal',size:0.9,angle:0,contrast:1,mode:'duo',color1:'#ff4050',color2:'#564de8',invert:false};
          if(!saved.effect)saved.effect='image';if(!saved.direction)saved.direction='horizontal';
          gradient=gradientPoints(saved);
          names.forEach(n=>{const key=n[0].toLowerCase()+n.slice(1);if(saved[key]!==undefined){if(n==='Invert')$(n).checked=saved[key];else $(n).value=saved[key];}});
          $('Density').value=job.saved?'custom':'medium';if(!job.saved)density();
          const image=new Image(),timer=setTimeout(()=>fail('读取图片超时'),20000);let settled=false;
          function fail(message){if(settled)return;settled=true;clearTimeout(timer);callHost('halftone_cancel',{},()=>{lock(false);$('Apply').disabled=true;$('Message').textContent=message;});}
          image.onerror=()=>fail('无法读取对象预览');
          image.onload=()=>{if(settled)return;try{const c=document.createElement('canvas');c.width=image.naturalWidth;c.height=image.naturalHeight;const ctx=c.getContext('2d');ctx.drawImage(image,0,0);pixels=ctx.getImageData(0,0,c.width,c.height);const f=Math.min(400/c.width,320/c.height);$('Original').getContext('2d').drawImage(image,(400-c.width*f)/2,(320-c.height*f)/2,c.width*f,c.height*f);settled=true;clearTimeout(timer);image.src='';lock(false);preview();}catch(e){fail(e.message);}};
          image.src='data:image/png;base64,'+require('fs').readFileSync(job.imagePath).toString('base64');
        }catch(e){callHost('halftone_cancel',{},()=>{lock(false);$('Apply').disabled=true;$('Message').textContent=e.message;});}
      });
    };
    $('Apply').onclick=()=>{if(pending||busy()||!dots.length)return;lock(true);$('Message').textContent='正在生成矢量圆点…';callHost('halftone_apply',{dots:dots,options:options()},raw=>{lock(false);try{const result=JSON.parse(raw);if(!result.ok)throw Error(result.error);job=pixels=null;dots=[];$('Modal').classList.remove('open');}catch(e){$('Message').textContent=e.message;$('Apply').disabled=true;}});};
  }
  window.HHHalftone={init:init,build:build};
})();
