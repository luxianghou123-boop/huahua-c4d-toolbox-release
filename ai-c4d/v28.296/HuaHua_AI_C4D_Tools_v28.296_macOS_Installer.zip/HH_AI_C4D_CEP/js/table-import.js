(function () {
  "use strict";
  const W = "http://schemas.openxmlformats.org/wordprocessingml/2006/main";
  function validate(rows, limits) {
    limits = limits || {rows:60, cols:6};
    if (!rows.length || rows.length > limits.rows || rows.some(r => !r.length || r.length > limits.cols)) throw new Error("每次最多 " + limits.rows + " 行、" + limits.cols + " 列。");
    const count = Math.max(...rows.map(r => r.length));
    rows = rows.map(r => Array.from({length: count}, (_, i) => String(r[i] == null ? "" : r[i]).replace(/[\r\n\t]+/g, " ").trim()));
    const size = rows.reduce((n, r) => n + r.join("").length, 0);
    if (!size || size > 12000) throw new Error("表格不能为空，且最多 12000 字符。");
    return rows;
  }
  function validatedTable(rows, merges, limits) {
    rows = validate(rows, limits);
    const occupied = new Set();
    merges = (merges || []).map(m => ({r:m.r, c:m.c, rowSpan:m.rowSpan, colSpan:m.colSpan}));
    merges.forEach(m => {
      if (![m.r,m.c,m.rowSpan,m.colSpan].every(Number.isInteger) || m.r < 0 || m.c < 0 || m.rowSpan < 1 || m.colSpan < 1 ||
          m.r+m.rowSpan > rows.length || m.c+m.colSpan > rows[0].length || m.rowSpan*m.colSpan < 2)
        throw new Error("合并单元格超出表格范围。");
      for (let r=m.r;r<m.r+m.rowSpan;r++) for(let c=m.c;c<m.c+m.colSpan;c++) {
        const key=r+":"+c;
        if (occupied.has(key)) throw new Error("合并单元格互相重叠。");
        occupied.add(key);
        if ((r!==m.r || c!==m.c) && rows[r][c]) throw new Error("合并区域含多个文字，请先整理表格。");
      }
    });
    return {rows,merges};
  }
  function wordAttribute(el, name) {
    return el ? el.getAttributeNS(W,name) || el.getAttribute("w:"+name) || el.getAttribute(name) : null;
  }
  function placedRows(sourceRows, limits) {
    const rows=[], merges=[], occupied={};
    sourceRows.forEach((source,r) => {
      const row=rows[r]=[];
      let c=0, lastHorizontal=null;
      source.forEach(cell => {
        while (occupied[r+":"+c]) c++;
        const span=cell.colSpan || 1;
        if (cell.vMerge === "continue") {
          const above=occupied[(r-1)+":"+c];
          if (!above || above.c !== c || above.c+above.colSpan < c+span) throw new Error("Word 纵向合并结构异常。");
          if (cell.text.trim()) throw new Error("合并区域含多个文字，请先整理表格。");
          for (let j=0;j<span;j++) occupied[r+":"+(c+j)]=above;
          above.rowSpan=Math.max(above.rowSpan,r-above.r+1);
        } else if (cell.hMerge === "continue") {
          if (!lastHorizontal || cell.text.trim()) throw new Error("Word 横向合并结构异常。");
          for(let j=0;j<span;j++) occupied[r+":"+(c+j)]=lastHorizontal;
          lastHorizontal.colSpan+=span;
        } else {
          row[c]=cell.text;
          const region={r,c,rowSpan:1,colSpan:span};
          for(let j=0;j<span;j++) occupied[r+":"+(c+j)]=region;
          if (span>1 || cell.vMerge==="restart" || cell.hMerge==="restart") merges.push(region);
          lastHorizontal=cell.hMerge==="restart" ? region : null;
        }
        c+=span;
      });
      if (c > limits.cols) throw new Error("表格列数超出限制。");
    });
    const width=Math.max(...rows.map((row,r) => Math.max(row.length,...Object.keys(occupied).filter(k=>k.indexOf(r+":")===0).map(k=>Number(k.split(":")[1])+1))));
    const grid=rows.map((row,r)=>Array.from({length:width},(_,c)=>row[c] || ""));
    return validatedTable(grid,merges.filter(m=>m.rowSpan*m.colSpan>1),limits);
  }
  function parseWord(xml, limits) {
    const doc = new DOMParser().parseFromString(xml, "application/xml");
    if (doc.querySelector("parsererror")) throw new Error("Word 文档格式损坏。");
    const tables = Array.from(doc.getElementsByTagNameNS(W, "tbl"));
    if (!tables.length) throw new Error("Word 文档中没有表格。");
    if (tables.length > 100) throw new Error("表格数量过多，请拆分文档。");
    return tables.filter(t => !t.parentNode.closest || !t.parentNode.closest("tbl")).map((table, index) => {
      try {
        if (table.getElementsByTagNameNS(W, "tbl").length) throw new Error("暂不支持嵌套表格。");
        if (["gridBefore", "gridAfter"].some(k => table.getElementsByTagNameNS(W, k).length)) throw new Error("暂不支持跨行偏移的表格。");
        const children = (el, name) => Array.from(el.children).filter(c => c.namespaceURI === W && c.localName === name);
        const source = children(table, "tr").map(row => children(row, "tc").map(cell => {
          const props=children(cell,"tcPr")[0], grid=props && children(props,"gridSpan")[0];
          const vm=props && children(props,"vMerge")[0], hm=props && children(props,"hMerge")[0];
          const mergeState=el=>el ? (wordAttribute(el,"val") || "continue") : null;
          return {text:children(cell,"p").map(p=>Array.from(p.getElementsByTagNameNS(W,"t")).map(t=>t.textContent).join("")).join(" "),
            colSpan:grid ? Number(wordAttribute(grid,"val")) : 1,vMerge:mergeState(vm),hMerge:mergeState(hm)};
        }));
        const parsed=placedRows(source,limits);
        return {label: "表格 " + (index + 1) + "（" + parsed.rows.length + " 行）", ...parsed};
      } catch (e) { return {label: "表格 " + (index + 1), error: e.message}; }
    });
  }
  async function readWord(file, limits) {
    if (!file || !/\.docx$/i.test(file.name)) throw new Error("请选择 .docx 文件；旧版 .doc 请另存为 .docx 或复制表格粘贴。");
    if (file.size > 20 * 1024 * 1024) throw new Error("Word 文件不能超过 20 MB。");
    let Zip = window.JSZip;
    if (!Zip && typeof require === "function") {
      const script = document.querySelector('script[src$="jszip-3.10.1.min.js"]');
      let path = decodeURIComponent(new URL(script.src).pathname);
      if (/^\/[A-Za-z]:\//.test(path)) path = path.slice(1);
      Zip = require(path);
    }
    if (!Zip) throw new Error("Word 读取组件未加载，请重新打开插件。");
    const zip = await Zip.loadAsync(await file.arrayBuffer());
    const entry = zip.file("word/document.xml");
    if (!entry) throw new Error("不是有效的 Word 文档。");
    // Bound decompression before materializing XML, including highly compressed inputs.
    let size = 0, chunks = [];
    const xml = await new Promise((resolve, reject) => {
      const stream = entry.internalStream("string");
      stream.on("data", chunk => {
        size += chunk.length;
        if (size > 4 * 1024 * 1024) { stream.pause(); chunks = []; reject(new Error("表格文档内容过大，请拆分后读取。")); return; }
        chunks.push(chunk);
      }).on("error", reject).on("end", () => resolve(chunks.join(""))).resume();
    });
    return parseWord(xml, limits);
  }
  async function readTable(file, limits) {
    limits = limits || {rows:60, cols:6};
    if (file && /\.docx$/i.test(file.name)) return readWord(file, limits);
    if (!file || !/\.xlsx$/i.test(file.name)) throw new Error("请选择 .docx 或 .xlsx；旧格式请另存或复制粘贴。");
    if (file.size > 10 * 1024 * 1024) throw new Error("Excel 文件不能超过 10 MB，请拆分后读取。");
    let Excel = window.XLSX;
    // In CEP, the UMD bundle can leave window.XLSX empty while exporting to Node.
    const nodeRequire = window.cep_node && typeof window.cep_node.require === "function" ? window.cep_node.require : (typeof require === "function" ? require : null);
    if ((!Excel || typeof Excel.read !== "function") && nodeRequire) {
      const script = document.querySelector('script[src$="xlsx-0.20.3.min.js"]');
      let path = decodeURIComponent(new URL(script.src).pathname);
      if (/^\/[A-Za-z]:\//.test(path)) path = path.slice(1);
      Excel = nodeRequire(path);
    }
    if (!Excel || typeof Excel.read !== "function" || !Excel.utils) throw new Error("Excel 读取组件未正确加载，请关闭并重新打开插件。");
    const book = Excel.read(await file.arrayBuffer(), {type: "array", cellText: true, cellFormula: true, sheetRows: limits.rows + 1});
    if (!book.SheetNames.length) throw new Error("文件中没有工作表。");
    if (book.SheetNames.length > 100) throw new Error("工作表过多，请拆分文件。");
    return book.SheetNames.map(name => {
      try {
        const sheet = book.Sheets[name];
        if (!sheet || !sheet['!ref']) throw new Error("工作表为空。");
        const range = Excel.utils.decode_range(sheet['!fullref'] || sheet['!ref']);
        (sheet['!merges'] || []).forEach(m => {
          range.s.r=Math.min(range.s.r,m.s.r); range.s.c=Math.min(range.s.c,m.s.c);
          range.e.r=Math.max(range.e.r,m.e.r); range.e.c=Math.max(range.e.c,m.e.c);
        });
        if (range.e.r - range.s.r >= limits.rows || range.e.c - range.s.c >= limits.cols) throw new Error("每张表最多 " + limits.rows + " 行、" + limits.cols + " 列，请拆分内容。");
        const rows = [];
        for (let r = range.s.r; r <= range.e.r; r++) {
          const row = [];
          for (let c = range.s.c; c <= range.e.c; c++) {
            const cell = sheet[Excel.utils.encode_cell({r:r,c:c})];
            if (cell && cell.t === 'e') throw new Error("表格含公式错误，请修正后读取。");
            if (cell && cell.f && cell.v == null) throw new Error("公式没有已保存结果，请在 Excel/WPS 中计算并保存后读取。");
            row.push(cell ? Excel.utils.format_cell(cell) : "");
          }
          rows.push(row);
        }
        const merges=(sheet['!merges'] || []).map(m=>({r:m.s.r-range.s.r,c:m.s.c-range.s.c,rowSpan:m.e.r-m.s.r+1,colSpan:m.e.c-m.s.c+1}));
        return {label: name + "（" + rows.length + " 行）", ...validatedTable(rows,merges,limits)};
      } catch (e) { return {label: name, error: e.message}; }
    });
  }
  function clipboard(html, plain, limits) {
    if (html) {
      const doc = new DOMParser().parseFromString(html, "text/html"), tables = doc.querySelectorAll("table");
      if (tables.length > 1) throw new Error("请一次只复制一张表格，不支持嵌套表格。");
      if (tables.length) {
        const source = Array.from(tables[0].rows).map((row,r) => Array.from(row.cells).map(cell => {
          cell.querySelectorAll("script,style").forEach(n => n.remove());
          return {text:cell.textContent,rowSpan:cell.rowSpan || tables[0].rows.length-r,colSpan:cell.colSpan};
        }));
        const rows=[], merges=[], occupied={};
        source.forEach((sourceRow,r)=>{
          rows[r]=[]; let c=0;
          sourceRow.forEach(cell=>{
            while(occupied[r+":"+c]) c++;
            rows[r][c]=cell.text;
            if(cell.rowSpan*cell.colSpan>1) merges.push({r,c,rowSpan:cell.rowSpan,colSpan:cell.colSpan});
            for(let dr=0;dr<cell.rowSpan;dr++) for(let dc=0;dc<cell.colSpan;dc++) occupied[(r+dr)+":"+(c+dc)]=true;
            c+=cell.colSpan;
          });
        });
        const width=Math.max(...Object.keys(occupied).map(k=>Number(k.split(":")[1])+1));
        return validatedTable(rows.map(row=>Array.from({length:width},(_,c)=>row[c]||"")),merges,limits);
      }
    }
    return validatedTable(window.HHTextColumns.parseTable(plain, limits), [], limits);
  }
  window.HHTableImport = {readWord: readWord, readTable: readTable, parseWord: parseWord, clipboard: clipboard};
})();
