#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")"
if pgrep -f '/Adobe Illustrator[^/]*/.*MacOS/Adobe Illustrator' >/dev/null; then
  printf '请先退出 Illustrator，然后重新运行安装程序。\n'
  read -r -p '按回车退出' _
  exit 1
fi
source_dir="$PWD/HH_AI_C4D_CEP"
target="$HOME/Library/Application Support/Adobe/CEP/extensions/HH_AI_C4D_CEP"
backup="$HOME/ai插件/插件备份/CEP-before-v28.296-$(date +%Y%m%d-%H%M%S)"
test "$(cat "$source_dir/HH_VERSION.txt")" = 'v28.296'
mkdir -p "$(dirname "$target")"
if [ -d "$target" ]; then
  mkdir -p "$backup"
  cp -R "$target" "$backup/"
fi
rsync -a --delete "$source_dir/" "$target/"
for version in 9 10 11 12 13 14 15; do
  defaults write "com.adobe.CSXS.$version" PlayerDebugMode 1
done
test "$(cat "$target/HH_VERSION.txt")" = 'v28.296'
printf '花花智能建模-AI端 v28.296 安装完成，请重新打开 Illustrator。\n'
read -r -p '按回车退出' _
