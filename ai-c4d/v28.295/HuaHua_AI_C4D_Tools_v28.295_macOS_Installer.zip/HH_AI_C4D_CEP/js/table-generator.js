(function () {
  "use strict";
  function init(callHost, busy) {
    const limits = {rows:100, cols:100};
    function displayNumber(n) { return Number(Number(n).toFixed(4)); }
    const $ = name => document.getElementById("generateTable" + name);
    const colorFields = ["FirstBg","FirstText","SecondBg","SecondText","ThirdBg","ThirdText","FirstStroke","BodyStroke"];
    const colorLabels = ["第一行底色","第一行文字","第 2/4/6 行底色","第 2/4/6 行文字","第 3/5/7 行底色","第 3/5/7 行文字","第一行描边","正文描边"];
    colorFields.forEach((name,i)=>{
      if(i%2===0){const row=document.createElement("div");row.className="table-generator-settings";$("RowColors").appendChild(row);}
      const label=document.createElement("label"), input=document.createElement("input");
      label.textContent=colorLabels[i];input.type="color";input.id="generateTable"+name;input.value=i%2?"#141414":"#ffffff";
      label.appendChild(input);$("RowColors").lastChild.appendChild(label);
    });
    function setColors(values){colorFields.forEach((name,i)=>{$(name).value=values[i];});}
    let mode = "blank", pending = false, rows = null, merges = [], tables = [], returnFocus, sourceToken = "", rectangle = false, totalHeightMm = 0, validSelection = false;
    let preset = "simple", stylePreset = "simple", loading = false, legacyColors = false, textColorManual = false;
    const presets = {
      simple:{strokePt:0.5,main:"#141414",base:"#ffffff"},
      gray:{strokePt:0.3,main:"#c8c8c8",base:"#f5f5f5"},
      blue:{strokePt:0.3,main:"#2f6fde",base:"#edf2f7"},
      borderless:{strokePt:0,main:"#141414",base:"#f5f5f5"}
    };
    function updatePresetUI() {
      $("Presets").querySelectorAll("button").forEach(b => { b.classList.toggle("active",b.dataset.preset===preset); b.setAttribute("aria-pressed",String(b.dataset.preset===preset)); });
      $("Custom").hidden = preset !== "custom";
    }
    function applyPreset(name) {
      preset=name; stylePreset=name; legacyColors=false; textColorManual=false; const p=presets[name];
      $("TextColor").value="#141414";
      $("Stroke").value=p.strokePt; $("HeaderColor").value=p.main; $("EvenColor").value=p.base;
      $("Banding").checked=false; $("TextBanding").checked=false;
      $("Header").checked=true; updatePresetUI(); setPending(false);
      setColors([name==="blue"?p.main:name==="gray"?"#e6e6e6":"#ffffff",name==="blue"?"#ffffff":"#141414","#ffffff","#141414",p.base,"#141414",p.main,p.main]);
    }
    $("Presets").querySelectorAll("button").forEach(b => b.onclick=()=>{if(!locked())applyPreset(b.dataset.preset);});
    function settingChanged(event) {
      if (loading) return;
      if (event.target === $("TextColor")) textColorManual=true;
      if (event.target === $("HeaderColor")) stylePreset="custom";
      preset="custom"; updatePresetUI();
    }
    $("More").addEventListener("input",settingChanged);
    $("More").addEventListener("change",settingChanged);
    function message(text, error) { $("Message").textContent = text; $("Message").dataset.error = String(!!error); }
    function locked() { return pending || busy(); }
    let fonts = [];
    const fontPickers = [];
    function closeFonts() { fontPickers.forEach(p => { p.popup.hidden = true; p.button.setAttribute("aria-expanded", "false"); }); }
    ["HeaderTypeface", "Typeface"].forEach(name => {
      const select = $(name), field = select.parentNode, button = document.createElement("button"), popup = document.createElement("div"), search = document.createElement("input"), list = document.createElement("div");
      button.type = "button"; button.className = "table-font-trigger"; button.id = select.id + "Button";
      button.setAttribute("aria-label", name === "HeaderTypeface" ? "选择首行字体" : "选择正文字体");
      button.setAttribute("aria-expanded", "false"); button.setAttribute("aria-controls", select.id + "Popup");
      popup.id = select.id + "Popup"; popup.className = "table-font-popup"; popup.hidden = true;
      search.type = "search"; search.placeholder = "搜索字体"; search.setAttribute("aria-label", name === "HeaderTypeface" ? "搜索首行字体" : "搜索正文字体");
      list.className = "table-font-options";
      popup.appendChild(search); popup.appendChild(list); field.appendChild(button); field.appendChild(popup);
      function sync() { button.textContent = select.selectedOptions.length ? select.selectedOptions[0].textContent : "默认字体"; button.title = button.textContent; }
      function filter() {
        list.textContent = ""; const query = search.value.toLowerCase().trim();
        Array.from(select.options).forEach(option => {
          if (query && (option.textContent + " " + option.value).toLowerCase().indexOf(query) < 0) return;
          const item = document.createElement("button"); item.type = "button"; item.textContent = option.textContent; item.title = option.textContent;
          item.setAttribute("aria-pressed", String(option.value === select.value));
          item.onclick = () => { if (locked()) return; select.value = option.value; sync(); closeFonts(); button.focus(); };
          list.appendChild(item);
        });
        if (!list.children.length) list.textContent = "没有匹配的字体";
      }
      button.onclick = () => { if (locked()) return; const open = popup.hidden; closeFonts(); if(open) { popup.hidden = false; button.setAttribute("aria-expanded", "true"); search.value = ""; filter(); search.focus(); } };
      search.oninput = filter;
      search.onkeydown = e => { if (e.key === "ArrowDown") { e.preventDefault(); const first = list.querySelector("button"); if (first) first.focus(); } };
      popup.onkeydown = e => { if (e.key === "Escape") { e.preventDefault(); e.stopPropagation(); closeFonts(); button.focus(); } };
      select.onchange = sync;
      fontPickers.push({popup:popup,button:button,sync:sync}); sync();
    });
    document.addEventListener("click", e => { if (!e.target.closest(".table-font-field")) closeFonts(); });
    function renderFonts() {
      ["HeaderTypeface", "Typeface"].forEach(name => {
        const select = $(name), selected = select.value;
        select.textContent = "";
        const defaultOption = document.createElement("option"); defaultOption.value = ""; defaultOption.textContent = "默认字体"; select.appendChild(defaultOption);
        fonts.forEach(font => {
          const option = document.createElement("option"); option.value = font.name; option.textContent = font.label; select.appendChild(option);
        });
        select.value = selected;
      });
    }
    let picking = "";
    let pickAway = false, pickFinishing = false;
    const pickBar = document.createElement("div");
    pickBar.className = "table-color-pick-bar"; pickBar.hidden = true;
    const finishPick = document.createElement("button"), cancelPick = document.createElement("button");
    finishPick.textContent = "完成取色"; cancelPick.textContent = "取消取色";
    finishPick.title = "按住 Shift 在 AI 画布点击颜色后完成取色";
    pickBar.appendChild(finishPick); pickBar.appendChild(cancelPick); document.body.appendChild(pickBar);
    function endPick(cancel) {
      if (!picking || busy() || pickFinishing) return;
      pickFinishing = true;
      finishPick.disabled = cancelPick.disabled = true;
      callHost(cancel ? "table_color_cancel" : "table_color_finish", {}, result => {
        pickFinishing = false;
        try {
          const retry = JSON.parse(result);
          if (retry.retryable && !cancel) { finishPick.disabled = cancelPick.disabled = false; return; }
        } catch(e) {}
        const target = picking; picking = ""; pickBar.hidden = true;
        $("Modal").classList.add("open"); $("Modal").setAttribute("aria-hidden", "false"); setPending(false);
        try { const data = JSON.parse(result); if (!data.ok) throw new Error(data.error); if (!cancel) { $(target).value = data.color; settingChanged({target:$(target)}); } message(cancel ? "已取消取色" : "已取得颜色，点击应用修改生效"); }
        catch(e) { message(e.message || "取色失败，请重试", true); }
      });
    }
    finishPick.onclick = () => endPick(false); cancelPick.onclick = () => endPick(true);
    window.addEventListener("blur", () => { if (picking) pickAway = true; });
    window.addEventListener("focus", () => { if (picking && pickAway) { pickAway = false; endPick(false); } });
    colorFields.concat(["HeaderColor", "OddColor", "EvenColor", "TextColor", "HeaderTextColor", "OddTextColor", "EvenTextColor"]).forEach(name => {
      const button = document.createElement("button"); button.type = "button"; button.textContent = "吸管";
      button.title = "使用 Illustrator 吸管取色（Shift 点击画布颜色）";
      button.className = "table-color-pick-button";
      $(name).parentNode.appendChild(button);
      button.onclick = event => {
        event.preventDefault(); if (locked() || picking || $(name).disabled) return;
        setPending(true);
        callHost("table_color_start", {}, result => {
          try {
            const data = JSON.parse(result); if (!data.ok) throw new Error(data.error);
            picking = name; pickAway = false; $("Modal").classList.remove("open"); $("Modal").setAttribute("aria-hidden", "true");
            pickBar.hidden = false; finishPick.disabled = cancelPick.disabled = false;
          } catch(e) { setPending(false); message(e.message || "无法启动吸管", true); }
        });
      };
    });
    window.addEventListener("beforeunload", () => { if (picking) callHost("table_color_cancel", {}, function () {}); });
    function setPending(value) {
      if (value) closeFonts();
      pending = value;
      $("Modal").querySelectorAll("button,input,textarea,select").forEach(el => { el.disabled = value; });
      $("Rows").disabled = $("Cols").disabled = value || !!rows;
      $("Width").disabled = $("Height").disabled = value || rectangle;
      $("Header").disabled = value || rectangle;
      ["HeaderColor", "OddColor", "EvenColor"].forEach(name => { $(name).disabled = value || (name === "OddColor"); });
      ["HeaderTextColor", "OddTextColor", "EvenTextColor"].forEach(name => { $(name).disabled = value || !$("TextBanding").checked; });
      $("Modal").querySelectorAll(".table-color-pick-button").forEach(button => { button.disabled = button.parentNode.querySelector('input[type="color"]').disabled; });
      $("Apply").disabled = value || !validSelection;
    }
    function setMode(next) {
      mode = next; $("Content").hidden = false;
      $("Modes").querySelectorAll("button").forEach(b => { const active = b.dataset.mode === mode; b.classList.toggle("active", active); b.setAttribute("aria-pressed", String(active)); });
      setPending(false);
    }
    function loadContext(info) {
      if (!info.ok) throw new Error(info.error || "无法读取表格");
      if (info.fonts) fonts = info.fonts;
      closeFonts(); renderFonts();
      validSelection = true;
      loading=true;
      sourceToken = info.token || ""; rectangle = info.kind === "rectangle"; totalHeightMm = info.totalHeightMm || 0;
      $("Title").textContent = rectangle ? "在选中区域里生成表格" : sourceToken ? "修改这个表格" : "生成表格";
      $("Apply").textContent = sourceToken && !rectangle ? "修改这个表格" : "生成表格";
      if (sourceToken) {
        const data = info.saved ? JSON.parse(info.saved) : {mode:"blank",rowCount:5,columnCount:3,strokePt:0.5,fontPt:12,alignment:"left",header:false};
        merges = data.merges || [];
        if (data.rows || (info.cells && info.cells.length)) {
          data.rows = data.rows || Array.from({length:data.rowCount}, () => Array(data.columnCount).fill(""));
          // Recover native text edits, including deleted cell text.
          data.rows = data.rows.map(r => r.map(() => ""));
          (info.cells || []).forEach(cell => { if (data.rows[cell.row]) data.rows[cell.row][cell.column] = cell.text; });
          accept({rows:data.rows,merges:data.merges || []});
        } else { rows = null; $("Text").value = ""; }
        $("Rows").value = data.rowCount; $("Cols").value = data.columnCount;
        $("Width").value = displayNumber(info.widthMm); $("Height").value = displayNumber(totalHeightMm / data.rowCount);
        $("Stroke").value = data.strokePt; $("Font").value = data.fontPt;
        $("HeaderFont").value = data.headerFontPt || data.fontPt;
        $("HeaderTypeface").value = data.headerFontName || ""; $("Typeface").value = data.fontName || "";
        $("Align").value = data.alignment; $("Header").checked = rectangle ? false : data.header;
        $("AutoFit").checked = data.autoFitText !== false;
        $("Banding").checked = !!data.rowBanding;
        $("HeaderColor").value = data.headerColor || "#d9e5f2";
        $("OddColor").value = data.oddRowColor || "#ffffff";
        $("EvenColor").value = data.evenRowColor || "#edf2f7";
        $("TextBanding").checked = !!data.textBanding;
        $("HeaderTextColor").value = data.headerTextColor || "#141414";
        $("OddTextColor").value = data.oddTextColor || "#141414";
        $("EvenTextColor").value = data.evenTextColor || "#141414";
        $("TextColor").value = data.textColor || data.oddTextColor || "#141414";
        textColorManual = data.textColorManual === true;
        legacyColors=data.legacyColors === true || !data.preset; preset=data.preset || "custom";
        stylePreset=data.stylePreset || preset;
        const baseText=data.textColor || data.oddTextColor || "#141414";
        setColors(data.cellColors || [stylePreset==="blue"||stylePreset==="custom"?data.headerColor:stylePreset==="gray"?"#e6e6e6":"#ffffff",data.textColorManual?baseText:stylePreset==="blue"?"#ffffff":(data.headerTextColor||"#141414"),data.oddRowColor||"#ffffff",baseText,data.evenRowColor||"#ffffff",data.textBanding?data.evenTextColor:baseText,data.headerColor||"#141414",data.headerColor||"#141414"]);
        setMode(rows && rows.some(r => r.some(Boolean)) ? "content" : data.mode);
      } else { rows=null; merges=[]; $("Text").value=""; $("Rows").value=5; $("Cols").value=3; $("Width").value=150; $("Height").value=12; $("Font").value=12; $("HeaderFont").value=12; preset="simple"; setMode("blank"); applyPreset("simple"); }
      loading=false; updatePresetUI();
      fontPickers.forEach(p => p.sync());
      setPending(false);
    }
    function accept(data) {
      rows = data.rows || data;
      merges = data.merges || [];
      if (!loading) setMode("content");
      $("Text").value = rows.map(r => r.map(c => /["\t\r\n]/.test(c) ? '"' + c.replace(/"/g, '""') + '"' : c).join("\t")).join("\n");
      $("Rows").value = rows.length; $("Cols").value = rows[0].length;
      $("Rows").disabled = $("Cols").disabled = true;
      if (rectangle) $("Height").value = displayNumber(totalHeightMm / rows.length);
      message("已读取 " + rows.length + " 行、" + rows[0].length + " 列" + (merges.length ? "，含 " + merges.length + " 处合并单元格" : ""));
    }
    function close() {
      if (pending) return;
      $("Modal").classList.remove("open"); $("Modal").setAttribute("aria-hidden", "true");
      if (returnFocus) returnFocus.focus();
    }
    $("Btn").onclick = () => {
      if (locked()) return;
      returnFocus = document.activeElement;
      $("Modal").classList.add("open"); $("Modal").setAttribute("aria-hidden", "false");
      validSelection = false; message("正在读取选择…"); setPending(true);
      callHost("table_read", {}, result => {
        setPending(false);
        try { const info = JSON.parse(result); if (!info.ok) throw new Error(info.error); loadContext(info); message(""); $("Close").focus(); }
        catch(e) { validSelection = false; sourceToken = ""; $("Apply").disabled = true; message(e.message, true); }
      });
    };
    $("Close").onclick = $("Cancel").onclick = close;
    $("Banding").onchange = () => { if (!pending) setPending(false); };
    $("TextBanding").onchange = () => { if (!pending) setPending(false); };
    $("Modes").querySelectorAll("button").forEach(button => { button.onclick = () => {
      if (locked()) return;
      setMode(button.dataset.mode); message("");
    }; });
    $("Read").onclick = () => { if (!locked()) $("File").click(); };
    $("File").onchange = async () => {
      const file = $("File").files[0]; $("File").value = "";
      if (!file || locked()) return;
      setPending(true); message("正在读取表格…");
      try {
        tables = await HHTableImport.readTable(file, limits);
        $("Sheet").textContent = "";
        tables.forEach((table, i) => { const option = document.createElement("option"); option.value = String(i); option.textContent = table.label; $("Sheet").appendChild(option); });
        $("Sheet").hidden = tables.length < 2;
        if (tables[0].error) throw new Error(tables[0].error);
        accept(tables[0]);
      } catch (e) { rows = null; merges = []; $("Text").value = ""; message(e.message || "读取失败", true); }
      finally { setPending(false); }
    };
    $("Sheet").onchange = () => {
      if (locked()) return;
      const table = tables[Number($("Sheet").value)];
      if (!table || table.error) { rows = null; merges = []; $("Text").value = ""; message(table ? table.error : "请选择表格", true); return; }
      accept(table);
    };
    $("Paste").onclick = () => { if (!locked()) { $("Text").focus(); $("Text").select(); } };
    $("Text").addEventListener("paste", e => {
      if (locked() || !e.clipboardData) return;
      e.preventDefault();
      try { accept(HHTableImport.clipboard(e.clipboardData.getData("text/html"), e.clipboardData.getData("text/plain"), limits)); }
      catch (error) { message(error.message, true); }
    });
    $("Text").oninput = () => {
      try { merges = []; rows = $("Text").value.trim() ? HHTextColumns.parseTable($("Text").value, limits) : null; if(rows){$("Rows").value = rows.length; $("Cols").value = rows[0].length;} if(rectangle) $("Height").value = displayNumber(totalHeightMm / Number($("Rows").value)); setMode(rows?"content":"blank"); message(""); }
      catch (e) { rows = null; merges = []; setPending(false); message(e.message, true); }
    };
    $("Rows").oninput = () => { if (rectangle && Number($("Rows").value) > 0) $("Height").value = displayNumber(totalHeightMm / Number($("Rows").value)); };
    $("Apply").onclick = () => {
      if (!validSelection) return;
      if (locked()) { message("Illustrator 正忙，请稍后再试。", true); return; }
      try {
        if (mode === "content" || (sourceToken && rows && rows.some(r => r.some(Boolean)))) {
          rows = HHTextColumns.parseTable($("Text").value, limits);
          const nr = Number($("Rows").value), nc = Number($("Cols").value);
          if (!Number.isInteger(nr) || !Number.isInteger(nc) || nr < 1 || nc < 1 || nr > 100 || nc > 100) throw new Error("行数、列数必须是 1～100 的整数。");
          if (rows.some((r, i) => r.some((text, j) => text && (i >= nr || j >= nc)))) throw new Error("减少行列会丢失文字，请先移走或清空对应单元格内容。");
          rows = Array.from({length:nr}, (_, i) => Array.from({length:nc}, (_, j) => rows[i] && rows[i][j] || ""));
          if (rows.some(r => r.some(Boolean))) mode = "content";
          else if (!sourceToken) throw new Error("请先读取或粘贴表格内容。");
        }
        if (mode === "content" && rows.length * rows[0].length > 1000) throw new Error("带内容表格最多 1000 个单元格，请拆分表格。");
        const params = {sourceToken: sourceToken, mode: mode, rows: mode === "content" ? rows : null, merges:merges, rowCount: Number($("Rows").value), columnCount: Number($("Cols").value),
          widthMm: Number($("Width").value), rowHeightMm: Number($("Height").value), strokePt: Number($("Stroke").value), fontPt: Number($("Font").value),
          headerFontPt: Number($("HeaderFont").value), fontName: $("Typeface").value, headerFontName: $("HeaderTypeface").value,
          alignment: $("Align").value, header: $("Header").checked,
          autoFitText: $("AutoFit").checked, preset:preset, stylePreset:stylePreset, legacyColors:legacyColors,
          textColor:$("TextColor").value, textColorManual:textColorManual,
          cellColors:colorFields.map(name=>$(name).value),
          rowBanding: $("Banding").checked, headerColor: $("HeaderColor").value,
          oddRowColor: $("OddColor").value, evenRowColor: $("EvenColor").value,
          textBanding: $("TextBanding").checked, headerTextColor: $("HeaderTextColor").value,
          oddTextColor: $("OddTextColor").value, evenTextColor: $("EvenTextColor").value};
        setPending(true); message("正在生成…");
        callHost("generate_table", params, result => {
          setPending(false);
          try { const data = JSON.parse(result); if (!data.ok) throw new Error(data.error || "生成失败"); if(data.context) loadContext(data.context); message("已生成 " + data.rows + " 行、" + data.columns + " 列表格" + (data.autoFitExpanded ? "，已自动扩展宽度 / 行高" : data.autoFitCount ? "，已自适应 " + data.autoFitCount + " 个单元格" : "")); }
          catch (e) { message(e.message, true); }
        });
      } catch (e) { setPending(false); message(e.message, true); }
    };
    $("Modal").addEventListener("keydown", e => {
      if (e.key === "Escape") { e.stopPropagation(); close(); }
      if (e.key === "Tab") {
        const items = Array.from($("Modal").querySelectorAll("button,input,textarea,select")).filter(el => !el.disabled && el.offsetParent !== null);
        if (!items.length) return;
        if (e.shiftKey && document.activeElement === items[0]) { e.preventDefault(); items[items.length - 1].focus(); }
        else if (!e.shiftKey && document.activeElement === items[items.length - 1]) { e.preventDefault(); items[0].focus(); }
      }
    });
  }
  window.HHTableGenerator = {init: init};
})();
