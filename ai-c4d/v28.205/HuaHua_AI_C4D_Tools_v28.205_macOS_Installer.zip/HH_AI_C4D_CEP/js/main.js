(function () {
  const CONFIG = window.HH_PLUGIN_CONFIG || {};
  const CURRENT_VERSION = CONFIG.PLUGIN_VERSION || "28.205";
  const API_BASE_URL = CONFIG.API_BASE_URL || "http://43.155.144.82";
  const PLUGIN_CODE = CONFIG.PLUGIN_CODE || "hh_ai_c4d";
  const CLIENT_CODE = CONFIG.CLIENT_CODE || "ai_to_c4d_panel";
  const AUTH_BYPASS_FOR_LOCAL_TEST = CONFIG.AUTH_BYPASS_FOR_LOCAL_TEST === true;
  const AUTH_REFRESH_INTERVAL_MS = 10 * 60 * 1000;
  const HEARTBEAT_INTERVAL_MS = 10 * 60 * 1000;
  const OFFLINE_GRACE_MS = 24 * 60 * 60 * 1000;
  const AUTH_REJECT_STATUSES = [
    "license_disabled",
    "license_expired",
    "user_disabled",
    "plugin_disabled",
    "device_limit_exceeded",
    "session_replaced",
    "machine_replaced",
    "unauthorized",
    "forbidden",
    "token_invalid",
    "no_license",
    "plugin_not_found"
  ];
  const UPDATE_CHECK_PATH = "/api/plugin/check-update";
  const cs = new CSInterface();
  const state = {
    mode: "both",
    format: "png",
    updateInfo: null,
    exporting: false,
    auth: {
      token: "",
      user: null,
      license: null,
      authorized: false,
      offline: false,
      message: "未登录",
      currentDevices: null,
      maxDevices: null,
      heartbeatTimer: null
    }
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.prototype.slice.call(document.querySelectorAll(selector));
  let shadowPreviewTimer = null;

  function jsxString(value) {
    return JSON.stringify(String(value || ""));
  }

  function evalScript(script, callback) {
    cs.evalScript(script, function (result) {
      if (callback) callback(result);
    });
  }

  function loadHost() {
    const root = cs.getSystemPath(SystemPath.EXTENSION);
    const hostPath = root + "/jsx/host.jsx";
    evalScript("$.evalFile(" + jsxString(hostPath) + ")", function () {
      refreshStatus();
    });
  }

  function callHost(action, params, callback) {
    const script = "HH_execute(" + JSON.stringify(action) + "," + JSON.stringify(params || {}) + ")";
    evalScript(script, callback || refreshStatus);
  }

  function selectedValue(name) {
    const active = $('.segmented[data-name="' + name + '"] button.active');
    return active ? active.dataset.value : "";
  }

  function normalizeVersion(version) {
    return String(version || "").replace(/^v/i, "").split(".").map(function (part) {
      const value = parseInt(part, 10);
      return Number.isNaN(value) ? 0 : value;
    });
  }

  function compareVersions(left, right) {
    const a = normalizeVersion(left);
    const b = normalizeVersion(right);
    const size = Math.max(a.length, b.length);
    for (let i = 0; i < size; i += 1) {
      const av = a[i] || 0;
      const bv = b[i] || 0;
      if (av > bv) return 1;
      if (av < bv) return -1;
    }
    return 0;
  }

  function setUpdateStatus(message, isNotice) {
    const el = $("#updateStatus");
    if (!el) return;
    el.textContent = message || "";
    el.classList.toggle("show", !!message);
    const button = $("#checkUpdateBtn");
    if (button) button.classList.toggle("has-update", !!isNotice);
  }

  function currentPlatformKey() {
    const platform = String(navigator.platform || navigator.userAgent || "").toLowerCase();
    return platform.indexOf("win") >= 0 ? "windows" : "mac";
  }

  function updatePlatformKey() {
    return currentPlatformKey() === "windows" ? "win" : "mac";
  }

  function unwrapUpdatePayload(data) {
    if (data && data.data && typeof data.data === "object") return data.data;
    if (data && data.result && typeof data.result === "object") return data.result;
    return data || {};
  }

  function asArrayNotes(value) {
    if (!value) return [];
    if (Array.isArray(value)) return value;
    return String(value).split(/\r?\n/).filter(Boolean);
  }

  function formatFileSize(size) {
    if (typeof size === "string" && /[a-zA-Z\u4e00-\u9fa5]/.test(size)) return size;
    const value = Number(size || 0);
    if (!value || Number.isNaN(value)) return "";
    if (value >= 1024 * 1024) return (value / 1024 / 1024).toFixed(1) + " MB";
    if (value >= 1024) return Math.round(value / 1024) + " KB";
    return value + " B";
  }

  function downloadSourceLabel(url) {
    const text = String(url || "");
    if (!text) return "";
    let host = "";
    try { host = new URL(text).host; } catch (error) { host = text.replace(/^https?:\/\//i, "").split("/")[0]; }
    if (text.indexOf("43.155.144.82") >= 0 || text.indexOf("/downloads/") >= 0) return "下载来源：服务器镜像下载，推荐";
    return "下载来源：后台下载地址" + (host ? "（" + host + "）" : "");
  }

  function normalizeUpdateInfo(data) {
    const payload = unwrapUpdatePayload(data);
    const latestVersion = payload.latestVersion || payload.version || payload.newVersion || "";
    const hasUpdateValue = payload.hasUpdate;
    const updateAvailableValue = payload.updateAvailable;
    let hasUpdate = false;
    if (typeof hasUpdateValue === "boolean") hasUpdate = hasUpdateValue;
    else if (typeof updateAvailableValue === "boolean") hasUpdate = updateAvailableValue;
    else hasUpdate = compareVersions(latestVersion, CURRENT_VERSION) > 0;

    const downloads = payload.downloads || {};
    const platformDownload = downloads[updatePlatformKey()] || downloads[currentPlatformKey()] || downloads.mac || downloads.macos || downloads.windows || {};
    const downloadUrl = payload.downloadUrl || platformDownload.downloadUrl || platformDownload.url || payload.mirrorDownloadUrl || platformDownload.mirrorDownloadUrl || "";
    const fallbackUrl = payload.fallbackUrl || payload.originalDownloadUrl || platformDownload.fallbackUrl || platformDownload.originalDownloadUrl || "";
    const notes = payload.releaseNotes || payload.notes || payload.changelog || payload.changes || [];
    return {
      success: payload.success,
      hasUpdate: hasUpdate,
      currentVersion: payload.currentVersion || CURRENT_VERSION,
      latestVersion: latestVersion,
      title: payload.title || ("花花 AI 辅助工具 v" + (latestVersion || CURRENT_VERSION)),
      notes: asArrayNotes(notes),
      downloadUrl: downloadUrl,
      fallbackUrl: fallbackUrl,
      fileSize: payload.fileSize || payload.size || platformDownload.fileSize || platformDownload.size || "",
      sha256: payload.sha256 || payload.hash || platformDownload.sha256 || platformDownload.hash || "",
      forceUpdate: !!payload.forceUpdate,
      source: downloadSourceLabel(downloadUrl),
      raw: payload
    };
  }

  function requestBackendUpdateInfo(callback) {
    const info = platformInfo();
    authRequest("POST", UPDATE_CHECK_PATH, {
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      currentVersion: CURRENT_VERSION,
      version: CURRENT_VERSION,
      platform: updatePlatformKey(),
      os: info.os,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      app: "illustrator"
    }, state.auth.token || "", function (error, data) {
      if (error || !data) {
        callback(error || new Error("empty response"));
        return;
      }
      if (data.success === false) {
        callback(new Error(data.message || "check-update failed"), data);
        return;
      }
      callback(null, normalizeUpdateInfo(data));
    });
  }

  function openExternalUrl(url) {
    if (!url) return;
    try {
      if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
        window.cep.util.openURLInDefaultBrowser(url);
        return;
      }
    } catch (error) {}
    window.open(url, "_blank");
  }

  function showUpdateDialog(info) {
    state.updateInfo = info;
    $("#updateLatest").textContent = "v" + (info.latestVersion || "");
    $("#updateTitle").textContent = info.title || "花花 AI 辅助工具新版";
    $("#updateNotes").textContent = (info.notes || []).join("\n");
    const meta = [];
    meta.push("当前版本：v" + (info.currentVersion || CURRENT_VERSION));
    if (info.latestVersion) meta.push("最新版本：v" + info.latestVersion);
    if (info.source) meta.push(info.source);
    if (info.fileSize) meta.push("文件大小：" + formatFileSize(info.fileSize));
    if (info.forceUpdate) meta.push("强制更新");
    $("#updateSource").textContent = meta.join(" · ");
    $("#updateSha").textContent = info.sha256 ? "SHA256: " + info.sha256 : "";
    const fallbackBtn = $("#fallbackDownloadBtn");
    if (fallbackBtn) fallbackBtn.style.display = info.fallbackUrl ? "" : "none";
    $("#updateModal").classList.add("open");
    $("#updateModal").setAttribute("aria-hidden", "false");
  }

  function closeUpdateDialog() {
    $("#updateModal").classList.remove("open");
    $("#updateModal").setAttribute("aria-hidden", "true");
  }

  function checkForUpdates(manual) {
    setUpdateStatus("正在检查更新...", false);
    requestBackendUpdateInfo(function (error, info) {
      if (error || !info) {
        setUpdateStatus(manual ? "检查失败，请稍后重试" : "", false);
        if (manual) window.alert("检查更新失败，请稍后重试");
        return;
      }
      if (info.hasUpdate && compareVersions(info.latestVersion, CURRENT_VERSION) > 0) {
        setUpdateStatus("发现新版本 v" + info.latestVersion, true);
        showUpdateDialog(info);
        return;
      }
      setUpdateStatus(manual ? "当前已是最新版本 v" + CURRENT_VERSION : "", false);
      if (manual) window.alert("当前已是最新版本");
    });
  }


  const AUTH_STORAGE_KEY = "hhAiC4dAuthState";
  const DEVICE_STORAGE_KEY = "hhAiC4dDeviceId";
  const MACHINE_STORAGE_KEY = "hhMachineId";
  const CORE_BUTTON_IDS = [
    "exportBtn", "hotUpdateBtn",
    "markFallbackBtn", "clearFallbackBtn", "previewFallbackBtn", "clearFallbackPreviewBtn", "markFallbackReverseBtn", "clearFallbackReverseBtn",
    "filterMissingBtn", "customThicknessBtn",
    "readStrokeThicknessBtn", "previewStrokeThicknessBtn", "clearStrokeThicknessPreviewBtn", "markStrokeThicknessExportBtn", "clearStrokeThicknessExportBtn",
    "strokeThicknessDepth3mmBtn", "strokeThicknessDepth5mmBtn", "strokeThicknessDepth1cmBtn", "strokeThicknessDepth2cmBtn", "strokeThicknessDepth4cmBtn", "strokeThicknessDepth5cmBtn", "strokeThicknessDepth8cmBtn", "strokeThicknessDepth10cmBtn", "strokeThicknessDepth15cmBtn", "strokeThicknessDepth20cmBtn", "applyStrokeThicknessDepthBtn",
    "quickUnionCompoundExpandBtn", "outlineStrokeBtn", "offsetPathBtn", "simplifyPathBtn", "createTextOutlinesBtn", "dropShadowBtn", "applyShadowBtn",
    "renameArtboardsBtn", "createArtboardsBtn", "exportPdfBtn", "exportImagesBtn", "applyPdfExportBtn", "applyImageExportBtn",
    "cutBtn", "dimBoxBtn", "curveLenBtn", "labelBtn",
    "craftNoneBtn", "craftBacklitBtn", "craftFrontlitBtn", "craftCrystalBtn", "craftDualLitBtn", "craftClearBtn"
  ];

  const CRAFT_PRESETS = {
    none: {},
    acrylic_slot: { depthCm: 0.3, direction: "Z+", deleteSides: ["top"], openSides: ["top"], shellCm: 0.3 },
    sign_backlit: { frontThicknessMm: 30, backThicknessMm: 10, color: "#ff0000" },
    sign_frontlit: { frontThicknessMm: 5, backThicknessMm: 30, color: "#ff0000" },
    sign_crystal: { frontThicknessMm: 3, backThicknessMm: 10, color: "#ffffff" },
    sign_dual_lit: { frontThicknessMm: 5, backThicknessMm: 30, color: "#ff0000" }
  };

  let cachedMachineId = "";

  function storageGet(key) {
    try { return window.localStorage.getItem(key) || ""; } catch (error) { return ""; }
  }

  function storageSet(key, value) {
    try { window.localStorage.setItem(key, value); } catch (error) {}
  }

  function storageRemove(key) {
    try { window.localStorage.removeItem(key); } catch (error) {}
  }

  function generateUuid() {
    if (window.crypto && window.crypto.getRandomValues) {
      const bytes = new Uint8Array(16);
      window.crypto.getRandomValues(bytes);
      bytes[6] = (bytes[6] & 0x0f) | 0x40;
      bytes[8] = (bytes[8] & 0x3f) | 0x80;
      const hex = Array.prototype.map.call(bytes, b => ("00" + b.toString(16)).slice(-2));
      return hex.slice(0,4).join("") + "-" + hex.slice(4,6).join("") + "-" + hex.slice(6,8).join("") + "-" + hex.slice(8,10).join("") + "-" + hex.slice(10).join("");
    }
    return "dev-" + Date.now() + "-" + Math.random().toString(16).slice(2);
  }

  function getDeviceId() {
    let id = storageGet(DEVICE_STORAGE_KEY);
    if (!id) {
      id = generateUuid();
      storageSet(DEVICE_STORAGE_KEY, id);
    }
    return id;
  }

  function validId(value) {
    return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(String(value || ""));
  }

  function machineIdFileInfo() {
    try {
      if (typeof require !== "function") return null;
      const path = require("path");
      const os = require("os");
      const rawPlatform = String(navigator.platform || navigator.userAgent || "").toLowerCase();
      const isWin = rawPlatform.indexOf("win") >= 0;
      const appDataDir = (typeof process !== "undefined" && process.env && process.env.APPDATA) ? process.env.APPDATA : "";
      const baseDir = isWin
        ? path.join(appDataDir || os.homedir(), "HuahuaPlugin")
        : path.join(os.homedir(), ".huahua_plugin");
      return {
        dir: baseDir,
        file: path.join(baseDir, "machine_id.json")
      };
    } catch (error) {
      return null;
    }
  }

  function readMachineIdFile() {
    try {
      if (typeof require !== "function") return "";
      const fs = require("fs");
      const info = machineIdFileInfo();
      if (!info || !fs.existsSync(info.file)) return "";
      const raw = fs.readFileSync(info.file, "utf8");
      const data = JSON.parse(raw || "{}");
      return validId(data.machineId) ? data.machineId : "";
    } catch (error) {
      return "";
    }
  }

  function writeMachineIdFile(machineId) {
    try {
      if (typeof require !== "function") return false;
      const fs = require("fs");
      const info = machineIdFileInfo();
      if (!info) return false;
      if (!fs.existsSync(info.dir)) fs.mkdirSync(info.dir, { recursive: true });
      fs.writeFileSync(info.file, JSON.stringify({
        machineId: machineId,
        createdAt: new Date().toISOString()
      }, null, 2), "utf8");
      return true;
    } catch (error) {
      return false;
    }
  }

  function getOrCreateMachineId() {
    if (validId(cachedMachineId)) return cachedMachineId;
    let machineId = readMachineIdFile();
    if (!machineId) {
      machineId = storageGet(MACHINE_STORAGE_KEY);
      if (!validId(machineId)) machineId = generateUuid();
      writeMachineIdFile(machineId);
    }
    cachedMachineId = machineId;
    storageSet(MACHINE_STORAGE_KEY, machineId);
    return machineId;
  }

  function machineIdShort() {
    return getOrCreateMachineId().slice(0, 8);
  }

  function platformInfo() {
    const raw = String(navigator.platform || navigator.userAgent || "").toLowerCase();
    const isWin = raw.indexOf("win") >= 0;
    const isMac = raw.indexOf("mac") >= 0;
    return {
      platform: isWin ? "windows" : "mac",
      os: isWin ? "Windows" : (isMac ? "macOS" : navigator.platform || "unknown"),
      deviceName: (isWin ? "Windows" : "Mac") + " - " + getDeviceId().slice(0, 8)
    };
  }

  function loadAuthStore() {
    try {
      const raw = storageGet(AUTH_STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (error) { return {}; }
  }

  function saveAuthStore(extra) {
    const info = platformInfo();
    const data = Object.assign({}, loadAuthStore(), extra || {}, {
      API_BASE_URL: API_BASE_URL,
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      deviceName: info.deviceName,
      platform: info.platform,
      os: info.os
    });
    storageSet(AUTH_STORAGE_KEY, JSON.stringify(data));
    return data;
  }

  function clearAuthStore() {
    storageRemove(AUTH_STORAGE_KEY);
  }

  function nodeAuthRequest(method, path, body, token, callback) {
    try {
      if (typeof require !== "function") return false;
      const url = require("url");
      const http = require("http");
      const https = require("https");
      const endpoint = url.parse(API_BASE_URL.replace(/\/$/, "") + path);
      const transport = endpoint.protocol === "https:" ? https : http;
      const payload = body ? JSON.stringify(body) : "";
      const headers = {
        "Content-Type": "application/json",
        "Content-Length": Buffer.byteLength(payload)
      };
      if (token) headers.Authorization = "Bearer " + token;
      const req = transport.request({
        hostname: endpoint.hostname,
        port: endpoint.port || (endpoint.protocol === "https:" ? 443 : 80),
        path: endpoint.path,
        method: method,
        headers: headers
      }, function (res) {
        let text = "";
        res.setEncoding("utf8");
        res.on("data", function (chunk) { text += chunk; });
        res.on("end", function () {
          let data = {};
          try { data = text ? JSON.parse(text) : {}; } catch (error) { data = { message: text || "响应解析失败" }; }
          data.httpStatus = res.statusCode;
          if (res.statusCode >= 200 && res.statusCode < 300) callback(null, data);
          else {
            const error = new Error((data && data.message) || ("HTTP " + res.statusCode));
            error.statusCode = res.statusCode;
            callback(error, data);
          }
        });
      });
      req.on("error", function (error) { callback(error); });
      req.setTimeout(8000, function () {
        req.destroy(new Error("timeout"));
      });
      req.write(payload);
      req.end();
      return true;
    } catch (error) {
      return false;
    }
  }

  function authRequest(method, path, body, token, callback) {
    const xhr = new XMLHttpRequest();
    let completed = false;
    function finish(error, data) {
      if (completed) return;
      completed = true;
      callback(error, data);
    }
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4 || completed) return;
      let data = null;
      try { data = xhr.responseText ? JSON.parse(xhr.responseText) : {}; } catch (error) { data = { message: xhr.responseText || "响应解析失败" }; }
      if (xhr.status === 0 && nodeAuthRequest(method, path, body, token, finish)) return;
      data.httpStatus = xhr.status;
      if (xhr.status >= 200 && xhr.status < 300) finish(null, data);
      else {
        const error = new Error((data && data.message) || ("HTTP " + xhr.status));
        error.statusCode = xhr.status;
        finish(error, data);
      }
    };
    try {
      xhr.open(method, API_BASE_URL.replace(/\/$/, "") + path, true);
      xhr.timeout = 8000;
      xhr.setRequestHeader("Content-Type", "application/json");
      if (token) xhr.setRequestHeader("Authorization", "Bearer " + token);
      xhr.ontimeout = function () {
        if (nodeAuthRequest(method, path, body, token, finish)) return;
        finish(new Error("timeout"), {});
      };
      xhr.send(body ? JSON.stringify(body) : null);
    } catch (error) {
      if (nodeAuthRequest(method, path, body, token, finish)) return;
      finish(error, {});
    }
  }

  function accountName(user) {
    if (!user) return "未登录";
    return user.nickname || user.email || user.phone || user.id || "已登录";
  }

  function authRejectStatus(data) {
    const body = authResultBody(data);
    const raw = String((body && (body.reason || body.status || body.code)) || (data && (data.reason || data.status || data.code)) || "").toLowerCase();
    const message = String((body && body.message) || (data && data.message) || "");
    if (raw) return raw;
    if (/machine_replaced|账号已在其他电脑登录|其他电脑登录/i.test(message)) return "machine_replaced";
    if (/session_replaced|账号已在其他设备登录|其他设备登录/i.test(message)) return "session_replaced";
    if (/token.*invalid|token 无效|登录已失效/i.test(message)) return "token_invalid";
    return "";
  }

  function authRejectMessage(data, fallback) {
    const status = authRejectStatus(data);
    if (status === "no_license") return "当前账号暂无授权，请联系管理员开通。";
    if (status === "license_expired") return "授权已到期，请联系管理员续费。";
    if (status === "license_disabled") return "授权已被禁用，请联系管理员。";
    if (status === "user_disabled") return "账号已被禁用，请联系管理员。";
    if (status === "plugin_disabled") return "插件服务已被禁用，请联系管理员。";
    if (status === "machine_replaced") return "账号已在其他电脑登录，请重新登录。";
    if (status === "session_replaced") return "账号已在其他设备登录，请重新登录。";
    if (status === "unauthorized" || status === "token_invalid" || status === "forbidden") return "登录已失效，请重新登录。";
    if (status === "device_limit_exceeded") return "设备数量限制，请联系管理员。";
    const body = authResultBody(data);
    return (body && body.message) || (data && data.message) || fallback || "授权不可用";
  }

  function authResultBody(data) {
    if (data && data.data && typeof data.data === "object") return data.data;
    return data || {};
  }

  function isExplicitAuthRejection(data, error) {
    const body = authResultBody(data);
    const status = authRejectStatus(data);
    const message = String((body && body.message) || (data && data.message) || "");
    const httpStatus = (body && body.httpStatus) || (data && data.httpStatus) || (error && error.statusCode);
    if (httpStatus === 401 || httpStatus === 403) return true;
    if (AUTH_REJECT_STATUSES.indexOf(status) >= 0) return true;
    if (/machine_replaced|账号已在其他电脑登录|其他电脑登录/i.test(message)) return true;
    if (/session_replaced|账号已在其他设备登录|其他设备登录/i.test(message)) return true;
    if (data && data.success === false) return true;
    if (body && body.allowed === false) return true;
    if (data && data.allowed === false) return true;
    return false;
  }

  function lastVerifiedAgeMs() {
    const saved = loadAuthStore();
    const ts = Date.parse(saved.lastVerifiedAt || "");
    if (!Number.isFinite(ts)) return Infinity;
    return Date.now() - ts;
  }

  function offlineGraceAvailable() {
    const saved = loadAuthStore();
    return !!saved.token && !!saved.license && lastVerifiedAgeMs() <= OFFLINE_GRACE_MS;
  }

  function applyOfflineGrace(message) {
    if (!offlineGraceAvailable()) {
      applyAuthFailure(message || "无法连接授权后台，请联网验证", false);
      return false;
    }
    const saved = loadAuthStore();
    state.auth.token = saved.token || state.auth.token;
    state.auth.user = saved.user || state.auth.user;
    state.auth.license = saved.license || state.auth.license;
    state.auth.authorized = true;
    state.auth.offline = true;
    setAuthMessage("离线授权中：网络异常，使用最近一次授权");
    updateAuthUi();
    startHeartbeat();
    return true;
  }

  function handleAuthFailure(data, error, fallbackMessage) {
    if (isExplicitAuthRejection(data, error)) {
      const status = authRejectStatus(data);
      applyAuthFailure(authRejectMessage(data, fallbackMessage || "授权已失效"), status === "machine_replaced" || status === "session_replaced" || status === "unauthorized" || status === "token_invalid" || status === "forbidden");
      saveAuthStore({ licenseInvalidAt: new Date().toISOString() });
      return false;
    }
    return applyOfflineGrace((error && error.message) || fallbackMessage || "网络异常，无法连接授权后台");
  }

  function formatDate(value) {
    if (!value) return "-";
    try { return new Date(value).toLocaleString(); } catch (error) { return String(value); }
  }

  function setCoreEnabled(enabled, reason) {
    if (AUTH_BYPASS_FOR_LOCAL_TEST) {
      enabled = true;
      reason = "本地测试模式，已跳过授权限制";
    }
    const shouldDisable = !enabled;
    CORE_BUTTON_IDS.forEach(function (id) {
      const el = document.getElementById(id);
      if (!el) return;
      el.disabled = shouldDisable;
      el.classList.toggle("auth-locked", shouldDisable);
      if (shouldDisable) el.setAttribute("title", reason || "请先登录并完成授权校验");
      else el.removeAttribute("title");
    });
    $$('[data-thick]').forEach(function (el) {
      el.disabled = shouldDisable;
      el.classList.toggle("auth-locked", shouldDisable);
      if (shouldDisable) el.setAttribute("title", reason || "请先登录并完成授权校验");
      else el.removeAttribute("title");
    });
  }

  function setAuthMessage(message) {
    state.auth.message = message || "";
    const el = $("#authMessage");
    if (el) el.textContent = state.auth.message || "";
  }

  function updateAuthUi() {
    const cfg = CONFIG || {};
    const user = state.auth.user;
    const license = state.auth.license || {};
    const authorized = !!state.auth.authorized;
    const offline = authorized && !!state.auth.offline;
    const accountBtn = $("#accountBtn");
    if (accountBtn) {
      accountBtn.classList.toggle("authorized", authorized);
      accountBtn.classList.toggle("denied", !!state.auth.token && !authorized);
    }
    if ($("#accountBtnLabel")) $("#accountBtnLabel").textContent = offline ? "离线授权" : (authorized ? "已授权" : (state.auth.token ? "未授权" : "账号"));
    if ($("#authApiBase")) $("#authApiBase").textContent = API_BASE_URL;
    if ($("#authModalVersion")) $("#authModalVersion").textContent = cfg.VERSION_LABEL || ("v" + CURRENT_VERSION);
    if ($("#authCurrentUser")) $("#authCurrentUser").textContent = accountName(user);
    if ($("#authLicenseStatus")) $("#authLicenseStatus").textContent = offline ? "离线授权" : (authorized ? "已授权" : (state.auth.token ? "授权失败" : "未授权"));
    if ($("#authDeviceInfo")) $("#authDeviceInfo").textContent = platformInfo().deviceName;
    if ($("#authMachineId")) $("#authMachineId").textContent = machineIdShort();
    if ($("#authPlan")) $("#authPlan").textContent = license.plan || "-";
    if ($("#authExpiresAt")) $("#authExpiresAt").textContent = formatDate(license.expiresAt);
    if ($("#authDeviceCount")) {
      const cur = state.auth.currentDevices == null ? "-" : state.auth.currentDevices;
      $("#authDeviceCount").textContent = cur;
    }
    if ($("#authLastVerified")) $("#authLastVerified").textContent = formatDate(loadAuthStore().lastVerifiedAt);
    const loginPanel = $("#authLoginPanel");
    const registerPanel = $("#authRegisterPanel");
    const infoPanel = $("#authInfoPanel");
    if (loginPanel && state.auth.token) loginPanel.style.display = "none";
    if (loginPanel && !state.auth.token && (!registerPanel || registerPanel.style.display !== "grid")) loginPanel.style.display = "grid";
    if (registerPanel && state.auth.token) registerPanel.style.display = "none";
    if (infoPanel) infoPanel.style.display = state.auth.token ? "grid" : "none";
    setCoreEnabled(authorized, state.auth.message || "请先登录并完成授权校验");
    if (AUTH_BYPASS_FOR_LOCAL_TEST && $("#authMessage")) {
      $("#authMessage").textContent = "本地测试模式：已跳过授权限制";
    }
  }

  function applyAuthSuccess(token, user, license, registerInfo, message) {
    state.auth.token = token;
    state.auth.user = user || state.auth.user;
    state.auth.license = license || state.auth.license;
    state.auth.authorized = true;
    state.auth.offline = false;
    state.auth.currentDevices = registerInfo && registerInfo.currentDevices != null ? registerInfo.currentDevices : state.auth.currentDevices;
    state.auth.maxDevices = registerInfo && registerInfo.maxDevices != null ? registerInfo.maxDevices : (license && license.maxDevices != null ? license.maxDevices : state.auth.maxDevices);
    saveAuthStore({ token: token, user: state.auth.user, license: state.auth.license, lastVerifiedAt: new Date().toISOString() });
    setAuthMessage(message || "授权有效");
    updateAuthUi();
    startHeartbeat();
  }

  function applyAuthFailure(message, clearToken) {
    if (state.auth.heartbeatTimer) window.clearInterval(state.auth.heartbeatTimer);
    state.auth.heartbeatTimer = null;
    state.auth.authorized = false;
    state.auth.offline = false;
    state.auth.license = clearToken ? null : state.auth.license;
    if (clearToken) {
      state.auth.token = "";
      state.auth.user = null;
      clearAuthStore();
    }
    setAuthMessage(message || "授权不可用");
    updateAuthUi();
  }

  function showAuthLoginPanel(message) {
    const loginPanel = $("#authLoginPanel");
    const registerPanel = $("#authRegisterPanel");
    if (registerPanel) registerPanel.style.display = "none";
    if (loginPanel) loginPanel.style.display = "grid";
    if (message) setAuthMessage(message);
  }

  function showAuthRegisterPanel() {
    const loginPanel = $("#authLoginPanel");
    const registerPanel = $("#authRegisterPanel");
    if (loginPanel) loginPanel.style.display = "none";
    if (registerPanel) registerPanel.style.display = "grid";
    setAuthMessage("请填写邮箱和密码注册账号");
  }

  function verifyLicenseFlow(token, user, done) {
    const info = platformInfo();
    const basePayload = {
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      version: CURRENT_VERSION,
      platform: info.platform,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      deviceName: info.deviceName,
      os: info.os
    };
    setAuthMessage("正在校验授权...");
    authRequest("POST", "/api/plugin/check-license", basePayload, token, function (licenseErr, licenseData) {
      if (licenseErr || !licenseData || licenseData.allowed !== true) {
        const allowedByGrace = handleAuthFailure(licenseData, licenseErr, "授权校验失败");
        if (done) done(allowedByGrace, licenseData);
        return;
      }
      setAuthMessage("正在绑定设备...");
      authRequest("POST", "/api/plugin/register-device", basePayload, token, function (regErr, regData) {
        if (regErr || !regData || regData.allowed === false || regData.success === false) {
          const allowedByGrace = handleAuthFailure(regData, regErr, "设备绑定失败");
          if (done) done(allowedByGrace, regData);
          return;
        }
        state.auth.token = token;
        state.auth.user = user || state.auth.user;
        state.auth.license = licenseData;
        sendHeartbeat(token, function (heartbeatOk, heartbeatData) {
          if (!heartbeatOk && isExplicitAuthRejection(heartbeatData)) {
            return;
          }
          applyAuthSuccess(token, user, licenseData, regData, regData.message || licenseData.message || "授权有效");
          if (done) done(true, { license: licenseData, register: regData });
        });
      });
    });
  }

  function ensureFreshAuth(done) {
    if (AUTH_BYPASS_FOR_LOCAL_TEST) {
      done(true);
      return;
    }
    if (!state.auth.token) {
      applyAuthFailure("未登录，请先登录后台账号", false);
      done(false);
      return;
    }
    if (state.auth.authorized && lastVerifiedAgeMs() <= AUTH_REFRESH_INTERVAL_MS) {
      done(true);
      return;
    }
    setAuthMessage("正在刷新授权...");
    verifyLicenseFlow(state.auth.token, state.auth.user, function (allowed) {
      done(!!allowed);
    });
  }

  function fetchCurrentUserThenVerify(token, fallbackUser) {
    setAuthMessage("正在读取账号信息...");
    authRequest("GET", "/api/auth/me", null, token, function (meErr, meData) {
      if (meErr) {
        if (isExplicitAuthRejection(meData, meErr)) {
          applyAuthFailure("登录已失效，请重新登录", true);
          return;
        }
        const allowedByGrace = applyOfflineGrace("网络异常，使用最近一次授权");
        if (!allowedByGrace) applyAuthFailure("无法读取账号信息，请联网验证", false);
        return;
      }
      const user = meData && (meData.user || meData.data || meData);
      state.auth.user = user || fallbackUser || null;
      saveAuthStore({ token: token, user: state.auth.user, lastLoginAt: new Date().toISOString() });
      verifyLicenseFlow(token, state.auth.user);
    });
  }

  function bindCoreFreshnessGuard() {
    CORE_BUTTON_IDS.forEach(function (id) {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener("click", function (event) {
        if (AUTH_BYPASS_FOR_LOCAL_TEST || el.dataset.authFreshBypass === "1") return;
        if (state.auth.authorized && lastVerifiedAgeMs() <= AUTH_REFRESH_INTERVAL_MS) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        ensureFreshAuth(function (allowed) {
          if (!allowed) {
            window.alert(state.auth.message || "当前未授权，无法使用核心功能。");
            return;
          }
          el.dataset.authFreshBypass = "1";
          el.click();
          window.setTimeout(function () { delete el.dataset.authFreshBypass; }, 0);
        });
      }, true);
    });
  }

  function loginAuth() {
    const account = String($("#authAccountInput").value || "").trim();
    const password = String($("#authPasswordInput").value || "");
    if (!account || !password) {
      setAuthMessage("请输入账号和密码");
      return;
    }
    setAuthMessage("正在登录...");
    authRequest("POST", "/api/auth/login", { account: account, password: password, machineId: getOrCreateMachineId(), clientCode: CLIENT_CODE, pluginCode: PLUGIN_CODE }, "", function (err, data) {
      if (err || !data || data.success !== true || !data.token) {
        applyAuthFailure((data && data.message) || (err && err.message) || "登录失败", true);
        return;
      }
      saveAuthStore({ token: data.token, user: data.user || null, lastLoginAt: new Date().toISOString() });
      state.auth.token = data.token;
      state.auth.user = data.user || null;
      fetchCurrentUserThenVerify(data.token, data.user || null);
    });
  }

  function registerAuth() {
    const email = String($("#authRegisterEmailInput").value || "").trim();
    const nickname = String($("#authRegisterNicknameInput").value || "").trim();
    const password = String($("#authRegisterPasswordInput").value || "");
    const confirm = String($("#authRegisterConfirmInput").value || "");
    if (!email || !password) {
      setAuthMessage("请输入邮箱和密码");
      return;
    }
    if (password !== confirm) {
      setAuthMessage("两次输入的密码不一致");
      return;
    }
    setAuthMessage("正在注册...");
    authRequest("POST", "/api/auth/register", {
      email: email,
      password: password,
      confirmPassword: confirm,
      passwordConfirm: confirm,
      machineId: getOrCreateMachineId(),
      nickname: nickname,
      name: nickname
    }, "", function (err, data) {
      if (err || !data || data.success !== true) {
        setAuthMessage((data && data.message) || (err && err.message) || "注册失败");
        return;
      }
      if ($("#authRegisterPasswordInput")) $("#authRegisterPasswordInput").value = "";
      if ($("#authRegisterConfirmInput")) $("#authRegisterConfirmInput").value = "";
      if ($("#authAccountInput")) $("#authAccountInput").value = email;
      showAuthLoginPanel("注册成功，请登录");
    });
  }

  function autoVerifyAuth() {
    const saved = loadAuthStore();
    if (authStoreNeedsCloudReset(saved)) {
      clearAuthStore();
      state.auth.token = "";
      state.auth.user = null;
      state.auth.license = null;
      state.auth.authorized = false;
      state.auth.offline = false;
      applyAuthFailure("后台地址或插件授权标识已切换，请重新登录", false);
      return;
    }
    const token = saved.token || "";
    state.auth.token = token;
    state.auth.user = saved.user || null;
    state.auth.license = saved.license || null;
    if (!token) {
      applyAuthFailure("未登录，请先登录后台账号", false);
      return;
    }
    setAuthMessage("正在恢复登录状态...");
    authRequest("GET", "/api/auth/me", null, token, function (err, data) {
      if (err) {
        if (isExplicitAuthRejection(data, err)) {
          applyAuthFailure("登录已失效，请重新登录", true);
        } else {
          applyOfflineGrace("网络异常，使用最近一次授权");
        }
        return;
      }
      const user = data && (data.user || data.data || data);
      state.auth.user = user || saved.user || null;
      verifyLicenseFlow(token, state.auth.user);
    });
  }

  function authStoreNeedsCloudReset(saved) {
    if (!saved || !saved.token) return false;
    const savedBase = String(saved.API_BASE_URL || "");
    if (!savedBase) return true;
    if (/localhost|127\.0\.0\.1/i.test(savedBase)) return true;
    if (savedBase !== API_BASE_URL) return true;
    if (saved.pluginCode && saved.pluginCode !== PLUGIN_CODE) return true;
    if (saved.clientCode && saved.clientCode !== CLIENT_CODE) return true;
    return false;
  }

  function sendHeartbeat(token, callback) {
    const info = platformInfo();
    authRequest("POST", "/api/plugin/heartbeat", {
      pluginCode: PLUGIN_CODE,
      clientCode: CLIENT_CODE,
      deviceId: getDeviceId(),
      machineId: getOrCreateMachineId(),
      version: CURRENT_VERSION,
      platform: info.platform
    }, token || state.auth.token, function (err, data) {
      if (err) {
        handleAuthFailure(data, err, "heartbeat 失败");
        if (callback) callback(false, data);
        return;
      }
      if (isExplicitAuthRejection(data, err)) {
        handleAuthFailure(data, null, "授权已失效");
        if (callback) callback(false, data);
        return;
      }
      saveAuthStore({ lastHeartbeatAt: new Date().toISOString() });
      if (callback) callback(true, data);
    });
  }

  function startHeartbeat() {
    if (state.auth.heartbeatTimer) window.clearInterval(state.auth.heartbeatTimer);
    state.auth.heartbeatTimer = window.setInterval(function () {
      if (state.auth.authorized && state.auth.token) sendHeartbeat(state.auth.token);
    }, HEARTBEAT_INTERVAL_MS);
  }

  function logoutAuth() {
    if (state.auth.heartbeatTimer) window.clearInterval(state.auth.heartbeatTimer);
    state.auth.heartbeatTimer = null;
    state.auth.token = "";
    state.auth.user = null;
    state.auth.license = null;
    state.auth.authorized = false;
    state.auth.offline = false;
    state.auth.currentDevices = null;
    state.auth.maxDevices = null;
    clearAuthStore();
    setAuthMessage("已退出登录");
    updateAuthUi();
  }

  function openAuthModal() {
    updateAuthUi();
    $("#authModal").classList.add("open");
    $("#authModal").setAttribute("aria-hidden", "false");
  }

  function closeAuthModal() {
    $("#authModal").classList.remove("open");
    $("#authModal").setAttribute("aria-hidden", "true");
  }

  function bindAuth() {
    if ($("#accountBtn")) $("#accountBtn").addEventListener("click", openAuthModal);
    if ($("#authCloseBtn")) $("#authCloseBtn").addEventListener("click", closeAuthModal);
    if ($("#authModal")) $("#authModal").addEventListener("click", function (event) { if (event.target === $("#authModal")) closeAuthModal(); });
    if ($("#authLoginBtn")) $("#authLoginBtn").addEventListener("click", loginAuth);
    if ($("#authPasswordInput")) $("#authPasswordInput").addEventListener("keydown", function (event) { if (event.key === "Enter") loginAuth(); });
    if ($("#authShowRegisterBtn")) $("#authShowRegisterBtn").addEventListener("click", showAuthRegisterPanel);
    if ($("#authBackLoginBtn")) $("#authBackLoginBtn").addEventListener("click", function () { showAuthLoginPanel("请输入后台账号密码"); });
    if ($("#authRegisterBtn")) $("#authRegisterBtn").addEventListener("click", registerAuth);
    if ($("#authRegisterConfirmInput")) $("#authRegisterConfirmInput").addEventListener("keydown", function (event) { if (event.key === "Enter") registerAuth(); });
    if ($("#authRecheckBtn")) $("#authRecheckBtn").addEventListener("click", function () {
      if (!state.auth.token) { setAuthMessage("请先登录"); updateAuthUi(); return; }
      verifyLicenseFlow(state.auth.token, state.auth.user);
    });
    if ($("#authLogoutBtn")) $("#authLogoutBtn").addEventListener("click", logoutAuth);
  }

  function exportOptions() {
    return {
      mode: selectedValue("mode") || state.mode,
      dpi: parseInt($("#dpiSelect").value, 10) || 300,
      format: selectedValue("format") || state.format
    };
  }

  function setExportButtonsEnabled(enabled) {
    const exportBtn = $("#exportBtn");
    const hotUpdateBtn = $("#hotUpdateBtn");
    const coreAllowed = AUTH_BYPASS_FOR_LOCAL_TEST || !!state.auth.authorized;
    if (exportBtn) exportBtn.disabled = !enabled || !coreAllowed;
    if (hotUpdateBtn) hotUpdateBtn.disabled = !enabled || !coreAllowed;
  }

  function chooseExportJsonFile(callback) {
    evalScript("HH_selectExportJsonFile()", function (filePath) {
      const value = String(filePath || "");
      if (!value || value === "CANCEL" || value === "null") {
        callback("");
        return;
      }
      if (value.indexOf("ERROR:") === 0) {
        $("#statusText").textContent = value.replace(/^ERROR:/, "");
        callback("");
        return;
      }
      callback(value);
    });
  }

  function runExportWithProgress(forceChooseDir) {
    if (state.exporting) return;
    const options = exportOptions();
    const beginExport = function (jsonPath) {
      if (!jsonPath) {
        return;
      }
      state.exporting = true;
      setExportButtonsEnabled(false);
      window.setTimeout(function () {
        const script = "HH_exportToFilePath(" +
          JSON.stringify(options.mode) + "," +
          options.dpi + "," +
          JSON.stringify(options.format) + "," +
          JSON.stringify(jsonPath) + ")";
        evalScript(script, function (message) {
          state.exporting = false;
          setExportButtonsEnabled(true);
          refreshStatus();
        });
      }, 80);
    };

    chooseExportJsonFile(function (jsonPath) {
      if (!jsonPath) {
        $("#statusText").textContent = "已取消导出";
        return;
      }
      beginExport(jsonPath);
    });
  }

  function refreshStatus() {
    callHost("check_status", {}, function (message) {
      if (!message || message === "CEP_NOT_AVAILABLE") {
        $("#statusText").textContent = "等待 Illustrator CEP 环境";
        return;
      }
      const cleanMessage = String(message).replace(/^STATUS:/, "");
      $("#statusText").textContent = cleanMessage;
      if (cleanMessage.indexOf("选中") >= 0) {
        refreshStrokeThicknessDepthInfo();
        refreshCraftMarkerInfo();
      } else {
        setStrokeThicknessDepthInfo("描边厚度导出厚度：未设置");
        setCraftMarkerInfo("当前工艺：普通对象");
      }
    });
  }

  function setStrokeThicknessInfo(message) {
    const info = $("#strokeThicknessInfo");
    if (!info) return;
    info.textContent = message || "未读取描边信息";
  }

  function setStrokeThicknessDepthInfo(message) {
    const info = $("#strokeThicknessDepthInfo");
    if (!info) return;
    info.textContent = message || "描边厚度导出厚度：未设置";
  }

  function refreshStrokeThicknessDepthInfo() {
    if (!$("#strokeThicknessDepthInfo")) return;
    callHost("read_stroke_thickness_depth_info", {}, function (message) {
      setStrokeThicknessDepthInfo(String(message || "").replace(/^STROKE_DEPTH_INFO:/, ""));
    });
  }

  function setCraftMarkerInfo(message) {
    const info = $("#craftMarkerInfo");
    if (!info) return;
    info.textContent = message || "当前工艺：普通对象";
  }

  function refreshCraftMarkerInfo() {
    if (!$("#craftMarkerInfo")) return;
    callHost("get_craft_marker", {}, function (message) {
      setCraftMarkerInfo(String(message || "").replace(/^CRAFT_INFO:/, ""));
    });
  }

  function setCraftMarker(type) {
    callHost("set_craft_marker", {
      craftType: type,
      craftParams: CRAFT_PRESETS[type] || {}
    }, function (message) {
      setCraftMarkerInfo(String(message || "").replace(/^CRAFT_INFO:/, ""));
      refreshStatus();
    });
  }

  function clearCraftMarker() {
    callHost("clear_craft_marker", {}, function (message) {
      setCraftMarkerInfo(String(message || "").replace(/^CRAFT_INFO:/, ""));
      refreshStatus();
    });
  }

  function setStrokeThicknessDepth(depthMm) {
    callHost("set_stroke_thickness_depth", { depthMm: depthMm }, function (message) {
      setStrokeThicknessDepthInfo(String(message || "").replace(/^STROKE_DEPTH_INFO:/, ""));
      refreshStatus();
    });
  }

  function applyTheme(theme) {
    const next = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("theme-light", next === "light");
    document.body.classList.toggle("theme-dark", next !== "light");
    const glyph = $("#themeToggle .theme-glyph");
    const label = $("#themeLabel");
    if (glyph) glyph.textContent = next === "light" ? "☀" : "☾";
    if (label) label.textContent = next === "light" ? "明亮" : "暗黑";
    try {
      window.localStorage.setItem("hhTheme", next);
    } catch (error) {}
  }

  function bindTheme() {
    let saved = "dark";
    try {
      saved = window.localStorage.getItem("hhTheme") || "dark";
    } catch (error) {}
    applyTheme(saved);
    $("#themeToggle").addEventListener("click", () => {
      applyTheme(document.body.classList.contains("theme-light") ? "dark" : "light");
    });
  }

  function dimParams() {
    return {
      offset: parseFloat($("#dimOffset").value) || 20,
      fontSize: parseFloat($("#fontSize").value) || 40,
      scale: parseFloat($("#scaleValue").value) || 1,
      unit: $("#unitSelect").value,
      isRound: $("#roundDim").checked,
      decimal: 1,
      showW: $("#showW").checked,
      showH: $("#showH").checked,
      lineWeight: 2,
      tickLen: 20,
      sizeNote: $("#sizeNote").value,
      mat: $("#matNote").value,
      proc: $("#procNote").value,
      thick: $("#thickNote").value
    };
  }

  function openDropShadowModal() {
    $("#dropShadowModal").classList.add("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "false");
    if ($("#shadowPreview").checked) {
      requestDropShadowPreview();
    }
  }

  function closeDropShadowModal() {
    $("#dropShadowModal").classList.remove("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "true");
  }

  function cancelDropShadowModal() {
    if (shadowPreviewTimer) {
      window.clearTimeout(shadowPreviewTimer);
      shadowPreviewTimer = null;
    }
    callHost("drop_shadow_native_cancel", {}, function () {
      closeDropShadowModal();
      refreshStatus();
    });
  }

  function openModal(selector) {
    $(selector).classList.add("open");
    $(selector).setAttribute("aria-hidden", "false");
  }

  function closeModal(selector) {
    $(selector).classList.remove("open");
    $(selector).setAttribute("aria-hidden", "true");
  }

  function readNumber(selector, fallback) {
    const raw = String($(selector).value || "").trim();
    if (!raw) return fallback;
    const value = parseFloat(raw);
    return Number.isNaN(value) ? fallback : value;
  }

  function shadowParams(silent) {
    const params = {
      offsetXmm: readNumber("#shadowX", 2),
      offsetYmm: readNumber("#shadowY", 2),
      blurMm: readNumber("#shadowBlur", 2),
      opacity: readNumber("#shadowOpacity", 40),
      colorHex: String($("#shadowColor").value || "#000000"),
      blendMode: String($("#shadowBlend").value || "multiply")
    };
    const colorOk = /^#[0-9a-fA-F]{6}$/.test(params.colorHex);
    if (params.blurMm < 0 || params.opacity < 0 || params.opacity > 100 || !colorOk) {
      if (!silent) window.alert("请检查投影参数");
      return null;
    }
    return params;
  }

  function artboardRangeValue(selector) {
    const value = String($(selector).value || "全部").trim();
    return value || "全部";
  }

  function isArtboardRangeInput(value) {
    return value === "全部" || value.toLowerCase() === "all" || /^[0-9]+(?:\s*-\s*[0-9]+)?(?:\s*,\s*[0-9]+(?:\s*-\s*[0-9]+)?)*$/.test(value);
  }

  function readImageDpi() {
    const preset = $("#imageDpi").value;
    const raw = preset === "custom" ? $("#imageDpiCustom").value : preset;
    const dpi = parseFloat(raw);
    if (Number.isNaN(dpi) || dpi <= 0) {
      window.alert("分辨率请输入正数");
      return null;
    }
    return dpi;
  }

  function readPdfDpi() {
    const preset = $("#pdfDpi").value;
    const raw = preset === "custom" ? $("#pdfDpiCustom").value : preset;
    const dpi = parseFloat(raw);
    if (Number.isNaN(dpi) || dpi <= 0) {
      window.alert("分辨率请输入正数");
      return null;
    }
    return dpi;
  }

  function readImageScale() {
    const preset = $("#imageScale").value;
    const raw = preset === "custom" ? $("#imageScaleCustom").value : preset;
    const match = String(raw || "").trim().match(/^1\s*:\s*([0-9]+(?:\.[0-9]+)?)$/);
    if (!match) {
      window.alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
      return null;
    }
    const scale = parseFloat(match[1]);
    if (Number.isNaN(scale) || scale <= 0) {
      window.alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
      return null;
    }
    return raw;
  }

  function pdfExportParams() {
    const range = artboardRangeValue("#pdfArtboardRange");
    const dpi = readPdfDpi();
    if (dpi === null) return null;
    if (!isArtboardRangeInput(range)) {
      window.alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
      return null;
    }
    return { range, dpi };
  }

  function imageExportParams() {
    const range = artboardRangeValue("#imageArtboardRange");
    const dpi = readImageDpi();
    const scale = readImageScale();
    if (dpi === null || scale === null) return null;
    if ($("#imageExportMode").value === "artboards" && !isArtboardRangeInput(range)) {
      window.alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
      return null;
    }
    return {
      mode: $("#imageExportMode").value,
      format: $("#imageFormat").value,
      colorMode: $("#imageColorMode").value,
      dpi: dpi,
      scale: scale,
      range: range
    };
  }

  function requestDropShadowPreview() {
    const params = shadowParams(true);
    if (!params) return;
    callHost("drop_shadow_native_preview", params, refreshStatus);
  }

  function scheduleDropShadowPreview() {
    if (!$("#shadowPreview").checked) return;
    if (shadowPreviewTimer) window.clearTimeout(shadowPreviewTimer);
    shadowPreviewTimer = window.setTimeout(function () {
      shadowPreviewTimer = null;
      requestDropShadowPreview();
    }, 300);
  }

  function bindTabs() {
    $$(".tab").forEach((button) => {
      button.addEventListener("click", () => {
        $$(".tab").forEach((item) => item.classList.remove("active"));
        $$(".view").forEach((view) => view.classList.remove("active"));
        button.classList.add("active");
        $("#tab-" + button.dataset.tab).classList.add("active");
        refreshStatus();
      });
    });
  }

  function bindSegmented() {
    $$(".segmented").forEach((group) => {
      group.querySelectorAll("button").forEach((button) => {
        button.addEventListener("click", () => {
          group.querySelectorAll("button").forEach((item) => item.classList.remove("active"));
          button.classList.add("active");
          state[group.dataset.name] = button.dataset.value;
        });
      });
    });
  }

  function bindNotePresets() {
    $$(".note-select").forEach((select) => {
      select.addEventListener("change", () => {
        const target = document.getElementById(select.dataset.target);
        if (target) target.value = select.value;
      });
    });
  }

  function bindActions() {
    $("#exportBtn").addEventListener("click", () => {
      runExportWithProgress(false);
    });

    $("#hotUpdateBtn").addEventListener("click", () => {
      const options = exportOptions();
      evalScript("HH_hotUpdate(" + JSON.stringify(options.mode) + "," + options.dpi + "," + JSON.stringify(options.format) + ")", refreshStatus);
    });

    $("#markFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: true }));
    $("#clearFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: false }));
    const previewFallbackBtn = $("#previewFallbackBtn");
    if (previewFallbackBtn) previewFallbackBtn.addEventListener("click", () => callHost("preview_fallback_export", {}));
    const clearFallbackPreviewBtn = $("#clearFallbackPreviewBtn");
    if (clearFallbackPreviewBtn) clearFallbackPreviewBtn.addEventListener("click", () => callHost("clear_fallback_preview", {}));
    const markFallbackReverseBtn = $("#markFallbackReverseBtn");
    if (markFallbackReverseBtn) markFallbackReverseBtn.addEventListener("click", () => callHost("set_fallback_reverse", { enabled: true }));
    const clearFallbackReverseBtn = $("#clearFallbackReverseBtn");
    if (clearFallbackReverseBtn) clearFallbackReverseBtn.addEventListener("click", () => callHost("set_fallback_reverse", { enabled: false }));
    $("#filterMissingBtn").addEventListener("click", () => callHost("filter_missing", {}));
    const readStrokeThicknessBtn = $("#readStrokeThicknessBtn");
    if (readStrokeThicknessBtn) {
      readStrokeThicknessBtn.addEventListener("click", () => {
        callHost("read_stroke_thickness_info", {}, function (message) {
          setStrokeThicknessInfo(String(message || "").replace(/^STROKE_INFO:/, ""));
          refreshStatus();
        });
      });
    }
    const previewStrokeThicknessBtn = $("#previewStrokeThicknessBtn");
    if (previewStrokeThicknessBtn) previewStrokeThicknessBtn.addEventListener("click", () => callHost("preview_stroke_thickness", {}));
    const clearStrokeThicknessPreviewBtn = $("#clearStrokeThicknessPreviewBtn");
    if (clearStrokeThicknessPreviewBtn) clearStrokeThicknessPreviewBtn.addEventListener("click", () => callHost("clear_stroke_thickness_preview", {}));
    const markStrokeThicknessExportBtn = $("#markStrokeThicknessExportBtn");
    if (markStrokeThicknessExportBtn) markStrokeThicknessExportBtn.addEventListener("click", () => callHost("set_stroke_thickness_export", { enabled: true }));
    const clearStrokeThicknessExportBtn = $("#clearStrokeThicknessExportBtn");
    if (clearStrokeThicknessExportBtn) clearStrokeThicknessExportBtn.addEventListener("click", () => callHost("set_stroke_thickness_export", { enabled: false }));
    const strokeDepthButtons = [
      ["#strokeThicknessDepth3mmBtn", 3],
      ["#strokeThicknessDepth5mmBtn", 5],
      ["#strokeThicknessDepth1cmBtn", 10],
      ["#strokeThicknessDepth2cmBtn", 20],
      ["#strokeThicknessDepth4cmBtn", 40],
      ["#strokeThicknessDepth5cmBtn", 50],
      ["#strokeThicknessDepth8cmBtn", 80],
      ["#strokeThicknessDepth10cmBtn", 100],
      ["#strokeThicknessDepth15cmBtn", 150],
      ["#strokeThicknessDepth20cmBtn", 200]
    ];
    strokeDepthButtons.forEach(([selector, depthMm]) => {
      const button = $(selector);
      if (button) button.addEventListener("click", () => setStrokeThicknessDepth(depthMm));
    });
    const applyStrokeThicknessDepthBtn = $("#applyStrokeThicknessDepthBtn");
    if (applyStrokeThicknessDepthBtn) {
      applyStrokeThicknessDepthBtn.addEventListener("click", () => {
        const valueCm = parseFloat($("#strokeThicknessCustomDepthInput").value);
        if (!Number.isFinite(valueCm) || valueCm <= 0) {
          window.alert("请输入有效的自定义厚度 cm");
          return;
        }
        setStrokeThicknessDepth(Math.round(valueCm * 10 * 100) / 100);
      });
    }

    $$("[data-thick]").forEach((button) => {
      button.addEventListener("click", () => callHost("set_thickness", { val: parseInt(button.dataset.thick, 10) }));
    });

    $("#customThicknessBtn").addEventListener("click", () => {
      const value = parseFloat($("#customThickness").value);
      if (Number.isNaN(value)) return;
      callHost("set_thickness", { val: Math.round(value * 10) });
    });

    $("#cutBtn").addEventListener("click", () => {
      callHost("cut", {
        sides: {
          top: $("#sideTop").checked,
          bottom: $("#sideBottom").checked,
          left: $("#sideLeft").checked,
          right: $("#sideRight").checked
        },
        radius: parseFloat($("#slotRadius").value) || 5
      });
    });

    const craftBindings = [
      ["#craftNoneBtn", "none"],
      ["#craftBacklitBtn", "sign_backlit"],
      ["#craftFrontlitBtn", "sign_frontlit"],
      ["#craftCrystalBtn", "sign_crystal"],
      ["#craftDualLitBtn", "sign_dual_lit"]
    ];
    craftBindings.forEach(([selector, type]) => {
      const button = $(selector);
      if (button) button.addEventListener("click", () => setCraftMarker(type));
    });
    const craftClearBtn = $("#craftClearBtn");
    if (craftClearBtn) craftClearBtn.addEventListener("click", clearCraftMarker);

    $("#quickUnionCompoundExpandBtn").addEventListener("click", () => callHost("quick_union_compound_expand", {}));
    $("#outlineStrokeBtn").addEventListener("click", () => callHost("outline_stroke", {}));
    $("#offsetPathBtn").addEventListener("click", () => callHost("offset_path", {}));
    $("#simplifyPathBtn").addEventListener("click", () => callHost("simplify_path", {}));
    $("#createTextOutlinesBtn").addEventListener("click", () => callHost("create_text_outlines", {}));
    $("#dropShadowBtn").addEventListener("click", openDropShadowModal);
    $("#renameArtboardsBtn").addEventListener("click", () => callHost("rename_artboards", {}));
    $("#createArtboardsBtn").addEventListener("click", () => callHost("create_artboards_from_selection", {}));
    $("#exportPdfBtn").addEventListener("click", () => openModal("#pdfExportModal"));
    $("#exportImagesBtn").addEventListener("click", () => openModal("#imageExportModal"));
    $("#cancelPdfExportBtn").addEventListener("click", () => closeModal("#pdfExportModal"));
    $("#cancelImageExportBtn").addEventListener("click", () => closeModal("#imageExportModal"));
    $("#pdfExportModal").addEventListener("click", (event) => {
      if (event.target === $("#pdfExportModal")) closeModal("#pdfExportModal");
    });
    $("#imageExportModal").addEventListener("click", (event) => {
      if (event.target === $("#imageExportModal")) closeModal("#imageExportModal");
    });
    $("#applyPdfExportBtn").addEventListener("click", () => {
      const params = pdfExportParams();
      if (!params) return;
      callHost("export_pdf_by_artboards", params, function (message) {
        closeModal("#pdfExportModal");
        refreshStatus();
      });
    });
    $("#applyImageExportBtn").addEventListener("click", () => {
      const params = imageExportParams();
      if (!params) return;
      callHost("export_images", params, function (message) {
        closeModal("#imageExportModal");
        refreshStatus();
      });
    });
    $("#checkUpdateBtn").addEventListener("click", () => checkForUpdates(true));
    $("#closeUpdateBtn").addEventListener("click", closeUpdateDialog);
    $("#downloadUpdateBtn").addEventListener("click", () => {
      const url = state.updateInfo && state.updateInfo.downloadUrl;
      if (!url) {
        window.alert("暂无可用下载地址，请联系管理员。");
        return;
      }
      openExternalUrl(url);
    });
    $("#fallbackDownloadBtn").addEventListener("click", () => {
      const url = state.updateInfo && state.updateInfo.fallbackUrl;
      if (!url) {
        window.alert("备用下载地址不可用，请联系管理员。");
        return;
      }
      openExternalUrl(url);
    });
    $("#updateModal").addEventListener("click", (event) => {
      if (event.target === $("#updateModal")) closeUpdateDialog();
    });
    $("#cancelShadowBtn").addEventListener("click", cancelDropShadowModal);
    $("#dropShadowModal").addEventListener("click", (event) => {
      if (event.target === $("#dropShadowModal")) cancelDropShadowModal();
    });
    ["#shadowX", "#shadowY", "#shadowBlur", "#shadowOpacity", "#shadowColor", "#shadowBlend"].forEach((selector) => {
      const input = $(selector);
      input.addEventListener("input", scheduleDropShadowPreview);
      input.addEventListener("change", scheduleDropShadowPreview);
    });
    $("#shadowPreview").addEventListener("change", () => {
      if ($("#shadowPreview").checked) {
        requestDropShadowPreview();
      } else {
        callHost("drop_shadow_native_cancel", {}, refreshStatus);
      }
    });
    $("#applyShadowBtn").addEventListener("click", () => {
      const params = shadowParams();
      if (!params) return;
      if (shadowPreviewTimer) {
        window.clearTimeout(shadowPreviewTimer);
        shadowPreviewTimer = null;
      }
      callHost("drop_shadow_native_apply", params, function () {
        closeDropShadowModal();
        refreshStatus();
      });
    });

    $("#dimBoxBtn").addEventListener("click", () => callHost("dim_box", dimParams()));
    $("#curveLenBtn").addEventListener("click", () => callHost("dim_curve_text_below", dimParams()));
    $("#labelBtn").addEventListener("click", () => callHost("label_material", dimParams()));
  }

  bindTabs();
  bindSegmented();
  bindNotePresets();
  bindTheme();
  bindAuth();
  updateAuthUi();
  bindActions();
  bindCoreFreshnessGuard();
  autoVerifyAuth();
  loadHost();
  window.setTimeout(function () {
    checkForUpdates(false);
  }, 1400);
  window.setInterval(refreshStatus, 1800);
}());
