// AI_C4D_Tools_v28.236_Defringe_TextBounds.jsx
// 作用：花花 AI 辅助工具全集 (AI 端) - 默认悬浮版
// 修复日志 v28.67：
// 1.[完美边界] 彻底攻克“文字边界空白”问题！当文字作为剪切蒙版时，导出贴图不再包含字体的透明排版区域（大白框）。脚本会智能测量“真实笔画墨水边界”，完美裁切贴图，确保和 C4D 路径 100% 严丝合缝贴合。
// 2.[调试清理] 导出时不再额外写出 _debug.txt，仅保留 JSON 和贴图文件。
// 3.[剪切组导出] 对剪切蒙版组不再只信任内部 mask，改为“内部 mask + 整组全部路径”合并去重导出，避免主体轮廓漏掉。
// 4.[轮廓追踪兜底] 当剪切组现有矢量路径面积明显偏小、疑似只剩花瓣时，自动把剪切结果转成黑色实心轮廓后图像描摹，回收主体外轮廓。
// 5.[外框过滤] 图像描摹兜底后，自动剔除“接近整张边界的大外框路径”，避免 C4D 导入成整块矩形。

#target illustrator
#targetengine "session_HH_Tools_v28_139_CEP"

// ============================================================================
// 1. JSON Polyfill
// ============================================================================
if (typeof JSON !== "object") { JSON = {}; }
(function () {
    "use strict";
    if (typeof JSON.stringify !== "function") {
        JSON.stringify = function (value) {
            var str = function(key, holder) {
                var value = holder[key];
                if (typeof value === "string") return "\"" + value.replace(/[\\"]/g, "\\$&") + "\"";
                if (typeof value === "number") return isFinite(value) ? String(value) : "null";
                if (typeof value === "boolean") return String(value);
                if (!value) return "null";
                if (Object.prototype.toString.call(value) === "[object Array]") {
                    var arr =[]; for (var i = 0; i < value.length; i++) arr[i] = str(i, value) || "null";
                    return "[" + arr.join(",") + "]";
                }
                if (typeof value === "object") {
                    var partial =[]; for (var k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            var v = str(k, value); if (v) partial.push("\"" + k + "\":" + v);
                        }
                    }
                    return "{" + partial.join(",") + "}";
                }
                return "null";
            };
            return str("", { "": value });
        };
    }
}());

// ============================================================================
// 2. 核心逻辑 (主线程运行)
// ============================================================================
function WORKER_FUNCTION(action, params) {
    try {
        var ENABLE_CLIPPING_SOLID_FORCE_TEXTURE = false;
        var tools = {
            getTagD: function(name) {
                if (!name) return null;
                var idx = name.lastIndexOf("_d");
                if (idx !== -1) {
                    var part = name.substring(idx + 2);
                    var tIdx = part.indexOf("_t");
                    if (tIdx !== -1) part = part.substring(0, tIdx);
                    part = part.split(/[^0-9]/)[0];
                    var v = parseInt(part);
                    if (!isNaN(v)) return v;
                }
                return null;
            },
            getTagT: function(name) {
                if (!name) return null;
                var idx = name.lastIndexOf("_t");
                if (idx !== -1) {
                    var part = name.substring(idx + 2);
                    var stxIdx = part.indexOf("_stx");
                    if (stxIdx !== -1) part = part.substring(0, stxIdx);
                    var fbrIdx = part.indexOf("_fbr");
                    if (fbrIdx !== -1) part = part.substring(0, fbrIdx);
                    var fbIdx = part.indexOf("_fb");
                    if (fbIdx !== -1) part = part.substring(0, fbIdx);
                    return part;
                }
                return null;
            },
            getFallbackExport: function(name) {
                if (!name) return false;
                return name.lastIndexOf("_fb") !== -1 || name.lastIndexOf("_fbr") !== -1;
            },
            getFallbackReverse: function(name) {
                if (!name) return false;
                return name.lastIndexOf("_fbr") !== -1;
            },
            getStrokeThicknessExport: function(name) {
                if (!name) return false;
                return name.lastIndexOf("_stx") !== -1;
            },
            getPureName: function(name) {
                if (!name) return "";
                var stxIdx = name.lastIndexOf("_stx");
                if (stxIdx !== -1) name = name.substring(0, stxIdx);
                var fbrIdx = name.lastIndexOf("_fbr");
                if (fbrIdx !== -1) name = name.substring(0, fbrIdx);
                var fbIdx = name.lastIndexOf("_fb");
                if (fbIdx !== -1) name = name.substring(0, fbIdx);
                var dIdx = name.lastIndexOf("_d");
                if (dIdx !== -1) name = name.substring(0, dIdx);
                var tIdx = name.lastIndexOf("_t");
                if (tIdx !== -1) name = name.substring(0, tIdx);
                return name;
            },
            getFullSuffix: function(name) {
                if (!name) return "";
                var suffix = "";
                var d = this.getTagD(name);
                var t = this.getTagT(name);
                if (d !== null) suffix += "_d" + d;
                if (t) suffix += "_t" + t;
                return suffix;
            },
            rebuildName: function(name, dVal, tVal, fallbackExport, fallbackReverse, strokeThicknessExport) {
                var base = this.getPureName(name || "Item");
                if (!base) base = "Obj_" + Math.round(Math.random()*1000);
                if (strokeThicknessExport === undefined) strokeThicknessExport = this.getStrokeThicknessExport(name);
                var newName = base;
                if (dVal !== null && dVal !== undefined) newName += "_d" + dVal;
                if (tVal) newName += "_t" + tVal;
                if (fallbackReverse) fallbackExport = true;
                if (fallbackExport) newName += "_fb";
                if (fallbackReverse) newName += "_fbr";
                if (strokeThicknessExport) newName += "_stx";
                return newName;
            },
            cleanName: function(name) {
                if (!name) name = "Untitled";
                var badCode =[92, 47, 58, 42, 63, 34, 60, 62, 124, 46]; 
                var res = "";
                for (var i = 0; i < name.length; i++) {
                    var c = name.charCodeAt(i);
                    var isBad = false;
                    for (var j = 0; j < badCode.length; j++) { if (c === badCode[j]) { isBad = true; break; } }
                    if (isBad) res += "_"; else res += name.charAt(i);
                }
                return res;
            },
            
            // --- 颜色解析 ---
            parseColor: function(c) {
                try {
                    if (!c) return null;
                    if (c.typename === "RGBColor") {
                        return[Math.round(c.red), Math.round(c.green), Math.round(c.blue)];
                    }
                    if (c.typename === "CMYKColor") {
                        try {
                            var srcVals =[c.cyan, c.magenta, c.yellow, c.black];
                            var dstVals = app.convertSampleColor(ImageColorSpace.CMYK, srcVals, ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose);
                            return[Math.round(dstVals[0]), Math.round(dstVals[1]), Math.round(dstVals[2])];
                        } catch(err) {
                            var k = c.black / 100;
                            var r = 255 * (1 - c.cyan / 100) * (1 - k);
                            var g = 255 * (1 - c.magenta / 100) * (1 - k);
                            var b = 255 * (1 - c.yellow / 100) * (1 - k);
                            return[Math.round(r), Math.round(g), Math.round(b)];
                        }
                    }
                    if (c.typename === "GrayColor") { 
                        try {
                            var dstVals = app.convertSampleColor(ImageColorSpace.GrayScale,[c.gray], ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose);
                            return[Math.round(dstVals[0]), Math.round(dstVals[1]), Math.round(dstVals[2])];
                        } catch(e) {
                            var v = 255 * (1 - c.gray / 100); 
                            return[Math.round(v), Math.round(v), Math.round(v)]; 
                        }
                    }
                    if (c.typename === "SpotColor") return this.parseColor(c.spot.color);
                    if (c.typename === "GradientColor") {
                        try { return this.parseColor(c.gradient.gradientStops[0].color); } catch(e) { return[200, 200, 200]; }
                    }
                    if (c.typename === "PatternColor") return[150, 150, 150]; 
                    return null;
                } catch(e) { return null; }
            },
            
            getRGB: function(item) {
                try {
                    if (!item) return null;
                    if (item.filled && item.fillColor) {
                        var c = this.parseColor(item.fillColor);
                        if (c) return c;
                    }
                    if (item.typename === "CompoundPathItem" && item.pathItems) {
                        for (var i = 0; i < item.pathItems.length; i++) {
                            var subPath = item.pathItems[i];
                            if (subPath.filled && subPath.fillColor) {
                                var c = this.parseColor(subPath.fillColor);
                                if (c) return c;
                            }
                        }
                    }
                    return null;
                } catch(e) { return null; }
            },

            findDeepColor: function(item) {
                if (!item) return null;
                if (item.clipping) return null; 
                var c = this.getRGB(item);
                if (c) return c;

                if (item.typename === "GroupItem" && item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        var child = item.pageItems[i];
                        var childColor = this.findDeepColor(child);
                        if (childColor) return childColor;
                    }
                }
                
                if (item.typename === "CompoundPathItem" && item.pathItems) {
                     for (var j = 0; j < item.pathItems.length; j++) {
                        var subC = this.getRGB(item.pathItems[j]);
                        if (subC) return subC;
                    }
                }
                return null;
            }
        };

        // 【重构核心】：脱水版真实边界测量（去除文字排版空白区域）
        var getTightBounds = function(item) {
            var getTrueBounds = function(obj) {
                if (obj.typename === "TextFrame") {
                    try {
                        // 提取真实物理边界核心：复制 -> 解除蒙版 -> 转曲 -> 拿尺寸 -> 销毁
                        var dup = obj.duplicate();
                        dup.clipping = false; 
                        var out = dup.createOutline(); 
                        var b = out.geometricBounds;
                        out.remove();
                        return [b[0], b[1], b[2], b[3]];
                    } catch(e) {}
                }
                return [obj.geometricBounds[0], obj.geometricBounds[1], obj.geometricBounds[2], obj.geometricBounds[3]];
            };

            if (item.typename === "GroupItem" && item.clipped) {
                var mask = null;
                try {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        if (item.pageItems[i].clipping === true) { mask = item.pageItems[i]; break; }
                    }
                    if (!mask && item.pageItems.length > 0) mask = item.pageItems[0];
                } catch(e){}
                
                if (mask) {
                    return getTrueBounds(mask);
                }
            }
            
            if (item.typename === "GroupItem" && !item.clipped) {
                var gL = 9999999999, gT = -9999999999, gR = -9999999999, gB = 9999999999;
                var found = false;
                for (var k = 0; k < item.pageItems.length; k++) {
                    var b = getTightBounds(item.pageItems[k]); 
                    if (b) {
                        found = true;
                        gL = Math.min(gL, b[0]); gT = Math.max(gT, b[1]);
                        gR = Math.max(gR, b[2]); gB = Math.min(gB, b[3]);
                    }
                }
                if (found) return[gL, gT, gR, gB];
            }
            return getTrueBounds(item);
        };

        var drawLine = function(container, x1, y1, x2, y2, color, strokeWidth) {
            var line = container.pathItems.add();
            line.setEntirePath([[x1, y1],[x2, y2]]);
            line.stroked = true; line.strokeColor = color; line.strokeWidth = strokeWidth; line.filled = false;
            return line;
        };
        var drawText = function(container, content, x, y, size, color) {
            var txt = container.textFrames.add();
            txt.contents = content;
            var attr = txt.textRange.characterAttributes;
            attr.size = size; attr.fillColor = color;
            try { attr.textFont = app.textFonts.getByName("SimHei"); } catch(e) { try{attr.textFont=app.textFonts.getByName("STHeiti");}catch(e2){} }
            txt.position =[x, y];
            return txt;
        };
        var convertValue = function(ptValue, scale, unitType, decimal, isRound) {
            var val = (ptValue / 2.83464567) * scale;
            var suffix = "mm";
            if (unitType === "cm") { val /= 10; suffix = "cm"; } else if (unitType === "m") { val /= 1000; suffix = "m"; }
            if (isRound) {
                var frac = val - Math.floor(val);
                val = (frac > 0.5) ? Math.ceil(val) : Math.floor(val);
                return val + suffix;
            }
            return val.toFixed(decimal) + suffix;
        };
        var getDimColor = function(docRef) {
            var c = new RGBColor(); c.red = 255; c.green = 0; c.blue = 0;
            try { if (docRef.documentColorSpace === DocumentColorSpace.CMYK) { c = new CMYKColor(); c.cyan=0; c.magenta=100; c.yellow=100; c.black=0; } } catch(e){}
            return c;
        };

        if (action === "check_status") {
            try {
                if (app.documents.length === 0) return "STATUS:未打开文档";
                var doc = app.activeDocument;
                var sel = doc.selection;
                if (!sel || sel.length === 0) return "STATUS:⚪ 请选中对象...";
                
                var missingCount = 0;
                var fallbackCount = 0;
                var fallbackReverseCount = 0;
                var strokeExportCount = 0;
                var strokeDepthHasValue = false;
                var strokeDepthFirst = null;
                var strokeDepthMixed = false;
                var strokeDepthUnset = 0;
                var readStrokeDepthFromNoteForStatus = function(statusItem) {
                    try {
                        var note = String(statusItem.note || "");
                        var match = note.match(/(^|\n)HH_STROKE_THICKNESS_DEPTH_MM=([0-9]+(?:\.[0-9]+)?)/);
                        if (match && match[2] !== undefined) {
                            var value = parseFloat(match[2]);
                            if (!isNaN(value) && value > 0) return value;
                        }
                    } catch(e0) {}
                    return null;
                };
                var formatStrokeDepthForStatus = function(value) {
                    var v = parseFloat(value);
                    if (isNaN(v)) return "";
                    if (Math.abs(v - Math.round(v)) < 0.001) return Math.round(v) + "mm";
                    return v.toFixed(2).replace(/0+$/, "").replace(/\.$/, "") + "mm";
                };
                for (var m = 0; m < sel.length; m++) {
                    if (tools.getTagD(sel[m].name) === null) {
                        missingCount++;
                    }
                    if (tools.getFallbackReverse(sel[m].name)) {
                        fallbackReverseCount++;
                    } else if (tools.getFallbackExport(sel[m].name)) {
                        fallbackCount++;
                    }
                    if (tools.getStrokeThicknessExport(sel[m].name) || readStrokeDepthFromNoteForStatus(sel[m]) !== null && String(sel[m].note || "").indexOf("HH_STROKE_THICKNESS_EXPORT=1") !== -1) {
                        strokeExportCount++;
                    }
                    var strokeDepthValue = readStrokeDepthFromNoteForStatus(sel[m]);
                    if (strokeDepthValue === null) {
                        strokeDepthUnset++;
                    } else if (!strokeDepthHasValue) {
                        strokeDepthFirst = strokeDepthValue;
                        strokeDepthHasValue = true;
                    } else if (Math.abs(strokeDepthFirst - strokeDepthValue) > 0.001) {
                        strokeDepthMixed = true;
                    }
                }
                if (strokeDepthHasValue && strokeDepthUnset > 0 && sel.length > 1) strokeDepthMixed = true;
                
                var firstD = tools.getTagD(sel[0].name);
                var info = "STATUS:✅ 选中 " + sel.length + " 个";
                
                if (firstD !== null) {
                    info += " | 厚度: " + firstD + "mm";
                } else if (!strokeDepthHasValue) {
                    info += " | 无厚度";
                }

                if (strokeDepthHasValue) {
                    info += " | 描边厚度：" + (strokeDepthMixed ? "多个" : formatStrokeDepthForStatus(strokeDepthFirst));
                }

                if (missingCount > 0 && !strokeDepthHasValue) {
                    info += " ⚠️ " + missingCount + "个漏设!";
                } else if (missingCount === 0 && sel.length > 1) {
                    info += " (均已设)";
                }
                if (fallbackCount > 0) {
                    info += " | 兜底:" + fallbackCount;
                }
                if (fallbackReverseCount > 0) {
                    info += " | 反选兜底:" + fallbackReverseCount;
                }
                if (strokeExportCount > 0) {
                    info += " | 描边导出:开";
                    if (strokeExportCount > 1) info += "(" + strokeExportCount + ")";
                }
                try {
                    var craftStatus = readCraftInfoForSelection().replace(/^CRAFT_INFO:/, "");
                    if (craftStatus && craftStatus.indexOf("请先选中") === -1) info += " | " + craftStatus;
                } catch(craftStatusErr) {}
                
                return info;
            } catch(e) { return "STATUS:读取错误"; }
        }

        var quickActions = {
            quick_union_compound_expand: true,
            outline_stroke: true,
            offset_path: true,
            simplify_path: true,
            create_text_outlines: true,
            drop_shadow: true,
            drop_shadow_preview: true,
            drop_shadow_apply: true,
            drop_shadow_cancel: true,
            drop_shadow_native_preview: true,
            drop_shadow_native_apply: true,
            drop_shadow_native_cancel: true
        };

        var quickActionsNeedSelection = {
            quick_union_compound_expand: true,
            outline_stroke: true,
            offset_path: true,
            simplify_path: true,
            create_text_outlines: true,
            drop_shadow: true,
            drop_shadow_preview: true,
            drop_shadow_apply: false,
            drop_shadow_cancel: false,
            drop_shadow_native_preview: true,
            drop_shadow_native_apply: false,
            drop_shadow_native_cancel: false
        };

        if (quickActions[action] && app.documents.length === 0) {
            alert("请先打开 Illustrator 文档");
            return "NO_DOC";
        }

        var artboardExportActions = {
            rename_artboards: true,
            create_artboards_from_selection: true,
            export_pdf_by_artboards: true,
            export_images: true
        };

        if (artboardExportActions[action] && app.documents.length === 0) {
            alert("请先打开 Illustrator 文档");
            return "NO_DOC";
        }

        if (app.documents.length === 0) { alert("错误: 没有打开的文档"); return; }
        var doc = app.activeDocument ? app.activeDocument : app.documents[0];
        try { app.activeDocument = doc; } catch(e){} 
        var originalSel = doc.selection;

        var STROKE_PREVIEW_LAYER = "HH_STROKE_THICKNESS_PREVIEW";
        var STROKE_EXPORT_TEMP_LAYER = "HH_STROKE_THICKNESS_EXPORT_TEMP";
        var PT_TO_MM = 0.3527777778;
        var STROKE_EXPORT_NOTE_KEY = "HH_STROKE_THICKNESS_EXPORT";
        var STROKE_DEPTH_NOTE_KEY = "HH_STROKE_THICKNESS_DEPTH_MM";
        var SKIP_EXPORT_NOTE_KEY = "HH_SKIP_EXPORT";
        var STROKE_GENERATED_FROM_NOTE_KEY = "HH_STROKE_THICKNESS_GENERATED_FROM";
        var DEFAULT_STROKE_THICKNESS_DEPTH_MM = 20;
        var DEBUG_EXPORT_REPORT = false;
        var CRAFT_NOTE_KEY = "HH_CRAFT_MARKER";
        var CRAFT_LABELS = {
            none: "普通对象",
            acrylic_slot: "亚克力插槽",
            sign_backlit: "背发光字",
            sign_frontlit: "正发光字",
            sign_crystal: "水晶字",
            sign_dual_lit: "正背发字"
        };
        var CRAFT_DEFAULT_PARAMS = {
            none: {},
            acrylic_slot: { depthCm: 0.3, direction: "Z+", deleteSides: ["top"], openSides: ["top"], shellCm: 0.3 },
            sign_backlit: { frontThicknessMm: 30, backThicknessMm: 10, color: "#ff0000" },
            sign_frontlit: { frontThicknessMm: 5, backThicknessMm: 30, color: "#ff0000" },
            sign_crystal: { frontThicknessMm: 3, backThicknessMm: 10, color: "#ffffff" },
            sign_dual_lit: { frontThicknessMm: 5, backThicknessMm: 30, color: "#ff0000" }
        };

        var makeRgb = function(r, g, b) {
            var c = new RGBColor();
            c.red = r; c.green = g; c.blue = b;
            return c;
        };

        var normalizeCraftType = function(type) {
            var t = String(type || "none");
            return CRAFT_LABELS[t] ? t : "none";
        };

        var cloneCraftValue = function(value) {
            if (value && Object.prototype.toString.call(value) === "[object Array]") {
                var arr = [];
                for (var i = 0; i < value.length; i++) arr.push(cloneCraftValue(value[i]));
                return arr;
            }
            if (value && typeof value === "object") {
                var obj = {};
                for (var k in value) {
                    if (Object.prototype.hasOwnProperty.call(value, k)) obj[k] = cloneCraftValue(value[k]);
                }
                return obj;
            }
            return value;
        };

        var defaultCraftParams = function(type) {
            type = normalizeCraftType(type);
            return cloneCraftValue(CRAFT_DEFAULT_PARAMS[type] || {});
        };

        var mergeCraftParams = function(type, params) {
            var merged = defaultCraftParams(type);
            if (params && typeof params === "object") {
                for (var k in params) {
                    if (Object.prototype.hasOwnProperty.call(params, k)) merged[k] = cloneCraftValue(params[k]);
                }
            }
            return merged;
        };

        var makeCraftInfo = function(type, params) {
            var craftType = normalizeCraftType(type);
            return { type: craftType, params: mergeCraftParams(craftType, params) };
        };

        var parseCraftParamsFromRaw = function(raw) {
            var params = {};
            try {
                var parseArrayField = function(fieldName) {
                    var re = new RegExp('"' + fieldName + '"\\s*:\\s*\\[([^\\]]*)\\]');
                    var match = raw.match(re);
                    if (!match || !match[1]) return null;
                    var values = [];
                    var parts = match[1].split(",");
                    for (var i = 0; i < parts.length; i++) {
                        var v = parts[i].replace(/^[\\s"']+|[\\s"']+$/g, "");
                        if (v) values.push(v);
                    }
                    return values;
                };
                var parseNumberField = function(fieldName) {
                    var re = new RegExp('"' + fieldName + '"\\s*:\\s*(-?[0-9]+(?:\\.[0-9]+)?)');
                    var match = raw.match(re);
                    if (!match || match[1] === undefined) return null;
                    var n = parseFloat(match[1]);
                    return isNaN(n) ? null : n;
                };
                var parseStringField = function(fieldName) {
                    var re = new RegExp('"' + fieldName + '"\\s*:\\s*"([^"]*)"');
                    var match = raw.match(re);
                    return match && match[1] !== undefined ? match[1] : null;
                };
                var openSides = parseArrayField("openSides");
                var deleteSides = parseArrayField("deleteSides");
                if (openSides) params.openSides = openSides;
                if (deleteSides) params.deleteSides = deleteSides;
                var depthCm = parseNumberField("depthCm");
                var shellCm = parseNumberField("shellCm");
                var frontThicknessMm = parseNumberField("frontThicknessMm");
                var backThicknessMm = parseNumberField("backThicknessMm");
                var direction = parseStringField("direction");
                var color = parseStringField("color");
                if (depthCm !== null) params.depthCm = depthCm;
                if (shellCm !== null) params.shellCm = shellCm;
                if (frontThicknessMm !== null) params.frontThicknessMm = frontThicknessMm;
                if (backThicknessMm !== null) params.backThicknessMm = backThicknessMm;
                if (direction !== null) params.direction = direction;
                if (color !== null) params.color = color;
            } catch(e) {}
            return params;
        };

        var readCraftFromNote = function(note) {
            try {
                var text = String(note || "");
                if (!text) return null;
                if (typeof JSON.parse === "function" && text.charAt(0) === "{") {
                    try {
                        var obj = JSON.parse(text);
                        var objType = obj.craftType || obj.hhCraftType || obj.type;
                        if (objType) return makeCraftInfo(objType, obj.craftParams || obj.hhCraftParams || obj.params || {});
                    } catch(jsonNoteErr) {}
                }
                var lines = text.split(/\r?\n/);
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].indexOf(CRAFT_NOTE_KEY + "=") !== 0) continue;
                    var raw = lines[i].substring((CRAFT_NOTE_KEY + "=").length);
                    if (typeof JSON.parse === "function") {
                        try {
                            var marker = JSON.parse(raw);
                            return makeCraftInfo(marker.craftType || marker.type || marker.hhCraftType, marker.craftParams || marker.params || marker.hhCraftParams || {});
                        } catch(markerJsonErr) {}
                    }
                    var typeMatch = raw.match(/"(?:craftType|type|hhCraftType)"\s*:\s*"([^"]+)"/);
                    if (typeMatch && typeMatch[1]) return makeCraftInfo(typeMatch[1], parseCraftParamsFromRaw(raw));
                    return makeCraftInfo(raw, {});
                }
            } catch(e) {}
            return null;
        };

        var readCraftMarker = function(item) {
            try {
                if (!item) return null;
                return readCraftFromNote(item.note || "");
            } catch(e) {}
            return null;
        };

        var setCraftMarker = function(item, type, params) {
            if (!item) return false;
            try {
                var craft = makeCraftInfo(type, params);
                var note = String(item.note || "");
                if (typeof JSON.parse === "function" && note.charAt(0) === "{") {
                    try {
                        var obj = JSON.parse(note);
                        obj.craftType = craft.type;
                        obj.craftParams = craft.params;
                        item.note = JSON.stringify(obj);
                        return true;
                    } catch(jsonSetErr) {}
                }
                var lines = note ? note.split(/\r?\n/) : [];
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].indexOf(CRAFT_NOTE_KEY + "=") === 0) continue;
                    if (lines[i] !== "") kept.push(lines[i]);
                }
                kept.push(CRAFT_NOTE_KEY + "=" + JSON.stringify({ type: craft.type, params: craft.params }));
                item.note = kept.join("\n");
                return true;
            } catch(e) {}
            return false;
        };

        var clearCraftMarker = function(item) {
            if (!item) return false;
            try {
                var note = String(item.note || "");
                if (typeof JSON.parse === "function" && note.charAt(0) === "{") {
                    try {
                        var obj = JSON.parse(note);
                        delete obj.craftType;
                        delete obj.craftParams;
                        delete obj.hhCraftType;
                        delete obj.hhCraftParams;
                        item.note = JSON.stringify(obj);
                        return true;
                    } catch(jsonClearErr) {}
                }
                var lines = note ? note.split(/\r?\n/) : [];
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].indexOf(CRAFT_NOTE_KEY + "=") === 0) continue;
                    if (lines[i] !== "") kept.push(lines[i]);
                }
                item.note = kept.join("\n");
                return true;
            } catch(e) {}
            return false;
        };

        var findCraftInAncestors = function(item) {
            var node = item;
            var guard = 0;
            while (node && guard < 20) {
                try {
                    if (node.typename === "Layer" || node.typename === "Document") break;
                    var direct = readCraftMarker(node);
                    if (direct) return direct;
                    node = node.parent;
                } catch(e) { break; }
                guard++;
            }
            return null;
        };

        var findCraftInChildren = function(item, depth) {
            if (!item || depth > 8) return null;
            try {
                var direct = readCraftMarker(item);
                if (direct) return direct;
                if (item.typename === "GroupItem" && item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        var childCraft = findCraftInChildren(item.pageItems[i], depth + 1);
                        if (childCraft) return childCraft;
                    }
                }
                if (item.typename === "CompoundPathItem" && item.pathItems) {
                    for (var j = 0; j < item.pathItems.length; j++) {
                        var subCraft = findCraftInChildren(item.pathItems[j], depth + 1);
                        if (subCraft) return subCraft;
                    }
                }
            } catch(e) {}
            return null;
        };

        var getCraftForExportSource = function(item) {
            var found = findCraftInAncestors(item);
            if (!found) found = findCraftInChildren(item, 0);
            if (!found) found = makeCraftInfo("none", {});
            return found;
        };

        var appendCraftFieldsToJsonItem = function(jsonText, sourceItem) {
            try {
                var craft = getCraftForExportSource(sourceItem);
                var craftType = normalizeCraftType(craft.type);
                var craftParams = craft.params || {};
                return String(jsonText).replace(/\}$/, ',"craftType":"' + craftType + '","craftParams":' + JSON.stringify(craftParams) + '}');
            } catch(e) {
                return String(jsonText).replace(/\}$/, ',"craftType":"none","craftParams":{}}');
            }
        };

        var readCraftInfoForSelection = function() {
            if (!originalSel || originalSel.length === 0) return "CRAFT_INFO:请先选中要标注工艺的对象";
            var first = null;
            var mixed = false;
            for (var i = 0; i < originalSel.length; i++) {
                var craft = getCraftForExportSource(originalSel[i]);
                var key = normalizeCraftType(craft.type) + "|" + JSON.stringify(craft.params || {});
                if (first === null) {
                    first = key;
                } else if (first !== key) {
                    mixed = true;
                    break;
                }
            }
            if (mixed) return "CRAFT_INFO:多个对象工艺不一致";
            var type = first ? first.split("|")[0] : "none";
            return "CRAFT_INFO:当前工艺：" + (CRAFT_LABELS[type] || CRAFT_LABELS.none);
        };

        var parseStrokeThicknessDepthMm = function(item) {
            try {
                var note = String(item.note || "");
                var match = note.match(new RegExp("(^|\\n)" + STROKE_DEPTH_NOTE_KEY + "=([0-9]+(?:\\.[0-9]+)?)"));
                if (match && match[2] !== undefined) {
                    var value = parseFloat(match[2]);
                    if (!isNaN(value) && value > 0) return value;
                }
            } catch(e) {}
            return null;
        };

        var hasStrokeThicknessExportFlag = function(item) {
            try {
                if (!item) return false;
                if (tools.getStrokeThicknessExport(item.name)) return true;
                var note = String(item.note || "");
                return note.match(new RegExp("(^|\\n)" + STROKE_EXPORT_NOTE_KEY + "=1(\\n|$)")) !== null;
            } catch(e) {}
            return false;
        };

        var findStrokeThicknessExportOwner = function(item) {
            var node = item;
            var guard = 0;
            while (node && guard < 20) {
                try {
                    if (node.typename === "Layer" || node.typename === "Document") break;
                    if (hasStrokeThicknessExportFlag(node)) return node;
                    node = node.parent;
                } catch(e) {
                    break;
                }
                guard++;
            }
            return null;
        };

        var findStrokeThicknessDepthOwner = function(item) {
            var node = item;
            var guard = 0;
            while (node && guard < 20) {
                try {
                    if (node.typename === "Layer" || node.typename === "Document") break;
                    if (parseStrokeThicknessDepthMm(node) !== null) return node;
                    node = node.parent;
                } catch(e) {
                    break;
                }
                guard++;
            }
            return null;
        };

        var hasStrokeThicknessCandidate = function(item) {
            try {
                return !!findStrokeReadablePath(item);
            } catch(e) {}
            return false;
        };

        var setStrokeThicknessExportFlag = function(item, enabled) {
            if (!item) return false;
            try {
                var note = String(item.note || "");
                var lines = note ? note.split(/\r?\n/) : [];
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].indexOf(STROKE_EXPORT_NOTE_KEY + "=") === 0) continue;
                    if (lines[i] !== "") kept.push(lines[i]);
                }
                if (enabled) kept.push(STROKE_EXPORT_NOTE_KEY + "=1");
                item.note = kept.join("\n");
                return true;
            } catch(e) {}
            return false;
        };

        var hasNoteFlag = function(item, key) {
            try {
                if (!item || !key) return false;
                var note = String(item.note || "");
                return note.match(new RegExp("(^|\\n)" + key + "=1(\\n|$)")) !== null;
            } catch(e) {}
            return false;
        };

        var setNoteFlag = function(item, key, enabled) {
            if (!item || !key) return false;
            try {
                var note = String(item.note || "");
                var lines = note ? note.split(/\r?\n/) : [];
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].indexOf(key + "=") === 0) continue;
                    if (lines[i] !== "") kept.push(lines[i]);
                }
                if (enabled) kept.push(key + "=1");
                item.note = kept.join("\n");
                return true;
            } catch(e) {}
            return false;
        };

        var hasSkipExportFlag = function(item) {
            return hasNoteFlag(item, SKIP_EXPORT_NOTE_KEY);
        };

        var setSkipExportFlag = function(item, enabled) {
            return setNoteFlag(item, SKIP_EXPORT_NOTE_KEY, enabled);
        };

        var setStrokeThicknessDepthMm = function(item, depthMm) {
            if (!item) return false;
            var value = parseFloat(depthMm);
            if (isNaN(value) || value <= 0) return false;
            var cleanValue = Math.round(value * 100) / 100;
            try {
                var note = String(item.note || "");
                var lines = note ? note.split(/\r?\n/) : [];
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].indexOf(STROKE_DEPTH_NOTE_KEY + "=") === 0) continue;
                    if (lines[i] !== "") kept.push(lines[i]);
                }
                kept.push(STROKE_DEPTH_NOTE_KEY + "=" + cleanValue);
                item.note = kept.join("\n");
                return true;
            } catch(e) {}
            return false;
        };

        var formatStrokeThicknessDepthMm = function(depthMm) {
            var v = parseFloat(depthMm);
            if (isNaN(v)) return "未设置";
            if (Math.abs(v - Math.round(v)) < 0.001) return Math.round(v) + "mm";
            return v.toFixed(2).replace(/0+$/, "").replace(/\.$/, "") + "mm";
        };

        var readStrokeThicknessDepthInfo = function() {
            if (!originalSel || originalSel.length === 0) {
                return "STROKE_DEPTH_INFO:描边厚度导出厚度：未设置";
            }
            var firstValue = null;
            var hasValue = false;
            var unsetCount = 0;
            var mixed = false;
            for (var i = 0; i < originalSel.length; i++) {
                var value = parseStrokeThicknessDepthMm(originalSel[i]);
                if (value === null) {
                    unsetCount++;
                    continue;
                }
                if (!hasValue) {
                    firstValue = value;
                    hasValue = true;
                } else if (Math.abs(firstValue - value) > 0.001) {
                    mixed = true;
                }
            }
            if (!hasValue) return "STROKE_DEPTH_INFO:描边厚度导出厚度：未设置";
            if (unsetCount > 0 && originalSel.length > 1) mixed = true;
            if (mixed) return "STROKE_DEPTH_INFO:描边厚度导出厚度：多个不同厚度";
            return "STROKE_DEPTH_INFO:描边厚度导出厚度：" + formatStrokeThicknessDepthMm(firstValue);
        };

        var removeStrokeThicknessPreview = function() {
            var removed = false;
            for (var spl = doc.layers.length - 1; spl >= 0; spl--) {
                try {
                    if (doc.layers[spl].name === STROKE_PREVIEW_LAYER) {
                        doc.layers[spl].locked = false;
                        doc.layers[spl].visible = true;
                        doc.layers[spl].remove();
                        removed = true;
                    }
                } catch(e) {}
            }
            return removed;
        };

        var getOrCreateStrokePreviewLayer = function() {
            removeStrokeThicknessPreview();
            var layer = doc.layers.add();
            layer.name = STROKE_PREVIEW_LAYER;
            layer.locked = false;
            layer.visible = true;
            return layer;
        };

        var getColorTypeName = function(color) {
            try {
                if (!color) return "None";
                return color.typename || "Unknown";
            } catch(e) {
                return "Unknown";
            }
        };

        var isStrokeReadablePath = function(item) {
            try {
                return item && item.typename === "PathItem" && (item.stroked || item.clipping) && item.strokeWidth > 0;
            } catch(e) {
                return false;
            }
        };

        var collectStrokeReadablePaths = function(item) {
            var paths = [];
            var seen = [];
            var addPath = function(path) {
                if (!path) return;
                try {
                    if (path.guides || path.hidden || path.locked) return;
                } catch(skipErr) {}
                if (!isStrokeReadablePath(path)) return;
                for (var s = 0; s < seen.length; s++) {
                    try { if (seen[s] === path) return; } catch(seenErr) {}
                }
                seen.push(path);
                paths.push(path);
            };
            var walk = function(node) {
                if (!node) return;
                try {
                    if (node.hidden || node.locked) return;
                } catch(hiddenErr) {}
                try {
                    if (node.typename === "PathItem") {
                        addPath(node);
                    } else if (node.typename === "CompoundPathItem" && node.pathItems) {
                        for (var cpi = 0; cpi < node.pathItems.length; cpi++) walk(node.pathItems[cpi]);
                    } else if (node.typename === "GroupItem" && node.pageItems) {
                        for (var gi = 0; gi < node.pageItems.length; gi++) walk(node.pageItems[gi]);
                    } else if (node.typename === "TextFrame") {
                        var dup = null;
                        try {
                            dup = node.duplicate(doc.layers[0], ElementPlacement.PLACEATBEGINNING);
                            var outline = dup.createOutline();
                            walk(outline);
                            try { outline.remove(); } catch(removeOutlineErr) {}
                        } catch(textOutlineErr) {
                            try { if (dup) dup.remove(); } catch(removeDupErr) {}
                        }
                    }
                } catch(e) {}
            };
            walk(item);
            return paths;
        };

        var strokeReadablePathDebug = function(paths) {
            var parts = [];
            if (!paths) return "";
            for (var i = 0; i < paths.length; i++) {
                try {
                    var pp = paths[i].pathPoints ? paths[i].pathPoints.length : 0;
                    parts.push(String(pp));
                } catch(e) {
                    parts.push("err");
                }
            }
            return parts.join(",");
        };

        var countAllPathItemsForDebug = function(item) {
            var count = 0;
            var walk = function(node) {
                if (!node) return;
                try {
                    if (node.typename === "PathItem") {
                        count++;
                    } else if (node.typename === "CompoundPathItem" && node.pathItems) {
                        for (var cpi = 0; cpi < node.pathItems.length; cpi++) walk(node.pathItems[cpi]);
                    } else if (node.typename === "GroupItem" && node.pageItems) {
                        for (var gi = 0; gi < node.pageItems.length; gi++) walk(node.pageItems[gi]);
                    }
                } catch(e) {}
            };
            walk(item);
            return count;
        };

        var countAllPathItemsInItemsForDebug = function(items) {
            var count = 0;
            if (!items) return count;
            for (var i = 0; i < items.length; i++) {
                count += countAllPathItemsForDebug(items[i]);
            }
            return count;
        };

        var findStrokeReadablePath = function(item) {
            if (!item) return null;
            try {
                if (isStrokeReadablePath(item)) return item;
                var paths = collectStrokeReadablePaths(item);
                if (paths && paths.length > 0) return paths[0];
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        if (isStrokeReadablePath(item.pathItems[cpi])) return item.pathItems[cpi];
                    }
                }
                if (item.typename === "GroupItem") {
                    for (var gi = 0; gi < item.pageItems.length; gi++) {
                        var found = findStrokeReadablePath(item.pageItems[gi]);
                        if (found) return found;
                    }
                }
            } catch(e) {}
            return null;
        };

        var hasVisibleStrokePath = function(item) {
            try {
                if (!item || item.typename !== "PathItem") return false;
                if (!item.stroked) return false;
                if (!item.strokeColor || item.strokeColor.typename === "NoColor") return false;
                if (Number(item.strokeWidth || 0) <= 0) return false;
                return true;
            } catch(e) {}
            return false;
        };

        var boundsArea = function(bounds) {
            try {
                if (!bounds || bounds.length < 4) return 0;
                return Math.abs((bounds[2] - bounds[0]) * (bounds[1] - bounds[3]));
            } catch(e) {}
            return 0;
        };

        var boundsOverlapRatio = function(a, b) {
            try {
                if (!a || !b || a.length < 4 || b.length < 4) return 0;
                var left = Math.max(a[0], b[0]);
                var right = Math.min(a[2], b[2]);
                var top = Math.min(a[1], b[1]);
                var bottom = Math.max(a[3], b[3]);
                var w = right - left;
                var h = top - bottom;
                if (w <= 0 || h <= 0) return 0;
                var inter = Math.abs(w * h);
                var denom = Math.max(Math.min(boundsArea(a), boundsArea(b)), 0.001);
                return inter / denom;
            } catch(e) {}
            return 0;
        };

        var findDirectClippingPath = function(group) {
            if (!group || group.typename !== "GroupItem") return null;
            try {
                for (var i = 0; i < group.pageItems.length; i++) {
                    if (group.pageItems[i].typename === "PathItem" && group.pageItems[i].clipping === true) return group.pageItems[i];
                }
                for (var j = 0; j < group.pageItems.length; j++) {
                    var child = group.pageItems[j];
                    if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0 && child.pathItems[0].clipping) {
                        return child.pathItems[0];
                    }
                }
            } catch(e) {}
            return null;
        };

        var findStrokePathForClippingGroup = function(item) {
            if (!item || item.typename !== "GroupItem" || !item.clipped) return findStrokeReadablePath(item);
            var clipPath = findDirectClippingPath(item);
            if (clipPath && hasVisibleStrokePath(clipPath)) return clipPath;
            var clipBounds = null;
            try { if (clipPath && clipPath.geometricBounds) clipBounds = clipPath.geometricBounds; } catch(e0) {}
            var bestPath = null;
            var bestScore = -1;
            try {
                for (var i = 0; i < item.pageItems.length; i++) {
                    var child = item.pageItems[i];
                    var path = null;
                    if (child.typename === "PathItem") {
                        path = child;
                    } else if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0) {
                        for (var cpi = 0; cpi < child.pathItems.length; cpi++) {
                            if (hasVisibleStrokePath(child.pathItems[cpi])) {
                                path = child.pathItems[cpi];
                                break;
                            }
                        }
                    }
                    if (!hasVisibleStrokePath(path)) continue;
                    if (path.clipping === true) continue;
                    var score = 0;
                    try {
                        if (clipBounds && path.geometricBounds) {
                            score = boundsOverlapRatio(clipBounds, path.geometricBounds);
                        } else {
                            score = boundsArea(path.geometricBounds);
                        }
                    } catch(e1) {}
                    if (clipBounds && score < 0.8) continue;
                    if (score > bestScore) {
                        bestScore = score;
                        bestPath = path;
                    }
                }
            } catch(e2) {}
            return bestPath || clipPath;
        };

        var getStrokeFillRgb = function(item) {
            try {
                var path = findStrokeReadablePath(item);
                if (path && path.filled && path.fillColor) {
                    var fill = tools.parseColor(path.fillColor);
                    if (fill) return fill;
                }
            } catch(e) {}
            try {
                return tools.findDeepColor(item) || [128, 128, 128];
            } catch(e2) {}
            return [128, 128, 128];
        };

        var hasEffectiveFillColor = function(item) {
            if (!item) return false;
            try {
                if (item.typename === "PathItem") {
                    if (!item.filled) return false;
                    if (!item.fillColor || item.fillColor.typename === "NoColor") return false;
                    return true;
                }
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        if (hasEffectiveFillColor(item.pathItems[cpi])) return true;
                    }
                    return false;
                }
                if (item.typename === "GroupItem") {
                    for (var gi = 0; gi < item.pageItems.length; gi++) {
                        if (hasEffectiveFillColor(item.pageItems[gi])) return true;
                    }
                    return false;
                }
            } catch(e) {}
            return false;
        };

        var hasTextureLikeFillSource = function(item) {
            if (!item) return false;
            try {
                if (item.typename === "RasterItem" || item.typename === "PlacedItem" || item.typename === "MeshItem") return true;
                if (item.typename === "PathItem") {
                    if (item.filled && item.fillColor) {
                        var ft = item.fillColor.typename || "";
                        if (ft === "GradientColor" || ft === "PatternColor") return true;
                    }
                    return false;
                }
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        if (hasTextureLikeFillSource(item.pathItems[cpi])) return true;
                    }
                    return false;
                }
                if (item.typename === "GroupItem") {
                    if (item.clipped && containsAnyRasterDescendant(item)) return true;
                    for (var gi = 0; gi < item.pageItems.length; gi++) {
                        if (hasTextureLikeFillSource(item.pageItems[gi])) return true;
                    }
                    return false;
                }
            } catch(e) {}
            return false;
        };

        var findTextureLikeDescendant = function(item) {
            if (!item) return null;
            try {
                if (item.typename === "RasterItem" || item.typename === "PlacedItem" || item.typename === "MeshItem") return item;
                if (item.typename === "PathItem") {
                    if (item.filled && item.fillColor) {
                        var ft = item.fillColor.typename || "";
                        if (ft === "GradientColor" || ft === "PatternColor") return item;
                    }
                    return null;
                }
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        var cpFound = findTextureLikeDescendant(item.pathItems[cpi]);
                        if (cpFound) return cpFound;
                    }
                    return null;
                }
                if (item.typename === "GroupItem") {
                    for (var gi = 0; gi < item.pageItems.length; gi++) {
                        var found = findTextureLikeDescendant(item.pageItems[gi]);
                        if (found) return item.clipped ? item : found;
                    }
                }
            } catch(e) {}
            return null;
        };

        var hasClippingPathDescendant = function(item) {
            if (!item) return false;
            try {
                if (item.typename === "PathItem") {
                    return !!item.clipping;
                }
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        if (hasClippingPathDescendant(item.pathItems[cpi])) return true;
                    }
                    return false;
                }
                if (item.typename === "GroupItem") {
                    if (item.clipped) return true;
                    for (var gi = 0; gi < item.pageItems.length; gi++) {
                        if (hasClippingPathDescendant(item.pageItems[gi])) return true;
                    }
                    return false;
                }
            } catch(e) {}
            return false;
        };

        var isClippingTextureSource = function(item) {
            if (!item) return false;
            try {
                if (item.typename === "GroupItem" && (item.clipped || hasClippingPathDescendant(item))) return true;
            } catch(e) {}
            return false;
        };

        var isSolidFillColor = function(color) {
            try {
                if (!color) return false;
                var t = color.typename || "";
                return t === "RGBColor" || t === "CMYKColor" || t === "GrayColor";
            } catch(e) {}
            return false;
        };

        var findClippingGroupOwner = function(item) {
            var node = item;
            var guard = 0;
            while (node && guard < 20) {
                try {
                    if (node.typename === "Layer" || node.typename === "Document") break;
                    if (node.typename === "GroupItem" && (node.clipped || hasClippingPathDescendant(node))) return node;
                    node = node.parent;
                } catch(e) {
                    break;
                }
                guard++;
            }
            return null;
        };

        var detectSolidColorInsideClippingGroup = function(item) {
            var clipGroup = findClippingGroupOwner(item);
            if (!clipGroup) return null;
            var best = null;
            var scan = function(node, depth) {
                if (!node || depth > 30) return;
                try {
                    if (node.hidden || node.locked) return;
                } catch(hiddenErr) {}
                try {
                    if (node.typename === "PathItem") {
                        if (node.clipping) return;
                        if (!node.filled || !node.fillColor || !isSolidFillColor(node.fillColor)) return;
                        var rgb = tools.parseColor(node.fillColor);
                        if (!rgb) return;
                        var area = 0;
                        try {
                            var b = node.visibleBounds || node.geometricBounds;
                            area = Math.abs((b[2] - b[0]) * (b[1] - b[3]));
                        } catch(areaErr) {}
                        if (!best || area >= best.area) best = { color: rgb, area: area };
                        return;
                    }
                    if (node.typename === "CompoundPathItem") {
                        for (var cpi = 0; cpi < node.pathItems.length; cpi++) scan(node.pathItems[cpi], depth + 1);
                        return;
                    }
                    if (node.typename === "GroupItem") {
                        for (var gi = 0; gi < node.pageItems.length; gi++) scan(node.pageItems[gi], depth + 1);
                        return;
                    }
                } catch(e) {}
            };
            scan(clipGroup, 0);
            return best ? best.color : null;
        };

        var collectSolidColorRectsInsideClippingGroup = function(item) {
            var clipGroup = findClippingGroupOwner(item);
            var rects = [];
            if (!clipGroup) return rects;
            var scan = function(node, depth) {
                if (!node || depth > 30) return;
                try {
                    if (node.hidden || node.locked) return;
                } catch(hiddenErr) {}
                try {
                    if (node.typename === "PathItem") {
                        if (node.clipping) return;
                        if (!node.filled || !node.fillColor || !isSolidFillColor(node.fillColor)) return;
                        var rgb = tools.parseColor(node.fillColor);
                        if (!rgb) return;
                        var b = null;
                        try { b = node.geometricBounds || node.visibleBounds; } catch(boundsErr) {}
                        if (!b || b.length < 4) return;
                        if (b[2] <= b[0] || b[1] <= b[3]) return;
                        rects.push({ color: rgb, bounds: [b[0], b[1], b[2], b[3]] });
                        return;
                    }
                    if (node.typename === "CompoundPathItem") {
                        for (var cpi = 0; cpi < node.pathItems.length; cpi++) scan(node.pathItems[cpi], depth + 1);
                        return;
                    }
                    if (node.typename === "GroupItem") {
                        for (var gi = 0; gi < node.pageItems.length; gi++) scan(node.pageItems[gi], depth + 1);
                        return;
                    }
                } catch(e) {}
            };
            scan(clipGroup, 0);
            return rects;
        };

        var findStrokeFillTextureSource = function(item) {
            var node = item;
            var guard = 0;
            while (node && guard < 20) {
                try {
                    if (node.typename === "Layer" || node.typename === "Document") break;
                    if (isClippingTextureSource(node)) return node;
                    if (findTextureLikeDescendant(node)) return node;
                    node = node.parent;
                } catch(e) {
                    break;
                }
                guard++;
            }
            return null;
        };

        var disableStrokesRecursive = function(item) {
            if (!item) return;
            try {
                if (item.typename === "PathItem") {
                    item.stroked = false;
                    return;
                }
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        try { item.pathItems[cpi].stroked = false; } catch(e0) {}
                    }
                    return;
                }
                if (item.typename === "GroupItem") {
                    for (var gi = 0; gi < item.pageItems.length; gi++) {
                        disableStrokesRecursive(item.pageItems[gi]);
                    }
                }
            } catch(e) {}
        };

        var getStrokeStrokeRgb = function(item) {
            try {
                var path = findStrokeReadablePath(item);
                if (path && path.strokeColor) {
                    var stroke = tools.parseColor(path.strokeColor);
                    if (stroke) return stroke;
                }
            } catch(e) {}
            return [0, 0, 0];
        };

        var collectPreviewTargets = function(item, out) {
            if (!item) return out;
            try {
                if (item.typename === "PathItem") {
                    out.push(item);
                } else if (item.typename === "CompoundPathItem" || item.typename === "GroupItem") {
                    out.push(item);
                }
            } catch(e) {}
            return out;
        };

	        var detectStrokeAlignment = function(path) {
            var rawValue = null;
            var rawAvailable = false;
            var rawType = "unavailable";
            var rawString = "unavailable";
            var rawNumber = "NaN";
            var alignment = "unknown";
            var alignmentKnown = false;
            var alignmentUnknownReason = "";
            var method = "none";
            var boundsExpansion = "unavailable";
            var enumDebug = "StrokeAlignment unavailable";

            try {
                rawValue = path.strokeAlignment;
                rawAvailable = true;
                rawType = typeof rawValue;
                rawString = String(rawValue);
                var n = Number(rawValue);
                if (!isNaN(n)) rawNumber = String(n);
            } catch(e) {
                rawString = "unavailable: " + e.message;
            }
            var rawTrim = String(rawString || "").replace(/^\s+|\s+$/g, "");
            var rawIsUndefined =
                rawValue === undefined ||
                rawValue === null ||
                rawTrim === "" ||
                rawTrim.toLowerCase() === "undefined" ||
                rawTrim.toLowerCase() === "null" ||
                rawTrim.indexOf("unavailable") === 0;

            var upper = String(rawString || "").toUpperCase();
            if (upper.indexOf("INSIDE") !== -1 || upper.indexOf("内") !== -1) {
                alignment = "inside";
                alignmentKnown = true;
                method = "rawString";
            } else if (upper.indexOf("OUTSIDE") !== -1 || upper.indexOf("外") !== -1) {
                alignment = "outside";
                alignmentKnown = true;
                method = "rawString";
            } else if (upper.indexOf("CENTER") !== -1 || upper.indexOf("CENTRE") !== -1 || upper.indexOf("居") !== -1) {
                alignment = "center";
                alignmentKnown = true;
                method = "rawString";
            }

            var compareEnum = function(propName, target) {
                try {
                    if (typeof StrokeAlignment !== "undefined" && StrokeAlignment[propName] !== undefined) {
                        if (enumDebug === "StrokeAlignment unavailable") enumDebug = "";
                        enumDebug += propName + "=" + String(StrokeAlignment[propName]) + ";";
                        if (rawAvailable && rawValue === StrokeAlignment[propName]) {
                            alignment = target;
                            alignmentKnown = true;
                            method = "StrokeAlignment." + propName;
                        }
                    }
                } catch(e) {}
            };
            if (alignment === "unknown") {
                compareEnum("INSIDEALIGNMENT", "inside");
                compareEnum("INSIDE", "inside");
                compareEnum("OUTSIDEALIGNMENT", "outside");
                compareEnum("OUTSIDE", "outside");
                compareEnum("CENTERALIGNMENT", "center");
                compareEnum("CENTER", "center");
            }

            if (alignment === "unknown") {
                try {
                    var gb = path.geometricBounds;
                    var vb = path.visibleBounds;
                    var sw = Number(path.strokeWidth || 0);
                    var exps = [
                        Math.abs(gb[0] - vb[0]),
                        Math.abs(vb[1] - gb[1]),
                        Math.abs(vb[2] - gb[2]),
                        Math.abs(gb[3] - vb[3])
                    ];
                    var avg = (exps[0] + exps[1] + exps[2] + exps[3]) / 4.0;
                    boundsExpansion = "avg=" + avg.toFixed(3) + "pt; strokeWidth=" + sw.toFixed(3) + "pt; deltas=" + [
                        exps[0].toFixed(3),
                        exps[1].toFixed(3),
                        exps[2].toFixed(3),
                        exps[3].toFixed(3)
                    ].join(",");
                    if (sw > 0) {
                        var ratio = avg / sw;
                        if (ratio <= 0.25) {
                            alignment = "inside";
                            alignmentKnown = true;
                            method = "boundsExpansion";
                        } else if (ratio >= 0.75) {
                            alignment = "outside";
                            alignmentKnown = true;
                            method = "boundsExpansion";
                        } else {
                            if (rawIsUndefined) {
                                alignment = "unknown";
                                alignmentKnown = false;
                                alignmentUnknownReason = "undefined_alignment_center_bounds";
                                method = "boundsExpansionUnknown";
                            } else {
                                alignment = "center";
                                alignmentKnown = true;
                                method = "boundsExpansion";
                            }
                        }
                    }
                } catch(boundsErr) {
                    boundsExpansion = "unavailable: " + boundsErr.message;
                }
            }

            if (alignment === "unknown" && rawNumber !== "NaN") {
                var rawNum = parseInt(rawNumber, 10);
                if (rawNum === 0) alignment = "center";
                else if (rawNum === 1) alignment = "inside";
                else if (rawNum === 2 || rawNum === 3) alignment = "outside";
                if (alignment !== "unknown") {
                    alignmentKnown = true;
                    method = "numericFallback";
                }
            }
            if (!alignmentKnown && !alignmentUnknownReason) alignmentUnknownReason = rawIsUndefined ? "undefined_alignment" : "unknown_alignment";

            return {
                kind: alignment,
                alignment: alignment,
                alignmentKnown: alignmentKnown,
                alignmentUnknownReason: alignmentUnknownReason,
                raw: rawString,
                rawType: rawType,
                rawString: rawString,
                rawNumber: rawNumber,
                method: method,
                boundsExpansion: boundsExpansion,
                enumDebug: enumDebug
	            };
	        };

	        var enrichStrokeAlignmentDebug = function(result, sourceType, sourceItem, paths, candidates, fallbackUsed, fallbackReason, unknownCandidateCount, groupInfo) {
	            if (!result) result = {};
	            result.alignmentSourceType = sourceType || "";
	            try { result.alignmentSourceItemName = sourceItem && sourceItem.name ? String(sourceItem.name) : ""; } catch(e0) { result.alignmentSourceItemName = ""; }
	            try { result.alignmentSourceTypename = sourceItem && sourceItem.typename ? String(sourceItem.typename) : ""; } catch(e1) { result.alignmentSourceTypename = ""; }
	            result.alignmentSourcePathCount = paths ? paths.length : 0;
	            result.alignmentCandidateCount = candidates ? candidates.length : 0;
	            result.alignmentKnown = !!(result.kind && result.kind !== "unknown" && result.alignmentKnown !== false);
	            result.alignmentKnownCandidateCount = candidates ? candidates.length : 0;
	            result.alignmentUnknownCandidateCount = unknownCandidateCount || 0;
	            var vals = [];
	            var raws = [];
	            if (candidates) {
	                for (var i = 0; i < candidates.length; i++) {
	                    try { vals.push(String(candidates[i].kind || candidates[i].alignment || "unknown")); } catch(vErr) { vals.push("unknown"); }
	                    try { raws.push(String(candidates[i].raw || candidates[i].rawString || "unavailable")); } catch(rErr) { raws.push("unavailable"); }
	                }
	            }
	            result.alignmentCandidateResolvedValues = vals.join(",");
	            result.alignmentCandidateRawValues = raws.join("|");
	            result.alignmentResolvedFromChildPath = sourceType === "childPathItem" || sourceType === "childPathMajority" || sourceType === "childPathPreferred";
	            result.alignmentResolvedFromGroupChildren = sourceType === "childPathMajority" || sourceType === "childPathPreferred";
	            result.alignmentInheritedFromGroup = !!(groupInfo && groupInfo.inherited);
	            result.alignmentGroupResolvedValue = groupInfo && groupInfo.value ? groupInfo.value : "";
	            result.alignmentGroupKnownCandidateCount = groupInfo && groupInfo.knownCount ? groupInfo.knownCount : 0;
	            result.alignmentGroupUnknownCandidateCount = groupInfo && groupInfo.unknownCount ? groupInfo.unknownCount : 0;
	            result.alignmentFinalDecisionReason = groupInfo && groupInfo.reason ? groupInfo.reason : (fallbackUsed ? (fallbackReason || "fallback") : sourceType || "");
	            result.alignmentFallbackUsed = !!fallbackUsed;
	            result.alignmentFallbackReason = fallbackReason || "";
	            return result;
	        };

	        var cloneStrokeAlignmentWithGroupInheritance = function(base, groupAlignment) {
	            if (!groupAlignment || !groupAlignment.kind || groupAlignment.kind === "unknown") return base;
	            var out = {};
	            for (var k in (base || {})) {
	                try { out[k] = base[k]; } catch(copyErr) {}
	            }
	            out.kind = groupAlignment.kind;
	            out.alignment = groupAlignment.kind;
	            out.alignmentKnown = true;
	            out.raw = base && base.raw ? base.raw : "inherited";
	            out.rawString = out.raw;
	            out.rawType = base && base.rawType ? base.rawType : "inherited";
	            out.method = "groupInherited";
	            out.alignmentFallbackUsed = false;
	            out.alignmentFallbackReason = "";
	            out.alignmentInheritedFromGroup = true;
	            out.alignmentGroupResolvedValue = groupAlignment.kind;
	            out.alignmentGroupKnownCandidateCount = groupAlignment.alignmentKnownCandidateCount || groupAlignment.alignmentCandidateCount || 0;
	            out.alignmentGroupUnknownCandidateCount = groupAlignment.alignmentUnknownCandidateCount || 0;
	            out.alignmentFinalDecisionReason = "inherited_from_group_majority";
	            out.alignmentSourceType = "groupInherited";
	            return out;
	        };

	        var getStrokeAlignmentFromSource = function(source) {
	            var unknown = {
	                kind: "unknown",
	                alignment: "unknown",
	                raw: "unavailable",
	                rawType: "unavailable",
	                rawString: "unavailable",
	                rawNumber: "NaN",
	                method: "none",
	                boundsExpansion: "unavailable",
	                enumDebug: ""
	            };
	            try {
	                if (source && source.typename === "PathItem" && isStrokeReadablePath(source)) {
	                    var own = detectStrokeAlignment(source);
	                    if (own && own.kind && own.kind !== "unknown") {
	                        return enrichStrokeAlignmentDebug(own, "sourcePathItem", source, [source], [own], false, "");
	                    }
	                }
	            } catch(ownErr) {}

	            var paths = [];
	            var candidates = [];
	            var unknownCandidateCount = 0;
	            try { paths = collectStrokeReadablePaths(source) || []; } catch(e0) { paths = []; }
	            for (var i = 0; i < paths.length; i++) {
	                try {
	                    var a = detectStrokeAlignment(paths[i]);
	                    if (a && a.alignmentKnown && a.kind && a.kind !== "unknown") {
	                        a._sourcePath = paths[i];
	                        candidates.push(a);
	                    } else {
	                        unknownCandidateCount++;
	                    }
	                } catch(pathAlignErr) {}
	            }

	            if (candidates.length > 0) {
	                var preferred = null;
	                for (var p = 0; p < candidates.length; p++) {
	                    if (candidates[p].method && candidates[p].method !== "boundsExpansion" && candidates[p].method !== "none") {
	                        preferred = candidates[p];
	                        break;
	                    }
	                }
	                if (!preferred) {
	                    var counts = { inside: 0, outside: 0, center: 0 };
	                    for (var c = 0; c < candidates.length; c++) {
	                        if (counts[candidates[c].kind] !== undefined) counts[candidates[c].kind]++;
	                    }
	                    var majorityKind = "center";
	                    if (counts.inside >= counts.outside && counts.inside >= counts.center && counts.inside > 0) majorityKind = "inside";
	                    else if (counts.outside >= counts.inside && counts.outside >= counts.center && counts.outside > 0) majorityKind = "outside";
	                    else if (counts.center > 0) majorityKind = "center";
	                    for (var m = 0; m < candidates.length; m++) {
	                        if (candidates[m].kind === majorityKind) {
	                            preferred = candidates[m];
	                            break;
	                        }
	                    }
	                }
	                if (preferred) {
	                    var sourceType = candidates.length > 1 ? "childPathMajority" : "childPathItem";
	                    if (preferred.method && preferred.method !== "boundsExpansion" && preferred.method !== "none") sourceType = "childPathPreferred";
	                    return enrichStrokeAlignmentDebug(preferred, sourceType, preferred._sourcePath || source, paths, candidates, false, "", unknownCandidateCount, null);
	                }
	            }

	            try {
	                var path = findStrokeReadablePath(source);
	                if (path) {
	                    var direct = detectStrokeAlignment(path);
	                    if (direct && direct.alignmentKnown && direct.kind && direct.kind !== "unknown") {
	                        return enrichStrokeAlignmentDebug(direct, "directPathFallback", path, paths, candidates.length ? candidates : [direct], false, "", unknownCandidateCount, null);
	                    }
	                }
	            } catch(e1) {}
	            return enrichStrokeAlignmentDebug(unknown, "none", source, paths, candidates, true, "no_alignment_found", unknownCandidateCount, null);
	        };

	        var alignmentLabel = function(kind) {
            if (kind === "outside") return "外对齐";
            if (kind === "inside") return "内对齐";
            if (kind === "center") return "居中";
            return "未知，默认按居中处理";
        };

        var clearPreviewAppearance = function(item) {
            try {
                if (item.typename === "PathItem") {
                    item.filled = false;
                    item.stroked = false;
                } else if (item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) clearPreviewAppearance(item.pageItems[i]);
                } else if (item.pathItems) {
                    for (var j = 0; j < item.pathItems.length; j++) clearPreviewAppearance(item.pathItems[j]);
                }
            } catch(e) {}
        };

        var clearClippingFlagRecursive = function(item) {
            if (!item) return;
            try {
                if (item.typename === "PathItem") {
                    item.clipping = false;
                    return;
                }
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        try { item.pathItems[cpi].clipping = false; } catch(e0) {}
                    }
                    return;
                }
                if (item.typename === "GroupItem") {
                    item.clipped = false;
                    for (var gi = 0; gi < item.pageItems.length; gi++) clearClippingFlagRecursive(item.pageItems[gi]);
                }
            } catch(e) {}
        };

        var styleOutlinePreviewItem = function(item, color) {
            try {
                if (item.typename === "PathItem") {
                    item.filled = false;
                    item.stroked = true;
                    item.strokeColor = color;
                    item.strokeWidth = 2;
                } else if (item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) styleOutlinePreviewItem(item.pageItems[i], color);
                } else if (item.pathItems) {
                    for (var j = 0; j < item.pathItems.length; j++) styleOutlinePreviewItem(item.pathItems[j], color);
                }
            } catch(e) {}
        };

        var styleFillPreviewItem = function(item, color) {
            try {
                if (item.typename === "PathItem") {
                    item.filled = true;
                    item.fillColor = color;
                    item.stroked = false;
                } else if (item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) styleFillPreviewItem(item.pageItems[i], color);
                } else if (item.pathItems) {
                    for (var j = 0; j < item.pathItems.length; j++) styleFillPreviewItem(item.pathItems[j], color);
                }
            } catch(e) {}
        };

        var cleanSplitPreviewObject = function(item, isRoot) {
            var stats = { removedHelperPathCount: 0, removedInvisiblePathCount: 0 };
            var mergeStats = function(childStats) {
                if (!childStats) return;
                stats.removedHelperPathCount += childStats.removedHelperPathCount || 0;
                stats.removedInvisiblePathCount += childStats.removedInvisiblePathCount || 0;
            };
            var hasHelperName = function(node) {
                try {
                    var n = String(node.name || "").toLowerCase();
                    return n.indexOf("temp") !== -1 ||
                        n.indexOf("helper") !== -1 ||
                        n.indexOf("outer") !== -1 ||
                        n.indexOf("bounds") !== -1 ||
                        n.indexOf("mask") !== -1 ||
                        n.indexOf("subtract") !== -1 ||
                        n.indexOf("stroke") !== -1 ||
                        n.indexOf("ring") !== -1;
                } catch(e) {}
                return false;
            };
            var hasValidGeometryPath = function(pathItem) {
                try {
                    if (!pathItem || pathItem.typename !== "PathItem") return false;
                    if (!pathItem.pathPoints || pathItem.pathPoints.length < 3) return false;
                    var b = pathItem.geometricBounds;
                    if (!b || b.length < 4) return false;
                    var w = Math.abs(b[2] - b[0]);
                    var h = Math.abs(b[1] - b[3]);
                    return w > 0.01 && h > 0.01;
                } catch(e) {}
                return false;
            };
            var hasValidGeometryTree = function(node) {
                if (!node) return false;
                try {
                    if (node.typename === "PathItem") return hasValidGeometryPath(node);
                    if (node.typename === "CompoundPathItem" && node.pathItems) {
                        for (var cpi = 0; cpi < node.pathItems.length; cpi++) {
                            if (hasValidGeometryTree(node.pathItems[cpi])) return true;
                        }
                        return false;
                    }
                    if (node.typename === "GroupItem" && node.pageItems) {
                        for (var gi = 0; gi < node.pageItems.length; gi++) {
                            if (hasValidGeometryTree(node.pageItems[gi])) return true;
                        }
                    }
                } catch(e) {}
                return false;
            };
            var isInvisiblePath = function(pathItem) {
                try { if (pathItem.hidden) return true; } catch(e0) {}
                try { if (Number(pathItem.opacity) <= 0) return true; } catch(e1) {}
                try {
                    var filled = !!pathItem.filled;
                    var stroked = !!pathItem.stroked;
                    if (!filled && !stroked && !hasValidGeometryPath(pathItem)) return true;
                } catch(e2) {}
                return false;
            };
            try {
                if (!item) return stats;
                if (!isRoot && hasHelperName(item) && !hasValidGeometryTree(item)) {
                    try { item.remove(); stats.removedHelperPathCount++; } catch(removeHelperErr) {}
                    return stats;
                }
                if (item.typename === "PathItem") {
                    if (!isRoot && isInvisiblePath(item)) {
                        try { item.remove(); stats.removedInvisiblePathCount++; } catch(removeInvisibleErr) {}
                    }
                    return stats;
                }
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = item.pathItems.length - 1; cpi >= 0; cpi--) {
                        mergeStats(cleanSplitPreviewObject(item.pathItems[cpi], false));
                    }
                    var hasFilledPath = false;
                    try {
                        for (var cpi2 = 0; cpi2 < item.pathItems.length; cpi2++) {
                            if (item.pathItems[cpi2].filled) {
                                hasFilledPath = true;
                                break;
                            }
                        }
                    } catch(e3) {}
                    if (!isRoot && !hasFilledPath && !hasValidGeometryTree(item)) {
                        try { item.remove(); stats.removedInvisiblePathCount++; } catch(removeCompoundErr) {}
                    }
                    return stats;
                }
                if (item.pageItems) {
                    for (var pi = item.pageItems.length - 1; pi >= 0; pi--) {
                        mergeStats(cleanSplitPreviewObject(item.pageItems[pi], false));
                    }
                    try {
                        if (!isRoot && item.pageItems.length === 0) {
                            item.remove();
                            stats.removedInvisiblePathCount++;
                        }
                    } catch(e4) {}
                }
            } catch(e5) {}
            return stats;
        };

        var applyOffsetPathEffect = function(item, offsetPt) {
            if (Math.abs(offsetPt) < 0.001) return true;
            var offset = String(offsetPt).replace(/,/g, ".");
            var xmls = [
                '<LiveEffect name="Adobe Offset Path"><Dict data="R mlim 4 R ofst ' + offset + ' I jntp 0 "/></LiveEffect>',
                '<LiveEffect name="Offset Path"><Dict data="R mlim 4 R ofst ' + offset + ' I jntp 0 "/></LiveEffect>'
            ];
            var lastErr = "";
            for (var i = 0; i < xmls.length; i++) {
                try {
                    item.applyEffect(xmls[i]);
                    return true;
                } catch(e) {
                    lastErr = e.message;
                }
            }
            throw new Error(lastErr || "Offset Path Live Effect 不可用");
        };

        var duplicateStrokePreview = function(source, layer, color, offsetPt, label, mode) {
            var dup = source.duplicate(layer, ElementPlacement.PLACEATEND);
            dup.name = label;
            clearClippingFlagRecursive(dup);
            // Offset Path must be applied before adding preview stroke/fill.
            // Applying offset after a 2pt preview stroke can expand from the preview appearance and make outside-aligned strokes too large.
            clearPreviewAppearance(dup);
            applyOffsetPathEffect(dup, offsetPt);
            if (mode === "fill") {
                styleFillPreviewItem(dup, color);
            } else {
                styleOutlinePreviewItem(dup, color);
            }
            if (mode === "fill") {
                cleanSplitPreviewObject(dup, true);
            }
            return dup;
        };

        var prepareStrokeOnlyPreviewItem = function(item, color) {
            try {
                if (item.typename === "PathItem") {
                    item.filled = false;
                    if ((item.stroked || item.clipping) && item.strokeWidth > 0) {
                        item.stroked = true;
                        item.strokeColor = color;
                    } else {
                        item.stroked = false;
                    }
                } else if (item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) prepareStrokeOnlyPreviewItem(item.pageItems[i], color);
                } else if (item.pathItems) {
                    for (var j = 0; j < item.pathItems.length; j++) prepareStrokeOnlyPreviewItem(item.pathItems[j], color);
                }
            } catch(e) {}
        };

        var selectedPreviewItems = function(layer) {
            var items = [];
            try {
                var sel = doc.selection;
                if (!sel) return items;
                for (var i = 0; i < sel.length; i++) {
                    try {
                        if (sel[i] && sel[i].layer && sel[i].layer.name === layer.name) items.push(sel[i]);
                    } catch(e) {}
                }
            } catch(e2) {}
            return items;
        };

        var expandAppearanceSafe = function(item, layer, finalName, finalColor) {
            var expanded = [];
            if (!item) return expanded;
            try {
                try { doc.selection = null; } catch(clearSelErr) {}
                try { item.selected = true; } catch(selectErr) {}
                try { app.executeMenuCommand("expandStyle"); } catch(expandErr) {}
                expanded = selectedPreviewItems(layer);
                if (!expanded || expanded.length === 0) expanded = [item];
                for (var i = 0; i < expanded.length; i++) {
                    try { expanded[i].name = finalName; } catch(nameErr) {}
                    styleFillPreviewItem(expanded[i], finalColor);
                    cleanSplitPreviewObject(expanded[i], true);
                }
            } catch(e) {
                expanded = [item];
            }
            return expanded;
        };

        var expandAppearanceItemsSafe = function(items, layer, finalName, finalColor) {
            var out = [];
            if (!items) return out;
            for (var i = 0; i < items.length; i++) {
                var expanded = expandAppearanceSafe(items[i], layer, finalName, finalColor);
                for (var j = 0; j < expanded.length; j++) out.push(expanded[j]);
            }
            return out;
        };

        var duplicateActualStrokeRegionPreview = function(source, layer, color) {
            var dup = source.duplicate(layer, ElementPlacement.PLACEATEND);
            dup.name = "HH_STROKE_RED_REGION_PREVIEW";
            clearClippingFlagRecursive(dup);
            prepareStrokeOnlyPreviewItem(dup, color);
            try { doc.selection = null; } catch(e0) {}
            try { dup.selected = true; } catch(e1) {}
            try {
                app.executeMenuCommand("Live Outline Stroke");
                app.executeMenuCommand("expandStyle");
            } catch(e2) {
                try { app.executeMenuCommand("expandStyle"); } catch(e3) {}
            }
            var selected = selectedPreviewItems(layer);
            if (selected.length === 0) selected = [dup];
            for (var i = 0; i < selected.length; i++) {
                try {
                    selected[i].name = "HH_STROKE_RED_REGION_PREVIEW";
                    styleFillPreviewItem(selected[i], color);
                    sendPreviewToBack(selected[i]);
                } catch(e4) {}
            }
            return selected;
        };

        var bringPreviewToFront = function(item) {
            try { item.zOrder(ZOrderMethod.BRINGTOFRONT); } catch(e) {}
        };

        var sendPreviewToBack = function(item) {
            try { item.zOrder(ZOrderMethod.SENDTOBACK); } catch(e) {}
        };

        var readStrokeThicknessInfo = function() {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中一个带描边的对象");
                return "STROKE_INFO:请先选中一个带描边的对象";
            }
            var item = originalSel[0];
            var path = findStrokeReadablePath(item);
            if (!path) {
                alert("当前对象没有可读取的描边");
                return "STROKE_INFO:当前对象没有可读取的描边";
            }
            var align = detectStrokeAlignment(path);
            var widthPt = 0;
            try { widthPt = Number(path.strokeWidth || 0); } catch(e) {}
            var widthMm = widthPt * PT_TO_MM;
            var hasFill = false, hasStroke = false;
            try { hasFill = !!path.filled; } catch(e1) {}
            try { hasStroke = !!path.stroked; } catch(e2) {}
            var strokeType = "None", fillType = "None";
            try { strokeType = getColorTypeName(path.strokeColor); } catch(e3) {}
            try { fillType = getColorTypeName(path.fillColor); } catch(e4) {}
            var name = "";
            try { name = item.name || path.name || "(未命名)"; } catch(e5) { name = "(未命名)"; }
            return "STROKE_INFO:" +
                "selectedItemType：" + item.typename +
                "\ndetectedPathType：" + path.typename +
                "\n对象名称：" + name +
                "\npathName：" + (path.name || "(未命名路径)") +
                "\n是否有描边：" + (hasStroke ? "是" : "否") +
                "\n是否有填充：" + (hasFill ? "是" : "否") +
                "\nstroked=" + (hasStroke ? "true" : "false") +
                "\n描边宽度：" + widthPt.toFixed(2) + " pt / " + widthMm.toFixed(2) + " mm" +
                "\n描边对齐：" + alignmentLabel(align.kind) +
                "\nstrokeAlignment 调试：" +
                "\nraw=" + align.raw +
                "\ntypeof=" + align.rawType +
                "\nstring=" + align.rawString +
                "\nnumber=" + align.rawNumber +
                "\napp.version=" + app.version +
                "\nfinal detected alignment=" + align.alignment +
                "\ndetectMethod=" + align.method +
                "\nboundsExpansion=" + align.boundsExpansion +
                "\nenumDebug=" + align.enumDebug +
                "\n描边颜色类型：" + strokeType +
                "\n填充颜色类型：" + fillType;
        };

	        var isKnownStrokeAlignment = function(align) {
	            return !!(align && align.alignmentKnown !== false && align.kind && align.kind !== "unknown");
	        };
	        var applyTaskAlignmentDebug = function(align, kind, reason, inheritedFromTask, fallbackUsed) {
	            if (!align) align = {};
	            align.kind = kind;
	            align.alignment = kind;
	            align.alignmentKnown = true;
	            align.alignmentFallbackUsed = !!fallbackUsed;
	            align.alignmentFallbackReason = fallbackUsed ? reason : "";
	            align.alignmentFinalDecisionReason = reason || align.alignmentFinalDecisionReason || "";
	            align.debugTaskSourceAlignment = kind;
	            align.debugTaskSourceAlignmentKnown = !fallbackUsed;
	            align.debugTaskSourceAlignmentReason = reason || "";
	            align.debugOriginalSourceObjectId = "";
	            align.debugAlignmentInheritedFromTask = !!inheritedFromTask;
	            align.debugAlignmentInheritedFromSourceObject = false;
	            align.debugSourceObjectAlignmentCacheHit = false;
	            align.alignmentFallbackScope = inheritedFromTask ? "task" : (fallbackUsed ? "final" : "source");
	            return align;
	        };
	        var describeAlignmentSourceObject = function(source) {
	            try {
	                var t = source && source.typename ? String(source.typename) : "Item";
	                var n = "";
	                try { n = source && source.name ? String(source.name) : ""; } catch(nameErr) {}
	                return t + "::" + n;
	            } catch(e) {}
	            return "";
	        };
	        var inferUnknownAlignmentForStrokeTask = function(source, path, readablePaths, align) {
	            try {
	                if (!align || align.kind !== "unknown") return align;
	                var pathCount = readablePaths ? readablePaths.length : 0;
	                var raw = align.raw ? String(align.raw) : "";
	                var rawLooksUndefined = raw === "" || raw === "undefined" || raw.indexOf("unavailable") === 0;
	                var hasFill = false;
	                var hasStroke = false;
	                var sourceType = "";
	                var strokeDepthMm = null;
	                try { hasFill = !!(path && path.filled); } catch(fillErr) {}
	                try { hasStroke = !!(path && path.stroked); } catch(strokeErr) {}
	                try { sourceType = source && source.typename ? String(source.typename) : ""; } catch(typeErr) {}
	                try { strokeDepthMm = parseStrokeThicknessDepthMm(source); } catch(depthErr) {}
	                if (rawLooksUndefined && hasStroke && pathCount <= 80 && (pathCount > 1 || sourceType === "GroupItem" || sourceType === "CompoundPathItem")) {
	                    return applyTaskAlignmentDebug(align, "inside", "inferred_from_multipath_task_geometry", true, false);
	                }
	                if (rawLooksUndefined && hasStroke && strokeDepthMm !== null && strokeDepthMm !== undefined && Number(strokeDepthMm) <= 10) {
	                    return applyTaskAlignmentDebug(align, "inside", "inferred_from_stroke_depth_task_geometry", true, false);
	                }
	            } catch(e) {}
	            return align;
	        };

	        var buildStrokeThicknessPreviewItems = function(source, layer, red, blue, sourceStrokeAlignment) {
            var result = {
                ok: false,
                redItems: [],
                blueItems: [],
                strokeRingParts: [],
                made: 0,
                errorMessage: "",
                alignment: "unknown",
                innerOffset: 0
            };
            var readablePaths = collectStrokeReadablePaths(source);
            var path = readablePaths && readablePaths.length > 0 ? readablePaths[0] : findStrokeReadablePath(source);
            if (!path) {
                result.errorMessage = "当前对象没有可读取的描边";
                return result;
            }
	            var sourceAlign = sourceStrokeAlignment || getStrokeAlignmentFromSource(source);
	            var sourceAlignValid = isKnownStrokeAlignment(sourceAlign);
	            var align = sourceAlignValid ? sourceAlign : detectStrokeAlignment(path);
	            align = inferUnknownAlignmentForStrokeTask(source, path, readablePaths, align);
	            if (!isKnownStrokeAlignment(align)) {
	                align = applyTaskAlignmentDebug(align, "center", "no_alignment_found_final_center", false, true);
	            } else if (!align.debugTaskSourceAlignment) {
	                align = applyTaskAlignmentDebug(align, align.kind, align.alignmentFinalDecisionReason || align.method || "source_alignment", false, false);
	            }
	            var mode = align.kind === "unknown" ? "center" : align.kind;
	            var alignmentInheritedFromSource = !!(sourceAlignValid || align.debugAlignmentInheritedFromTask || align.alignmentInheritedFromGroup || align.alignmentSourceType === "groupInherited");
	            var alignmentFallbackUsed = !!(align && align.alignmentFallbackUsed);
	            var alignmentFallbackReason = alignmentFallbackUsed ? ((align && align.alignmentFallbackReason) || "sourceAlignmentUnavailable") : "";
            var width = Number(path.strokeWidth || 0);
            var innerOffset = 0;
            if (mode === "outside") {
                innerOffset = 0;
            } else if (mode === "inside") {
                innerOffset = -width;
            } else {
                innerOffset = -width / 2;
            }
            try {
                var redSource = source;
                var bluePathSources = [];
                try {
                    if (source && source.typename === "GroupItem" && source.clipped && path) {
                        redSource = path;
                        bluePathSources = [path];
                    }
                } catch(redSourceErr) {}
                if (!bluePathSources || bluePathSources.length === 0) {
                    bluePathSources = readablePaths && readablePaths.length > 0 ? readablePaths : [path];
                }
                var blueItems = [];
                var redItems = [];
                var strokeRingParts = [];
                for (var bp = 0; bp < bluePathSources.length; bp++) {
                    try {
                        var redForPath = duplicateActualStrokeRegionPreview(bluePathSources[bp], layer, red);
                        redForPath = expandAppearanceItemsSafe(redForPath, layer, "HH_STROKE_RED_REGION_PREVIEW", red);
                        var blueRegion = duplicateStrokePreview(bluePathSources[bp], layer, blue, innerOffset, "HH_STROKE_FILL_PREVIEW", "fill");
                        var expandedBlue = expandAppearanceSafe(blueRegion, layer, "HH_STROKE_FILL_PREVIEW", blue);
                        var originalSegsForThisPath = getSegsFromItem(bluePathSources[bp]);
                        var innerOffsetSegsForThisPath = [];
                        for (var ebSeg = 0; ebSeg < expandedBlue.length; ebSeg++) {
                            var localBlueSegs = getSegsFromItem(expandedBlue[ebSeg]);
                            for (var lbs = 0; lbs < localBlueSegs.length; lbs++) innerOffsetSegsForThisPath.push(localBlueSegs[lbs]);
                        }
                        var debugSourceObjectId = "";
                        try {
                            debugSourceObjectId = String(source.typename || "Item") + ":" + String(source.name || "") + ":path_" + bp;
                        } catch(debugSourceErr) {
                            debugSourceObjectId = "path_" + bp;
                        }
                        for (var er = 0; er < redForPath.length; er++) redItems.push(redForPath[er]);
                        for (var eb = 0; eb < expandedBlue.length; eb++) blueItems.push(expandedBlue[eb]);
	                        strokeRingParts.push({
	                            pathIndex: bp,
	                            ringIndex: bp,
	                            sourceFillSegmentIndex: bp,
	                            sourcePath: bluePathSources[bp],
	                            originalSegs: originalSegsForThisPath,
	                            innerOffsetSegs: innerOffsetSegsForThisPath,
	                            fillSegsForRing: innerOffsetSegsForThisPath,
	                            debugSourceObjectId: debugSourceObjectId,
	                            debugLocalFillSegmentIndex: bp,
	                            debugRingLocalIndex: bp,
	                            strokeAlignmentRaw: align.raw,
	                            strokeAlignmentResolved: mode,
	                            sourceStrokeAlignmentResolved: mode,
	                            ringStrokeAlignmentResolved: mode,
	                            alignmentInheritedFromSource: alignmentInheritedFromSource,
	                            alignmentFallbackUsed: alignmentFallbackUsed,
	                            alignmentFallbackReason: alignmentFallbackReason,
	                            alignmentSourceType: align.alignmentSourceType || "",
	                            alignmentSourceItemName: align.alignmentSourceItemName || "",
	                            alignmentSourceTypename: align.alignmentSourceTypename || "",
	                            alignmentSourcePathCount: align.alignmentSourcePathCount || 0,
	                            alignmentCandidateCount: align.alignmentCandidateCount || 0,
	                            alignmentKnown: align.alignmentKnown !== false,
	                            alignmentUnknownCandidateCount: align.alignmentUnknownCandidateCount || 0,
	                            alignmentKnownCandidateCount: align.alignmentKnownCandidateCount || align.alignmentCandidateCount || 0,
	                            alignmentCandidateResolvedValues: align.alignmentCandidateResolvedValues || "",
	                            alignmentCandidateRawValues: align.alignmentCandidateRawValues || "",
	                            alignmentResolvedFromChildPath: !!align.alignmentResolvedFromChildPath,
	                            alignmentResolvedFromGroupChildren: !!align.alignmentResolvedFromGroupChildren,
	                            alignmentInheritedFromGroup: !!align.alignmentInheritedFromGroup,
	                            alignmentGroupResolvedValue: align.alignmentGroupResolvedValue || "",
	                            alignmentGroupKnownCandidateCount: align.alignmentGroupKnownCandidateCount || 0,
	                            alignmentGroupUnknownCandidateCount: align.alignmentGroupUnknownCandidateCount || 0,
	                            alignmentFinalDecisionReason: align.alignmentFinalDecisionReason || "",
	                            debugTaskSourceAlignment: align.debugTaskSourceAlignment || mode,
	                            debugTaskSourceAlignmentKnown: align.debugTaskSourceAlignmentKnown !== false,
	                            debugTaskSourceAlignmentReason: align.debugTaskSourceAlignmentReason || align.alignmentFinalDecisionReason || "",
	                            debugOriginalSourceObjectId: describeAlignmentSourceObject(source),
	                            debugAlignmentInheritedFromTask: !!align.debugAlignmentInheritedFromTask,
	                            debugAlignmentInheritedFromSourceObject: !!align.debugAlignmentInheritedFromSourceObject,
	                            debugSourceObjectAlignmentCacheHit: !!align.debugSourceObjectAlignmentCacheHit,
	                            alignmentFallbackScope: align.alignmentFallbackScope || "",
	                            alignmentMode: mode,
	                            redItems: redForPath || [],
	                            blueItems: expandedBlue || []
	                        });
                    } catch(bluePathErr) {}
                }
                for (var bi = 0; bi < blueItems.length; bi++) bringPreviewToFront(blueItems[bi]);
                result.ok = true;
                result.redItems = redItems || [];
                result.blueItems = blueItems || [];
                result.strokeRingParts = strokeRingParts || [];
                result.made = result.redItems.length + result.blueItems.length;
                result.alignment = mode;
                result.innerOffset = innerOffset;
                result.strokeReadablePathCount = readablePaths ? readablePaths.length : 0;
                result.strokeReadablePathPoints = strokeReadablePathDebug(readablePaths);
                result.blueInnerBoundaryPathCount = bluePathSources ? bluePathSources.length : 0;
                result.redPathCount = countAllPathItemsInItemsForDebug(result.redItems);
                result.bluePathCount = countAllPathItemsInItemsForDebug(result.blueItems);
            } catch(e) {
                result.errorMessage = e.message;
            }
            return result;
        };

        var reverseSegmentText = function(segText) {
            try {
                var pts = eval("(" + segText + ")");
                if (!pts || !pts.length) return segText;
                var out = [];
                for (var i = pts.length - 1; i >= 0; i--) {
                    var cur = pts[i];
                    var a = cur.a || [0, 0];
                    var inT = cur.inT || cur["in"] || a;
                    var outT = cur.outT || cur["out"] || a;
                    out.push('{"a":[' + a[0] + ',' + a[1] + '],"inT":[' + outT[0] + ',' + outT[1] + '],"outT":[' + inT[0] + ',' + inT[1] + ']}');
                }
                return "[" + out.join(",") + "]";
            } catch(e) {}
            return segText;
        };

        var appendUniqueReversedSegments = function(targetSegs, sourceSegs) {
            if (!targetSegs || !sourceSegs || sourceSegs.length === 0) return 0;
            var seen = {};
            for (var i = 0; i < targetSegs.length; i++) {
                try { seen[String(targetSegs[i])] = true; } catch(e0) {}
            }
            var added = 0;
            for (var j = 0; j < sourceSegs.length; j++) {
                try {
                    var reversed = reverseSegmentText(sourceSegs[j]);
                    var key = String(reversed);
                    if (seen[key]) continue;
                    targetSegs.push(reversed);
                    seen[key] = true;
                    added++;
                } catch(e1) {}
            }
            return added;
        };

        var parseSegmentTextForCompare = function(segText) {
            try {
                var pts = eval("(" + segText + ")");
                if (!pts || !pts.length) return null;
                var minX = 999999999, minY = 999999999, maxX = -999999999, maxY = -999999999;
                var area = 0;
                for (var i = 0; i < pts.length; i++) {
                    var cur = pts[i] || {};
                    var nxt = pts[(i + 1) % pts.length] || {};
                    var a = cur.a || [0, 0];
                    var b = nxt.a || [0, 0];
                    var x = Number(a[0] || 0);
                    var y = Number(a[1] || 0);
                    minX = Math.min(minX, x);
                    maxX = Math.max(maxX, x);
                    minY = Math.min(minY, y);
                    maxY = Math.max(maxY, y);
                    area += (Number(a[0] || 0) * Number(b[1] || 0)) - (Number(b[0] || 0) * Number(a[1] || 0));
                }
                area = area / 2;
                return {
                    pointCount: pts.length,
                    minX: minX,
                    minY: minY,
                    maxX: maxX,
                    maxY: maxY,
                    centerX: (minX + maxX) / 2,
                    centerY: (minY + maxY) / 2,
                    width: Math.abs(maxX - minX),
                    height: Math.abs(maxY - minY),
                    area: area,
                    absArea: Math.abs(area)
                };
            } catch(e) {}
            return null;
        };

        var isSimilarSegmentGeometry = function(segA, segB, tolerance) {
            var a = parseSegmentTextForCompare(segA);
            var b = parseSegmentTextForCompare(segB);
            if (!a || !b) return false;
            var tol = tolerance || 0.75;
            if (Math.abs(a.minX - b.minX) > tol) return false;
            if (Math.abs(a.maxX - b.maxX) > tol) return false;
            if (Math.abs(a.minY - b.minY) > tol) return false;
            if (Math.abs(a.maxY - b.maxY) > tol) return false;
            if (Math.abs(a.centerX - b.centerX) > tol) return false;
            if (Math.abs(a.centerY - b.centerY) > tol) return false;
            var maxPoints = Math.max(a.pointCount, b.pointCount);
            if (Math.abs(a.pointCount - b.pointCount) > Math.max(2, Math.round(maxPoints * 0.12))) return false;
            var maxArea = Math.max(a.absArea, b.absArea, 0.01);
            if (Math.abs(a.absArea - b.absArea) / maxArea > 0.025) return false;
            return true;
        };

        var hasSimilarSegmentGeometry = function(list, seg, tolerance) {
            if (!list || !seg) return false;
            for (var i = 0; i < list.length; i++) {
                if (isSimilarSegmentGeometry(list[i], seg, tolerance)) return true;
            }
            return false;
        };

        var findSimilarSegmentGeometryIndex = function(list, seg, tolerance) {
            if (!list || !seg) return -1;
            for (var i = 0; i < list.length; i++) {
                if (isSimilarSegmentGeometry(list[i], seg, tolerance)) return i;
            }
            return -1;
        };

        var reverseSegmentList = function(sourceSegs) {
            var out = [];
            if (!sourceSegs) return out;
            for (var i = 0; i < sourceSegs.length; i++) {
                try { out.push(reverseSegmentText(sourceSegs[i])); } catch(e) {}
            }
            return out;
        };

        var appendMissingReversedSegments = function(targetSegs, sourceSegs, tolerance) {
            var stats = { added: 0, skippedDuplicate: 0 };
            if (!targetSegs || !sourceSegs || sourceSegs.length === 0) return stats;
            var tol = tolerance || 0.75;
            for (var j = 0; j < sourceSegs.length; j++) {
                try {
                    var reversed = reverseSegmentText(sourceSegs[j]);
                    if (hasSimilarSegmentGeometry(targetSegs, reversed, tol)) {
                        stats.skippedDuplicate++;
                        continue;
                    }
                    targetSegs.push(reversed);
                    stats.added++;
                } catch(e1) {}
            }
            return stats;
        };

        var cleanStrokeSegmentsForExport = function(strokeSegs, fillSegs, options) {
            var stats = {
                segments: [],
                duplicateStrokeSegmentsRemoved: 0,
                fillEchoSegmentsRemoved: 0,
                protectedInnerBoundaryKept: 0,
                protectedInnerBoundaryRemoved: 0
            };
            if (!strokeSegs || strokeSegs.length === 0) return stats;
            var opts = options || {};
            var tol = opts.tolerance || 0.75;
            var protectedSegs = opts.protectedInnerBoundarySegs || [];
            for (var i = 0; i < strokeSegs.length; i++) {
                var seg = strokeSegs[i];
                if (hasSimilarSegmentGeometry(stats.segments, seg, tol)) {
                    stats.duplicateStrokeSegmentsRemoved++;
                    continue;
                }
                stats.segments.push(seg);
            }
            for (var p = 0; p < protectedSegs.length; p++) {
                var protectedSeg = protectedSegs[p];
                var existingIndex = findSimilarSegmentGeometryIndex(stats.segments, protectedSeg, tol);
                if (existingIndex >= 0) {
                    stats.segments[existingIndex] = protectedSeg;
                    stats.protectedInnerBoundaryKept++;
                } else {
                    stats.segments.push(protectedSeg);
                    stats.protectedInnerBoundaryKept++;
                }
            }
            if (!fillSegs || fillSegs.length === 0 || stats.segments.length <= 1) return stats;

            var filtered = [];
            var keptFillBoundary = {};
            var keptProtectedBoundary = {};
            for (var s = 0; s < stats.segments.length; s++) {
                var matchFillIndex = -1;
                var matchProtectedIndex = findSimilarSegmentGeometryIndex(protectedSegs, stats.segments[s], tol);
                if (matchProtectedIndex >= 0) {
                    if (keptProtectedBoundary[matchProtectedIndex]) {
                        stats.fillEchoSegmentsRemoved++;
                        continue;
                    }
                    keptProtectedBoundary[matchProtectedIndex] = true;
                    filtered.push(protectedSegs[matchProtectedIndex]);
                    continue;
                }
                for (var f = 0; f < fillSegs.length; f++) {
                    if (isSimilarSegmentGeometry(stats.segments[s], fillSegs[f], tol)) {
                        matchFillIndex = f;
                        break;
                    }
                }
                if (matchFillIndex >= 0) {
                    stats.fillEchoSegmentsRemoved++;
                    continue;
                }
                filtered.push(stats.segments[s]);
            }
            stats.segments = filtered;
            return stats;
        };

        var removeFillEchoSegmentsFromRing = function(ringSegs, fillSegs, protectedInnerBoundarySegs, tolerance) {
            var stats = {
                segments: [],
                before: ringSegs ? ringSegs.length : 0,
                after: 0,
                removed: 0,
                originalFillSegmentsRemoved: 0
            };
            if (!ringSegs || ringSegs.length === 0) return stats;
            var tol = tolerance || 0.75;
            var protectedSegs = protectedInnerBoundarySegs || [];
            for (var i = 0; i < ringSegs.length; i++) {
                var seg = ringSegs[i];
                if (findSimilarSegmentGeometryIndex(protectedSegs, seg, tol) >= 0) {
                    stats.segments.push(seg);
                    continue;
                }
                if (fillSegs && fillSegs.length > 0 && findSimilarSegmentGeometryIndex(fillSegs, seg, tol) >= 0) {
                    stats.removed++;
                    stats.originalFillSegmentsRemoved++;
                    continue;
                }
                stats.segments.push(seg);
            }
            stats.after = stats.segments.length;
            return stats;
        };

	        var segmentBoundsDiff = function(segA, segB) {
	            var a = parseSegmentTextForCompare(segA);
	            var b = parseSegmentTextForCompare(segB);
	            if (!a || !b) return 999999999;
	            return Math.abs(a.minX - b.minX) +
	                Math.abs(a.maxX - b.maxX) +
	                Math.abs(a.minY - b.minY) +
	                Math.abs(a.maxY - b.maxY);
	        };

	        var signedSegmentArea = function(segText) {
	            var meta = parseSegmentTextForCompare(segText);
	            return meta ? meta.area : 0;
	        };

	        var ensureOppositeDirection = function(segText, outerSegText) {
	            try {
	                var segArea = signedSegmentArea(segText);
	                var outerArea = signedSegmentArea(outerSegText);
	                if (segArea === 0 || outerArea === 0) return segText;
	                if ((segArea > 0 && outerArea > 0) || (segArea < 0 && outerArea < 0)) {
	                    return reverseSegmentText(segText);
	                }
	            } catch(e) {}
	            return segText;
	        };

	        var containsSegmentMeta = function(container, inner, tolerance) {
	            if (!container || !inner) return false;
	            var tol = tolerance || 0.75;
	            if (container.absArea <= inner.absArea) return false;
	            if (container.minX - tol > inner.centerX) return false;
	            if (container.maxX + tol < inner.centerX) return false;
	            if (container.minY - tol > inner.centerY) return false;
	            if (container.maxY + tol < inner.centerY) return false;
	            if (container.minX - tol > inner.minX) return false;
	            if (container.maxX + tol < inner.maxX) return false;
	            if (container.minY - tol > inner.minY) return false;
	            if (container.maxY + tol < inner.maxY) return false;
	            return true;
	        };

	        var isValidRedRegionHole = function(candidate, outerSeg, fillSeg, allFillSegs, fallbackInnerSegs, tolerance) {
	            var result = { ok: false, reason: "" };
	            var tol = tolerance || 0.75;
	            var candMeta = parseSegmentTextForCompare(candidate);
	            var outerMeta = parseSegmentTextForCompare(outerSeg);
	            if (!candMeta || !outerMeta) {
	                result.reason = "missing_meta";
	                return result;
	            }
	            if (!containsSegmentMeta(outerMeta, candMeta, tol)) {
	                result.reason = "not_inside_outer";
	                return result;
	            }
	            if (fillSeg && isSimilarSegmentGeometry(candidate, fillSeg, tol)) {
	                result.reason = "same_as_current_fill";
	                return result;
	            }
	            if (allFillSegs && findSimilarSegmentGeometryIndex(allFillSegs, candidate, tol) >= 0) {
	                result.reason = "same_as_any_fill";
	                return result;
	            }
	            if (fallbackInnerSegs && findSimilarSegmentGeometryIndex(fallbackInnerSegs, candidate, tol) >= 0) {
	                result.reason = "same_as_offset_inner";
	                return result;
	            }
	            var minArea = Math.max(0.5, outerMeta.absArea * 0.001);
	            if (candMeta.absArea < minArea) {
	                result.reason = "too_small";
	                return result;
	            }
	            if (candMeta.absArea >= outerMeta.absArea * 0.92) {
	                result.reason = "too_large";
	                return result;
	            }
	            result.ok = true;
	            result.reason = "ok";
	            result.area = candMeta.absArea;
	            return result;
	        };

	        var shouldApplyRedRegionHoleForRing = function(candidate, ringInfo, allFillSegs, fillSegmentRoles, tolerance) {
	            var result = {
	                ok: false,
	                reason: "",
	                ringLooksLikeComplexGlyphBody: false,
	                candidateMatchesAnyHoleFillSeg: false,
	                candidateMatchesAnyOtherFillSeg: false,
	                candidateInsideCurrentOuter: false,
	                candidateInsideCurrentFill: false,
	                candidateAreaRatioToOuter: 0,
	                candidateAreaRatioToFill: 0
	            };
	            var tol = tolerance || 0.75;
	            var outerSeg = ringInfo ? ringInfo.outerSeg : null;
	            var fillSeg = ringInfo ? ringInfo.fillSeg : null;
	            var sourceFillSegmentIndex = ringInfo ? ringInfo.sourceFillSegmentIndex : -1;
	            var contourRole = ringInfo ? ringInfo.contourRole : "";
	            if (contourRole !== "outer") {
	                result.reason = "not_outer_contour";
	                return result;
	            }
	            var candMeta = parseSegmentTextForCompare(candidate);
	            var outerMeta = parseSegmentTextForCompare(outerSeg);
	            var fillMeta = parseSegmentTextForCompare(fillSeg);
	            if (!candMeta || !outerMeta || !fillMeta) {
	                result.reason = "missing_meta";
	                return result;
	            }
	            result.candidateInsideCurrentOuter = containsSegmentMeta(outerMeta, candMeta, tol);
	            result.candidateInsideCurrentFill = containsSegmentMeta(fillMeta, candMeta, tol);
	            result.candidateAreaRatioToOuter = candMeta.absArea / Math.max(outerMeta.absArea, 0.001);
	            result.candidateAreaRatioToFill = candMeta.absArea / Math.max(fillMeta.absArea, 0.001);
	            if (!result.candidateInsideCurrentOuter) {
	                result.reason = "not_inside_current_outer";
	                return result;
	            }
	            if (isSimilarSegmentGeometry(candidate, fillSeg, tol)) {
	                result.reason = "same_as_current_fill";
	                return result;
	            }
	            if (allFillSegs) {
	                for (var i = 0; i < allFillSegs.length; i++) {
	                    if (i === sourceFillSegmentIndex) continue;
	                    if (!isSimilarSegmentGeometry(candidate, allFillSegs[i], tol)) continue;
	                    result.candidateMatchesAnyOtherFillSeg = true;
	                    if (fillSegmentRoles && fillSegmentRoles[i] === "hole") result.candidateMatchesAnyHoleFillSeg = true;
	                }
	            }
	            if (result.candidateMatchesAnyOtherFillSeg || result.candidateMatchesAnyHoleFillSeg) {
	                result.reason = "matches_existing_fill_or_hole";
	                return result;
	            }
	            result.ringLooksLikeComplexGlyphBody =
	                fillMeta.pointCount >= 18 &&
	                outerMeta.pointCount >= 18 &&
	                result.candidateAreaRatioToOuter >= 0.0025 &&
	                result.candidateAreaRatioToOuter <= 0.35 &&
	                result.candidateAreaRatioToFill >= 0.0025 &&
	                result.candidateAreaRatioToFill <= 0.45;
	            if (!result.ringLooksLikeComplexGlyphBody) {
	                result.reason = "not_complex_glyph_body";
	                return result;
	            }
	            result.ok = true;
	            result.reason = "complexGlyphBodyHole";
	            return result;
	        };

	        var classifyFillSegmentRoles = function(fillSegs, tolerance) {
	            var roles = [];
	            if (!fillSegs) return roles;
	            var tol = tolerance || 0.75;
	            var metas = [];
	            for (var i = 0; i < fillSegs.length; i++) {
	                metas.push(parseSegmentTextForCompare(fillSegs[i]));
	                roles.push("outer");
	            }
	            for (var s = 0; s < metas.length; s++) {
	                var depth = 0;
	                for (var p = 0; p < metas.length; p++) {
	                    if (p === s) continue;
	                    if (containsSegmentMeta(metas[p], metas[s], tol)) depth++;
	                }
	                roles[s] = (depth % 2 === 1) ? "hole" : "outer";
	            }
	            return roles;
	        };

	        var boundsRelationToFill = function(candidate, fillMeta, tolerance) {
	            var meta = parseSegmentTextForCompare(candidate);
	            if (!meta || !fillMeta) return "unknown";
	            var tol = tolerance || 0.75;
	            if (containsSegmentMeta(meta, fillMeta, tol)) return "outsideFill";
	            if (containsSegmentMeta(fillMeta, meta, tol)) return "insideFill";
	            if (meta.absArea > fillMeta.absArea) return "largerArea";
	            if (meta.absArea < fillMeta.absArea) return "smallerArea";
	            return "similarArea";
	        };

	        var formatSegmentPoint = function(pt) {
	            var a = pt.a || [0, 0];
	            var inT = pt.inT || pt["in"] || a;
	            var outT = pt.outT || pt["out"] || a;
	            return '{"a":[' + a[0] + ',' + a[1] + '],"inT":[' + inT[0] + ',' + inT[1] + '],"outT":[' + outT[0] + ',' + outT[1] + ']}';
	        };

	        var scaleSegmentTextAroundCenter = function(segText, scaleX, scaleY) {
	            try {
	                var pts = eval("(" + segText + ")");
	                var meta = parseSegmentTextForCompare(segText);
	                if (!pts || !pts.length || !meta) return segText;
	                var cx = meta.centerX;
	                var cy = meta.centerY;
	                var out = [];
	                var scalePoint = function(p) {
	                    if (!p || p.length < 2) return [cx, cy];
	                    return [
	                        cx + (Number(p[0] || 0) - cx) * scaleX,
	                        cy + (Number(p[1] || 0) - cy) * scaleY
	                    ];
	                };
	                for (var i = 0; i < pts.length; i++) {
	                    var cur = pts[i] || {};
	                    var a = cur.a || [0, 0];
	                    var inT = cur.inT || cur["in"] || a;
	                    var outT = cur.outT || cur["out"] || a;
	                    out.push(formatSegmentPoint({
	                        a: scalePoint(a),
	                        inT: scalePoint(inT),
	                        outT: scalePoint(outT)
	                    }));
	                }
	                return "[" + out.join(",") + "]";
	            } catch(e) {}
	            return segText;
	        };

	        var generateHoleSideBoundarySegment = function(fillSeg, ringOuterSegs, tolerance) {
	            var result = {
	                segment: null,
	                method: "none",
	                boundsRelation: "none"
	            };
	            var fillMeta = parseSegmentTextForCompare(fillSeg);
	            if (!fillMeta) return result;
	            var tol = tolerance || 0.75;
	            var maxExpandX = 0;
	            var maxExpandY = 0;
	            if (ringOuterSegs) {
	                for (var i = 0; i < ringOuterSegs.length; i++) {
	                    var candMeta = parseSegmentTextForCompare(ringOuterSegs[i]);
	                    if (!candMeta) continue;
	                    var relation = boundsRelationToFill(ringOuterSegs[i], fillMeta, tol);
	                    if (relation !== "outsideFill" && relation !== "largerArea") continue;
	                    maxExpandX = Math.max(maxExpandX,
	                        Math.max(0, fillMeta.minX - candMeta.minX),
	                        Math.max(0, candMeta.maxX - fillMeta.maxX)
	                    );
	                    maxExpandY = Math.max(maxExpandY,
	                        Math.max(0, fillMeta.minY - candMeta.minY),
	                        Math.max(0, candMeta.maxY - fillMeta.maxY)
	                    );
	                }
	            }
	            if (maxExpandX <= 0 && fillMeta.width > 0) maxExpandX = Math.max(0.25, fillMeta.width * 0.035);
	            if (maxExpandY <= 0 && fillMeta.height > 0) maxExpandY = Math.max(0.25, fillMeta.height * 0.035);
	            var targetW = Math.max(0.01, fillMeta.width - maxExpandX * 2);
	            var targetH = Math.max(0.01, fillMeta.height - maxExpandY * 2);
	            var scaleX = fillMeta.width > 0 ? targetW / fillMeta.width : 1;
	            var scaleY = fillMeta.height > 0 ? targetH / fillMeta.height : 1;
	            result.segment = scaleSegmentTextAroundCenter(fillSeg, scaleX, scaleY);
	            result.method = "offsetFillSegmentTowardHole";
	            result.boundsRelation = "insideHole";
	            return result;
	        };

		        var pickOuterStrokeSegmentsForFill = function(ringOuterSegs, directFillSeg, allFillSegs, fillSegmentRoles, sourceFillSegmentIndex, fallbackInnerSegs, contourRole, tolerance) {
	            var result = {
	                segments: [],
	                outerBoundarySource: "none",
	                outerBoundaryDirection: contourRole === "hole" ? "holeSide" : "outside",
	                outerBoundaryBoundsRelation: "none",
	                holeOuterBoundarySelected: false,
	                outerBoundaryIsHoleSide: false,
	                holeOuterBoundaryGenerated: false,
	                holeOuterBoundaryGenerationMethod: "",
	                extraContourCount: 0,
	                compoundHoleContourSuppressed: 0,
	                redRegionHoleCandidateCount: 0,
	                redRegionHoleAppliedCount: 0,
	                redRegionHoleRejectedCount: 0,
	                redRegionHoleRejectedReasons: [],
	                redRegionHoleArea: [],
	                redRegionHoleDirectionFixed: 0,
	                ringLooksLikeComplexGlyphBody: false,
	                candidateMatchesAnyHoleFillSeg: false,
	                candidateMatchesAnyOtherFillSeg: false,
	                candidateInsideCurrentOuter: false,
	                candidateInsideCurrentFill: false,
	                candidateAreaRatioToOuter: [],
	                candidateAreaRatioToFill: [],
	                redRegionHoleApplyDecision: "disabled",
	                redRegionHoleApplyReason: ""
	            };
	            if (!ringOuterSegs || ringOuterSegs.length === 0) return result;
	            var tol = tolerance || 0.75;
	            var bestSeg = null;
	            var bestScore = null;
	            var bestRelation = "none";
	            var fillMeta = directFillSeg ? parseSegmentTextForCompare(directFillSeg) : null;
	            for (var i = 0; i < ringOuterSegs.length; i++) {
	                var seg = ringOuterSegs[i];
	                if (directFillSeg && isSimilarSegmentGeometry(seg, directFillSeg, tol)) continue;
	                if (fallbackInnerSegs && fallbackInnerSegs.length > 0 && findSimilarSegmentGeometryIndex(fallbackInnerSegs, seg, tol) >= 0) continue;
	                var meta = parseSegmentTextForCompare(seg);
	                if (!meta) continue;
	                var relation = boundsRelationToFill(seg, fillMeta, tol);
	                var score = meta.absArea;
	                if (fillMeta && contourRole === "hole") {
	                    if (relation === "insideFill") score = 1000000000000 - meta.absArea;
	                    else score = -meta.absArea;
	                } else if (fillMeta) {
	                    if (relation === "outsideFill") score = 1000000000000 + meta.absArea;
	                    else score = meta.absArea;
	                }
	                if (!bestSeg || score > bestScore) {
	                    bestSeg = seg;
	                    bestScore = score;
	                    bestRelation = relation;
	                }
	            }
	            if (bestSeg) {
	                if (contourRole === "hole" && !(bestRelation === "insideFill" || bestRelation === "smallerArea")) {
	                    var generated = generateHoleSideBoundarySegment(directFillSeg, ringOuterSegs, tol);
	                    if (generated.segment) {
	                        result.segments.push(generated.segment);
	                        result.outerBoundarySource = "generatedHoleSideBoundary";
	                        result.outerBoundaryBoundsRelation = generated.boundsRelation;
	                        result.outerBoundaryIsHoleSide = true;
	                        result.holeOuterBoundarySelected = true;
	                        result.holeOuterBoundaryGenerated = true;
	                        result.holeOuterBoundaryGenerationMethod = generated.method;
	                        return result;
	                    }
	                    return result;
	                }
	                result.segments.push(bestSeg);
	                result.outerBoundarySource = "redOuterCandidate";
	                result.outerBoundaryBoundsRelation = bestRelation;
	                result.outerBoundaryIsHoleSide = contourRole === "hole" && (bestRelation === "insideFill" || bestRelation === "smallerArea");
	                result.holeOuterBoundarySelected = contourRole === "hole" && result.outerBoundaryIsHoleSide;
	                if (contourRole === "outer") {
	                    for (var extraIdx = 0; extraIdx < ringOuterSegs.length; extraIdx++) {
	                        var extraSeg = ringOuterSegs[extraIdx];
	                        if (isSimilarSegmentGeometry(extraSeg, bestSeg, tol)) continue;
	                        result.redRegionHoleCandidateCount++;
	                        var holeCheck = isValidRedRegionHole(extraSeg, bestSeg, directFillSeg, allFillSegs, fallbackInnerSegs, tol);
	                        if (!holeCheck.ok) {
	                            result.redRegionHoleRejectedCount++;
	                            result.redRegionHoleRejectedReasons.push(holeCheck.reason);
	                            continue;
	                        }
	                        var applyCheck = shouldApplyRedRegionHoleForRing(extraSeg, {
	                            outerSeg: bestSeg,
	                            fillSeg: directFillSeg,
	                            sourceFillSegmentIndex: sourceFillSegmentIndex,
	                            contourRole: contourRole
	                        }, allFillSegs, fillSegmentRoles, tol);
	                        result.ringLooksLikeComplexGlyphBody = result.ringLooksLikeComplexGlyphBody || applyCheck.ringLooksLikeComplexGlyphBody;
	                        result.candidateMatchesAnyHoleFillSeg = result.candidateMatchesAnyHoleFillSeg || applyCheck.candidateMatchesAnyHoleFillSeg;
	                        result.candidateMatchesAnyOtherFillSeg = result.candidateMatchesAnyOtherFillSeg || applyCheck.candidateMatchesAnyOtherFillSeg;
	                        result.candidateInsideCurrentOuter = result.candidateInsideCurrentOuter || applyCheck.candidateInsideCurrentOuter;
	                        result.candidateInsideCurrentFill = result.candidateInsideCurrentFill || applyCheck.candidateInsideCurrentFill;
	                        result.candidateAreaRatioToOuter.push(Math.round(applyCheck.candidateAreaRatioToOuter * 10000) / 10000);
	                        result.candidateAreaRatioToFill.push(Math.round(applyCheck.candidateAreaRatioToFill * 10000) / 10000);
	                        if (!applyCheck.ok) {
	                            result.redRegionHoleRejectedCount++;
	                            result.redRegionHoleRejectedReasons.push(applyCheck.reason);
	                            result.redRegionHoleApplyDecision = "rejected";
	                            result.redRegionHoleApplyReason = applyCheck.reason;
	                            continue;
	                        }
	                        var fixedHole = ensureOppositeDirection(extraSeg, bestSeg);
	                        if (fixedHole !== extraSeg) result.redRegionHoleDirectionFixed++;
	                        result.redRegionHoleArea.push(Math.round((holeCheck.area || 0) * 100) / 100);
	                        if (!hasSimilarSegmentGeometry(result.segments, fixedHole, tol)) {
	                            result.segments.push(fixedHole);
	                            result.redRegionHoleAppliedCount++;
	                            result.redRegionHoleApplyDecision = "applied";
	                            result.redRegionHoleApplyReason = applyCheck.reason;
	                        }
	                    }
	                    result.extraContourCount = result.redRegionHoleAppliedCount;
	                    if (result.redRegionHoleAppliedCount > 0) result.outerBoundarySource += "+redRegionHoleContour";
	                }
	                result.compoundHoleContourSuppressed = Math.max(0, result.redRegionHoleRejectedCount);
	                return result;
	            }
	            if (contourRole === "hole") {
	                var generatedFallback = generateHoleSideBoundarySegment(directFillSeg, ringOuterSegs, tol);
	                if (generatedFallback.segment) {
	                    result.segments.push(generatedFallback.segment);
	                    result.outerBoundarySource = "generatedHoleSideBoundary";
	                    result.outerBoundaryBoundsRelation = generatedFallback.boundsRelation;
	                    result.outerBoundaryIsHoleSide = true;
	                    result.holeOuterBoundarySelected = true;
	                    result.holeOuterBoundaryGenerated = true;
	                    result.holeOuterBoundaryGenerationMethod = generatedFallback.method;
	                }
	                return result;
	            }
	            for (var f = 0; f < ringOuterSegs.length; f++) {
	                if (!hasSimilarSegmentGeometry(result.segments, ringOuterSegs[f], tol)) result.segments.push(ringOuterSegs[f]);
	            }
	            result.outerBoundarySource = "fallbackAllRedOuter";
	            result.outerBoundaryBoundsRelation = "unfiltered";
		            return result;
		        };

		        var formatSegmentBoundsDebug = function(meta) {
		            if (!meta) return "";
		            return [
		                Math.round(meta.minX * 100) / 100,
		                Math.round(meta.minY * 100) / 100,
		                Math.round(meta.maxX * 100) / 100,
		                Math.round(meta.maxY * 100) / 100
		            ].join(",");
		        };

		        var pickOriginalSegmentForFill = function(fillSeg, originalSegs, tolerance) {
		            if (!originalSegs || originalSegs.length <= 0) return null;
		            if (originalSegs.length === 1) return originalSegs[0];
		            var fillMeta = parseSegmentTextForCompare(fillSeg);
		            var bestSeg = originalSegs[0];
		            var bestScore = 999999999;
		            for (var i = 0; i < originalSegs.length; i++) {
		                var meta = parseSegmentTextForCompare(originalSegs[i]);
		                if (!meta || !fillMeta) continue;
		                var score =
		                    Math.abs(meta.centerX - fillMeta.centerX) +
		                    Math.abs(meta.centerY - fillMeta.centerY) +
		                    Math.abs(meta.absArea - fillMeta.absArea) / 1000;
		                if (score < bestScore) {
		                    bestScore = score;
		                    bestSeg = originalSegs[i];
		                }
		            }
		            return bestSeg;
		        };

		        var makeInsideHoleExpandedFillSegment = function(fillSeg, originalSegs, tolerance) {
		            var result = {
		                segment: fillSeg,
		                originalSegment: null,
		                expandsHole: false,
		                relation: "unknown",
		                corrected: false,
		                direction: "none",
		                originalBounds: "",
		                fillBounds: ""
		            };
		            var tol = tolerance || 0.75;
		            var originalSeg = pickOriginalSegmentForFill(fillSeg, originalSegs, tol);
		            result.originalSegment = originalSeg;
		            var originalMeta = parseSegmentTextForCompare(originalSeg);
		            var fillMeta = parseSegmentTextForCompare(fillSeg);
		            result.originalBounds = formatSegmentBoundsDebug(originalMeta);
		            result.fillBounds = formatSegmentBoundsDebug(fillMeta);
		            if (!originalSeg || !originalMeta || !fillMeta) return result;
		            var expanded =
		                fillMeta.width > originalMeta.width + tol ||
		                fillMeta.height > originalMeta.height + tol ||
		                fillMeta.absArea > originalMeta.absArea + tol;
		            if (expanded) {
		                result.expandsHole = true;
		                result.relation = "holeExpanded";
		                result.direction = "alreadyExpanded";
		                return result;
		            }
		            result.relation = "holeShrunk";
		            var deltaW = Math.max(0, originalMeta.width - fillMeta.width);
		            var deltaH = Math.max(0, originalMeta.height - fillMeta.height);
		            if (deltaW <= 0 && originalMeta.width > 0) deltaW = Math.max(0.25, originalMeta.width * 0.035);
		            if (deltaH <= 0 && originalMeta.height > 0) deltaH = Math.max(0.25, originalMeta.height * 0.035);
		            var targetW = Math.max(0.01, originalMeta.width + deltaW);
		            var targetH = Math.max(0.01, originalMeta.height + deltaH);
		            var scaleX = originalMeta.width > 0 ? targetW / originalMeta.width : 1;
		            var scaleY = originalMeta.height > 0 ? targetH / originalMeta.height : 1;
		            result.segment = scaleSegmentTextAroundCenter(originalSeg, scaleX, scaleY);
		            var fixedMeta = parseSegmentTextForCompare(result.segment);
		            result.fillBounds = formatSegmentBoundsDebug(fixedMeta);
		            result.expandsHole = true;
		            result.relation = "holeExpanded";
		            result.corrected = true;
		            result.direction = "reversedForHole";
		            return result;
		        };

		        var correctInsideHoleFillSegsForRingParts = function(fillSegs, fillSegmentRoles, ringParts, fillBaseIndex, tolerance) {
		            if (!fillSegs || !fillSegmentRoles || !ringParts) return 0;
		            var fixed = 0;
		            var tol = tolerance || 0.75;
		            for (var i = 0; i < ringParts.length; i++) {
		                var rp = ringParts[i];
		                if (!rp || rp.alignmentMode !== "inside") continue;
		                var idx = (fillBaseIndex || 0) + (typeof rp.sourceFillSegmentIndex === "number" ? rp.sourceFillSegmentIndex : i);
		                var localInnerSegs = rp.innerOffsetSegs && rp.innerOffsetSegs.length ? rp.innerOffsetSegs : (rp.fillSegsForRing || []);
		                var localInnerSeg = localInnerSegs && localInnerSegs.length ? localInnerSegs[0] : null;
		                if (localInnerSeg && (idx < 0 || idx >= fillSegs.length || !isSimilarSegmentGeometry(fillSegs[idx], localInnerSeg, tol))) {
		                    var localIdx = findSimilarSegmentGeometryIndex(fillSegs, localInnerSeg, tol);
		                    if (localIdx >= 0) idx = localIdx;
		                }
		                if (idx < 0 || idx >= fillSegs.length) continue;
		                if (fillSegmentRoles[idx] !== "hole") continue;
		                var fix = makeInsideHoleExpandedFillSegment(localInnerSeg || fillSegs[idx], rp.originalSegs, tol);
		                if (fix && fix.segment) {
		                    if (rp.innerOffsetSegs && rp.innerOffsetSegs.length) rp.innerOffsetSegs[0] = fix.segment;
		                    if (rp.fillSegsForRing && rp.fillSegsForRing.length) rp.fillSegsForRing[0] = fix.segment;
		                }
		                if (fix && fix.segment && fix.corrected) {
		                    fillSegs[idx] = fix.segment;
		                    fixed++;
		                }
		            }
		            return fixed;
		        };

		        var buildStrokeRingSegmentsFromOuterAndFill = function(ringOuterSegs, fillSegs, fillSegmentRoles, sourceFillSegmentIndex, fallbackInnerSegs, tolerance, alignmentMode, originalSegs, strokeAlignmentRaw, sourceStrokeAlignmentResolved, ringStrokeAlignmentResolved, alignmentInheritedFromSource, alignmentFallbackUsed, alignmentFallbackReason, debugSourceObjectId, debugLocalFillSegmentIndex, debugGlobalFillSegmentIndex) {
	            var stats = {
	                segments: [],
	                before: ringOuterSegs ? ringOuterSegs.length : 0,
	                after: 0,
	                fillOriginalSegmentsFound: 0,
	                fillOriginalSegmentsRemoved: 0,
	                offsetInnerSegmentsIgnored: fallbackInnerSegs ? fallbackInnerSegs.length : 0,
	                fallbackOffsetInnerUsed: false,
	                sourceFillSegmentIndex: sourceFillSegmentIndex,
	                fillSegmentUsedAsInner: false,
	                innerBoundarySource: "",
	                ringInnerMatchesFillSegment: false,
	                ringInnerBoundsDiff: 999999999,
	                fillSegmentContourRole: "unknown",
	                outerBoundarySource: "none",
	                outerBoundaryDirection: "unknown",
	                outerBoundaryBoundsRelation: "none",
	                holeOuterBoundarySelected: false,
	                outerBoundaryIsHoleSide: false,
	                holeOuterBoundaryGenerated: false,
	                holeOuterBoundaryGenerationMethod: "",
	                extraContourCount: 0,
	                compoundHoleContourSuppressed: 0,
	                redRegionHoleCandidateCount: 0,
	                redRegionHoleAppliedCount: 0,
	                redRegionHoleRejectedCount: 0,
	                redRegionHoleRejectedReasons: "",
	                redRegionHoleArea: "",
	                redRegionHoleDirectionFixed: 0,
	                ringLooksLikeComplexGlyphBody: false,
	                candidateMatchesAnyHoleFillSeg: false,
	                candidateMatchesAnyOtherFillSeg: false,
	                candidateInsideCurrentOuter: false,
	                candidateInsideCurrentFill: false,
	                candidateAreaRatioToOuter: "",
	                candidateAreaRatioToFill: "",
	                redRegionHoleApplyDecision: "",
		                redRegionHoleApplyReason: "",
		                strokeAlignmentRaw: strokeAlignmentRaw || "",
		                strokeAlignmentResolved: alignmentMode || "unknown",
		                sourceStrokeAlignmentResolved: sourceStrokeAlignmentResolved || alignmentMode || "unknown",
		                ringStrokeAlignmentResolved: ringStrokeAlignmentResolved || alignmentMode || "unknown",
		                alignmentInheritedFromSource: !!alignmentInheritedFromSource,
		                alignmentFallbackUsed: !!alignmentFallbackUsed,
		                alignmentFallbackReason: alignmentFallbackReason || "",
		                alignmentMode: alignmentMode || "unknown",
		                fillBoundarySource: "",
		                strokeOuterBoundarySource: "",
		                strokeInnerBoundarySource: "",
		                insideFillInsetApplied: false,
		                insideStrokeUsesOriginalAsOuter: false,
		                insideStrokeUsesInnerOffsetAsInner: false,
		                insideOverlapPreventionApplied: false,
		                insideHoleOffsetDirection: "",
		                insideHoleFillExpandsHole: false,
		                insideHoleBoundsRelation: "",
		                insideHoleOffsetCorrected: false,
		                insideHoleOriginalBounds: "",
		                insideHoleFillBounds: "",
		                debugSourceObjectId: debugSourceObjectId || "",
		                debugLocalFillSegmentIndex: (debugLocalFillSegmentIndex !== null && debugLocalFillSegmentIndex !== undefined) ? debugLocalFillSegmentIndex : -1,
		                debugGlobalFillSegmentIndex: (debugGlobalFillSegmentIndex !== null && debugGlobalFillSegmentIndex !== undefined) ? debugGlobalFillSegmentIndex : sourceFillSegmentIndex,
		                debugRingUsesLocalInnerSeg: false,
		                debugRingInnerFallbackUsed: false,
		                debugRingInnerFallbackReason: "",
		                debugInnerSegSourceObjectId: "",
		                debugFillSegSourceObjectId: "",
		                debugOriginalSegBounds: "",
		                debugInnerOffsetSegBounds: "",
		                debugFillSegBounds: "",
		                debugRingInnerBounds: "",
		                roles: ""
	            };
	            if (!ringOuterSegs || ringOuterSegs.length === 0) return stats;
	            var tol = tolerance || 0.75;
	            var fillList = fillSegs || [];
	            var directFillSeg = null;
	            var roleLookupIndex = sourceFillSegmentIndex;
	            if (fallbackInnerSegs && fallbackInnerSegs.length > 0) {
	                directFillSeg = fallbackInnerSegs[0];
	                stats.debugRingUsesLocalInnerSeg = true;
	                stats.debugInnerSegSourceObjectId = debugSourceObjectId || "";
	                stats.debugFillSegSourceObjectId = debugSourceObjectId || "";
	                var matchedLocalFillIndex = findSimilarSegmentGeometryIndex(fillList, directFillSeg, tol);
	                if (matchedLocalFillIndex >= 0) {
	                    roleLookupIndex = matchedLocalFillIndex;
	                    stats.debugGlobalFillSegmentIndex = matchedLocalFillIndex;
	                }
	            } else if (typeof sourceFillSegmentIndex === "number" && sourceFillSegmentIndex >= 0 && sourceFillSegmentIndex < fillList.length) {
	                directFillSeg = fillList[sourceFillSegmentIndex];
	                stats.debugRingInnerFallbackUsed = true;
	                stats.debugRingInnerFallbackReason = "no_local_inner";
	                stats.debugInnerSegSourceObjectId = "globalFillSegs";
	                stats.debugFillSegSourceObjectId = "globalFillSegs";
	            }
	            stats.debugOriginalSegBounds = originalSegs && originalSegs.length > 0 ? formatSegmentBoundsDebug(parseSegmentTextForCompare(originalSegs[0])) : "";
	            stats.debugInnerOffsetSegBounds = directFillSeg ? formatSegmentBoundsDebug(parseSegmentTextForCompare(directFillSeg)) : "";
	            stats.debugFillSegBounds = directFillSeg ? formatSegmentBoundsDebug(parseSegmentTextForCompare(directFillSeg)) : "";
	            var contourRole = "outer";
	            try {
	                if (fillSegmentRoles && fillSegmentRoles[roleLookupIndex]) contourRole = fillSegmentRoles[roleLookupIndex];
		            } catch(roleErr) {}
		            stats.fillSegmentContourRole = contourRole;
		            if (alignmentMode === "inside" && directFillSeg && originalSegs && originalSegs.length > 0) {
		                for (var ios = 0; ios < originalSegs.length; ios++) {
		                    if (!hasSimilarSegmentGeometry(stats.segments, originalSegs[ios], tol)) stats.segments.push(originalSegs[ios]);
		                }
		                var insideFillSeg = directFillSeg;
		                var insideHoleFix = null;
		                if (contourRole === "hole") {
		                    insideHoleFix = makeInsideHoleExpandedFillSegment(directFillSeg, originalSegs, tol);
		                    if (insideHoleFix && insideHoleFix.segment) insideFillSeg = insideHoleFix.segment;
		                    stats.insideHoleOffsetDirection = insideHoleFix ? insideHoleFix.direction : "none";
		                    stats.insideHoleFillExpandsHole = !!(insideHoleFix && insideHoleFix.expandsHole);
		                    stats.insideHoleBoundsRelation = insideHoleFix ? insideHoleFix.relation : "unknown";
		                    stats.insideHoleOffsetCorrected = !!(insideHoleFix && insideHoleFix.corrected);
		                    stats.insideHoleOriginalBounds = insideHoleFix ? insideHoleFix.originalBounds : "";
		                    stats.insideHoleFillBounds = insideHoleFix ? insideHoleFix.fillBounds : "";
		                }
		                var reversedInsideFill = reverseSegmentList([insideFillSeg]);
		                for (var irf = 0; irf < reversedInsideFill.length; irf++) stats.segments.push(reversedInsideFill[irf]);
		                stats.fillOriginalSegmentsFound = 1;
		                stats.fillSegmentUsedAsInner = true;
		                stats.innerBoundarySource = "innerOffsetSegs";
		                stats.ringInnerMatchesFillSegment = reversedInsideFill.length > 0 && isSimilarSegmentGeometry(reversedInsideFill[0], insideFillSeg, tol);
		                stats.ringInnerBoundsDiff = reversedInsideFill.length > 0 ? segmentBoundsDiff(reversedInsideFill[0], insideFillSeg) : 999999999;
		                stats.debugRingInnerBounds = reversedInsideFill.length > 0 ? formatSegmentBoundsDebug(parseSegmentTextForCompare(reversedInsideFill[0])) : "";
		                stats.outerBoundarySource = "originalSegs";
		                stats.outerBoundaryDirection = "insideOriginal";
		                stats.outerBoundaryBoundsRelation = "originalToInnerOffset";
		                stats.fillBoundarySource = "innerOffsetSegs";
		                stats.strokeOuterBoundarySource = "originalSegs";
		                stats.strokeInnerBoundarySource = "innerOffsetSegs";
		                stats.insideFillInsetApplied = true;
		                stats.insideStrokeUsesOriginalAsOuter = true;
		                stats.insideStrokeUsesInnerOffsetAsInner = true;
		                stats.insideOverlapPreventionApplied = true;
		                stats.fillOriginalSegmentsRemoved = Math.max(0, stats.before - originalSegs.length);
		                stats.after = stats.segments.length;
		                stats.roles = "outer:" + originalSegs.length + ",inner:1,alignmentMode:inside,fillBoundarySource:" + stats.fillBoundarySource + ",strokeOuterBoundarySource:" + stats.strokeOuterBoundarySource + ",strokeInnerBoundarySource:" + stats.strokeInnerBoundarySource + ",insideFillInsetApplied:true,insideStrokeUsesOriginalAsOuter:true,insideStrokeUsesInnerOffsetAsInner:true,insideOverlapPreventionApplied:true,insideHoleBoundsRelation:" + stats.insideHoleBoundsRelation + ",insideHoleFillExpandsHole:" + stats.insideHoleFillExpandsHole + ",insideHoleOffsetCorrected:" + stats.insideHoleOffsetCorrected + ",sourceFillSegmentIndex:" + sourceFillSegmentIndex + ",fillSegmentContourRole:" + stats.fillSegmentContourRole;
		                return stats;
		            }
		            var outerPick = pickOuterStrokeSegmentsForFill(ringOuterSegs, directFillSeg, fillList, fillSegmentRoles, sourceFillSegmentIndex, fallbackInnerSegs, contourRole, tol);
	            var outerSegs = outerPick.segments || [];
	            stats.outerBoundarySource = outerPick.outerBoundarySource;
	            stats.outerBoundaryDirection = outerPick.outerBoundaryDirection;
	            stats.outerBoundaryBoundsRelation = outerPick.outerBoundaryBoundsRelation;
	            stats.holeOuterBoundarySelected = outerPick.holeOuterBoundarySelected;
	            stats.outerBoundaryIsHoleSide = outerPick.outerBoundaryIsHoleSide;
	            stats.holeOuterBoundaryGenerated = outerPick.holeOuterBoundaryGenerated;
	            stats.holeOuterBoundaryGenerationMethod = outerPick.holeOuterBoundaryGenerationMethod;
	            stats.extraContourCount = 0;
	            stats.extraContourCount = outerPick.extraContourCount || 0;
	            stats.compoundHoleContourSuppressed = outerPick.compoundHoleContourSuppressed || 0;
	            stats.redRegionHoleCandidateCount = outerPick.redRegionHoleCandidateCount || 0;
	            stats.redRegionHoleAppliedCount = outerPick.redRegionHoleAppliedCount || 0;
	            stats.redRegionHoleRejectedCount = outerPick.redRegionHoleRejectedCount || 0;
	            stats.redRegionHoleRejectedReasons = (outerPick.redRegionHoleRejectedReasons || []).join("|");
	            stats.redRegionHoleArea = (outerPick.redRegionHoleArea || []).join("|");
	            stats.redRegionHoleDirectionFixed = outerPick.redRegionHoleDirectionFixed || 0;
	            stats.ringLooksLikeComplexGlyphBody = outerPick.ringLooksLikeComplexGlyphBody || false;
	            stats.candidateMatchesAnyHoleFillSeg = outerPick.candidateMatchesAnyHoleFillSeg || false;
	            stats.candidateMatchesAnyOtherFillSeg = outerPick.candidateMatchesAnyOtherFillSeg || false;
	            stats.candidateInsideCurrentOuter = outerPick.candidateInsideCurrentOuter || false;
	            stats.candidateInsideCurrentFill = outerPick.candidateInsideCurrentFill || false;
	            stats.candidateAreaRatioToOuter = (outerPick.candidateAreaRatioToOuter || []).join("|");
	            stats.candidateAreaRatioToFill = (outerPick.candidateAreaRatioToFill || []).join("|");
	            stats.redRegionHoleApplyDecision = outerPick.redRegionHoleApplyDecision || "";
		            stats.redRegionHoleApplyReason = outerPick.redRegionHoleApplyReason || "";
		            for (var o = 0; o < outerSegs.length; o++) stats.segments.push(outerSegs[o]);
		            stats.fillBoundarySource = directFillSeg ? "originalSegs" : "";
		            stats.strokeOuterBoundarySource = stats.outerBoundarySource || "redOuterCandidate";
		            stats.strokeInnerBoundarySource = directFillSeg ? "originalSegs" : "";
		            if (directFillSeg) {
	                var reversedFill = reverseSegmentList([directFillSeg]);
	                for (var rf = 0; rf < reversedFill.length; rf++) stats.segments.push(reversedFill[rf]);
	                stats.fillOriginalSegmentsFound = 1;
	                stats.fillSegmentUsedAsInner = true;
	                stats.innerBoundarySource = stats.debugRingUsesLocalInnerSeg ? "ringPart.innerOffsetSegs[0]" : "fillSegs[" + sourceFillSegmentIndex + "]";
	                stats.ringInnerMatchesFillSegment = reversedFill.length > 0 && isSimilarSegmentGeometry(reversedFill[0], directFillSeg, tol);
	                stats.ringInnerBoundsDiff = reversedFill.length > 0 ? segmentBoundsDiff(reversedFill[0], directFillSeg) : 999999999;
	                stats.debugRingInnerBounds = reversedFill.length > 0 ? formatSegmentBoundsDebug(parseSegmentTextForCompare(reversedFill[0])) : "";
	            } else if ((!fillSegs || fillSegs.length === 0) && fallbackInnerSegs && fallbackInnerSegs.length > 0) {
	                var reversedFallback = reverseSegmentList(fallbackInnerSegs);
	                for (var ri = 0; ri < reversedFallback.length; ri++) {
	                    if (!hasSimilarSegmentGeometry(stats.segments, reversedFallback[ri], tol)) {
	                        stats.segments.push(reversedFallback[ri]);
	                        stats.fallbackOffsetInnerUsed = true;
	                    }
	                }
	                stats.innerBoundarySource = "fallbackOffsetInner";
	            } else {
	                stats.innerBoundarySource = "missingFillSegsIndex";
	            }
	            stats.fillOriginalSegmentsRemoved = Math.max(0, stats.before - outerSegs.length);
	            stats.after = stats.segments.length;
	            stats.roles = "outer:" + outerSegs.length + ",inner:" + (directFillSeg ? 1 : 0) + ",extraContourCount:" + stats.extraContourCount + ",redRegionHoleCandidateCount:" + stats.redRegionHoleCandidateCount + ",redRegionHoleAppliedCount:" + stats.redRegionHoleAppliedCount + ",redRegionHoleRejectedCount:" + stats.redRegionHoleRejectedCount + ",redRegionHoleApplyDecision:" + stats.redRegionHoleApplyDecision + ",redRegionHoleApplyReason:" + stats.redRegionHoleApplyReason + ",compoundHoleContourSuppressed:" + stats.compoundHoleContourSuppressed + ",sourceFillSegmentIndex:" + sourceFillSegmentIndex + ",fillSegmentContourRole:" + stats.fillSegmentContourRole + ",outerBoundarySource:" + stats.outerBoundarySource + ",outerBoundaryDirection:" + stats.outerBoundaryDirection + ",outerBoundaryBoundsRelation:" + stats.outerBoundaryBoundsRelation + ",holeOuterBoundarySelected:" + stats.holeOuterBoundarySelected + ",outerBoundaryIsHoleSide:" + stats.outerBoundaryIsHoleSide + ",holeOuterBoundaryGenerated:" + stats.holeOuterBoundaryGenerated + ",holeOuterBoundaryGenerationMethod:" + stats.holeOuterBoundaryGenerationMethod + ",innerBoundarySource:" + stats.innerBoundarySource + ",fillSegmentUsedAsInner:" + stats.fillSegmentUsedAsInner + ",offsetInnerIgnored:" + stats.offsetInnerSegmentsIgnored + ",fallbackOffsetInnerUsed:" + stats.fallbackOffsetInnerUsed + ",ringInnerMatchesFillSegment:" + stats.ringInnerMatchesFillSegment + ",ringInnerBoundsDiff:" + stats.ringInnerBoundsDiff;
	            return stats;
	        };

        var renameStrokeThicknessExportItems = function(items, name) {
            if (!items) return 0;
            var count = 0;
            for (var i = 0; i < items.length; i++) {
                try {
                    items[i].name = name;
                    count++;
                } catch(e) {}
            }
            return count;
        };

        var getStrokeThicknessSplitNames = function(source) {
            var baseName = "StrokePart";
            try {
                baseName = tools.getPureName(source.name) || source.name || baseName;
            } catch(e) {}
            baseName = tools.cleanName(baseName);

            var fillDepthMm = null;
            try { fillDepthMm = tools.getTagD(source.name); } catch(e2) {}

            var strokeDepthMm = parseStrokeThicknessDepthMm(source);
            var strokeDepthDefaultUsed = false;
            if (strokeDepthMm === null || isNaN(parseFloat(strokeDepthMm)) || parseFloat(strokeDepthMm) <= 0) {
                strokeDepthMm = DEFAULT_STROKE_THICKNESS_DEPTH_MM;
                strokeDepthDefaultUsed = true;
            }
            strokeDepthMm = Math.round(parseFloat(strokeDepthMm) * 100) / 100;

            var typeSuffix = "";
            try {
                var t = tools.getTagT(source.name);
                if (t) typeSuffix = "_t" + t;
            } catch(e3) {}

            var fillName = baseName + "_fill" + (fillDepthMm !== null && fillDepthMm !== undefined ? "_d" + fillDepthMm : "") + typeSuffix;
            var strokeName = baseName + "_stroke_d" + strokeDepthMm + typeSuffix;
            return {
                baseName: baseName,
                fillName: tools.cleanName(fillName),
                strokeName: tools.cleanName(strokeName),
                fillDepthMm: fillDepthMm,
                strokeDepthMm: strokeDepthMm,
                strokeDepthDefaultUsed: strokeDepthDefaultUsed
            };
        };

        var applyStrokeThicknessSplitNames = function(result, names) {
            if (!result || !names) return;
            renameStrokeThicknessExportItems(result.blueItems, names.fillName);
            renameStrokeThicknessExportItems(result.redItems, names.strokeName);
        };

        var getStrokeThicknessSourceKey = function(source) {
            try {
                var key = tools.getPureName(source.name) || source.name || "StrokeSource";
                return tools.cleanName(key);
            } catch(e) {}
            return "StrokeSource";
        };

        var getGeneratedFromKey = function(item) {
            try {
                var note = String(item.note || "");
                var match = note.match(new RegExp("(^|\\n)" + STROKE_GENERATED_FROM_NOTE_KEY + "=([^\\n\\r]+)"));
                if (match && match[2] !== undefined) return match[2];
            } catch(e) {}
            return null;
        };

        var setGeneratedFromKey = function(item, sourceKey) {
            if (!item || !sourceKey) return false;
            try {
                var note = String(item.note || "");
                var lines = note ? note.split(/\r?\n/) : [];
                var kept = [];
                for (var i = 0; i < lines.length; i++) {
                    if (lines[i].indexOf(STROKE_GENERATED_FROM_NOTE_KEY + "=") === 0) continue;
                    if (lines[i] !== "") kept.push(lines[i]);
                }
                kept.push(STROKE_GENERATED_FROM_NOTE_KEY + "=" + sourceKey);
                item.note = kept.join("\n");
                return true;
            } catch(e) {}
            return false;
        };

        var markStrokeThicknessGeneratedItems = function(items, sourceKey) {
            var count = 0;
            if (!items) return count;
            for (var i = 0; i < items.length; i++) {
                try {
                    setGeneratedFromKey(items[i], sourceKey);
                    setStrokeThicknessExportFlag(items[i], false);
                    setSkipExportFlag(items[i], false);
                    count++;
                } catch(e) {}
            }
            return count;
        };

        var collectStrokeThicknessGeneratedItems = function(sourceKey) {
            var out = [];
            if (!sourceKey) return out;
            var walk = function(container) {
                if (!container) return;
                try {
                    var items = container.pageItems;
                    if (!items) return;
                    for (var i = 0; i < items.length; i++) {
                        var item = items[i];
                        try {
                            if (getGeneratedFromKey(item) === sourceKey) out.push(item);
                        } catch(e0) {}
                        try {
                            if (item.typename === "GroupItem") walk(item);
                        } catch(e1) {}
                    }
                } catch(e) {}
            };
            walk(doc);
            return out;
        };

        var removeStrokeThicknessGeneratedItems = function(sourceKey) {
            var removed = 0;
            var generated = collectStrokeThicknessGeneratedItems(sourceKey);
            for (var i = generated.length - 1; i >= 0; i--) {
                try {
                    generated[i].locked = false;
                    generated[i].hidden = false;
                    generated[i].remove();
                    removed++;
                } catch(e) {}
            }
            return removed;
        };

        var clearStrokeThicknessSourceFlagsByKey = function(sourceKey) {
            if (!sourceKey) return 0;
            var cleared = 0;
            var walk = function(container) {
                if (!container) return;
                try {
                    var items = container.pageItems;
                    if (!items) return;
                    for (var i = 0; i < items.length; i++) {
                        var item = items[i];
                        try {
                            if (!getGeneratedFromKey(item) && getStrokeThicknessSourceKey(item) === sourceKey) {
                                setStrokeThicknessExportFlag(item, false);
                                setSkipExportFlag(item, false);
                                var dVal = tools.getTagD(item.name);
                                var tVal = tools.getTagT(item.name);
                                item.name = tools.rebuildName(
                                    item.name,
                                    dVal,
                                    tVal,
                                    tools.getFallbackExport(item.name),
                                    tools.getFallbackReverse(item.name),
                                    false
                                );
                                cleared++;
                            }
                        } catch(e0) {}
                        try {
                            if (item.typename === "GroupItem") walk(item);
                        } catch(e1) {}
                    }
                } catch(e) {}
            };
            walk(doc);
            return cleared;
        };

        var selectionContainsStrokeGeneratedForKey = function(selItems, sourceKey) {
            if (!selItems || !sourceKey) return false;
            for (var i = 0; i < selItems.length; i++) {
                try {
                    if (getGeneratedFromKey(selItems[i]) === sourceKey) return true;
                } catch(e) {}
            }
            return false;
        };

        var buildStrokeThicknessExportPartsOnArtLayer = function(source) {
            var result = {
                ok: false,
                fillItems: [],
                strokeItems: [],
                fillName: "",
                strokeName: "",
                sourceKey: "",
                errorMessage: ""
            };
            if (!source) {
                result.errorMessage = "missing_source";
                return result;
            }
            try {
                result.sourceKey = getStrokeThicknessSourceKey(source);
                removeStrokeThicknessGeneratedItems(result.sourceKey);

                var targetLayer = null;
                try { targetLayer = source.layer; } catch(layerErr) {}
                if (!targetLayer) targetLayer = doc.activeLayer;
                targetLayer.locked = false;
                targetLayer.visible = true;

                var fillRgb = getStrokeFillRgb(source);
                var strokeRgb = getStrokeStrokeRgb(source);
                var fillColor = makeRgb(fillRgb[0], fillRgb[1], fillRgb[2]);
                var strokeColor = makeRgb(strokeRgb[0], strokeRgb[1], strokeRgb[2]);
                var splitNames = getStrokeThicknessSplitNames(source);
                var splitResult = buildStrokeThicknessPreviewItems(source, targetLayer, strokeColor, fillColor);
                if (!splitResult.ok) {
                    result.errorMessage = splitResult.errorMessage || "split_failed";
                    return result;
                }

                applyStrokeThicknessSplitNames(splitResult, splitNames);
                splitResult.redItems = groupStrokeThicknessItemsIfNeeded(splitResult.redItems, targetLayer, splitNames.strokeName);
                splitResult.blueItems = groupStrokeThicknessItemsIfNeeded(splitResult.blueItems, targetLayer, splitNames.fillName);
                applyStrokeThicknessSplitNames(splitResult, splitNames);

                markStrokeThicknessGeneratedItems(splitResult.blueItems, result.sourceKey);
                markStrokeThicknessGeneratedItems(splitResult.redItems, result.sourceKey);

                result.ok = true;
                result.fillItems = splitResult.blueItems || [];
                result.strokeItems = splitResult.redItems || [];
                result.fillName = splitNames.fillName;
                result.strokeName = splitNames.strokeName;
            } catch(e) {
                result.errorMessage = e.message;
            }
            return result;
        };

        var groupStrokeThicknessItemsIfNeeded = function(items, layer, name) {
            if (!items || items.length <= 1) return items || [];
            try {
                var group = layer.groupItems.add();
                group.name = name;
                for (var i = items.length - 1; i >= 0; i--) {
                    try { items[i].move(group, ElementPlacement.PLACEATBEGINNING); } catch(e) {}
                }
                return [group];
            } catch(e2) {
                return items;
            }
        };

        var previewStrokeThickness = function() {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中一个带描边的对象");
                return "NO_SEL";
            }
            var layer = getOrCreateStrokePreviewLayer();
            var made = 0;
            var errors = [];
            var createdNames = [];
            for (var si = 0; si < originalSel.length; si++) {
                var source = originalSel[si];
                var fillRgb = getStrokeFillRgb(source);
                var strokeRgb = getStrokeStrokeRgb(source);
                var fillColor = makeRgb(fillRgb[0], fillRgb[1], fillRgb[2]);
                var strokeColor = makeRgb(strokeRgb[0], strokeRgb[1], strokeRgb[2]);
                var splitNames = getStrokeThicknessSplitNames(source);
                var previewResult = buildStrokeThicknessPreviewItems(source, layer, strokeColor, fillColor);
                if (previewResult.ok) {
                    applyStrokeThicknessSplitNames(previewResult, splitNames);
                    previewResult.redItems = groupStrokeThicknessItemsIfNeeded(previewResult.redItems, layer, splitNames.strokeName);
                    previewResult.blueItems = groupStrokeThicknessItemsIfNeeded(previewResult.blueItems, layer, splitNames.fillName);
                    createdNames.push(splitNames.fillName + " / " + splitNames.strokeName);
                    made += previewResult.made;
                } else {
                    errors.push(source.typename + ": " + previewResult.errorMessage);
                    continue;
                }
            }
            try { restoreSelection(originalSel); } catch(e2) {}
            if (made > 0) {
                alert("描边厚度拆分预览已生成\n填充对象 / 描边对象：\n" + createdNames.join("\n"));
                return "OK_STROKE_THICKNESS_PREVIEW:" + made;
            }
            removeStrokeThicknessPreview();
            alert("当前对象类型暂不支持描边厚度预览，请先转为普通路径或复合路径。\n" + errors.join("\n"));
            return "ERR_STROKE_THICKNESS_PREVIEW:" + errors.join(" | ");
        };

        var collectFallbackTracePaths = function(item) {
            var paths = [];
            if (!item) return paths;
            try {
                if (item.typename === "PathItem") {
                    paths.push(item);
                } else if (item.typename === "CompoundPathItem") {
                    for (var i = 0; i < item.pathItems.length; i++) paths.push(item.pathItems[i]);
                } else if (item.typename === "GroupItem") {
                    for (var j = 0; j < item.pageItems.length; j++) {
                        paths = paths.concat(collectFallbackTracePaths(item.pageItems[j]));
                    }
                }
            } catch(e) {}
            return paths;
        };

        var getFallbackFillKind = function(item) {
            try {
                if (!item || item.typename !== "PathItem") return "none";
                if (!item.filled || !item.fillColor || item.fillColor.typename === "NoColor") return "none";
                var color = item.fillColor;
                if (color.typename === "RGBColor") {
                    var r = Math.round(color.red), g = Math.round(color.green), b = Math.round(color.blue);
                    if (r >= 245 && g >= 245 && b >= 245) return "white";
                    if (r <= 10 && g <= 10 && b <= 10) return "black";
                    return "other";
                }
                if (color.typename === "GrayColor") {
                    if (color.gray >= 95) return "white";
                    if (color.gray <= 5) return "black";
                    return "other";
                }
                if (color.typename === "CMYKColor") {
                    if (color.black <= 5 && color.cyan <= 8 && color.magenta <= 8 && color.yellow <= 8) return "white";
                    if (color.black >= 90) return "black";
                    return "other";
                }
            } catch(e) {}
            return "none";
        };

        var collectFallbackPathsByFill = function(root) {
            var result = { whitePaths: [], blackPaths: [], otherPaths: [] };
            var paths = collectFallbackTracePaths(root);
            for (var i = 0; i < paths.length; i++) {
                var kind = getFallbackFillKind(paths[i]);
                if (kind === "white") result.whitePaths.push(paths[i]);
                else if (kind === "black") result.blackPaths.push(paths[i]);
                else if (kind === "other") result.otherPaths.push(paths[i]);
            }
            return result;
        };

        var fallbackPathToSegment = function(pth) {
            try {
                var pp = pth.pathPoints;
                if (!pp || pp.length < 2) return "";
                var arr = [];
                for (var i = 0; i < pp.length; i++) {
                    var pt = pp[i];
                    var ax = Math.round(pt.anchor[0] * 100) / 100;
                    var ay = Math.round(-pt.anchor[1] * 100) / 100;
                    var ix = Math.round(pt.leftDirection[0] * 100) / 100;
                    var iy = Math.round(-pt.leftDirection[1] * 100) / 100;
                    var ox = Math.round(pt.rightDirection[0] * 100) / 100;
                    var oy = Math.round(-pt.rightDirection[1] * 100) / 100;
                    arr.push('{"a":[' + ax + ',' + ay + '],"inT":[' + ix + ',' + iy + '],"outT":[' + ox + ',' + oy + ']}');
                }
                return "[" + arr.join(",") + "]";
            } catch(e) {}
            return "";
        };

        var findFallbackTraceClipItem = function(group) {
            if (!group || group.typename !== "GroupItem") return null;
            try {
                for (var i = 0; i < group.pageItems.length; i++) {
                    if (group.pageItems[i].clipping === true) return group.pageItems[i];
                }
                for (var j = 0; j < group.pageItems.length; j++) {
                    var child = group.pageItems[j];
                    if (child.typename === "CompoundPathItem" &&
                        child.pathItems &&
                        child.pathItems.length > 0 &&
                        child.pathItems[0].clipping) {
                        return child;
                    }
                }
            } catch(e) {}
            return null;
        };

        var buildFallbackTraceSegments = function(item, bounds, workLayer, targetColor) {
            var result = {
                ok: false,
                targetColor: targetColor || "white",
                whitePathCount: 0,
                blackPathCount: 0,
                otherPathCount: 0,
                expandedPathCount: 0,
                segmentCount: 0,
                segments: [],
                attempts: [],
                errorMessage: ""
            };
            if (!item || !bounds || !workLayer) {
                result.errorMessage = "missing_item_bounds_or_workLayer";
                return result;
            }

            var runAttempt = function(clipOnly) {
                var dup = null, raster = null, traced = null, expanded = null, fillRect = null;
                var attempt = clipOnly ? "clipFlow" : "wholeObjectFlow";
                try {
                    dup = item.duplicate(workLayer, ElementPlacement.PLACEATBEGINNING);
                    dup.hidden = false;
                    dup.locked = false;

                    if (clipOnly) {
                        if (!dup || dup.typename !== "GroupItem") {
                            result.attempts.push(attempt + ":not_group");
                            try { if (dup) dup.remove(); } catch(e) {}
                            return false;
                        }
                        var clipItem = findFallbackTraceClipItem(dup);
                        if (!clipItem) {
                            result.attempts.push(attempt + ":no_clip_item");
                            try { if (dup) dup.remove(); } catch(e) {}
                            return false;
                        }
                        var toRemove = [];
                        for (var ri = 0; ri < dup.pageItems.length; ri++) {
                            if (dup.pageItems[ri] !== clipItem) toRemove.push(dup.pageItems[ri]);
                        }
                        for (var rr = 0; rr < toRemove.length; rr++) {
                            try { toRemove[rr].remove(); } catch(e) {}
                        }

                        var left = bounds[0] - 2;
                        var top = bounds[1] + 2;
                        var width = Math.max(1, (bounds[2] - bounds[0]) + 4);
                        var height = Math.max(1, (bounds[1] - bounds[3]) + 4);
                        fillRect = doc.pathItems.rectangle(top, left, width, height);
                        fillRect.stroked = false;
                        fillRect.filled = true;
                        var black = new RGBColor();
                        black.red = 0; black.green = 0; black.blue = 0;
                        fillRect.fillColor = black;
                        fillRect.move(dup, ElementPlacement.PLACEATEND);
                    }

                    var rastOpts = new RasterizeOptions();
                    rastOpts.resolution = 300;
                    rastOpts.transparency = true;
                    rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                    rastOpts.convertSpotColors = true;
                    rastOpts.convertTextToOutlines = false;

                    raster = doc.rasterize(dup, bounds, rastOpts);
                    if (!raster) {
                        result.attempts.push(attempt + ":rasterize_empty");
                        return false;
                    }

                    traced = raster.trace();
                    if (!traced) {
                        result.attempts.push(attempt + ":trace_empty");
                        return false;
                    }
                    try {
                        var tracingPresets = app.tracingPresetsList;
                        if (tracingPresets && tracingPresets.length > 0) {
                            traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                        }
                    } catch(e) {}
                    app.redraw();

                    try {
                        expanded = traced.tracing.expandTracing();
                    } catch(expandErr) {
                        expanded = traced;
                        result.errorMessage = "expandFallback:" + expandErr.message;
                    }
                    app.redraw();

                    var expandedPaths = collectFallbackTracePaths(expanded);
                    result.expandedPathCount += expandedPaths.length;
                    var fillGroups = collectFallbackPathsByFill(expanded);
                    result.whitePathCount += fillGroups.whitePaths.length;
                    result.blackPathCount += fillGroups.blackPaths.length;
                    result.otherPathCount += fillGroups.otherPaths.length;

                    var targetPaths = result.targetColor === "black" ? fillGroups.blackPaths : fillGroups.whitePaths;
                    for (var pi = 0; pi < targetPaths.length; pi++) {
                        var seg = fallbackPathToSegment(targetPaths[pi]);
                        if (seg) result.segments.push(seg);
                    }
                    result.segmentCount = result.segments.length;
                    result.ok = result.segmentCount > 0;
                    result.attempts.push(attempt + ":segments=" + result.segmentCount);
                    return result.ok;
                } catch(e) {
                    result.errorMessage = e.message;
                    result.attempts.push(attempt + ":error=" + e.message);
                    return false;
                } finally {
                    try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                    try { if (traced) traced.remove(); } catch(e) {}
                    try { if (raster) raster.remove(); } catch(e) {}
                    try { if (dup) dup.remove(); } catch(e) {}
                    try { if (fillRect) fillRect.remove(); } catch(e) {}
                }
            };

            if (!runAttempt(true)) {
                runAttempt(false);
            }
            return result;
        };

        var safeExecuteMenuCommand = function(commandNames, label, failureMessage) {
            var names = commandNames;
            if (typeof names === "string") names = [names];
            for (var i = 0; i < names.length; i++) {
                try {
                    app.executeMenuCommand(names[i]);
                    return "OK";
                } catch(e) {}
            }
            alert(failureMessage || ("无法调用 Illustrator 原生命令：" + label + "\n请确认当前 Illustrator 版本是否支持该菜单命令。"));
            return "COMMAND_FAILED";
        };

        var safeExecuteMenuSequence = function(commandNames, label, failureMessage) {
            try {
                for (var i = 0; i < commandNames.length; i++) {
                    app.executeMenuCommand(commandNames[i]);
                }
                return "OK";
            } catch(e) {
                alert(failureMessage || ("无法执行 Illustrator 原生命令：" + label + "\n" + e.message));
                return "COMMAND_FAILED";
            }
        };

        var tryMenuCommand = function(commandNames) {
            var names = commandNames;
            if (typeof names === "string") names = [names];
            for (var i = 0; i < names.length; i++) {
                try {
                    app.executeMenuCommand(names[i]);
                    return names[i];
                } catch(e) {}
            }
            return "";
        };

        var makeDefaultQuickFillColor = function() {
            var color = new RGBColor();
            color.red = 255;
            color.green = 255;
            color.blue = 255;
            return color;
        };

        var cloneIllustratorColor = function(color) {
            try {
                if (!color || color.typename === "NoColor") return null;
                var t = color.typename;
                if (t === "RGBColor") {
                    var rgb = new RGBColor();
                    rgb.red = color.red;
                    rgb.green = color.green;
                    rgb.blue = color.blue;
                    return rgb;
                }
                if (t === "CMYKColor") {
                    var cmyk = new CMYKColor();
                    cmyk.cyan = color.cyan;
                    cmyk.magenta = color.magenta;
                    cmyk.yellow = color.yellow;
                    cmyk.black = color.black;
                    return cmyk;
                }
                if (t === "GrayColor") {
                    var gray = new GrayColor();
                    gray.gray = color.gray;
                    return gray;
                }
                if (t === "SpotColor") {
                    var spot = new SpotColor();
                    spot.spot = color.spot;
                    spot.tint = color.tint;
                    return spot;
                }
                return color;
            } catch(e) {}
            return null;
        };

        var getFirstValidFillColor = function(items) {
            if (!items) return null;
            var visit = function(item) {
                try {
                    if (!item || item.hidden || item.locked) return null;
                } catch(e0) {}
                try {
                    if (item.typename === "PathItem") {
                        if (item.filled && item.fillColor && item.fillColor.typename !== "NoColor") {
                            return cloneIllustratorColor(item.fillColor);
                        }
                    }
                } catch(e1) {}
                try {
                    if (item.typename === "CompoundPathItem") {
                        for (var c = 0; c < item.pathItems.length; c++) {
                            var compoundColor = visit(item.pathItems[c]);
                            if (compoundColor) return compoundColor;
                        }
                    }
                } catch(e2) {}
                try {
                    if (item.pageItems) {
                        for (var p = 0; p < item.pageItems.length; p++) {
                            var childColor = visit(item.pageItems[p]);
                            if (childColor) return childColor;
                        }
                    }
                } catch(e3) {}
                return null;
            };
            for (var i = 0; i < items.length; i++) {
                var color = visit(items[i]);
                if (color) return color;
            }
            return null;
        };

        var applyFillColorDeep = function(item, color) {
            if (!item || !color) return 0;
            var changed = 0;
            try {
                if (item.typename === "PathItem") {
                    item.filled = true;
                    item.fillColor = cloneIllustratorColor(color) || color;
                    changed++;
                } else if (item.typename === "CompoundPathItem") {
                    try {
                        item.filled = true;
                        item.fillColor = cloneIllustratorColor(color) || color;
                        changed++;
                    } catch(compoundOuterErr) {}
                    for (var c = 0; c < item.pathItems.length; c++) {
                        changed += applyFillColorDeep(item.pathItems[c], color);
                    }
                } else if (item.pageItems) {
                    for (var p = 0; p < item.pageItems.length; p++) {
                        changed += applyFillColorDeep(item.pageItems[p], color);
                    }
                }
            } catch(e) {}
            return changed;
        };

        var runQuickUnionCompoundExpand = function() {
            try {
                var savedFillColor = getFirstValidFillColor(originalSel) || makeDefaultQuickFillColor();
                var groupCommand = tryMenuCommand(["group"]);
                if (!groupCommand) throw new Error("无法建立临时编组");
                var unionCommand = tryMenuCommand(["Live Pathfinder Add", "Pathfinder Add", "Add"]);
                if (!unionCommand) throw new Error("无法执行联集命令");

                // Pathfinder works reliably on a grouped selection; expand and ungroup before making the final compound path.
                tryMenuCommand(["expandStyle"]);
                for (var u = 0; u < 4; u++) {
                    if (!tryMenuCommand(["ungroup"])) break;
                }

                var compoundCommand = tryMenuCommand(["compoundPath", "makeCompoundPath", "Make Compound Path"]);
                if (!compoundCommand) throw new Error("无法建立复合路径");

                // Finalize any remaining live appearance. Some versions only expose expandStyle through scripting.
                tryMenuCommand(["expandStyle", "expand"]);
                var restoredCount = 0;
                try {
                    for (var s = 0; s < app.selection.length; s++) {
                        restoredCount += applyFillColorDeep(app.selection[s], savedFillColor);
                    }
                } catch(fillErr) {}
                try { app.redraw(); } catch(redrawErr) {}
                return "OK group=" + groupCommand + " union=" + unionCommand + " compound=" + compoundCommand + " fillPaths=" + restoredCount;
            } catch(e) {
                alert("联集扩展失败，请确认选中的是可编辑路径对象。");
                return "COMMAND_FAILED:" + e.message;
            }
        };

        var hexToRgb = function(hex) {
            var clean = String(hex || "#000000").replace("#", "");
            if (!/^[0-9a-fA-F]{6}$/.test(clean)) clean = "000000";
            return {
                r: parseInt(clean.substring(0, 2), 16),
                g: parseInt(clean.substring(2, 4), 16),
                b: parseInt(clean.substring(4, 6), 16),
                rn: Math.round((parseInt(clean.substring(0, 2), 16) / 255) * 1000) / 1000,
                gn: Math.round((parseInt(clean.substring(2, 4), 16) / 255) * 1000) / 1000,
                bn: Math.round((parseInt(clean.substring(4, 6), 16) / 255) * 1000) / 1000
            };
        };

        var isDropShadowPreview = function(item) {
            try {
                if (!item) return false;
                if (String(item.name || "").indexOf("HH_DROP_SHADOW_NATIVE_PREVIEW") >= 0) return true;
                if (String(item.note || "").indexOf("HH_DROP_SHADOW_NATIVE_PREVIEW") >= 0) return true;
                if (String(item.name || "").indexOf("HH_DROP_SHADOW_PREVIEW") >= 0) return true;
                if (String(item.note || "").indexOf("HH_DROP_SHADOW_PREVIEW") >= 0) return true;
            } catch(e) {}
            return false;
        };

        var isNativePreviewLayer = function(layer) {
            try {
                return layer && String(layer.name || "") === "HH_DROP_SHADOW_NATIVE_PREVIEW_LAYER";
            } catch(e) {}
            return false;
        };

        var readDropShadowParams = function(showAlert) {
            var ptPerMm = 2.83464567;
            var offsetX = parseFloat(params.offsetXmm);
            var offsetY = parseFloat(params.offsetYmm);
            var blurMm = parseFloat(params.blurMm);
            var opacityPct = parseFloat(params.opacity);
            var colorHex = String(params.colorHex || "#000000");
            var blendMode = String(params.blendMode || "multiply").toLowerCase();

            if (isNaN(offsetX)) offsetX = 2;
            if (isNaN(offsetY)) offsetY = 2;
            if (isNaN(blurMm)) blurMm = 2;
            if (isNaN(opacityPct)) opacityPct = 40;
            if (blendMode !== "normal") blendMode = "multiply";
            if (blurMm < 0 || opacityPct < 0 || opacityPct > 100 || !/^#[0-9a-fA-F]{6}$/.test(colorHex)) {
                if (showAlert) alert("请检查投影参数");
                return null;
            }

            var rgb = hexToRgb(colorHex);
            return {
                offsetXPt: offsetX * ptPerMm,
                offsetYPt: offsetY * ptPerMm,
                blurPt: blurMm * ptPerMm,
                opacityValue: opacityPct / 100,
                blendValue: blendMode === "normal" ? 0 : 1,
                red: rgb.r,
                green: rgb.g,
                blue: rgb.b,
                redNorm: rgb.rn,
                greenNorm: rgb.gn,
                blueNorm: rgb.bn,
                colorHex: colorHex,
                blendMode: blendMode,
                debugColor: colorHex + " rgb=" + rgb.r + "," + rgb.g + "," + rgb.b
            };
        };

        var removeDropShadowPreviews = function() {
            var removed = 0;
            try {
                for (var li = doc.layers.length - 1; li >= 0; li--) {
                    try {
                        var layer = doc.layers[li];
                        if (isNativePreviewLayer(layer)) {
                            layer.locked = false;
                            layer.visible = true;
                            layer.remove();
                            removed++;
                        }
                    } catch(layerErr) {}
                }
                for (var i = doc.pageItems.length - 1; i >= 0; i--) {
                    try {
                        var item = doc.pageItems[i];
                        if (isDropShadowPreview(item)) {
                            item.remove();
                            removed++;
                        }
                    } catch(e1) {}
                }
            } catch(e2) {}
            return removed;
        };

        var restoreSelection = function(items) {
            try {
                doc.selection = null;
                for (var i = 0; i < items.length; i++) {
                    try {
                        if (!isDropShadowPreview(items[i])) items[i].selected = true;
                    } catch(e1) {}
                }
            } catch(e2) {}
        };

        var buildDropShadowEffectXmls = function(parsed) {
            var data = 'I blnd ' + parsed.blendValue +
                ' R opac ' + parsed.opacityValue +
                ' R horz ' + parsed.offsetXPt +
                ' R vert ' + parsed.offsetYPt +
                ' R blur ' + parsed.blurPt +
                ' B usePSLBlur 1 I csrc 0 R dark 100 B pair 1 ';
            var rgbModelColor = "5 " + parsed.redNorm + " " + parsed.greenNorm + " " + parsed.blueNorm;
            var legacyRgbColor = parsed.red + " " + parsed.green + " " + parsed.blue;
            return [
                {
                    name: "sclr-rgb-model",
                    colorFragment: 'sclr=' + rgbModelColor,
                    xml: '<LiveEffect name="Adobe Drop Shadow"><Dict data="' + data + '"><Entry name="sclr" valueType="F"><Fill color="' + rgbModelColor + '"/></Entry></Dict></LiveEffect>'
                },
                {
                    name: "sclr-legacy-rgb",
                    colorFragment: 'sclr=' + legacyRgbColor,
                    xml: '<LiveEffect name="Adobe Drop Shadow"><Dict data="' + data + '"><Entry name="sclr" valueType="F"><Fill color="' + legacyRgbColor + '"/></Entry></Dict></LiveEffect>'
                },
                {
                    name: "simple-default-color",
                    colorFragment: "no-color-entry",
                    xml: '<LiveEffect name="Adobe Drop Shadow"><Dict data="' + data + '" /></LiveEffect>'
                }
            ];
        };

        var dropShadowLastCandidate = "";
        var dropShadowLastColorFragment = "";

        var applyNativeDropShadowLiveEffect = function(items, parsed) {
            var xmls = buildDropShadowEffectXmls(parsed);
            var count = 0;
            dropShadowLastCandidate = "";
            dropShadowLastColorFragment = "";
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (!item || !item.applyEffect) continue;
                for (var x = 0; x < xmls.length; x++) {
                    try {
                        item.applyEffect(xmls[x].xml);
                        if (!dropShadowLastCandidate) {
                            dropShadowLastCandidate = xmls[x].name;
                            dropShadowLastColorFragment = xmls[x].colorFragment;
                        }
                        count++;
                        break;
                    } catch(e) {
                        if (x === xmls.length - 1) {}
                    }
                }
            }
            return count;
        };

        var runNativeDropShadowPreview = function() {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }
            var parsed = readDropShadowParams(false);
            if (!parsed) return "BAD_PARAMS";
            var originals = [];
            for (var i = 0; i < originalSel.length; i++) {
                if (!isDropShadowPreview(originalSel[i])) originals.push(originalSel[i]);
            }
            if (originals.length === 0) {
                alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }
            removeDropShadowPreviews();
            var previewLayer = null;
            try {
                previewLayer = doc.layers.add();
                previewLayer.name = "HH_DROP_SHADOW_NATIVE_PREVIEW_LAYER";
            } catch(layerErr) {
                return "COMMAND_FAILED";
            }
            var previewItems = [];
            for (var p = 0; p < originals.length; p++) {
                try {
                    if (!originals[p] || !originals[p].duplicate) continue;
                    var dup = originals[p].duplicate(previewLayer, ElementPlacement.PLACEATEND);
                    dup.name = "HH_DROP_SHADOW_NATIVE_PREVIEW";
                    try { dup.note = "HH_DROP_SHADOW_NATIVE_PREVIEW"; } catch(noteErr) {}
                    previewItems.push(dup);
                } catch(dupErr) {}
            }
            if (previewItems.length === 0) {
                try { previewLayer.remove(); } catch(removeErr) {}
                restoreSelection(originals);
                return "COMMAND_FAILED";
            }
            try {
                doc.selection = null;
                for (var ps = 0; ps < previewItems.length; ps++) {
                    try { previewItems[ps].selected = true; } catch(selErr1) {}
                }
            } catch(selErr2) {}
            var count = applyNativeDropShadowLiveEffect(previewItems, parsed);
            if (count === 0) {
                try { previewLayer.remove(); } catch(removeErr2) {}
                restoreSelection(originals);
                return "COMMAND_FAILED";
            }
            try {
                for (var s = 0; s < previewItems.length; s++) {
                    try { previewItems[s].selected = false; } catch(selErr) {}
                }
            } catch(e3) {}
            restoreSelection(originals);
            return count > 0 ? ("OK_NATIVE_PREVIEW color=" + parsed.debugColor + " candidate=" + dropShadowLastCandidate + " " + dropShadowLastColorFragment) : "COMMAND_FAILED";
        };

        var runNativeDropShadowApply = function() {
            removeDropShadowPreviews();
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }
            var parsed = readDropShadowParams(true);
            if (!parsed) return "BAD_PARAMS";
            var count = applyNativeDropShadowLiveEffect(originalSel, parsed);
            if (count > 0) {
                try {
                    restoreSelection(originalSel);
                } catch(e2) {}
                alert("已添加原生投影，可在 Illustrator 外观面板中继续编辑");
                return "OK_NATIVE_LIVE_EFFECT color=" + parsed.debugColor + " candidate=" + dropShadowLastCandidate + " " + dropShadowLastColorFragment;
            }
            alert("当前 Illustrator 版本无法通过脚本添加原生投影，请手动使用：效果 > 风格化 > 投影");
            return "COMMAND_FAILED";
        };

        var runDropShadowPreview = function() {
            return runNativeDropShadowPreview();
        };

        var runDropShadowCancel = function() {
            removeDropShadowPreviews();
            return "OK_CANCEL";
        };

        if (quickActions[action]) {
            if (quickActionsNeedSelection[action] && (!originalSel || originalSel.length === 0)) {
                if (action === "quick_union_compound_expand") alert("请先选中要扩展的对象。");
                if (action === "outline_stroke") alert("请先选中需要处理的对象");
                if (action === "offset_path") alert("请先选中需要偏移的对象");
                if (action === "simplify_path") alert("请先选中需要简化的对象");
                if (action === "create_text_outlines") alert("请先选中需要转曲的文字");
                if (action === "drop_shadow" || action === "drop_shadow_preview" || action === "drop_shadow_native_preview") alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }

            if (action === "quick_union_compound_expand") {
                // 路径查找器联集 → 复合路径建立 → 扩展外观，保留 Illustrator 当前结果选区。
                return runQuickUnionCompoundExpand();
            }
            if (action === "outline_stroke") {
                // 对象 > 路径 > 轮廓化描边：先调用 Illustrator 的 Live Outline Stroke，再扩展外观落成真实路径。
                return safeExecuteMenuSequence(["Live Outline Stroke", "expandStyle"], "轮廓描边");
            }
            if (action === "offset_path") {
                // 对象 > 路径 > 偏移路径：恢复 v28.140 中已可用的 Illustrator 原生 Offset Path 弹窗调用链。
                return safeExecuteMenuCommand(["OffsetPath v23", "OffsetPath v22", "OffsetPath v21", "OffsetPath v20", "OffsetPath v19", "OffsetPath v18", "OffsetPath"], "路径偏移");
            }
            if (action === "simplify_path") {
                // 对象 > 路径 > 简化：优先打开 Illustrator 原生 Simplify 弹窗。
                return safeExecuteMenuCommand(["Simplify menu item", "simplify menu item", "Simplify", "SimplifyUI", "Path Simplify"], "简化路径");
            }
            if (action === "create_text_outlines") {
                // 文字 > 创建轮廓：Illustrator executeMenuCommand('outline') 对应 Type > Create Outlines。
                return safeExecuteMenuCommand(["outline"], "文字转曲");
            }
            if (action === "drop_shadow") {
                // 效果 > 风格化 > 投影：使用 Illustrator 原生 Live Effect，外观面板可继续编辑。
                return runNativeDropShadowApply();
            }
            if (action === "drop_shadow_preview") {
                return runDropShadowPreview();
            }
            if (action === "drop_shadow_apply") {
                return runNativeDropShadowApply();
            }
            if (action === "drop_shadow_cancel") {
                return runDropShadowCancel();
            }
            if (action === "drop_shadow_native_preview") {
                return runNativeDropShadowPreview();
            }
            if (action === "drop_shadow_native_apply") {
                return runNativeDropShadowApply();
            }
            if (action === "drop_shadow_native_cancel") {
                return runDropShadowCancel();
            }
        }

        var parseArtboardRange = function(input, totalCount) {
            var raw = String(input || "全部").replace(/\s+/g, "");
            if (raw === "" || raw === "全部" || raw.toLowerCase() === "all") {
                return {
                    rangeString: "1-" + totalCount,
                    indexes: (function() {
                        var all = [];
                        for (var ai = 1; ai <= totalCount; ai++) all.push(ai);
                        return all;
                    })()
                };
            }
            if (!/^[0-9]+(-[0-9]+)?(,[0-9]+(-[0-9]+)?)*$/.test(raw)) return null;
            var parts = raw.split(",");
            var indexes = [];
            var seen = {};
            for (var pi = 0; pi < parts.length; pi++) {
                var part = parts[pi];
                var start;
                var end;
                if (part.indexOf("-") >= 0) {
                    var pair = part.split("-");
                    start = parseInt(pair[0], 10);
                    end = parseInt(pair[1], 10);
                } else {
                    start = parseInt(part, 10);
                    end = start;
                }
                if (isNaN(start) || isNaN(end) || start < 1 || end < start || end > totalCount) return null;
                for (var ri = start; ri <= end; ri++) {
                    if (!seen[ri]) {
                        seen[ri] = true;
                        indexes.push(ri);
                    }
                }
            }
            indexes.sort(function(a, b) { return a - b; });
            return {
                rangeString: raw,
                indexes: indexes
            };
        };

        var parseScaleRatio = function(value) {
            var raw = String(value || "1:1").replace(/\s+/g, "");
            var m = raw.match(/^1:([0-9]+(\.[0-9]+)?)$/);
            if (!m) return null;
            var scale = parseFloat(m[1]);
            if (isNaN(scale) || scale <= 0) return null;
            return scale;
        };

        var sanitizeFileName = function(name) {
            return String(name || "export").replace(/\.[^\.]+$/, "").replace(/[\\\/:\*\?"<>\|]/g, "_");
        };

        var unionBounds = function(a, b) {
            if (!a) return b;
            if (!b) return a;
            return [
                Math.min(a[0], b[0]),
                Math.max(a[1], b[1]),
                Math.max(a[2], b[2]),
                Math.min(a[3], b[3])
            ];
        };

        var validBounds = function(bounds) {
            return bounds && bounds.length === 4 && bounds[2] > bounds[0] && bounds[1] > bounds[3];
        };

        var findClippingMaskBounds = function(item) {
            if (!item) return null;
            try {
                if (item.typename === "PathItem" && item.clipping) return item.geometricBounds;
            } catch(e0) {}
            try {
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        try {
                            if (item.pathItems[cpi].clipping) return item.pathItems[cpi].geometricBounds;
                        } catch(e1) {}
                    }
                }
            } catch(e2) {}
            try {
                if (item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        var childBounds = findClippingMaskBounds(item.pageItems[i]);
                        if (childBounds) return childBounds;
                    }
                }
            } catch(e3) {}
            return null;
        };

        var getItemExportBounds = function(item) {
            if (!item) return null;
            try {
                if (item.typename === "GroupItem" && item.clipped) {
                    var clipB = findClippingMaskBounds(item);
                    if (validBounds(clipB)) return clipB;
                }
            } catch(e0) {}
            try {
                var nestedClip = findClippingMaskBounds(item);
                if (item.typename === "GroupItem" && validBounds(nestedClip)) return nestedClip;
            } catch(e1) {}
            try {
                if (item.visibleBounds && validBounds(item.visibleBounds)) return item.visibleBounds;
            } catch(e2) {}
            try {
                if (item.geometricBounds && validBounds(item.geometricBounds)) return item.geometricBounds;
            } catch(e3) {}
            return null;
        };

        var renameAllArtboardsSequential = function(docRef) {
            var count = docRef.artboards.length;
            for (var ai = 0; ai < count; ai++) {
                docRef.artboards[ai].name = String(ai + 1);
            }
            return count;
        };

        if (action === "rename_artboards") {
            var renamedCount = renameAllArtboardsSequential(doc);
            alert("已重新命名 " + renamedCount + " 个画板");
            return "OK_RENAME_ARTBOARDS:" + renamedCount;
        }

        if (action === "create_artboards_from_selection") {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选择需要生成画板的对象");
                return "NO_SEL";
            }
            var created = 0;
            for (var cab = 0; cab < originalSel.length; cab++) {
                var b = getItemExportBounds(originalSel[cab]);
                if (!validBounds(b)) continue;
                try {
                    doc.artboards.add([b[0], b[1], b[2], b[3]]);
                    created++;
                } catch(addErr) {}
            }
            if (created === 0) {
                alert("未能根据选中对象生成画板");
                return "NO_BOUNDS";
            }
            renameAllArtboardsSequential(doc);
            alert("已生成 " + created + " 个画板，并按顺序重命名");
            return "OK_CREATE_ARTBOARDS:" + created;
        }

        if (action === "export_pdf_by_artboards") {
            var pdfRange = parseArtboardRange(params.range, doc.artboards.length);
            var pdfDpi = parseFloat(params.dpi);
            if (isNaN(pdfDpi) || pdfDpi <= 0) {
                alert("分辨率请输入正数");
                return "BAD_DPI";
            }
            if (!pdfRange) {
                alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
                return "BAD_RANGE";
            }
            var pdfFile = File.saveDialog("保存 PDF", "*.pdf");
            if (!pdfFile) return "CANCEL";
            var pdfPath = String(pdfFile.fsName);
            if (!/\.pdf$/i.test(pdfPath)) pdfFile = new File(pdfPath + ".pdf");
            try {
                var pdfOptions = new PDFSaveOptions();
                pdfOptions.saveMultipleArtboards = true;
                pdfOptions.artboardRange = pdfRange.rangeString;
                try { pdfOptions.preserveEditability = true; } catch(pdfOptErr) {}
                try { pdfOptions.colorDownsampling = pdfDpi; } catch(pdfDpiErr1) {}
                try { pdfOptions.colorDownsamplingImageThreshold = pdfDpi; } catch(pdfDpiErr2) {}
                try { pdfOptions.grayscaleDownsampling = pdfDpi; } catch(pdfDpiErr3) {}
                try { pdfOptions.grayscaleDownsamplingImageThreshold = pdfDpi; } catch(pdfDpiErr4) {}
                try { pdfOptions.monochromeDownsampling = pdfDpi; } catch(pdfDpiErr5) {}
                try { pdfOptions.monochromeDownsamplingImageThreshold = pdfDpi; } catch(pdfDpiErr6) {}
                doc.saveAs(pdfFile, pdfOptions);
                alert("PDF 导出完成");
                return "OK_EXPORT_PDF";
            } catch(pdfErr) {
                alert("PDF 导出失败：" + pdfErr.message);
                return "EXPORT_PDF_FAILED";
            }
        }

        if (action === "export_images") {
            var imageMode = String(params.mode || "selection");
            var imageFormat = String(params.format || "png").toLowerCase();
            var colorMode = String(params.colorMode || "rgb").toLowerCase();
            var dpiValue = parseFloat(params.dpi);
            var scaleValue = parseScaleRatio(params.scale);
            if (isNaN(dpiValue) || dpiValue <= 0) {
                alert("分辨率请输入正数");
                return "BAD_DPI";
            }
            if (!scaleValue) {
                alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
                return "BAD_SCALE";
            }
            if (imageFormat !== "jpg") imageFormat = "png";
            var exportFolder = Folder.selectDialog("选择图片导出文件夹");
            if (!exportFolder) return "CANCEL";
            var dpiExportScale = (dpiValue / 72.0) * 100.0;
            var artboardExportScale = dpiExportScale * scaleValue;
            var maxExportScale = 776.0;
            var docBaseName = sanitizeFileName(doc.name);
            var exportType = imageFormat === "jpg" ? ExportType.JPEG : ExportType.PNG24;
            var makeOptions = function(scalePercent) {
                if (scalePercent > maxExportScale) {
                    throw new Error("导出比例或分辨率过大，请降低比例或分辨率");
                }
                if (imageFormat === "jpg") {
                    var jpgOptions = new ExportOptionsJPEG();
                    jpgOptions.antiAliasing = true;
                    jpgOptions.artBoardClipping = true;
                    jpgOptions.qualitySetting = 90;
                    jpgOptions.horizontalScale = scalePercent;
                    jpgOptions.verticalScale = scalePercent;
                    return jpgOptions;
                }
                var pngOptions = new ExportOptionsPNG24();
                pngOptions.antiAliasing = true;
                pngOptions.transparency = true;
                pngOptions.artBoardClipping = true;
                pngOptions.horizontalScale = scalePercent;
                pngOptions.verticalScale = scalePercent;
                return pngOptions;
            };

            if (colorMode === "cmyk") {
                alert("当前图片格式以 Illustrator 位图导出能力为准；CMYK 成品建议导出 PDF 或另存 AI/EPS。");
            }

            if (imageMode === "artboards") {
                var imageRange = parseArtboardRange(params.range, doc.artboards.length);
                if (!imageRange) {
                    alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
                    return "BAD_RANGE";
                }
                var originalIndex = doc.artboards.getActiveArtboardIndex();
                var exportedBoards = 0;
                try {
                    for (var abi = 0; abi < imageRange.indexes.length; abi++) {
                        var boardNumber = imageRange.indexes[abi];
                        doc.artboards.setActiveArtboardIndex(boardNumber - 1);
                        var outFile = new File(exportFolder.fsName + "/" + docBaseName + "_画板" + boardNumber + "." + imageFormat);
                        doc.exportFile(outFile, exportType, makeOptions(artboardExportScale));
                        exportedBoards++;
                    }
                    doc.artboards.setActiveArtboardIndex(originalIndex);
                    alert("图片导出完成，共 " + exportedBoards + " 张");
                    return "OK_EXPORT_IMAGES:" + exportedBoards;
                } catch(boardExportErr) {
                    try { doc.artboards.setActiveArtboardIndex(originalIndex); } catch(resetErr) {}
                    alert("图片导出失败：按画板导出 PNG/JPG 文件失败。\n" + boardExportErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }
            }

            if (!originalSel || originalSel.length === 0) {
                alert("请先选择需要导出的对象");
                return "NO_SEL";
            }
            var originalArtboardIndex = -1;
            var tempArtboardIndex = -1;
            var tempLayer = null;
            var hiddenItems = [];
            try {
                originalArtboardIndex = doc.artboards.getActiveArtboardIndex();
            } catch(indexErr) {}
            try {
                var originalBounds = null;
                for (var obi = 0; obi < originalSel.length; obi++) {
                    originalBounds = unionBounds(originalBounds, getItemExportBounds(originalSel[obi]));
                }
                if (!validBounds(originalBounds)) {
                    alert("图片导出失败：识别选中对象范围失败。");
                    return "NO_BOUNDS";
                }

                try {
                    tempLayer = doc.layers.add();
                    tempLayer.name = "HH_IMAGE_EXPORT_TEMP_LAYER";
                } catch(layerErr) {
                    alert("图片导出失败：准备临时图层失败。\n" + layerErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }

                var duplicated = [];
                for (var si = 0; si < originalSel.length; si++) {
                    try {
                        duplicated.push(originalSel[si].duplicate(tempLayer, ElementPlacement.PLACEATEND));
                    } catch(dupErr) {}
                }
                if (duplicated.length === 0) {
                    alert("图片导出失败：复制选中对象失败。");
                    return "EXPORT_IMAGES_FAILED";
                }

                for (var hi = 0; hi < originalSel.length; hi++) {
                    try {
                        hiddenItems.push({ item: originalSel[hi], hidden: originalSel[hi].hidden });
                        originalSel[hi].hidden = true;
                    } catch(hiddenErr) {}
                }

                if (scaleValue !== 1) {
                    for (var rs = 0; rs < duplicated.length; rs++) {
                        try {
                            duplicated[rs].resize(scaleValue * 100.0, scaleValue * 100.0, true, true, true, true, scaleValue * 100.0, Transformation.CENTER);
                        } catch(resizeErr) {}
                    }
                }

                var exportBounds = null;
                for (var dbi = 0; dbi < duplicated.length; dbi++) {
                    exportBounds = unionBounds(exportBounds, getItemExportBounds(duplicated[dbi]));
                }
                if (!validBounds(exportBounds)) {
                    alert("图片导出失败：设置导出画板前未能识别临时对象范围。");
                    return "NO_BOUNDS";
                }

                try {
                    doc.artboards.add([exportBounds[0], exportBounds[1], exportBounds[2], exportBounds[3]]);
                    tempArtboardIndex = doc.artboards.length - 1;
                    doc.artboards.setActiveArtboardIndex(tempArtboardIndex);
                } catch(artboardErr) {
                    alert("图片导出失败：设置导出画板失败。\n" + artboardErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }

                var selectionFile = new File(exportFolder.fsName + "/" + docBaseName + "_选中对象." + imageFormat);
                try {
                    doc.exportFile(selectionFile, exportType, makeOptions(dpiExportScale));
                } catch(exportErr) {
                    alert("图片导出失败：导出 PNG/JPG 文件失败。\n" + exportErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }
                alert("图片导出完成，共 1 张");
                return "OK_EXPORT_IMAGES:1";
            } catch(selectionExportErr) {
                alert("图片导出失败：选中对象导出流程异常。\n" + selectionExportErr.message);
                return "EXPORT_IMAGES_FAILED";
            } finally {
                try {
                    if (tempArtboardIndex >= 0 && doc.artboards.length > 1) {
                        doc.artboards[tempArtboardIndex].remove();
                    }
                } catch(removeBoardErr) {}
                try {
                    if (originalArtboardIndex >= 0 && originalArtboardIndex < doc.artboards.length) {
                        doc.artboards.setActiveArtboardIndex(originalArtboardIndex);
                    }
                } catch(resetBoardErr) {}
                try {
                    for (var rh = 0; rh < hiddenItems.length; rh++) {
                        try { hiddenItems[rh].item.hidden = hiddenItems[rh].hidden; } catch(restoreHiddenErr) {}
                    }
                } catch(hiddenRestoreLoopErr) {}
                try {
                    if (tempLayer) {
                        tempLayer.locked = false;
                        tempLayer.visible = true;
                        tempLayer.remove();
                    }
                } catch(removeLayerErr) {}
                try { restoreSelection(originalSel); } catch(restoreSelErr) {}
            }
        }
        
        if (action === "filter_missing") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先框选需要检查的对象范围！"); return "NO_SEL"; }
            var missing =[];
            for (var i = 0; i < originalSel.length; i++) {
                if (tools.getTagD(originalSel[i].name) === null) {
                    missing.push(originalSel[i]);
                }
            }
            if (missing.length > 0) {
                doc.selection = null; 
                for (var j = 0; j < missing.length; j++) { missing[j].selected = true; }
                alert("🔍 已为您筛选出 " + missing.length + " 个【未设置厚度】的对象！\n您可以直接点击上方按钮为其设置厚度。");
            } else {
                alert("✅ 太棒了！当前选中的 " + originalSel.length + " 个对象都已经设置过厚度了。");
            }
            return "OK";
        }

        if (action === "set_thickness") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先选中对象"); return; }
            var dVal = params.val; 
            for (var i = 0; i < originalSel.length; i++) {
                var item = originalSel[i];
                var oldType = tools.getTagT(item.name);
                item.name = tools.rebuildName(item.name, dVal, oldType, tools.getFallbackExport(item.name), tools.getFallbackReverse(item.name));
            }
            return "OK"; 
        }

        if (action === "set_craft_marker") {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中要标注工艺的对象");
                return "CRAFT_INFO:请先选中要标注工艺的对象";
            }
            var craftTypeToSet = normalizeCraftType(params.craftType || params.type || "none");
            var craftParamsToSet = mergeCraftParams(craftTypeToSet, params.craftParams || params.params || {});
            var craftSetCount = 0;
            for (var cmi = 0; cmi < originalSel.length; cmi++) {
                if (setCraftMarker(originalSel[cmi], craftTypeToSet, craftParamsToSet)) craftSetCount++;
            }
            try { restoreSelection(originalSel); } catch(craftRestoreErr) {}
            if (!params.silent) alert("已标注：" + (CRAFT_LABELS[craftTypeToSet] || CRAFT_LABELS.none));
            return "CRAFT_INFO:已标注：" + (CRAFT_LABELS[craftTypeToSet] || CRAFT_LABELS.none) + " count=" + craftSetCount;
        }

        if (action === "clear_craft_marker") {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中要标注工艺的对象");
                return "CRAFT_INFO:请先选中要标注工艺的对象";
            }
            var craftClearCount = 0;
            for (var cci = 0; cci < originalSel.length; cci++) {
                if (clearCraftMarker(originalSel[cci])) craftClearCount++;
            }
            try { restoreSelection(originalSel); } catch(craftClearRestoreErr) {}
            if (!params.silent) alert("已清除工艺标注");
            return "CRAFT_INFO:已清除工艺标注 count=" + craftClearCount;
        }

        if (action === "get_craft_marker") {
            return readCraftInfoForSelection();
        }

        if (action === "set_fallback_export") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先选中对象"); return; }
            var enabled = !!params.enabled;
            for (var fbi = 0; fbi < originalSel.length; fbi++) {
                var fbItem = originalSel[fbi];
                var itemD = tools.getTagD(fbItem.name);
                var itemT = tools.getTagT(fbItem.name);
                fbItem.name = tools.rebuildName(fbItem.name, itemD, itemT, enabled, false);
            }
            alert(enabled ? "✅ 已标记为【兜底导出】" : "✅ 已取消【兜底导出】标记");
            return "OK";
        }

        if (action === "set_fallback_reverse") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先选中对象"); return; }
            var reverseEnabled = !!params.enabled;
            for (var fri = 0; fri < originalSel.length; fri++) {
                var frItem = originalSel[fri];
                var frD = tools.getTagD(frItem.name);
                var frT = tools.getTagT(frItem.name);
                frItem.name = tools.rebuildName(frItem.name, frD, frT, true, reverseEnabled);
            }
            alert(reverseEnabled ? "✅ 已标记为【反选兜底区域】" : "✅ 已取消【反选兜底区域】标记");
            return "OK";
        }

        if (action === "set_stroke_thickness_export") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先选中对象"); return; }
            var strokeExportEnabled = !!params.enabled;
            var defaultDepthApplied = 0;
            var removedGeneratedCount = 0;
            var markedStrokeExportInfo = [];
            for (var sti = 0; sti < originalSel.length; sti++) {
                var stItem = originalSel[sti];
                var sourceKeyForCancel = getGeneratedFromKey(stItem) || getStrokeThicknessSourceKey(stItem);
                if (strokeExportEnabled && parseStrokeThicknessDepthMm(stItem) === null) {
                    if (setStrokeThicknessDepthMm(stItem, DEFAULT_STROKE_THICKNESS_DEPTH_MM)) defaultDepthApplied++;
                }
                setStrokeThicknessExportFlag(stItem, strokeExportEnabled);
                setSkipExportFlag(stItem, false);
                var stD = tools.getTagD(stItem.name);
                var stT = tools.getTagT(stItem.name);
                stItem.name = tools.rebuildName(
                    stItem.name,
                    stD,
                    stT,
                    tools.getFallbackExport(stItem.name),
                    tools.getFallbackReverse(stItem.name),
                    strokeExportEnabled
                );
                if (!strokeExportEnabled) {
                    clearStrokeThicknessSourceFlagsByKey(sourceKeyForCancel);
                    removedGeneratedCount += removeStrokeThicknessGeneratedItems(sourceKeyForCancel);
                } else {
                    markedStrokeExportInfo.push(
                        "对象：" + String(stItem.name || "") +
                        "\n描边厚度：" + formatStrokeThicknessDepthMm(parseStrokeThicknessDepthMm(stItem)) +
                        "\nHH_STROKE_THICKNESS_EXPORT=" + (hasStrokeThicknessExportFlag(stItem) ? "1" : "0")
                    );
                }
            }
            try { restoreSelection(originalSel); } catch(restoreStrokeExportSelErr) {}
            alert(strokeExportEnabled ?
                ("✅ 已标记描边厚度导出\n开始导出时将自动拆分为 _fill / _stroke 两个对象\n" + markedStrokeExportInfo.join("\n\n") + (defaultDepthApplied > 0 ? "\n未设置厚度的对象已使用默认 20mm" : "")) :
                ("✅ 已取消【描边厚度导出】标记\n已删除自动生成对象：" + removedGeneratedCount));
            return "OK";
        }

        if (action === "set_stroke_thickness_depth") {
            if (!originalSel || originalSel.length === 0) {
                alert("⚠️ 请先选中对象");
                return "STROKE_DEPTH_INFO:描边厚度导出厚度：未设置";
            }
            var depthMm = parseFloat(params.depthMm);
            if (isNaN(depthMm) || depthMm <= 0) {
                alert("请输入有效的描边厚度导出厚度");
                return readStrokeThicknessDepthInfo();
            }
            var updatedDepthCount = 0;
            for (var sdi = 0; sdi < originalSel.length; sdi++) {
                if (setStrokeThicknessDepthMm(originalSel[sdi], depthMm)) updatedDepthCount++;
            }
            return readStrokeThicknessDepthInfo();
        }

        if (action === "read_stroke_thickness_depth_info") {
            return readStrokeThicknessDepthInfo();
        }

        if (action === "read_stroke_thickness_info") {
            return readStrokeThicknessInfo();
        }

        if (action === "preview_stroke_thickness") {
            return previewStrokeThickness();
        }

        if (action === "clear_stroke_thickness_preview") {
            var removedStrokePreview = removeStrokeThicknessPreview();
            alert(removedStrokePreview ? "已清除描边厚度预览" : "没有可清除的描边厚度预览");
            return removedStrokePreview ? "OK_CLEAR_STROKE_THICKNESS_PREVIEW" : "NO_STROKE_THICKNESS_PREVIEW";
        }

        if (action === "clear_fallback_preview") {
            var removedPreview = false;
            for (var cpl = doc.layers.length - 1; cpl >= 0; cpl--) {
                try {
                    if (doc.layers[cpl].name === "HH_FALLBACK_PREVIEW" ||
                        doc.layers[cpl].name === "HH_FALLBACK_PREVIEW_TEMP") {
                        doc.layers[cpl].locked = false;
                        doc.layers[cpl].visible = true;
                        doc.layers[cpl].remove();
                        removedPreview = true;
                    }
                } catch(e) {}
            }
            return removedPreview ? "OK_CLEAR_FALLBACK_PREVIEW" : "NO_FALLBACK_PREVIEW";
        }

        if (action === "preview_fallback_export") {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中需要预览兜底路径的对象");
                return "NO_SEL";
            }

            var removePreviewLayers = function() {
                for (var l = doc.layers.length - 1; l >= 0; l--) {
                    try {
                        if (doc.layers[l].name === "HH_FALLBACK_PREVIEW" ||
                            doc.layers[l].name === "HH_FALLBACK_PREVIEW_TEMP") {
                            doc.layers[l].locked = false;
                            doc.layers[l].visible = true;
                            doc.layers[l].remove();
                        }
                    } catch(e) {}
                }
            };

            var collectPreviewPaths = function(item) {
                var paths = [];
                if (!item) return paths;
                if (item.typename === "PathItem") {
                    paths.push(item);
                } else if (item.typename === "CompoundPathItem") {
                    for (var i = 0; i < item.pathItems.length; i++) paths.push(item.pathItems[i]);
                } else if (item.typename === "GroupItem") {
                    for (var j = 0; j < item.pageItems.length; j++) {
                        paths = paths.concat(collectPreviewPaths(item.pageItems[j]));
                    }
                }
                return paths;
            };

            var findPreviewClipItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        if (group.pageItems[i].clipping === true) return group.pageItems[i];
                    }
                    for (var j = 0; j < group.pageItems.length; j++) {
                        var child = group.pageItems[j];
                        if (child.typename === "CompoundPathItem" &&
                            child.pathItems &&
                            child.pathItems.length > 0 &&
                            child.pathItems[0].clipping) {
                            return child;
                        }
                    }
                } catch(e) {}
                return null;
            };

            var magenta = new RGBColor();
            magenta.red = 255; magenta.green = 0; magenta.blue = 255;

            var getPreviewFillKind = function(item) {
                try {
                    if (!item) return "none";
                    if (item.typename === "CompoundPathItem") {
                        var compoundKind = "none";
                        for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                            var subKind = getPreviewFillKind(item.pathItems[cpi]);
                            if (subKind === "white" || subKind === "black") return subKind;
                            if (subKind === "other") compoundKind = "other";
                        }
                        return compoundKind;
                    }
                    if (item.typename === "GroupItem") {
                        var groupKind = "none";
                        for (var gi = 0; gi < item.pageItems.length; gi++) {
                            var childKind = getPreviewFillKind(item.pageItems[gi]);
                            if (childKind === "white" || childKind === "black") return childKind;
                            if (childKind === "other") groupKind = "other";
                        }
                        return groupKind;
                    }
                    if (item.typename !== "PathItem") return "none";
                    if (!item.filled || !item.fillColor || item.fillColor.typename === "NoColor") return "none";
                    var color = item.fillColor;
                    if (color.typename === "RGBColor") {
                        var r = Math.round(color.red);
                        var g = Math.round(color.green);
                        var b = Math.round(color.blue);
                        if (r >= 245 && g >= 245 && b >= 245) return "white";
                        if (r <= 10 && g <= 10 && b <= 10) return "black";
                        return "other";
                    }
                    if (color.typename === "GrayColor") {
                        if (color.gray >= 95) return "white";
                        if (color.gray <= 5) return "black";
                        return "other";
                    }
                    if (color.typename === "CMYKColor") {
                        if (color.black <= 5 && color.cyan <= 8 && color.magenta <= 8 && color.yellow <= 8) return "white";
                        if (color.black >= 90) return "black";
                        return "other";
                    }
                } catch(e) {}
                return "none";
            };

            var collectPathsByFill = function(root) {
                var result = { whitePaths: [], blackPaths: [], otherPaths: [] };
                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "PathItem") {
                            var kind = getPreviewFillKind(node);
                            if (kind === "white") result.whitePaths.push(node);
                            else if (kind === "black") result.blackPaths.push(node);
                            else if (kind === "other") result.otherPaths.push(node);
                            return;
                        }
                        if (node.typename === "CompoundPathItem") {
                            for (var i = 0; i < node.pathItems.length; i++) walk(node.pathItems[i]);
                            return;
                        }
                        if (node.typename === "GroupItem") {
                            for (var j = 0; j < node.pageItems.length; j++) walk(node.pageItems[j]);
                        }
                    } catch(e) {}
                };
                walk(root);
                return result;
            };

            var copyPathToPreview = function(srcPath, previewParent) {
                try {
                    if (!srcPath || !srcPath.pathPoints || srcPath.pathPoints.length < 2) return false;
                    var dst = previewParent.pathItems.add();
                    for (var i = 0; i < srcPath.pathPoints.length; i++) {
                        var sp = srcPath.pathPoints[i];
                        var dp = dst.pathPoints.add();
                        dp.anchor = [sp.anchor[0], sp.anchor[1]];
                        dp.leftDirection = [sp.leftDirection[0], sp.leftDirection[1]];
                        dp.rightDirection = [sp.rightDirection[0], sp.rightDirection[1]];
                        try { dp.pointType = sp.pointType; } catch(e) {}
                    }
                    dst.closed = srcPath.closed;
                    dst.filled = false;
                    dst.stroked = true;
                    dst.strokeColor = magenta;
                    dst.strokeWidth = 2;
                    return true;
                } catch(e) {}
                return false;
            };

            var mergeOrGroupPreviewPaths = function(paths, previewLayer) {
                var stats = { groupCount: 0, pathCount: 0, merged: false };
                if (!paths || paths.length === 0) return stats;
                var previewGroup = previewLayer.groupItems.add();
                previewGroup.name = "HH_FALLBACK_PREVIEW_WHITE_GROUP";
                stats.groupCount = 1;
                stats.merged = true;
                for (var i = 0; i < paths.length; i++) {
                    if (copyPathToPreview(paths[i], previewGroup)) stats.pathCount++;
                }
                return stats;
            };

            var drawFallbackSegmentToPreview = function(segText, previewParent) {
                try {
                    if (!segText) return false;
                    var pts = eval("(" + segText + ")");
                    if (!pts || pts.length < 2) return false;
                    var dst = previewParent.pathItems.add();
                    for (var i = 0; i < pts.length; i++) {
                        var src = pts[i];
                        var p = dst.pathPoints.add();
                        p.anchor = [src.a[0], -src.a[1]];
                        p.leftDirection = [src.inT[0], -src.inT[1]];
                        p.rightDirection = [src.outT[0], -src.outT[1]];
                    }
                    dst.closed = true;
                    dst.filled = false;
                    dst.stroked = true;
                    dst.strokeColor = magenta;
                    dst.strokeWidth = 2;
                    return true;
                } catch(e) {}
                return false;
            };

            var drawFallbackSegmentsToPreview = function(segments, previewLayer) {
                var stats = { groupCount: 0, pathCount: 0, merged: false };
                if (!segments || segments.length === 0) return stats;
                var previewGroup = previewLayer.groupItems.add();
                previewGroup.name = "HH_FALLBACK_PREVIEW_WHITE_GROUP";
                stats.groupCount = 1;
                stats.merged = true;
                for (var i = 0; i < segments.length; i++) {
                    if (drawFallbackSegmentToPreview(segments[i], previewGroup)) stats.pathCount++;
                }
                return stats;
            };

            var tracePreviewForItem = function(item, bounds, previewLayer, tempLayer) {
                var totalCount = 0;
                var debug = {
                    selectedType: item ? item.typename : "None",
                    itemName: "",
                    bounds: bounds ? "[" + [
                        Math.round(bounds[0]*100)/100,
                        Math.round(bounds[1]*100)/100,
                        Math.round(bounds[2]*100)/100,
                        Math.round(bounds[3]*100)/100
                    ].join(",") + "]" : "None",
                    isGroupItem: item && item.typename === "GroupItem",
                    isClippingGroup: false,
                    isPlacedItem: item && item.typename === "PlacedItem",
                    isRasterItem: item && item.typename === "RasterItem",
                    traceStarted: false,
                    rasterizeSuccess: false,
                    traceSuccess: false,
                    expandSuccess: false,
                    expandedPathCount: 0,
                    whitePathCount: 0,
                    blackPathCount: 0,
                    otherPathCount: 0,
                    previewTargetColor: "white",
                    mergedPreview: false,
                    previewGroupCount: 0,
                    previewPathCount: 0,
                    collectedPathCount: 0,
                    segmentCount: 0,
                    errorMessage: "",
                    attempts: []
                };
                try { debug.itemName = item && item.name ? item.name : ""; } catch(e) {}
                try { debug.isClippingGroup = item && item.typename === "GroupItem" && item.clipped; } catch(e) {}

                var runAttempt = function(clipOnly) {
                    var count = 0;
                    var attempt = clipOnly ? "clipFlow" : "wholeObjectFlow";
                    var dup = null, raster = null, traced = null, expanded = null, fillRect = null;
                    if (!item || !bounds) {
                        debug.errorMessage = "missing_item_or_bounds";
                        return count;
                    }

                    try {
                        debug.traceStarted = true;
                        dup = item.duplicate(tempLayer, ElementPlacement.PLACEATBEGINNING);
                        dup.hidden = false;
                        dup.locked = false;

                        if (clipOnly) {
                            if (!dup || dup.typename !== "GroupItem") {
                                debug.attempts.push(attempt + ":not_group");
                                try { if (dup) dup.remove(); } catch(e) {}
                                return count;
                            }
                            var clipItem = findPreviewClipItem(dup);
                            if (!clipItem) {
                                debug.attempts.push(attempt + ":no_clip_item");
                                try { if (dup) dup.remove(); } catch(e) {}
                                return count;
                            }

                            var toRemove = [];
                            for (var i = 0; i < dup.pageItems.length; i++) {
                                if (dup.pageItems[i] !== clipItem) toRemove.push(dup.pageItems[i]);
                            }
                            for (var r = 0; r < toRemove.length; r++) {
                                try { toRemove[r].remove(); } catch(e) {}
                            }

                            var b = bounds;
                            var left = b[0] - 2;
                            var top = b[1] + 2;
                            var width = Math.max(1, (b[2] - b[0]) + 4);
                            var height = Math.max(1, (b[1] - b[3]) + 4);

                            fillRect = doc.pathItems.rectangle(top, left, width, height);
                            fillRect.stroked = false;
                            fillRect.filled = true;
                            var black = new RGBColor();
                            black.red = 0; black.green = 0; black.blue = 0;
                            fillRect.fillColor = black;
                            fillRect.move(dup, ElementPlacement.PLACEATEND);
                        }

                        var rastOpts = new RasterizeOptions();
                        rastOpts.resolution = 300;
                        rastOpts.transparency = true;
                        rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                        rastOpts.convertSpotColors = true;
                        rastOpts.convertTextToOutlines = false;

                        raster = doc.rasterize(dup, bounds, rastOpts);
                        if (!raster) {
                            debug.attempts.push(attempt + ":rasterize_empty");
                            return count;
                        }
                        debug.rasterizeSuccess = true;

                        traced = raster.trace();
                        if (!traced) {
                            debug.attempts.push(attempt + ":trace_empty");
                            return count;
                        }
                        debug.traceSuccess = true;
                        try {
                            var tracingPresets = app.tracingPresetsList;
                            if (tracingPresets && tracingPresets.length > 0) {
                                traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                            }
                        } catch(e) {}
                        app.redraw();

                        try {
                            expanded = traced.tracing.expandTracing();
                            debug.expandSuccess = true;
                        } catch(expandErr) {
                            expanded = traced;
                            debug.errorMessage = "expandFallback:" + expandErr.message;
                        }
                        app.redraw();

                        var tracedPaths = collectPreviewPaths(expanded);
                        debug.expandedPathCount += tracedPaths.length;
                        debug.collectedPathCount += tracedPaths.length;
                        var fillGroups = collectPathsByFill(expanded);
                        debug.whitePathCount += fillGroups.whitePaths.length;
                        debug.blackPathCount += fillGroups.blackPaths.length;
                        debug.otherPathCount += fillGroups.otherPaths.length;

                        if (fillGroups.whitePaths.length === 0) {
                            debug.attempts.push(attempt + ":no_white_fill");
                        } else {
                            var previewStats = mergeOrGroupPreviewPaths(fillGroups.whitePaths, previewLayer);
                            count += previewStats.pathCount;
                            debug.previewGroupCount += previewStats.groupCount;
                            debug.previewPathCount += previewStats.pathCount;
                            debug.mergedPreview = debug.mergedPreview || previewStats.merged;
                        }
                        debug.segmentCount += count;
                        debug.attempts.push(attempt + ":count=" + count);
                    } catch(e) {
                        debug.errorMessage = e.message;
                        debug.attempts.push(attempt + ":error=" + e.message);
                        count = 0;
                    }

                    try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                    try { if (traced) traced.remove(); } catch(e) {}
                    try { if (raster) raster.remove(); } catch(e) {}
                    try { if (dup) dup.remove(); } catch(e) {}
                    try { if (fillRect) fillRect.remove(); } catch(e) {}
                    return count;
                };

                // 先尝试 v28.157 的剪切组兜底 trace 流程；失败时强制对整个选中对象 trace。
                totalCount += runAttempt(true);
                if (totalCount <= 0) {
                    totalCount += runAttempt(false);
                }

                return { count: totalCount, debug: debug };
            };

            var legacyUnusedPreviewTrace = function(item, bounds, previewLayer, tempLayer) {
                var count = 0;
                var dup = null, raster = null, traced = null, expanded = null, fillRect = null;
                if (!item || item.typename !== "GroupItem" || !bounds) return count;

                try {
                    dup = item.duplicate(tempLayer, ElementPlacement.PLACEATBEGINNING);
                    dup.hidden = false;
                    dup.locked = false;

                    var clipItem = findPreviewClipItem(dup);
                    if (!clipItem) {
                        if (dup) dup.remove();
                        return count;
                    }

                    var toRemove = [];
                    for (var i = 0; i < dup.pageItems.length; i++) {
                        if (dup.pageItems[i] !== clipItem) toRemove.push(dup.pageItems[i]);
                    }
                    for (var r = 0; r < toRemove.length; r++) {
                        try { toRemove[r].remove(); } catch(e) {}
                    }

                    var b = bounds;
                    var left = b[0] - 2;
                    var top = b[1] + 2;
                    var width = Math.max(1, (b[2] - b[0]) + 4);
                    var height = Math.max(1, (b[1] - b[3]) + 4);

                    fillRect = doc.pathItems.rectangle(top, left, width, height);
                    fillRect.stroked = false;
                    fillRect.filled = true;
                    var black = new RGBColor();
                    black.red = 0; black.green = 0; black.blue = 0;
                    fillRect.fillColor = black;
                    fillRect.move(dup, ElementPlacement.PLACEATEND);

                    var rastOpts = new RasterizeOptions();
                    rastOpts.resolution = 300;
                    rastOpts.transparency = true;
                    rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                    rastOpts.convertSpotColors = true;
                    rastOpts.convertTextToOutlines = false;

                    raster = doc.rasterize(dup, bounds, rastOpts);
                    if (!raster) {
                        if (dup) dup.remove();
                        return count;
                    }

                    traced = raster.trace();
                    try {
                        var tracingPresets = app.tracingPresetsList;
                        if (tracingPresets && tracingPresets.length > 0) {
                            traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                        }
                    } catch(e) {}
                    app.redraw();

                    try {
                        expanded = traced.tracing.expandTracing();
                    } catch(e) {
                        expanded = traced;
                    }
                    app.redraw();

                    var tracedPaths = collectPreviewPaths(expanded);
                    var filteredPaths = [];
                    var candidates = [];
                    var baseW = Math.max(0.01, Math.abs(bounds[2] - bounds[0]));
                    var baseH = Math.max(0.01, Math.abs(bounds[1] - bounds[3]));
                    var hasInnerLarge = false;

                    for (var tp = 0; tp < tracedPaths.length; tp++) {
                        try {
                            var pb = getTightBounds(tracedPaths[tp]);
                            if (!pb) continue;
                            var wRatio = Math.abs(pb[2] - pb[0]) / baseW;
                            var hRatio = Math.abs(pb[1] - pb[3]) / baseH;
                            var coverage = Math.min(wRatio, hRatio);
                            candidates.push({ path: tracedPaths[tp], coverage: coverage });
                            if (coverage >= 0.55 && coverage < 0.98) hasInnerLarge = true;
                        } catch(e) {}
                    }

                    for (var ci = 0; ci < candidates.length; ci++) {
                        if (hasInnerLarge && candidates[ci].coverage >= 0.98) continue;
                        filteredPaths.push(candidates[ci].path);
                    }

                    if (filteredPaths.length === 0) filteredPaths = tracedPaths;
                    for (var fp = 0; fp < filteredPaths.length; fp++) {
                        if (copyPathToPreview(filteredPaths[fp], previewLayer)) count++;
                    }
                } catch(e) {
                    count = 0;
                }

                try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                try { if (traced) traced.remove(); } catch(e) {}
                try { if (raster) raster.remove(); } catch(e) {}
                try { if (dup) dup.remove(); } catch(e) {}
                try { if (fillRect) fillRect.remove(); } catch(e) {}
                return count;
            };

            removePreviewLayers();

            var previewLayer = doc.layers.add();
            previewLayer.name = "HH_FALLBACK_PREVIEW";
            previewLayer.visible = true;
            previewLayer.locked = false;

            var tempPreviewLayer = doc.layers.add();
            tempPreviewLayer.name = "HH_FALLBACK_PREVIEW_TEMP";
            tempPreviewLayer.visible = true;
            tempPreviewLayer.locked = false;

            var previewCount = 0;
            var previewDebug = [];
            var totalWhitePathCount = 0;
            var totalBlackPathCount = 0;
            try {
                for (var psi = 0; psi < originalSel.length; psi++) {
                    var previewReverse = tools.getFallbackReverse(originalSel[psi].name);
                    var previewTargetColor = previewReverse ? "black" : "white";
                    var fallbackResult = buildFallbackTraceSegments(originalSel[psi], getTightBounds(originalSel[psi]), tempPreviewLayer, previewTargetColor);
                    var previewStats = drawFallbackSegmentsToPreview(fallbackResult.segments, previewLayer);
                    previewCount += previewStats.pathCount;
                    totalWhitePathCount += fallbackResult.whitePathCount;
                    totalBlackPathCount += fallbackResult.blackPathCount;
                    previewDebug.push(
                        "selectedType=" + (originalSel[psi] ? originalSel[psi].typename : "None") +
                        " fallbackSource=previewLike" + (previewTargetColor === "black" ? "BlackFill" : "WhiteFill") +
                        " fallbackReverse=" + previewReverse +
                        " targetMode=" + (previewReverse ? "reverse" : "normal") +
                        " exportUsesPreviewLogic=true" +
                        " expandedPathCount=" + fallbackResult.expandedPathCount +
                        " whitePathCount=" + fallbackResult.whitePathCount +
                        " blackPathCount=" + fallbackResult.blackPathCount +
                        " otherPathCount=" + fallbackResult.otherPathCount +
                        " previewTargetColor=" + fallbackResult.targetColor +
                        " mergedPreview=" + previewStats.merged +
                        " previewGroupCount=" + previewStats.groupCount +
                        " previewPathCount=" + previewStats.pathCount +
                        " segmentCount=" + fallbackResult.segmentCount +
                        " attempts=" + fallbackResult.attempts.join(";") +
                        " errorMessage=" + fallbackResult.errorMessage
                    );
                }
            } finally {
                try { tempPreviewLayer.locked = false; tempPreviewLayer.visible = true; tempPreviewLayer.remove(); } catch(e) {}
            }

            if (previewCount <= 0) {
                try { previewLayer.remove(); } catch(e) {}
                var failMsg = (totalWhitePathCount <= 0 && totalBlackPathCount > 0 ?
                    "没有检测到白色填充路径，请检查 image trace expand 后的填充色。\n" :
                    "预览失败：\n") + previewDebug.join("\n");
                alert(failMsg);
                return "NO_FALLBACK_PREVIEW_PATH " + previewDebug.join(" | ");
            }

            alert("✅ 已生成兜底路径预览：" + previewCount + " 条路径\n" + previewDebug.join("\n"));
            return "OK_FALLBACK_PREVIEW count=" + previewCount + " " + previewDebug.join(" | ");
        }

        if (!originalSel || originalSel.length === 0) {
            if (action === "export" && params && params.silentExport) {
                return 'EXPORT_RESULT:{"ok":false,"error":"请先选中对象"}';
            }
            alert("错误: 请先选中对象");
            return;
        }

        if (action === "export") {
            var mode = params.mode; 
            var savePathStr = params.path;
            var dpi = params.dpi || 300;
            var format = String(params.format || "png").toLowerCase();
            if (format === "jpeg") format = "jpg";
            if (format !== "jpg") format = "png";
            var enableFallback = !!params.enableFallback;
            var silentExport = !!params.silentExport;
            var exportStartedAt = new Date().getTime();
            var progressUi = null;
            var resultJsonEscape = function(value) {
                try {
                    return String(value === undefined || value === null ? "" : value)
                        .replace(/\\/g, "\\\\")
                        .replace(/"/g, '\\"')
                        .replace(/\r/g, "\\r")
                        .replace(/\n/g, "\\n");
                } catch(e) {}
                return "";
            };
            var createExportProgressWindow = function() {
                if (!params || !params.showProgressWindow) return null;
                try {
                    var win = new Window("palette", "正在导出 C4D 文件");
                    win.orientation = "column";
                    win.alignChildren = ["fill", "top"];
                    win.margins = 16;
                    win.spacing = 10;
                    try { win.graphics.backgroundColor = win.graphics.newBrush(win.graphics.BrushType.SOLID_COLOR, [0.10, 0.12, 0.16, 1]); } catch(bgErr) {}

                    var header = win.add("group");
                    header.orientation = "column";
                    header.alignChildren = ["fill", "top"];
                    header.spacing = 4;
                    var title = header.add("statictext", undefined, "正在导出 C4D 文件");
                    try { title.graphics.font = ScriptUI.newFont(title.graphics.font.name, "BOLD", 17); } catch(fontErr) {}
                    var subtitle = header.add("statictext", undefined, "请稍候，正在处理对象与贴图...");
                    subtitle.characters = 44;

                    var card = win.add("panel", undefined, "");
                    card.orientation = "column";
                    card.alignChildren = ["fill", "top"];
                    card.margins = 14;
                    card.spacing = 8;
                    var stepText = card.add("statictext", undefined, "当前步骤：准备导出");
                    stepText.characters = 46;
                    var bar = card.add("progressbar", undefined, 0, 100);
                    bar.preferredSize = [390, 18];
                    var metaRow = card.add("group");
                    metaRow.orientation = "row";
                    metaRow.alignChildren = ["fill", "center"];
                    var percent = metaRow.add("statictext", undefined, "0%");
                    percent.characters = 12;
                    var stepIndexText = metaRow.add("statictext", undefined, "步骤 1 / 8");
                    stepIndexText.characters = 28;

                    var hint = win.add("statictext", undefined, "导出期间请勿关闭 Illustrator");
                    hint.characters = 44;
                    win.show();
                    win.update();
                    return {
                        win: win,
                        set: function(value, text) {
                            try {
                                var v = Math.max(0, Math.min(100, Math.round(value || 0)));
                                var label = text || "正在导出...";
                                var stepIndex = 1;
                                if (v >= 10) stepIndex = 2;
                                if (v >= 20) stepIndex = 3;
                                if (v >= 35) stepIndex = 4;
                                if (v >= 50) stepIndex = 5;
                                if (v >= 65) stepIndex = 6;
                                if (v >= 80) stepIndex = 7;
                                if (v >= 90) stepIndex = 8;
                                if (v >= 100) stepIndex = 8;
                                stepText.text = "当前步骤：" + label;
                                bar.value = v;
                                percent.text = v + "%";
                                stepIndexText.text = "步骤 " + stepIndex + " / 8";
                                win.update();
                            } catch(e) {}
                        },
                        close: function() {
                            try { win.close(); } catch(e) {}
                        }
                    };
                } catch(e) {}
                return null;
            };
            var updateExportProgress = function(value, text) {
                try {
                    if (progressUi) progressUi.set(value, text);
                } catch(e) {}
            };
            var closeExportProgress = function() {
                try {
                    if (progressUi) progressUi.close();
                } catch(e) {}
                progressUi = null;
            };
            var showExportCompleteDialog = function(ok, titleText, messageText, folderPath) {
                if (!params || !params.showProgressWindow) return;
                try {
                    closeExportProgress();
                    var dlg = new Window("dialog", titleText || (ok ? "导出完成" : "导出失败"));
                    dlg.orientation = "column";
                    dlg.alignChildren = ["fill", "top"];
                    dlg.margins = 16;
                    dlg.spacing = 10;
                    try { dlg.graphics.backgroundColor = dlg.graphics.newBrush(dlg.graphics.BrushType.SOLID_COLOR, [0.10, 0.12, 0.16, 1]); } catch(dlgBgErr) {}

                    var titleGroup = dlg.add("group");
                    titleGroup.orientation = "column";
                    titleGroup.alignChildren = ["fill", "top"];
                    titleGroup.spacing = 4;
                    var titleLabel = titleGroup.add("statictext", undefined, ok ? "导出完成" : "导出失败");
                    try { titleLabel.graphics.font = ScriptUI.newFont(titleLabel.graphics.font.name, "BOLD", 18); } catch(titleFontErr) {}
                    var subLabel = titleGroup.add("statictext", undefined, ok ? "文件已写入，可按需打开导出文件夹。" : "导出未完成，请检查错误信息。");
                    subLabel.characters = 46;

                    var card = dlg.add("panel", undefined, "导出摘要");
                    card.orientation = "column";
                    card.alignChildren = ["fill", "top"];
                    card.margins = 14;
                    card.spacing = 7;
                    var msg = card.add("statictext", undefined, messageText || "", { multiline: true });
                    msg.preferredSize = [440, 130];
                    var row = dlg.add("group");
                    row.orientation = "row";
                    row.alignment = "right";
                    if (ok && folderPath) {
                        var openBtn = row.add("button", undefined, "打开文件夹");
                        openBtn.onClick = function() {
                            try {
                                var folder = new Folder(folderPath);
                                if (folder.exists) folder.execute();
                            } catch(e) {}
                        };
                    }
                    var closeBtn = row.add("button", undefined, "关闭", { name: "ok" });
                    closeBtn.onClick = function() { dlg.close(); };
                    dlg.show();
                } catch(e) {}
            };
            progressUi = createExportProgressWindow();
            updateExportProgress(5, "准备导出...");

            var hasAnyExportDepth = function(item) {
                if (!item) return false;
                try {
                    if (tools.getTagD(item.name) !== null) return true;
                } catch(depthNameErr) {}
                try {
                    if (parseStrokeThicknessDepthMm(item) !== null) return true;
                } catch(depthNoteErr) {}
                try {
                    if (findStrokeThicknessDepthOwner(item)) return true;
                } catch(depthOwnerErr) {}
                try {
                    if (hasStrokeThicknessExportFlag(item)) return true;
                } catch(strokeFlagErr) {}
                try {
                    if (findStrokeThicknessExportOwner(item)) return true;
                } catch(strokeOwnerErr) {}
                return false;
            };

            // 防呆验证
            var missingCount = 0;
            for(var m = 0; m < originalSel.length; m++) {
                if(!hasAnyExportDepth(originalSel[m])) { missingCount++; }
            }
            updateExportProgress(10, "扫描对象...");
            if (missingCount > 0) {
                var msg = "⚠️ 导出警告：\n\n检测到选中的 " + originalSel.length + " 个对象中，有 " + missingCount + " 个【尚未设置厚度】（没有普通厚度或描边厚度）。\n\n如果直接导出，这些对象在 C4D 中将失去挤压厚度！\n\n是否仍然要继续强制导出？";
                if (!confirm(msg)) {
                    closeExportProgress();
                    if (silentExport) return 'EXPORT_RESULT:{"ok":false,"error":"用户取消导出"}';
                    return;
                }
            }

            var baseFile = new File(savePathStr);
            var exportDebugFile = (DEBUG_EXPORT_REPORT || !!params.debugReport) ? new File(baseFile.parent.fsName + "/" + baseFile.name.replace(/\.json$/i, "") + ".debug.txt") : null;
            var exportDebugLines = [];
            var scanDebugLines = [];
            var strokeSplitFailReasons = [];
            var strokeSplitFillObjectNames = [];
            var strokeSplitStrokeObjectNames = [];
            var originalSelectionNames = [];
            var originalSelectionPureNames = [];
            var splitStrokeFillAttemptCount = 0;
            var actualExportEntry = params.exportEntry || "HH_exportWithDialog/exportBtn/actual-ui-export";
            var safeDebugText = function(value) {
                try {
                    return String(value === undefined || value === null ? "" : value).replace(/\r?\n/g, "\\n");
                } catch(e) {}
                return "";
            };
            var safeNote = function(item) {
                try { return safeDebugText(item.note || ""); } catch(e) {}
                return "";
            };
            var parentDebugName = function(item) {
                try { return item.parent && item.parent.name ? String(item.parent.name) : ""; } catch(e) {}
                return "";
            };
            var parentDebugNote = function(item) {
                try { return item.parent ? safeNote(item.parent) : ""; } catch(e) {}
                return "";
            };
            var describeExportItemForDebug = function(prefix, item, index, parentStrokeFlag, parentStrokeDepth) {
                try {
                    var itemName = safeDebugText(item && item.name ? item.name : "");
                    var itemPure = "";
                    try { itemPure = tools.getPureName(itemName) || itemName; } catch(pureErr) { itemPure = itemName; }
                    exportDebugLines.push(
                        prefix +
                        " itemIndex=" + index +
                        " | item.name=" + itemName +
                        " | item.pureName=" + safeDebugText(itemPure) +
                        " | item.typename=" + safeDebugText(item ? item.typename : "None") +
                        " | item.note=" + safeNote(item) +
                        " | parent.name=" + safeDebugText(parentDebugName(item)) +
                        " | parent.note=" + parentDebugNote(item) +
                        " | detectedDepthMm=" + (tools.getTagD(itemName) !== null ? tools.getTagD(itemName) : "null") +
                        " | hasStrokeThicknessExportFlag=" + hasStrokeThicknessExportFlag(item) +
                        " | parentStrokeThicknessExport=" + (!!parentStrokeFlag) +
                        " | strokeThicknessDepthMm=" + (parseStrokeThicknessDepthMm(item) !== null ? parseStrokeThicknessDepthMm(item) : (parentStrokeDepth !== undefined && parentStrokeDepth !== null ? parentStrokeDepth : "null")) +
                        " | hasSkipExportFlag=" + hasSkipExportFlag(item)
                    );
                } catch(debugItemErr) {
                    exportDebugLines.push(prefix + " itemIndex=" + index + " | debugError=" + safeDebugText(debugItemErr.message));
                }
            };
            exportDebugLines.push("pluginVersion=v28.236");
            exportDebugLines.push("exportEntry=" + actualExportEntry);
            exportDebugLines.push("exportedJsonPath=" + baseFile.fsName);
            if (exportDebugFile) exportDebugLines.push("debugFilePath=" + exportDebugFile.fsName);
            exportDebugLines.push("selectionCount=" + (originalSel ? originalSel.length : 0));
            exportDebugLines.push("mode=" + mode + " | dpi=" + dpi + " | format=" + format + " | enableFallback=" + enableFallback);
            for (var dbgSel = 0; originalSel && dbgSel < originalSel.length; dbgSel++) {
                try {
                    originalSelectionNames.push(String(originalSel[dbgSel].name || ""));
                    originalSelectionPureNames.push(tools.getPureName(originalSel[dbgSel].name) || String(originalSel[dbgSel].name || ""));
                } catch(selNameErr) {}
                describeExportItemForDebug("selectedItem", originalSel[dbgSel], dbgSel, false, null);
            }
            var texFolder = new Folder(baseFile.parent.fsName + "/tex");
            if (!texFolder.exists) texFolder.create();
            var exportJsonBaseName = "export";
            try {
                exportJsonBaseName = baseFile.name.replace(/\.json$/i, "");
                exportJsonBaseName = tools.cleanName(exportJsonBaseName || "export");
                if (!exportJsonBaseName || exportJsonBaseName === "Untitled") exportJsonBaseName = "export";
            } catch(exportBaseNameErr) {
                exportJsonBaseName = "export";
            }
            var textureNameMap = {};
            var usedTextureBaseNames = {};
            var shortTextureHash = function(text) {
                var hash = 0;
                text = String(text || "");
                for (var i = 0; i < text.length; i++) {
                    hash = ((hash * 31) + text.charCodeAt(i)) & 0x7fffffff;
                }
                var out = hash.toString(36);
                return out.length > 4 ? out.substring(out.length - 4) : out;
            };
            var trimTextureBaseName = function(name, reserve) {
                name = String(name || "texture");
                var maxLen = 120 - (reserve || 0);
                if (maxLen < 40) maxLen = 40;
                if (name.length <= maxLen) return name;
                return name.substring(0, maxLen);
            };
            var makeTextureOutputName = function(rawName, uniqueKey) {
                var key = uniqueKey || rawName || "texture";
                if (textureNameMap[key]) return textureNameMap[key];
                var safeRaw = tools.cleanName(rawName || "texture");
                if (!safeRaw || safeRaw === "Untitled") safeRaw = "texture";
                var prefix = exportJsonBaseName + "_";
                var base = safeRaw.indexOf(prefix) === 0 ? safeRaw : (prefix + safeRaw);
                base = trimTextureBaseName(base, 8);
                var candidate = base;
                if (usedTextureBaseNames[candidate]) {
                    var suffix = "_" + shortTextureHash(key);
                    candidate = trimTextureBaseName(base, suffix.length) + suffix;
                    var n = 2;
                    while (usedTextureBaseNames[candidate]) {
                        var countedSuffix = suffix + "_" + n;
                        candidate = trimTextureBaseName(base, countedSuffix.length) + countedSuffix;
                        n++;
                    }
                }
                usedTextureBaseNames[candidate] = true;
                textureNameMap[key] = candidate;
                return candidate;
            };
            var findTextureOutputName = function(rawName) {
                for (var ti = 0; ti < imgList.length; ti++) {
                    if (imgList[ti].name === rawName) return imgList[ti].textureOutputName || imgList[ti].name;
                    if (imgList[ti].textureOutputName === rawName) return imgList[ti].textureOutputName;
                }
                return "";
            };

	            var scanList =[]; 
	            var imgList =[];  
	            var imgCount = 0;
                var exportedTextureNames = [];
            var skipExportCount = 0;
            var strokeExportPartsFoundCount = 0;
            var fillObjectsFoundCount = 0;
            var strokeObjectsFoundCount = 0;
            var exportedItemNames = [];
            var skippedItemNames = [];
            var copiedGeneratedSourceKeys = {};
            var processedStrokeThicknessOwnerKeys = {};
            var processedStrokeThicknessOwners = [];
            var totalStrokeOwnersFound = 0;
            var processedStrokeOwnerCount = 0;
            var skippedDuplicateOwnerCount = 0;
            var autoMarkedStrokeThicknessCount = 0;
            var autoMarkedStrokeThicknessNames = [];
            var strokeSplitExportTasks = [];
            var jsonImportIndexCounter = 0;
            var fallbackExportIdentityCounter = 1;
            var makeJsonRgbObject = function(rgb) {
                if (!rgb || rgb.length < 3) return null;
                return {
                    r: Math.round(rgb[0]),
                    g: Math.round(rgb[1]),
                    b: Math.round(rgb[2])
                };
            };
            var makeJsonIdentityValue = function(value) {
                return JSON.stringify(value === undefined || value === null ? "" : String(value));
            };
            var makeExportIdentity = function(baseName, index, isRealGroup, groupPath, sourceItem) {
                var safeBase = tools.cleanName(baseName || ("Part_" + (index + 1)));
                if (!safeBase || safeBase === "Untitled") safeBase = "Part_" + (index + 1);
                var objectId = "obj_" + tools.cleanName(safeBase + "_" + (index + 1));
                var groupId = null;
                var groupKey = "";
                var path = groupPath || [];
                if (isRealGroup) {
                    groupId = "group_" + tools.cleanName(safeBase + "_" + (index + 1));
                    groupKey = groupId;
                }
                return {
                    objectId: objectId,
                    baseName: safeBase,
                    groupName: isRealGroup ? safeBase : ("Part_" + (index + 1)),
                    groupId: groupId,
                    groupKey: groupKey,
                    groupPath: path,
                    sourceStackIndex: index,
                    sourceZOrderIndex: (function() { try { return sourceItem && sourceItem.zOrderPosition !== undefined ? Number(sourceItem.zOrderPosition) : index; } catch(e) {} return index; })(),
                    sourceLayerIndex: (function() { try { return sourceItem && sourceItem.layer && sourceItem.layer.zOrderPosition !== undefined ? Number(sourceItem.layer.zOrderPosition) : 0; } catch(e) {} return 0; })(),
                    sourceLayerName: (function() { try { return sourceItem && sourceItem.layer && sourceItem.layer.name ? String(sourceItem.layer.name) : ""; } catch(e) {} return ""; })()
                };
            };
            var cloneIdentityForChild = function(identity, childBaseName, childIndex) {
                if (!identity) return makeExportIdentity(childBaseName, childIndex, false, []);
                return {
                    objectId: identity.groupId ? ("obj_" + tools.cleanName((childBaseName || identity.baseName || "item") + "_" + (childIndex + 1))) : identity.objectId,
                    baseName: childBaseName || identity.baseName,
                    groupName: identity.groupName,
                    groupId: identity.groupId,
                    groupKey: identity.groupKey,
                    groupPath: identity.groupPath || [],
                    sourceStackIndex: (identity.sourceStackIndex !== undefined ? (Number(identity.sourceStackIndex) + ((childIndex + 1) / 1000)) : childIndex),
                    sourceZOrderIndex: (identity.sourceZOrderIndex !== undefined ? (Number(identity.sourceZOrderIndex) + ((childIndex + 1) / 1000)) : childIndex),
                    sourceLayerIndex: identity.sourceLayerIndex,
                    sourceLayerName: identity.sourceLayerName
                };
            };
            var getIdentityPartOrder = function(partType) {
                if (partType === "fill" || partType === "texture" || partType === "fallback" || partType === "reverseFallback") return 10;
                if (partType === "stroke") return 20;
                return 50;
            };
            var buildIdentityJsonFields = function(identity, partType, fillDepthMm, strokeDepthMm, fillRgb, strokeRgb) {
                var idx = jsonImportIndexCounter++;
                var safePart = partType || "unknown";
                var fallbackBase = identity && identity.baseName ? identity.baseName : ("Part_" + (idx + 1));
                var objectId = identity && identity.objectId ? identity.objectId : ("obj_" + tools.cleanName(fallbackBase + "_" + (idx + 1)));
                var itemId = objectId + "_" + safePart + "_" + (idx + 1);
                var groupPath = identity && identity.groupPath ? identity.groupPath : [];
                var groupId = identity && identity.groupId ? identity.groupId : null;
                var groupKey = identity && identity.groupKey ? identity.groupKey : "";
                var out = "";
                out += ',"objectId":' + makeJsonIdentityValue(objectId);
                out += ',"itemId":' + makeJsonIdentityValue(itemId);
                out += ',"partType":' + makeJsonIdentityValue(safePart);
                out += ',"groupId":' + (groupId ? makeJsonIdentityValue(groupId) : "null");
                out += ',"groupPath":' + JSON.stringify(groupPath);
                out += ',"groupKey":' + makeJsonIdentityValue(groupKey);
                out += ',"importIndex":' + idx;
                out += ',"sourceStackIndex":' + (identity && identity.sourceStackIndex !== undefined ? Number(identity.sourceStackIndex) : idx);
                out += ',"sourceZOrderIndex":' + (identity && identity.sourceZOrderIndex !== undefined ? Number(identity.sourceZOrderIndex) : (identity && identity.sourceStackIndex !== undefined ? Number(identity.sourceStackIndex) : idx));
                out += ',"sourceLayerIndex":' + (identity && identity.sourceLayerIndex !== undefined ? Number(identity.sourceLayerIndex) : 0);
                out += ',"sourceLayerName":' + makeJsonIdentityValue(identity && identity.sourceLayerName ? identity.sourceLayerName : "");
                out += ',"partOrder":' + getIdentityPartOrder(safePart);
                out += ',"fillDepth":' + (fillDepthMm !== null && fillDepthMm !== undefined && !isNaN(parseFloat(fillDepthMm)) ? (Math.round(parseFloat(fillDepthMm) * 100) / 100) : "null");
                out += ',"strokeDepth":' + (strokeDepthMm !== null && strokeDepthMm !== undefined && !isNaN(parseFloat(strokeDepthMm)) ? (Math.round(parseFloat(strokeDepthMm) * 100) / 100) : "null");
                out += ',"fillColor":' + JSON.stringify(makeJsonRgbObject(fillRgb));
                out += ',"strokeColor":' + JSON.stringify(makeJsonRgbObject(strokeRgb));
                return out;
            };
            var buildStrokeRingIdentityJsonFields = function(identity, ringIndex, fillDepthMm, strokeDepthMm, fillRgb, strokeRgb) {
                var idx = jsonImportIndexCounter++;
                var safeRingIndex = ringIndex || 0;
                var fallbackBase = identity && identity.baseName ? identity.baseName : ("Part_" + (idx + 1));
                var sourceObjectId = identity && identity.objectId ? identity.objectId : ("obj_" + tools.cleanName(fallbackBase + "_" + (idx + 1)));
                var objectId = sourceObjectId + "_strokeRing_" + safeRingIndex;
                var itemId = objectId + "_stroke_" + (idx + 1);
	                var sourceGroupId = identity && identity.groupId ? identity.groupId : null;
	                var sourceGroupKey = identity && identity.groupKey ? identity.groupKey : "";
	                var groupPath = identity && identity.groupPath ? identity.groupPath : [];
	                var parentGroupId = sourceGroupId ? sourceGroupId : null;
	                var parentGroupKey = sourceGroupKey ? sourceGroupKey : "";
	                var parentGroupPath = groupPath || [];
	                var sourceItemId = sourceObjectId;
	                var strokeCompoundGroupId = "strokeCompound_" + tools.cleanName(sourceObjectId || fallbackBase);
	                var out = "";
	                out += ',"objectId":' + makeJsonIdentityValue(objectId);
	                out += ',"sourceObjectId":' + makeJsonIdentityValue(sourceObjectId);
	                out += ',"sourceItemId":' + makeJsonIdentityValue(sourceItemId);
	                out += ',"itemId":' + makeJsonIdentityValue(itemId);
	                out += ',"partType":"stroke"';
		                out += ',"groupId":""';
		                out += ',"sourceGroupId":' + (sourceGroupId ? makeJsonIdentityValue(sourceGroupId) : "null");
		                out += ',"parentGroupId":' + (parentGroupId ? makeJsonIdentityValue(parentGroupId) : "null");
		                out += ',"groupPath":[]';
		                out += ',"groupKey":""';
	                out += ',"sourceGroupKey":' + makeJsonIdentityValue(sourceGroupKey);
	                out += ',"sourceGroupPath":' + JSON.stringify(groupPath);
	                out += ',"parentGroupKey":' + makeJsonIdentityValue(parentGroupKey);
	                out += ',"parentGroupPath":' + JSON.stringify(parentGroupPath);
	                out += ',"importIndex":' + idx;
	                out += ',"sourceStackIndex":' + (identity && identity.sourceStackIndex !== undefined ? Number(identity.sourceStackIndex) : idx);
	                out += ',"sourceZOrderIndex":' + (identity && identity.sourceZOrderIndex !== undefined ? Number(identity.sourceZOrderIndex) : (identity && identity.sourceStackIndex !== undefined ? Number(identity.sourceStackIndex) : idx));
	                out += ',"sourceLayerIndex":' + (identity && identity.sourceLayerIndex !== undefined ? Number(identity.sourceLayerIndex) : 0);
	                out += ',"sourceLayerName":' + makeJsonIdentityValue(identity && identity.sourceLayerName ? identity.sourceLayerName : "");
	                out += ',"partOrder":' + getIdentityPartOrder("stroke");
	                out += ',"strokeSubPathIndex":' + safeRingIndex;
	                out += ',"compoundPartIndex":' + safeRingIndex;
	                out += ',"preserveSeparateStrokeRing":true';
	                out += ',"doNotMergeGeometry":true';
	                out += ',"strokeCompoundGroupId":' + makeJsonIdentityValue(strokeCompoundGroupId);
	                out += ',"strokeCompoundRole":"member"';
	                out += ',"preserveCompoundHoleRelation":true';
	                out += ',"fillDepth":' + (fillDepthMm !== null && fillDepthMm !== undefined && !isNaN(parseFloat(fillDepthMm)) ? (Math.round(parseFloat(fillDepthMm) * 100) / 100) : "null");
                out += ',"strokeDepth":' + (strokeDepthMm !== null && strokeDepthMm !== undefined && !isNaN(parseFloat(strokeDepthMm)) ? (Math.round(parseFloat(strokeDepthMm) * 100) / 100) : "null");
                out += ',"fillColor":' + JSON.stringify(makeJsonRgbObject(fillRgb));
                out += ',"strokeColor":' + JSON.stringify(makeJsonRgbObject(strokeRgb));
                return out;
            };
            var sortJsonItemsBySourceStack = function(items) {
                var parsed = [];
                for (var si = 0; si < items.length; si++) {
                    try {
                        var obj = JSON.parse(items[si]);
                        obj.__originalImportIndex = obj.importIndex !== undefined ? Number(obj.importIndex) : si;
                        parsed.push(obj);
                    } catch(parseSortErr) {
                        parsed.push({ __rawJson: items[si], __originalImportIndex: si, sourceStackIndex: si, partOrder: 50 });
                    }
                }
                parsed.sort(function(a, b) {
                    var al = Number(a.sourceLayerIndex || 0);
                    var bl = Number(b.sourceLayerIndex || 0);
                    if (al !== bl) return al - bl;
                    var as = Number(a.sourceStackIndex !== undefined ? a.sourceStackIndex : a.__originalImportIndex);
                    var bs = Number(b.sourceStackIndex !== undefined ? b.sourceStackIndex : b.__originalImportIndex);
                    if (as !== bs) return as - bs;
                    var ap = Number(a.partOrder !== undefined ? a.partOrder : 50);
                    var bp = Number(b.partOrder !== undefined ? b.partOrder : 50);
                    if (ap !== bp) return ap - bp;
                    var ai = Number(a.__originalImportIndex || 0);
                    var bi = Number(b.__originalImportIndex || 0);
                    return ai - bi;
                });
                var names = [];
                var out = [];
                for (var oi = 0; oi < parsed.length; oi++) {
                    if (parsed[oi].__rawJson) {
                        out.push(parsed[oi].__rawJson);
                        names.push("");
                        continue;
                    }
                    parsed[oi].importIndex = oi;
                    try { delete parsed[oi].__originalImportIndex; } catch(delErr) {}
                    out.push(JSON.stringify(parsed[oi]));
                    names.push(parsed[oi].name || "");
                }
                return { items: out, names: names };
            };
            var ensureStrokeTaskIdentity = function(task, fallbackName) {
                if (!task) return makeExportIdentity("Part_" + (fallbackExportIdentityCounter++), fallbackExportIdentityCounter, false, []);
                if (task.identityMeta && task.identityMeta.objectId) {
                    if ((!task.group || task.group === "StrokePart") && task.identityMeta.groupName) task.group = task.identityMeta.groupName;
                    return task.identityMeta;
                }
                var base = "";
                try { base = tools.getPureName(fallbackName || task.name || task.group || "") || ""; } catch(identityFallbackErr) {}
                if (!base || base === "StrokePart") base = "Part_" + fallbackExportIdentityCounter;
                var identity = makeExportIdentity(base, fallbackExportIdentityCounter - 1, false, []);
                fallbackExportIdentityCounter++;
                task.identityMeta = identity;
                if (!task.group || task.group === "StrokePart") task.group = identity.groupName;
                return identity;
            };
            var origLevel = app.userInteractionLevel;
            app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;

            // 建立干净无污染的临时工作区图层
            var tempLayer = null;
            try {
                tempLayer = doc.layers.add();
                tempLayer.name = "HH_TEMP_EXPORT_" + Math.round(Math.random()*10000);
                tempLayer.printable = false; 
            } catch(e) {
                alert("创建临时图层失败，请检查文档是否被锁定！");
                app.userInteractionLevel = origLevel; return;
            }

            var duplicateExportItemToTemp = function(item) {
                if (!item) return null;
                try {
                    var dup = item.duplicate(tempLayer, ElementPlacement.PLACEATEND);
                    try { dup.name = item.name; } catch(copyNameErr) {}
                    try { dup.note = item.note || ""; } catch(copyNoteErr) {}
                    try {
                        var nm = String(item.name || "");
                        exportedItemNames.push(nm);
                        if (nm.indexOf("_fill") !== -1) fillObjectsFoundCount++;
                        if (nm.indexOf("_stroke") !== -1) strokeObjectsFoundCount++;
                    } catch(trackNameErr) {}
                    return dup;
                } catch(e) {}
                return null;
            };

            var duplicateStrokeGeneratedPartsForSource = function(sourceItem, sourceKey) {
                var copied = 0;
                if (!sourceKey) return copied;
                var generatedForSource = collectStrokeThicknessGeneratedItems(sourceKey);
                if ((!generatedForSource || generatedForSource.length === 0) && hasStrokeThicknessExportFlag(sourceItem)) {
                    var builtParts = buildStrokeThicknessExportPartsOnArtLayer(sourceItem);
                    if (builtParts && builtParts.ok) {
                        generatedForSource = [];
                        for (var bf = 0; bf < builtParts.fillItems.length; bf++) generatedForSource.push(builtParts.fillItems[bf]);
                        for (var bs = 0; bs < builtParts.strokeItems.length; bs++) generatedForSource.push(builtParts.strokeItems[bs]);
                    }
                }
                for (var gsrc = 0; generatedForSource && gsrc < generatedForSource.length; gsrc++) {
                    if (duplicateExportItemToTemp(generatedForSource[gsrc])) {
                        strokeExportPartsFoundCount++;
                        copied++;
                    }
                }
                if (copied > 0) copiedGeneratedSourceKeys[sourceKey] = true;
                return copied;
            };

            var hasProcessedStrokeOwner = function(owner) {
                for (var hpo = 0; hpo < processedStrokeThicknessOwners.length; hpo++) {
                    try {
                        if (processedStrokeThicknessOwners[hpo] === owner) return true;
                    } catch(e) {}
                }
                return false;
            };

            var collectStrokeExportTargets = function(source) {
                var targets = [];
                var seen = [];
                var addTarget = function(node) {
                    if (!node) return;
                    for (var i = 0; i < seen.length; i++) {
                        try { if (seen[i] === node) return; } catch(e) {}
                    }
                    seen.push(node);
                    targets.push(node);
                };
                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "GroupItem") {
                            if (node.clipped) {
                                addTarget(node);
                                return;
                            }
                            for (var gi = 0; gi < node.pageItems.length; gi++) {
                                walk(node.pageItems[gi]);
                            }
                            return;
                        }
                        if (node.typename === "PathItem" || node.typename === "CompoundPathItem") {
                            addTarget(node);
                        }
                    } catch(e) {}
                };
                walk(source);
                return targets;
            };

            var addStrokeSplitTaskForDuplicatedTarget = function(target, inheritedDepthMm, inheritedFillDepth, inheritedTypeSuffix, inheritedIdentity, fallbackIndex) {
                if (!target) return false;
                try {
                    if (inheritedDepthMm !== null && inheritedDepthMm !== undefined) {
                        setStrokeThicknessDepthMm(target, inheritedDepthMm);
                    }
                    setStrokeThicknessExportFlag(target, true);
                    var targetD = tools.getTagD(target.name);
                    if ((targetD === null || targetD === undefined || isNaN(parseFloat(targetD))) &&
                        inheritedFillDepth !== null && inheritedFillDepth !== undefined &&
                        !isNaN(parseFloat(inheritedFillDepth))) {
                        targetD = inheritedFillDepth;
                    }
                    var targetT = tools.getTagT(target.name);
                    if (!targetT && inheritedTypeSuffix) targetT = inheritedTypeSuffix;
                    target.name = tools.rebuildName(
                        target.name,
                        targetD,
                        targetT,
                        tools.getFallbackExport(target.name),
                        tools.getFallbackReverse(target.name),
                        true
                    );
                    var targetPure = "";
                    try { targetPure = tools.getPureName(target.name) || target.name || ""; } catch(targetPureErr) {}
                    if (!targetPure || targetPure === "StrokePart") targetPure = "Part_" + ((fallbackIndex || 0) + 1);
                    var targetIdentity = inheritedIdentity || makeExportIdentity(targetPure, fallbackIndex || 0, false, []);
                    var targetGroupName = targetIdentity && targetIdentity.groupName ? targetIdentity.groupName : ("Part_" + ((fallbackIndex || 0) + 1));
                    strokeSplitExportTasks.push({
                        name: target.name,
                        group: targetGroupName,
                        color: getStrokeFillRgb(target),
                        source: target,
                        refItem: target,
                        strokeThicknessExport: true,
                        strokeThicknessDepthMm: inheritedDepthMm !== null && inheritedDepthMm !== undefined ? inheritedDepthMm : parseStrokeThicknessDepthMm(target),
                        strokeThicknessExportRoot: true,
                        directStrokeSplitTask: true,
                        identityMeta: targetIdentity
                    });
                    setStrokeThicknessExportFlag(target, false);
                    target.name = tools.rebuildName(
                        target.name,
                        tools.getTagD(target.name),
                        tools.getTagT(target.name),
                        tools.getFallbackExport(target.name),
                        tools.getFallbackReverse(target.name),
                        false
                    );
                    setSkipExportFlag(target, true);
                    return true;
                } catch(e) {}
                return false;
            };

		            // 安全拷贝对象。描边厚度导出采用“源对象跳过 + 已生成 fill/stroke 普通对象导出”的硬规则。
		            for (var c = 0; c < originalSel.length; c++) {
	                try {
		                    var originalExportItem = originalSel[c];
                    var autoDepthForItem = parseStrokeThicknessDepthMm(originalExportItem);
                    if (!hasStrokeThicknessExportFlag(originalExportItem) &&
                        autoDepthForItem !== null &&
                        hasStrokeThicknessCandidate(originalExportItem)) {
                        setStrokeThicknessExportFlag(originalExportItem, true);
                        var autoD = tools.getTagD(originalExportItem.name);
                        var autoT = tools.getTagT(originalExportItem.name);
                        try {
                            originalExportItem.name = tools.rebuildName(
                                originalExportItem.name,
                                autoD,
                                autoT,
                                tools.getFallbackExport(originalExportItem.name),
                                tools.getFallbackReverse(originalExportItem.name),
                                true
                            );
                        } catch(autoNameErr) {}
                        autoMarkedStrokeThicknessCount++;
                        try { autoMarkedStrokeThicknessNames.push(String(originalExportItem.name || "")); } catch(autoPushErr) {}
                    }
                    var strokeOwner = findStrokeThicknessExportOwner(originalExportItem);
                    if (strokeOwner && strokeOwner !== originalExportItem) {
                        totalStrokeOwnersFound++;
                        if (hasProcessedStrokeOwner(strokeOwner)) {
                            skippedDuplicateOwnerCount++;
                            continue;
                        }
                        processedStrokeThicknessOwners.push(strokeOwner);
                        processedStrokeOwnerCount++;
                        var ownerKey = getStrokeThicknessSourceKey(strokeOwner);
                        processedStrokeThicknessOwnerKeys[ownerKey] = true;
                        originalExportItem = strokeOwner;
	                    } else if (strokeOwner) {
	                        totalStrokeOwnersFound++;
	                        if (hasProcessedStrokeOwner(strokeOwner)) {
	                            skippedDuplicateOwnerCount++;
	                            continue;
                        }
                        processedStrokeThicknessOwners.push(strokeOwner);
                        processedStrokeOwnerCount++;
	                        var ownKey = getStrokeThicknessSourceKey(strokeOwner);
	                        processedStrokeThicknessOwnerKeys[ownKey] = true;
	                    }
                    var originalPureForIdentity = "";
                    try { originalPureForIdentity = tools.getPureName(originalExportItem.name) || ""; } catch(identityPureErr) {}
                    if (!originalPureForIdentity) originalPureForIdentity = "Part_" + (c + 1);
                    var originalIsRealGroup = false;
                    try { originalIsRealGroup = originalExportItem && originalExportItem.typename === "GroupItem" && !originalExportItem.clipped; } catch(identityGroupErr) {}
                    var originalIdentity = makeExportIdentity(originalPureForIdentity, c, originalIsRealGroup, originalIsRealGroup ? [originalPureForIdentity] : []);
		                    var generatedKey = getGeneratedFromKey(originalExportItem);
		                    if (generatedKey && copiedGeneratedSourceKeys[generatedKey]) {
		                        continue;
		                    }

                    if (hasSkipExportFlag(originalExportItem) && !hasStrokeThicknessExportFlag(originalExportItem)) {
                        var skipSourceKey = generatedKey || getStrokeThicknessSourceKey(originalExportItem);
                        skipExportCount++;
                        try { skippedItemNames.push(String(originalExportItem.name || "")); } catch(skipNameErr) {}
                        duplicateStrokeGeneratedPartsForSource(originalExportItem, skipSourceKey);
                        continue;
                    }

	                    var duplicatedExportItem = duplicateExportItemToTemp(originalExportItem);
	                    if (!duplicatedExportItem) continue;
		                    try {
		                        if (hasStrokeThicknessExportFlag(originalExportItem)) {
		                            setStrokeThicknessExportFlag(duplicatedExportItem, true);
		                            var originalDepthForDup = parseStrokeThicknessDepthMm(originalExportItem);
		                            if (originalDepthForDup !== null) setStrokeThicknessDepthMm(duplicatedExportItem, originalDepthForDup);
                                var inheritedFillDepthForDup = tools.getTagD(originalExportItem.name);
                                var inheritedTypeForDup = tools.getTagT(originalExportItem.name);
                                var splitTargets = [];
                                try {
                                    if (duplicatedExportItem.typename === "GroupItem" && !duplicatedExportItem.clipped) {
                                        splitTargets = collectStrokeExportTargets(duplicatedExportItem);
                                    }
                                } catch(collectTargetsErr) {}
                                exportDebugLines.push(
                                    "collectStrokeExportTargets" +
                                    " | selectedName=" + safeDebugText(originalExportItem.name) +
                                    " | selectedType=" + safeDebugText(originalExportItem.typename) +
                                    " | duplicatedType=" + safeDebugText(duplicatedExportItem.typename) +
                                    " | targetCount=" + splitTargets.length
                                );
	                                if (splitTargets.length > 1) {
		                                    for (var splitTargetIndex = 0; splitTargetIndex < splitTargets.length; splitTargetIndex++) {
		                                        try {
		                                            exportDebugLines.push(
	                                                "strokeSplitTarget" +
                                                " | index=" + splitTargetIndex +
                                                " | name=" + safeDebugText(splitTargets[splitTargetIndex].name) +
                                                " | type=" + safeDebugText(splitTargets[splitTargetIndex].typename) +
	                                                " | isClippingGroup=" + (splitTargets[splitTargetIndex].typename === "GroupItem" && splitTargets[splitTargetIndex].clipped)
	                                            );
	                                        } catch(targetDebugErr) {}
	                                        try {
	                                            if (originalDepthForDup !== null && originalDepthForDup !== undefined) setStrokeThicknessDepthMm(splitTargets[splitTargetIndex], originalDepthForDup);
	                                            setStrokeThicknessExportFlag(splitTargets[splitTargetIndex], false);
	                                            setSkipExportFlag(splitTargets[splitTargetIndex], true);
	                                        } catch(groupTargetSkipErr) {}
	                                    }
		                                    strokeSplitExportTasks.push({
		                                        name: duplicatedExportItem.name,
		                                        group: originalIdentity.groupName,
		                                        color: getStrokeFillRgb(duplicatedExportItem),
		                                        source: duplicatedExportItem,
		                                        refItem: duplicatedExportItem,
		                                        strokeThicknessExport: true,
		                                        strokeThicknessDepthMm: originalDepthForDup !== null ? originalDepthForDup : parseStrokeThicknessDepthMm(duplicatedExportItem),
		                                        strokeThicknessExportRoot: true,
		                                        directStrokeSplitTask: true,
		                                        groupMergeStrokeExport: true,
		                                        mergeTargets: splitTargets,
		                                        mergeTargetCount: splitTargets.length,
                                                identityMeta: originalIdentity
			                                    });
		                                    setStrokeThicknessExportFlag(duplicatedExportItem, false);
		                                    duplicatedExportItem.name = tools.rebuildName(
		                                        duplicatedExportItem.name,
		                                        tools.getTagD(duplicatedExportItem.name),
		                                        tools.getTagT(duplicatedExportItem.name),
		                                        tools.getFallbackExport(duplicatedExportItem.name),
		                                        tools.getFallbackReverse(duplicatedExportItem.name),
		                                        false
		                                    );
		                                    setSkipExportFlag(duplicatedExportItem, true);
		                                    continue;
		                                }
	                            if (!tools.getStrokeThicknessExport(duplicatedExportItem.name)) {
	                                var dupD = tools.getTagD(duplicatedExportItem.name);
	                                var dupT = tools.getTagT(duplicatedExportItem.name);
                                duplicatedExportItem.name = tools.rebuildName(
                                    duplicatedExportItem.name,
                                    dupD,
                                    dupT,
                                    tools.getFallbackExport(duplicatedExportItem.name),
                                    tools.getFallbackReverse(duplicatedExportItem.name),
                                    true
	                                );
	                            }
		                            strokeSplitExportTasks.push({
		                                name: duplicatedExportItem.name,
		                                group: originalIdentity.groupName,
		                                color: getStrokeFillRgb(duplicatedExportItem),
		                                source: duplicatedExportItem,
		                                refItem: duplicatedExportItem,
		                                strokeThicknessExport: true,
		                                strokeThicknessDepthMm: originalDepthForDup !== null ? originalDepthForDup : parseStrokeThicknessDepthMm(duplicatedExportItem),
		                                strokeThicknessExportRoot: true,
		                                directStrokeSplitTask: true,
                                        identityMeta: originalIdentity
		                            });
	                            setStrokeThicknessExportFlag(duplicatedExportItem, false);
	                            setSkipExportFlag(duplicatedExportItem, true);
	                            duplicatedExportItem.name = tools.rebuildName(
	                                duplicatedExportItem.name,
	                                tools.getTagD(duplicatedExportItem.name),
	                                tools.getTagT(duplicatedExportItem.name),
	                                tools.getFallbackExport(duplicatedExportItem.name),
	                                tools.getFallbackReverse(duplicatedExportItem.name),
	                                false
	                            );
	                        }
	                    } catch(syncStrokeExportErr) {}
                } catch(e) {}
            }

	            var sel =[];
	            for (var p = 0; p < tempLayer.pageItems.length; p++) {
	                sel.push(tempLayer.pageItems[p]);
	            }

            var globalClipCounter = 1;
            var globalObjCounter = 1;

            // =======================================================
            // 扫描分类逻辑
            // =======================================================
            var findLargestClipItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var best = null;
                var bestArea = -1;

                var consider = function(item) {
                    try {
                        var b = item.geometricBounds;
                        if (!b) return;
                        var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                        if (area > bestArea) {
                            bestArea = area;
                            best = item;
                        }
                    } catch (e) {}
                };

                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "PathItem" && node.clipping) {
                            consider(node);
                            return;
                        }
                        if (node.typename === "CompoundPathItem" && node.pathItems && node.pathItems.length > 0 && node.pathItems[0].clipping) {
                            consider(node);
                            return;
                        }
                        if (node.typename === "GroupItem") {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };

                walk(group);
                return best;
            };

            var collectAllClipItems = function(group) {
                var out = [];
                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "PathItem" && node.clipping) {
                            out.push(node);
                            return;
                        }
                        if (node.typename === "CompoundPathItem" && node.pathItems && node.pathItems.length > 0 && node.pathItems[0].clipping) {
                            out.push(node);
                            return;
                        }
                        if (node.typename === "GroupItem") {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };
                walk(group);
                return out;
            };

            var findBestMaskForGroup = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var candidates = collectAllClipItems(group);
                if (!candidates || candidates.length === 0) return null;

                var gb = null;
                try { gb = group.geometricBounds; } catch (e) {}
                if (!gb) return candidates[0];
                var gw = Math.max(0.01, Math.abs(gb[2] - gb[0]));
                var gh = Math.max(0.01, Math.abs(gb[1] - gb[3]));

                var best = candidates[0];
                var bestCoverage = -1;
                var bestArea = -1;

                for (var i = 0; i < candidates.length; i++) {
                    try {
                        var b = candidates[i].geometricBounds;
                        if (!b) continue;
                        var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                        var coverage = Math.min(Math.abs(b[2] - b[0]) / gw, Math.abs(b[1] - b[3]) / gh);
                        if (coverage > bestCoverage || (coverage === bestCoverage && area > bestArea)) {
                            bestCoverage = coverage;
                            bestArea = area;
                            best = candidates[i];
                        }
                    } catch (e) {}
                }
                return best;
            };

            var shouldSplitClippedContainer = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.clipped) return false;
                var candidates = collectAllClipItems(group);
                if (!candidates || candidates.length < 2) return false;

                var gb = null;
                try { gb = group.geometricBounds; } catch (e) {}
                if (!gb) return false;
                var gw = Math.max(0.01, Math.abs(gb[2] - gb[0]));
                var gh = Math.max(0.01, Math.abs(gb[1] - gb[3]));

                var bestCoverage = -1;
                for (var i = 0; i < candidates.length; i++) {
                    try {
                        var b = candidates[i].geometricBounds;
                        if (!b) continue;
                        var coverage = Math.min(Math.abs(b[2] - b[0]) / gw, Math.abs(b[1] - b[3]) / gh);
                        if (coverage > bestCoverage) bestCoverage = coverage;
                    } catch (e) {}
                }

                return bestCoverage > 0 && bestCoverage < 0.35;
            };

            var containsAnyClippedGroup = function(group) {
                if (!group || group.typename !== "GroupItem") return false;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename === "GroupItem") {
                            if (child.clipped) return true;
                            if (containsAnyClippedGroup(child)) return true;
                        }
                    }
                } catch (e) {}
                return false;
            };

            var getPrimaryDirectClipItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        if (group.pageItems[i].clipping === true) return group.pageItems[i];
                    }
                    for (var j = 0; j < group.pageItems.length; j++) {
                        var child = group.pageItems[j];
                        if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0 && child.pathItems[0].clipping) {
                            return child;
                        }
                    }
                } catch (e) {}
                return null;
            };

            var findLargestNestedClippedGroupMask = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var bestMask = null;
                var bestArea = -1;

                var areaOf = function(item) {
                    try {
                        var b = item.geometricBounds;
                        if (!b) return -1;
                        return Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                    } catch (e) {
                        return -1;
                    }
                };

                var walk = function(node, skipSelf) {
                    if (!node || node.typename !== "GroupItem") return;
                    try {
                        if (!skipSelf && node.clipped) {
                            var mask = getPrimaryDirectClipItem(node);
                            if (mask) {
                                var area = areaOf(mask);
                                if (area > bestArea) {
                                    bestArea = area;
                                    bestMask = mask;
                                }
                            }
                        }
                        for (var i = 0; i < node.pageItems.length; i++) {
                            if (node.pageItems[i].typename === "GroupItem") {
                                walk(node.pageItems[i], false);
                            }
                        }
                    } catch (e) {}
                };

                walk(group, true);
                return bestMask;
            };

            var findLargestDirectOutlineItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var best = null;
                var bestArea = -1;

                var consider = function(item) {
                    try {
                        if (!item) return;
                        if (item.typename === "PathItem" && item.guides) return;
                        if (item.typename !== "PathItem" && item.typename !== "CompoundPathItem") return;
                        var b = item.geometricBounds;
                        if (!b) return;
                        var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                        if (area > bestArea) {
                            bestArea = area;
                            best = item;
                        }
                    } catch (e) {}
                };

                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        consider(group.pageItems[i]);
                    }
                } catch (e) {}

                return best;
            };

            var getItemArea = function(item) {
                try {
                    if (!item || !item.geometricBounds) return -1;
                    var b = item.geometricBounds;
                    return Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                } catch (e) {
                    return -1;
                }
            };

            var boundsArea = function(b) {
                if (!b || b.length < 4) return -1;
                return Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
            };

            var getGroupOwnBounds = function(group) {
                try {
                    if (!group || !group.geometricBounds) return null;
                    return [group.geometricBounds[0], group.geometricBounds[1], group.geometricBounds[2], group.geometricBounds[3]];
                } catch (e) {
                    return null;
                }
            };

            var getItemOuterBounds = function(item) {
                var result = null;
                var add = function(b) {
                    if (!b || b.length < 4) return;
                    result = unionTwoBounds(result, [b[0], b[1], b[2], b[3]]);
                };
                try { add(item.geometricBounds); } catch(e) {}
                try { add(item.visibleBounds); } catch(e) {}
                try { add(item.controlBounds); } catch(e) {}
                return result;
            };

            var isClipItem = function(item) {
                try {
                    if (!item) return false;
                    if (item.clipping === true) return true;
                    if (item.typename === "CompoundPathItem" && item.pathItems && item.pathItems.length > 0 && item.pathItems[0].clipping) return true;
                } catch (e) {}
                return false;
            };

            var countDirectRenderableChildren = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return 0;
                var count = 0;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (isClipItem(child)) continue;
                        if (child.guides) continue;
                        if (child.typename === "PathItem" || child.typename === "CompoundPathItem" ||
                            child.typename === "GroupItem" || child.typename === "TextFrame" ||
                            child.typename === "RasterItem" || child.typename === "PlacedItem" ||
                            child.typename === "MeshItem") {
                            count++;
                        }
                    }
                } catch (e) {}
                return count;
            };

            var countNestedTextFrames = function(item) {
                if (!item) return 0;
                var count = 0;
                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "TextFrame") {
                            count++;
                            return;
                        }
                        if (node.pageItems) {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };
                walk(item);
                return count;
            };

            var containsAnyRasterDescendant = function(item) {
                var found = false;
                var walk = function(node) {
                    if (!node || found) return;
                    try {
                        if (node.typename === "RasterItem" || node.typename === "PlacedItem" || node.typename === "MeshItem") {
                            found = true;
                            return;
                        }
                        if (node.pageItems) {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                                if (found) return;
                            }
                        }
                    } catch (e) {}
                };
                walk(item);
                return found;
            };

            var unionTwoBounds = function(a, b) {
                if (!a) return b;
                if (!b) return a;
                return [
                    Math.min(a[0], b[0]),
                    Math.max(a[1], b[1]),
                    Math.max(a[2], b[2]),
                    Math.min(a[3], b[3])
                ];
            };

            var getUnclippedChildrenBounds = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return null;
                var result = null;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (isClipItem(child)) continue;
                        var b = null;
                        try {
                            if (child.typename === "GroupItem") {
                                b = getUnclippedChildrenBounds(child);
                                if (!b && child.geometricBounds) {
                                    b = [child.geometricBounds[0], child.geometricBounds[1], child.geometricBounds[2], child.geometricBounds[3]];
                                }
                            } else if (child.geometricBounds) {
                                b = [child.geometricBounds[0], child.geometricBounds[1], child.geometricBounds[2], child.geometricBounds[3]];
                            }
                        } catch (e) {}
                        result = unionTwoBounds(result, b);
                    }
                } catch (e) {}
                return result;
            };

            var findLargestDirectClippedChild = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return null;
                var best = null;
                var bestArea = -1;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename !== "GroupItem" || !child.clipped) continue;
                        var b = getItemOuterBounds(child);
                        var a = boundsArea(b);
                        if (a > bestArea) {
                            bestArea = a;
                            best = child;
                        }
                    }
                } catch (e) {}
                return best;
            };

            var countDirectClippedChildren = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return 0;
                var count = 0;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename === "GroupItem" && child.clipped) count++;
                    }
                } catch (e) {}
                return count;
            };

            var collectDirectChildClippedGroups = function(group) {
                var groups = [];
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return groups;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename === "GroupItem" && child.clipped) groups.push(child);
                    }
                } catch (e) {}
                return groups;
            };

            var findDominantDirectOutlineItem = function(group) {
                var largest = findLargestDirectOutlineItem(group);
                if (!largest) return null;
                try {
                    var largestArea = getItemArea(largest);
                    var groupBounds = getItemOuterBounds(group);
                    var groupArea = boundsArea(groupBounds);
                    if (largestArea > 0 && groupArea > 0 && largestArea > groupArea * 0.6) {
                        return largest;
                    }
                } catch (e) {}
                return null;
            };

            var chooseParentExportContainer = function(item) {
                try {
                    if (!item || !item.parent || item.parent.typename !== "GroupItem") return null;
                    var parent = item.parent;
                    if (parent.clipped) return null;
                    var parentBounds = getItemOuterBounds(parent);
                    var selfBounds = getItemOuterBounds(item);
                    if (boundsArea(parentBounds) <= 0 || boundsArea(selfBounds) <= 0) return null;
                    if (boundsArea(parentBounds) <= boundsArea(selfBounds) * 1.05) return null;
                    if (countDirectClippedChildren(parent) > 1) return null;
                    return parent;
                } catch (e) {
                    return null;
                }
            };

            var countDescendantClippedGroups = function(group) {
                var count = 0;
                var walk = function(node) {
                    if (!node || node.typename !== "GroupItem") return;
                    try {
                        if (node.clipped) count++;
                        if (node.pageItems) {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                if (node.pageItems[i].typename === "GroupItem") walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };
                walk(group);
                return count;
            };

            var chooseAncestorExportContainer = function(item) {
                try {
                    if (!item) return null;
                    var selfBounds = getItemOuterBounds(item);
                    var selfArea = boundsArea(selfBounds);
                    if (selfArea <= 0) return null;
                    var node = item.parent;
                    while (node && node.typename === "GroupItem") {
                        var ancestorBounds = getItemOuterBounds(node);
                        var ancestorArea = boundsArea(ancestorBounds);
                        if (ancestorArea > selfArea * 1.05) {
                            if (countDescendantClippedGroups(node) <= 1) {
                                return node;
                            }
                            return null;
                        }
                        node = node.parent;
                    }
                } catch (e) {}
                return null;
            };

            var chooseOutermostClippedAncestor = function(item) {
                var best = item;
                try {
                    if (!item || item.typename !== "GroupItem" || !item.clipped) return item;
                    var node = item.parent;
                    while (node && node.typename === "GroupItem") {
                        if (node.clipped) {
                            best = node;
                            node = node.parent;
                            continue;
                        }
                        break;
                    }
                } catch (e) {}
                return best;
            };

            var shouldSplitLargeOuterClipContainer = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.clipped) return false;
                var mask = getPrimaryDirectClipItem(group);
                if (!mask || mask.typename !== "PathItem") return false;
                var gb = getGroupOwnBounds(group);
                if (!gb) return false;
                var groupArea = boundsArea(gb);
                var maskArea = getItemArea(mask);
                if (groupArea <= 0 || maskArea <= 0) return false;
                var coverage = Math.min(
                    Math.abs(mask.geometricBounds[2] - mask.geometricBounds[0]) / Math.max(0.01, Math.abs(gb[2] - gb[0])),
                    Math.abs(mask.geometricBounds[1] - mask.geometricBounds[3]) / Math.max(0.01, Math.abs(gb[1] - gb[3]))
                );
                var maskW = Math.abs(mask.geometricBounds[2] - mask.geometricBounds[0]);
                var maskH = Math.abs(mask.geometricBounds[1] - mask.geometricBounds[3]);
                var isLargeSheet = maskW > 250 && maskH > 150;
                return coverage > 0.85 && (isLargeSheet || countDirectRenderableChildren(group) >= 2 || countNestedTextFrames(group) >= 2);
            };

            var chooseOuterMaskForClippedGroup = function(group) {
                var clipMask = getPrimaryDirectClipItem(group);
                if (!clipMask) clipMask = findBestMaskForGroup(group);

                var outerOutline = findLargestDirectOutlineItem(group);
                if (!outerOutline) return clipMask;
                if (!clipMask) return outerOutline;

                var clipArea = getItemArea(clipMask);
                var outlineArea = getItemArea(outerOutline);

                // 有些文件是“外层白框 + 内层图片剪切框”：真正用于 C4D 的尺寸应取外层白框。
                if (outlineArea > 0 && clipArea > 0 && outlineArea > clipArea * 1.05) {
                    return outerOutline;
                }
                return clipMask;
            };

            var chooseExportBoundsForClippedGroup = function(group, maskItem) {
                var maskBounds = maskItem ? getTightBounds(maskItem) : null;
                var tightGroupBounds = getTightBounds(group);
                var outerGroupBounds = getItemOuterBounds(group);
                var contentBounds = getUnclippedChildrenBounds(group);
                var bestBounds = tightGroupBounds;
                if (boundsArea(outerGroupBounds) > boundsArea(bestBounds)) bestBounds = outerGroupBounds;
                if (boundsArea(contentBounds) > boundsArea(bestBounds)) bestBounds = contentBounds;
                if (!bestBounds) return maskBounds ? maskBounds : getTightBounds(group);
                if (!maskBounds) return bestBounds;

                var gArea = boundsArea(bestBounds);
                var mArea = boundsArea(maskBounds);
                if (gArea > 0 && mArea > 0 && gArea > mArea * 1.02) {
                    return bestBounds;
                }
                return maskBounds;
            };

            var mergeSegArrays = function(segArrays) {
                var merged = [];
                var seen = {};
                for (var i = 0; i < segArrays.length; i++) {
                    var arr = segArrays[i];
                    if (!arr || arr.length === 0) continue;
                    for (var j = 0; j < arr.length; j++) {
                        var seg = arr[j];
                        if (!seg || seg === "") continue;
                        var key = String(seg);
                        if (seen[key]) continue;
                        seen[key] = true;
                        merged.push(seg);
                    }
                }
                return merged;
            };

            var getPts = function(pth) {
                var pp = pth.pathPoints; if (!pp || pp.length < 2) return "";
                var arr =[];
                for (var i=0; i<pp.length; i++) {
                    var pt=pp[i];
                    var ax=Math.round(pt.anchor[0]*100)/100, ay=Math.round(-pt.anchor[1]*100)/100;
                    var ix=Math.round(pt.leftDirection[0]*100)/100, iy=Math.round(-pt.leftDirection[1]*100)/100;
                    var ox=Math.round(pt.rightDirection[0]*100)/100, oy=Math.round(-pt.rightDirection[1]*100)/100;
                    arr.push('{"a":['+ax+','+ay+'],"inT":['+ix+','+iy+'],"outT":['+ox+','+oy+']}');
                }
                return "[" + arr.join(",") + "]";
            };

            var getSegsFromItem = function(obj) {
                var segs =[];
                if (!obj) return segs;

                if (obj.typename === "TextFrame") {
                    try {
                        var dup = obj.duplicate(doc.layers[0], ElementPlacement.PLACEATBEGINNING);
                        dup.clipping = false; 
                        dup.hidden = false;
                        dup.locked = false;
                        var out = dup.createOutline(); 
                        var pths = collectAllPaths(out);
                        for (var i=0; i<pths.length; i++) {
                            var p = getPts(pths[i]);
                            if (p) segs.push(p);
                        }
                        out.remove(); 
                    } catch(e) {}
                } else {
                    var pths = collectAllPaths(obj);
                    for (var j=0; j<pths.length; j++) {
                        var p2 = getPts(pths[j]);
                        if (p2) segs.push(p2);
                    }
                }
                return segs;
            };

            var getOutermostPathItem = function(item) {
                if (!item) return null;
                if (item.typename === "PathItem") return item;
                if (item.typename === "CompoundPathItem" && item.pathItems && item.pathItems.length > 0) {
                    var best = null;
                    var bestArea = -1;
                    for (var i = 0; i < item.pathItems.length; i++) {
                        try {
                            var p = item.pathItems[i];
                            var b = p.geometricBounds;
                            if (!b) continue;
                            var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                            if (area > bestArea) {
                                bestArea = area;
                                best = p;
                            }
                        } catch (e) {}
                    }
                    return best;
                }
                return null;
            };

            var getPrimaryClipSegs = function(item) {
                var segs = [];
                var outer = getOutermostPathItem(item);
                if (!outer) return segs;
                var seg = getPts(outer);
                if (seg) segs.push(seg);
                return segs;
            };

            var collectAllPaths = function(item) {
                var paths =[];
                if (!item) return paths;
                if (item.typename === "PathItem") { paths.push(item); } 
                else if (item.typename === "CompoundPathItem") { 
                    for (var i = 0; i < item.pathItems.length; i++) { paths.push(item.pathItems[i]); } 
                } 
                else if (item.typename === "GroupItem") { 
                    for (var j = 0; j < item.pageItems.length; j++) { paths = paths.concat(collectAllPaths(item.pageItems[j])); } 
                }
                return paths;
            };

            var collectChildClippedGroups = function(group) {
                var groups = [];
                if (!group || group.typename !== "GroupItem") return groups;

                var walk = function(node, isRoot) {
                    if (!node || node.typename !== "GroupItem") return;
                    try {
                        if (!isRoot && node.clipped) {
                            groups.push(node);
                            return;
                        }
                        for (var i = 0; i < node.pageItems.length; i++) {
                            if (node.pageItems[i].typename === "GroupItem") {
                                walk(node.pageItems[i], false);
                            }
                        }
                    } catch (e) {}
                };

                walk(group, true);
                return groups;
            };

            var calcLargestPathCoverageForBounds = function(baseBounds, item) {
                if (!baseBounds || !item) return 0;
                var paths = collectAllPaths(item);
                if (!paths || paths.length === 0) return 0;
                var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                var best = 0;

                for (var i = 0; i < paths.length; i++) {
                    try {
                        var b = getTightBounds(paths[i]);
                        if (!b) continue;
                        var wRatio = Math.abs(b[2] - b[0]) / baseW;
                        var hRatio = Math.abs(b[1] - b[3]) / baseH;
                        var coverage = Math.min(wRatio, hRatio);
                        if (coverage > best) best = coverage;
                    } catch (e) {}
                }
                return best;
            };

	            var unionBounds = function(boundsList) {
	                if (!boundsList || boundsList.length === 0) return null;
                var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                var found = false;
                for (var i = 0; i < boundsList.length; i++) {
                    var b = boundsList[i];
                    if (!b || b.length < 4) continue;
                    found = true;
                    if (b[0] < left) left = b[0];
                    if (b[1] > top) top = b[1];
                    if (b[2] > right) right = b[2];
                    if (b[3] < bottom) bottom = b[3];
                }
	                return found ? [left, top, right, bottom] : null;
	            };

		            var containsFallbackDescendant = function(item) {
		                var found = false;
	                var walk = function(node) {
	                    if (!node || found) return;
	                    try {
	                        if (tools.getFallbackExport(node.name)) {
	                            found = true;
	                            return;
	                        }
	                        if (node.pageItems) {
	                            for (var i = 0; i < node.pageItems.length; i++) {
	                                walk(node.pageItems[i]);
	                                if (found) return;
	                            }
	                        }
	                    } catch(e) {}
	                };
		                walk(item);
		                return found;
		            };

		            var containsFallbackReverseDescendant = function(item) {
		                var found = false;
		                var walk = function(node) {
		                    if (!node || found) return;
		                    try {
		                        if (tools.getFallbackReverse(node.name)) {
		                            found = true;
		                            return;
		                        }
		                        if (node.pageItems) {
		                            for (var i = 0; i < node.pageItems.length; i++) {
		                                walk(node.pageItems[i]);
		                                if (found) return;
		                            }
		                        }
		                    } catch(e) {}
		                };
		                walk(item);
		                return found;
		            };

		            var containsStrokeThicknessDescendant = function(item) {
		                var found = false;
		                var walk = function(node) {
		                    if (!node || found) return;
		                    try {
		                        if (hasStrokeThicknessExportFlag(node)) {
		                            found = true;
		                            return;
		                        }
		                        if (node.pageItems) {
		                            for (var i = 0; i < node.pageItems.length; i++) {
		                                walk(node.pageItems[i]);
		                                if (found) return;
		                            }
		                        }
		                    } catch(e) {}
		                };
		                walk(item);
		                return found;
		            };

            var scan = function(item, parentSuffix, groupName, parentFallbackExport, parentFallbackReverse, parentStrokeThicknessExport, parentStrokeThicknessDepthMm, sharedTextureName, sharedTextureBounds, identityMeta) {
                try {
                    if (item && item.layer && (item.layer.name === "HH_FALLBACK_PREVIEW" || item.layer.name === STROKE_PREVIEW_LAYER)) {
                        scanDebugLines.push("scanSkip previewLayer | item.name=" + safeDebugText(item.name) + " | layer=" + safeDebugText(item.layer.name));
                        return;
                    }
                } catch(e) {}
                try {
                    if (hasSkipExportFlag(item) && !hasStrokeThicknessExportFlag(item)) {
                        scanDebugLines.push("scanSkip HH_SKIP_EXPORT | item.name=" + safeDebugText(item.name) + " | note=" + safeNote(item));
                        return;
                    }
                } catch(skipErr) {}
                var mySuffix = tools.getFullSuffix(item.name);
                var effectiveSuffix = mySuffix ? mySuffix : parentSuffix;
                var effectiveFallbackExport = tools.getFallbackExport(item.name) || !!parentFallbackExport || containsFallbackDescendant(item);
                var effectiveFallbackReverse = tools.getFallbackReverse(item.name) || !!parentFallbackReverse || containsFallbackReverseDescendant(item);
                var ownStrokeThicknessExport = hasStrokeThicknessExportFlag(item);
                var descendantStrokeThicknessExport = containsStrokeThicknessDescendant(item);
                var effectiveStrokeThicknessExport = ownStrokeThicknessExport || !!parentStrokeThicknessExport || descendantStrokeThicknessExport;
                var ownStrokeDepthMm = parseStrokeThicknessDepthMm(item);
                var effectiveStrokeThicknessDepthMm = ownStrokeDepthMm !== null ? ownStrokeDepthMm : parentStrokeThicknessDepthMm;
                scanDebugLines.push(
                    "scanItem" +
                    " | item.name=" + safeDebugText(item.name) +
                    " | item.typename=" + safeDebugText(item.typename) +
                    " | item.note=" + safeNote(item) +
                    " | parent.name=" + safeDebugText(parentDebugName(item)) +
                    " | parent.note=" + parentDebugNote(item) +
                    " | groupName=" + safeDebugText(groupName) +
                    " | detectedDepthMm=" + (tools.getTagD(item.name) !== null ? tools.getTagD(item.name) : "null") +
                    " | hasStrokeThicknessExportFlag=" + ownStrokeThicknessExport +
                    " | parentStrokeThicknessExport=" + (!!parentStrokeThicknessExport) +
                    " | descendantStrokeThicknessExport=" + descendantStrokeThicknessExport +
                    " | effectiveStrokeThicknessExport=" + effectiveStrokeThicknessExport +
                    " | strokeThicknessDepthMm=" + (effectiveStrokeThicknessDepthMm !== null && effectiveStrokeThicknessDepthMm !== undefined ? effectiveStrokeThicknessDepthMm : "null") +
                    " | hasSkipExportFlag=" + hasSkipExportFlag(item)
                );

                var inheritedStrokeGroupTargetCount = 0;
                try {
                    if ((ownStrokeThicknessExport || !!parentStrokeThicknessExport) &&
                        item.typename === "GroupItem" &&
                        !item.clipped) {
                        inheritedStrokeGroupTargetCount = collectStrokeExportTargets(item).length;
                        scanDebugLines.push(
                            "strokeGroupTargetCollect" +
                            " | item.name=" + safeDebugText(item.name) +
                            " | targetCount=" + inheritedStrokeGroupTargetCount
                        );
                    }
                } catch(strokeGroupTargetErr) {}

                if ((ownStrokeThicknessExport || !!parentStrokeThicknessExport) &&
                    mode !== "images" &&
                    (item.typename === "PathItem" || item.typename === "CompoundPathItem" || item.typename === "GroupItem") &&
                    !(item.typename === "GroupItem" && !item.clipped && inheritedStrokeGroupTargetCount > 1)) {
                    var rawStrokeExportName = tools.getPureName(item.name) || "StrokeThickness_" + (globalObjCounter++);
                    var safeStrokeExportName = tools.cleanName(rawStrokeExportName + effectiveSuffix);
                    var strokeExportColor = getStrokeFillRgb(item);
	                    scanList.push({
	                        name: safeStrokeExportName,
	                        group: groupName,
	                        color: strokeExportColor,
	                        isMask: false,
	                        source: item,
	                        refItem: item,
	                        fallbackExport: effectiveFallbackExport,
	                        fallbackReverse: effectiveFallbackReverse,
	                        strokeThicknessExport: true,
	                        strokeThicknessDepthMm: effectiveStrokeThicknessDepthMm,
	                        strokeThicknessExportRoot: true,
                            identityMeta: identityMeta
	                    });
                    return;
                }

		                if (item.typename === "GroupItem") {
		                    var shouldFlatten = item.clipped;
		                    var directClippedChildrenCount = 0;
		                    if (!shouldFlatten) {
		                        for (var cx = 0; cx < item.pageItems.length; cx++) {
		                            var child = item.pageItems[cx];
		                            if (child.typename === "GroupItem" && child.clipped) {
		                                directClippedChildrenCount++;
		                                continue;
		                            }
	                            if (child.typename === "RasterItem" ||
	                                child.typename === "PlacedItem" ||
	                                child.typename === "MeshItem") {
	                                shouldFlatten = true;
	                                break;
		                            }
		                        }
		                    }
		                    var childSharedTextureName = sharedTextureName;
		                    var childSharedTextureBounds = sharedTextureBounds;
		                    if (!shouldFlatten && directClippedChildrenCount > 1 && mode !== "curves") {
		                        var rawSharedName = tools.getPureName(item.name) || "ClipGroup_" + (globalClipCounter++);
		                        childSharedTextureName = tools.cleanName(rawSharedName + effectiveSuffix);
		                        childSharedTextureBounds = getTightBounds(item);
		                        imgList.push({ item: item, name: childSharedTextureName, bounds: childSharedTextureBounds, sharedGroupTexture: true });
		                    }

		                    if (shouldFlatten) {
                        var rawName = tools.getPureName(item.name) || "Clip_" + (globalClipCounter++);
                        var safeName = tools.cleanName(rawName + effectiveSuffix);
                        var foundColor = tools.findDeepColor(item) || [128, 128, 128];

                        var maskItem = null;
                        if (item.clipped) {
                            for (var i = 0; i < item.pageItems.length; i++) {
                                if (item.pageItems[i].clipping) { maskItem = item.pageItems[i]; break; }
                            }
                            if (!maskItem) {
                                for (var j = 0; j < item.pageItems.length; j++) {
                                    var cp = item.pageItems[j];
                                    if (cp.typename === "CompoundPathItem" && cp.pathItems && cp.pathItems.length > 0 && cp.pathItems[0].clipping) {
                                        maskItem = cp;
                                        break;
                                    }
                                }
                            }
                            if (!maskItem && item.pageItems.length > 0) maskItem = item.pageItems[0];
                        }

	                        if (mode !== "curves" && !sharedTextureName) {
	                            imgList.push({ item: item, name: safeName });
	                        }
	                        if (mode !== "images") {
                            var finalBounds = getTightBounds(item);
	                            scanList.push({
	                                name: safeName,
	                                group: groupName,
	                                color: foundColor,
	                                isMask: true,
	                                bounds: finalBounds,
	                                source: maskItem ? maskItem : item,
	                                maskSource: maskItem,
	                                isGroup: true,
	                                refItem: item,
		                                hasRasterDescendant: containsAnyRasterDescendant(item),
			                                exportMode: item.clipped ? "single_clipped_group" : "flatten_group_children",
			                                sharedTextureName: sharedTextureName || null,
				                                sharedTextureBounds: sharedTextureBounds || null,
				                                fallbackExport: effectiveFallbackExport,
			                                fallbackReverse: effectiveFallbackReverse,
			                                strokeThicknessExport: effectiveStrokeThicknessExport,
			                                strokeThicknessDepthMm: effectiveStrokeThicknessDepthMm,
                                            identityMeta: identityMeta
			                            });
                        }
                        return;
                    }

		                    for (var k = 0; k < item.pageItems.length; k++) {
                                var childIdentity = identityMeta;
                                try {
                                    if (identityMeta && identityMeta.groupId && item.pageItems[k]) {
                                        var childBaseForIdentity = tools.getPureName(item.pageItems[k].name) || ("Child_" + (k + 1));
                                        childIdentity = cloneIdentityForChild(identityMeta, childBaseForIdentity, k);
                                    }
                                } catch(childIdentityErr) {}
		                        scan(item.pageItems[k], effectiveSuffix, groupName, effectiveFallbackExport, effectiveFallbackReverse, effectiveStrokeThicknessExport, effectiveStrokeThicknessDepthMm, childSharedTextureName, childSharedTextureBounds, childIdentity);
		                    }
                }
                else if (item.typename === "TextFrame") {
                    if (mode !== "images") {
                        var rawTxt = tools.getPureName(item.name) || "Text_" + (globalObjCounter++);
                        var safeTxt = tools.cleanName(rawTxt + effectiveSuffix);
                        var txtColor =[128, 128, 128];
                        try {
                            if (item.textRange && item.textRange.characterAttributes && item.textRange.characterAttributes.fillColor) {
                                var tc = tools.parseColor(item.textRange.characterAttributes.fillColor);
                                if (tc) txtColor = tc;
                            }
                        } catch(e) {}
                        
	                            scanList.push({
	                                name: safeTxt, group: groupName, color: txtColor, isMask: false, source: item, fallbackExport: effectiveFallbackExport, fallbackReverse: effectiveFallbackReverse, strokeThicknessExport: effectiveStrokeThicknessExport, strokeThicknessDepthMm: effectiveStrokeThicknessDepthMm, identityMeta: identityMeta
	                            });
                    }
                }
                else if (item.typename === "RasterItem" || item.typename === "PlacedItem" || item.typename === "MeshItem") {
                    if (mode !== "curves") {
                        var rawNameImg = tools.getPureName(item.name) || "Img_" + (globalObjCounter++);
                        var safeNameImg = tools.cleanName(rawNameImg + effectiveSuffix);
                        imgList.push({item: item, name: safeNameImg});
                    }
                }
                else if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
                    if (item.typename==="PathItem" && item.guides) return; 
                    if (mode !== "images") {
                        var raw2 = tools.getPureName(item.name) || "Obj_" + (globalObjCounter++);
                        var safe2 = tools.cleanName(raw2 + effectiveSuffix);
                        var c = tools.getRGB(item) ||[128, 128, 128];
	                        scanList.push({
	                            name: safe2, group: groupName, color: c, isMask: false, source: item, fallbackExport: effectiveFallbackExport, fallbackReverse: effectiveFallbackReverse, strokeThicknessExport: effectiveStrokeThicknessExport, strokeThicknessDepthMm: effectiveStrokeThicknessDepthMm, identityMeta: identityMeta
	                        });
                    }
                }
            };

            try {
                updateExportProgress(20, "分析厚度 / 描边 / 剪切蒙版...");
	                for (var s = 0; s < sel.length; s++) {
	                    var root = sel[s];
	                    var rootFallback = tools.getFallbackExport(root.name);
	                    var rootReverse = tools.getFallbackReverse(root.name);
	                    var rootStrokeThickness = hasStrokeThicknessExportFlag(root);
	                    var rootStrokeDepthMm = parseStrokeThicknessDepthMm(root);
		                    var rootSuffix = tools.getFullSuffix(root.name);
		                    var pure = tools.getPureName(root.name);
		                    if (!pure || pure.indexOf("Part_") === -1) { pure = "Part_" + (s + 1); }
                            var rootIsRealGroup = false;
                            try { rootIsRealGroup = root && root.typename === "GroupItem" && !root.clipped; } catch(rootIdentityErr) {}
                            var rootIdentity = makeExportIdentity(pure, s, rootIsRealGroup, rootIsRealGroup ? [pure] : [], root);
		                    try { root.name = pure + rootSuffix + (rootFallback ? "_fb" : "") + (rootReverse ? "_fbr" : "") + (rootStrokeThickness ? "_stx" : ""); } catch(e) {}
			                    scan(root, rootSuffix, rootIdentity.groupName, rootFallback, rootReverse, rootStrokeThickness, rootStrokeDepthMm, null, null, rootIdentity);
		                }
                updateExportProgress(35, "生成路径数据...");

                // =======================================================
                // 3. 图片导出 (使用 getTightBounds，完美去白边裁切)
                // =======================================================
                if (imgList.length > 0) {
                    var exportScale = (dpi / 72.0) * 100.0;
                    if (exportScale > 776.0) exportScale = 776.0;

                    var opts, type;
                    if (format === "png") {
                        opts = new ExportOptionsPNG24(); 
                        opts.antiAliasing = true; opts.transparency = true; opts.artBoardClipping = true; 
                        opts.horizontalScale = exportScale; opts.verticalScale = exportScale;
                        type = ExportType.PNG24;
                    } else {
                        opts = new ExportOptionsJPEG(); 
                        opts.antiAliasing = true; opts.artBoardClipping = true; opts.qualitySetting = 100; 
                        opts.horizontalScale = exportScale; opts.verticalScale = exportScale;
                        type = ExportType.JPEG;
                    }
                    
                    var exportDoc = app.documents.add(doc.documentColorSpace);
                    var exportLayer = exportDoc.layers[0];
                    var defringe = 0.5;

	                    for (var k = 0; k < imgList.length; k++) {
                        var task = imgList[k];
                        var originalItem = task.item;
                        try {
                            updateExportProgress(65 + Math.min(10, Math.round((k / Math.max(1, imgList.length)) * 10)), "正在导出贴图 " + (k + 1) + " / " + imgList.length);
                            var tempDup = originalItem.duplicate(originalItem, ElementPlacement.PLACEBEFORE);
                            
                            // 【脱水边界】：此处的 bakeBounds 是精准脱水的墨水边界，完美剪裁
	                            var bakeBounds = task.bounds ? task.bounds : getTightBounds(originalItem);
                            var tightW = bakeBounds[2] - bakeBounds[0];
                            var tightH = bakeBounds[1] - bakeBounds[3];
                            
                            var rastOpts = new RasterizeOptions();
                            rastOpts.resolution = dpi; 
                            rastOpts.transparency = true; 
                            rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                            rastOpts.convertSpotColors = true; 
                            rastOpts.convertTextToOutlines = false; 
                            
                            var bakedItem = doc.rasterize(tempDup, bakeBounds, rastOpts);
                            var exportedItem = bakedItem.duplicate(exportLayer, ElementPlacement.PLACEATEND);
                            bakedItem.remove(); 
                            
                            var finalW = tightW - defringe;
                            var finalH = tightH - defringe;
                            if (finalW < 1) finalW = tightW; 
                            if (finalH < 1) finalH = tightH;

                            exportDoc.artboards[0].artboardRect =[0, 0, finalW, -finalH];
                            
                            var itemCenter =[exportedItem.left + exportedItem.width/2, exportedItem.top - exportedItem.height/2];
                            var boardCenter =[finalW/2, -finalH/2];
                            exportedItem.translate(boardCenter[0] - itemCenter[0], boardCenter[1] - itemCenter[1]);
                            
                            var originalTextureName = task.name;
                            var textureOutputName = task.textureOutputName || makeTextureOutputName(originalTextureName, "img_" + k + "_" + originalTextureName);
                            task.textureOutputName = textureOutputName;
                            for (var sl = 0; sl < scanList.length; sl++) {
                                try {
                                    if (scanList[sl].sharedTextureName === originalTextureName) {
                                        scanList[sl].sharedTextureOutputName = textureOutputName;
                                    }
                                    if ((scanList[sl].name === originalTextureName || scanList[sl].refItem === originalItem || scanList[sl].source === originalItem) && !scanList[sl].sharedTextureName) {
                                        scanList[sl].textureOutputName = textureOutputName;
                                    }
                                } catch(assignTextureNameErr) {}
                            }
                            var finalFile = new File(texFolder.fsName + "/" + textureOutputName + "." + format);
                            var staleOtherFile = new File(texFolder.fsName + "/" + textureOutputName + "." + (format === "jpg" ? "png" : "jpg"));
                            try { if (staleOtherFile.exists) staleOtherFile.remove(); } catch(removeStaleTextureErr) {}
                            try { if (finalFile.exists) finalFile.remove(); } catch(removeSameJsonTextureErr) {}
                            
                            updateExportProgress(65 + Math.min(10, Math.round((k / Math.max(1, imgList.length)) * 10)), "正在导出贴图 " + (k + 1) + " / " + imgList.length);
                            exportDoc.exportFile(finalFile, type, opts);
                            exportedTextureNames.push(finalFile.name);
                            imgCount++;
                            exportedItem.remove();
                        } catch(e) {}
                    }
	                    exportDoc.close(SaveOptions.DONOTSAVECHANGES);
                }
                updateExportProgress(50, "生成 JSON 数据...");

                // =======================================================
                // 4. JSON 导出 (完美穿透提取文字笔画)
                // =======================================================
	                if (scanList.length > 0 || strokeSplitExportTasks.length > 0) {
                    var makeRect = function(b) {
                        var L=b[0],T=b[1],R=b[2],B=b[3];
                        var f=function(u,v){return '{"a":['+(Math.round(u*100)/100)+','+(Math.round(-v*100)/100)+']}';};
                        return '[['+f(L,T)+','+f(R,T)+','+f(R,B)+','+f(L,B)+']]';
                    };

                    var calcBoundsCoverage = function(baseBounds, items) {
                        if (!baseBounds || !items || items.length === 0) return 0;
                        var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                        var found = false;
                        for (var i = 0; i < items.length; i++) {
                            try {
                                var b = getTightBounds(items[i]);
                                if (!b) continue;
                                found = true;
                                left = Math.min(left, b[0]);
                                top = Math.max(top, b[1]);
                                right = Math.max(right, b[2]);
                                bottom = Math.min(bottom, b[3]);
                            } catch(e) {}
                        }
                        if (!found) return 0;
                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var curW = Math.max(0.0, Math.abs(right - left));
                        var curH = Math.max(0.0, Math.abs(top - bottom));
                        var wRatio = curW / baseW;
                        var hRatio = curH / baseH;
                        return Math.min(wRatio, hRatio);
                    };

// --- 开始插入：找回 28.37 的群组深入遍历方法 ---
                    var collectInternalMasks = function(item) {
                        var masks = [];
                        var seen = {};

                        var addMask = function(maskItem) {
                            if (!maskItem) return;
                            try {
                                var key = maskItem.typename + "|" + maskItem.name + "|" + String(maskItem.pageItems ? maskItem.pageItems.length : maskItem.pathPoints ? maskItem.pathPoints.length : 0);
                                if (seen[key]) return;
                                seen[key] = true;
                            } catch(e) {}
                            masks.push(maskItem);
                        };

                        var walk = function(node) {
                            if (!node || node.typename !== "GroupItem") return;
                            if (node.clipped) {
                                var m = null;
                                try {
                                    for (var i = 0; i < node.pageItems.length; i++) {
                                        if (node.pageItems[i].clipping) { m = node.pageItems[i]; break; }
                                    }
                                    if (!m) {
                                        for (var j = 0; j < node.pageItems.length; j++) {
                                            var child = node.pageItems[j];
                                            if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0 && child.pathItems[0].clipping) {
                                                m = child;
                                                break;
                                            }
                                        }
                                    }
                                } catch(e) {}
                                addMask(m);
                            }
                            for (var k = 0; k < node.pageItems.length; k++) {
                                if (node.pageItems[k].typename === "GroupItem") {
                                    walk(node.pageItems[k]);
                                }
                            }
                        };

                        walk(item);
                        return masks;
                    };

                    var calcLargestPathCoverage = function(baseBounds, item) {
                        if (!baseBounds || !item) return 0;
                        var paths = collectAllPaths(item);
                        if (!paths || paths.length === 0) return 0;

                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var best = 0;

                        for (var i = 0; i < paths.length; i++) {
                            try {
                                var b = getTightBounds(paths[i]);
                                if (!b) continue;
                                var wRatio = Math.abs(b[2] - b[0]) / baseW;
                                var hRatio = Math.abs(b[1] - b[3]) / baseH;
                                var coverage = Math.min(wRatio, hRatio);
                                if (coverage > best) best = coverage;
                            } catch(e) {}
                        }
                        return best;
                    };

                    var parseSegPoints = function(segText) {
                        if (!segText || segText === "") return [];
                        try { return eval("(" + segText + ")"); } catch (e) {}
                        return [];
                    };

                    var calcSegArrayMetrics = function(baseBounds, segArrays) {
                        var result = { unionCoverage: 0, totalCoverage: 0, largestCoverage: 0 };
                        if (!baseBounds || !segArrays || segArrays.length === 0) return result;
                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var baseArea = Math.max(0.01, baseW * baseH);
                        var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                        var found = false;
                        var totalArea = 0;

                        for (var sa = 0; sa < segArrays.length; sa++) {
                            var pts = parseSegPoints(segArrays[sa]);
                            if (!pts || pts.length === 0) continue;
                            var sLeft = 9999999999, sTop = -9999999999, sRight = -9999999999, sBottom = 9999999999;
                            var segFound = false;
                            for (var sp = 0; sp < pts.length; sp++) {
                                if (!pts[sp] || !pts[sp].a) continue;
                                segFound = true;
                                found = true;
                                var ax = pts[sp].a[0], ay = pts[sp].a[1];
                                if (ax < sLeft) sLeft = ax;
                                if (ax > sRight) sRight = ax;
                                if (ay > sTop) sTop = ay;
                                if (ay < sBottom) sBottom = ay;
                            }
                            if (!segFound) continue;
                            if (sLeft < left) left = sLeft;
                            if (sRight > right) right = sRight;
                            if (sTop > top) top = sTop;
                            if (sBottom < bottom) bottom = sBottom;

                            var curW = Math.max(0, sRight - sLeft);
                            var curH = Math.max(0, sTop - sBottom);
                            var curArea = curW * curH;
                            totalArea += curArea;
                            var curLargest = Math.min(curW / baseW, curH / baseH);
                            if (curLargest > result.largestCoverage) result.largestCoverage = curLargest;
                        }

                        if (!found) return result;
                        var unionW = Math.max(0, right - left);
                        var unionH = Math.max(0, top - bottom);
                        result.unionCoverage = Math.min(unionW / baseW, unionH / baseH);
                        result.totalCoverage = Math.min(1, totalArea / baseArea);
                        return result;
                    };

                    var analyzeStandardSegments = function(baseBounds, segArrays) {
                        var result = {
                            segmentCount: 0,
                            unionCoverage: 0,
                            totalCoverage: 0,
                            largestCoverage: 0,
                            largestArea: 0,
                            secondLargestArea: 0,
                            medianArea: 0,
                            areaUniformity: 0,
                            smallSegmentCount: 0,
                            smallSegmentRatio: 0,
                            hasLargeBoardLikePath: false,
                            looksLikeMissingMainShape: false
                        };
                        if (!baseBounds || !segArrays || segArrays.length === 0) return result;

                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var baseArea = Math.max(0.01, baseW * baseH);
                        var metrics = calcSegArrayMetrics(baseBounds, segArrays);
                        result.unionCoverage = metrics.unionCoverage;
                        result.totalCoverage = metrics.totalCoverage;
                        result.largestCoverage = metrics.largestCoverage;

                        var areas = [];
                        for (var sa = 0; sa < segArrays.length; sa++) {
                            var pts = parseSegPoints(segArrays[sa]);
                            if (!pts || pts.length === 0) continue;
                            var sLeft = 9999999999, sTop = -9999999999, sRight = -9999999999, sBottom = 9999999999;
                            var segFound = false;
                            for (var sp = 0; sp < pts.length; sp++) {
                                if (!pts[sp] || !pts[sp].a) continue;
                                segFound = true;
                                var ax = pts[sp].a[0], ay = pts[sp].a[1];
                                if (ax < sLeft) sLeft = ax;
                                if (ax > sRight) sRight = ax;
                                if (ay > sTop) sTop = ay;
                                if (ay < sBottom) sBottom = ay;
                            }
                            if (!segFound) continue;
                            var curW = Math.max(0, sRight - sLeft);
                            var curH = Math.max(0, sTop - sBottom);
                            var curArea = curW * curH;
                            var curCoverage = Math.min(curW / baseW, curH / baseH);
                            areas.push(curArea);
                            result.segmentCount++;
                            if (curCoverage < 0.08) result.smallSegmentCount++;
                        }

                        if (areas.length > 0) {
                            areas.sort(function(a, b) { return b - a; });
                            result.largestArea = areas[0];
                            result.secondLargestArea = areas.length > 1 ? areas[1] : 0;
                            result.medianArea = areas[Math.floor(areas.length / 2)];
                            result.areaUniformity = result.largestArea / Math.max(0.01, result.medianArea);
                        }
                        if (result.segmentCount > 0) {
                            result.smallSegmentRatio = result.smallSegmentCount / result.segmentCount;
                        }

                        if (result.segmentCount === 1 && result.largestCoverage > 0.75) {
                            result.hasLargeBoardLikePath = true;
                        } else if (result.secondLargestArea > 0 && (result.largestArea / Math.max(0.01, result.secondLargestArea)) > 8 && result.largestCoverage > 0.55) {
                            result.hasLargeBoardLikePath = true;
                        }

                        if (!result.hasLargeBoardLikePath &&
                            result.largestCoverage < 0.18 &&
                            result.unionCoverage < 0.45 &&
                            result.segmentCount > 0 &&
                            result.segmentCount < 18 &&
                            result.smallSegmentRatio >= 0.55 &&
                            result.areaUniformity > 1.8) {
                            result.looksLikeMissingMainShape = true;
                        }

                        return result;
                    };

                    var findPrimaryClipItem = function(group) {
                        if (!group || group.typename !== "GroupItem") return null;
                        try {
                            for (var i = 0; i < group.pageItems.length; i++) {
                                if (group.pageItems[i].clipping === true) return group.pageItems[i];
                            }
                            for (var j = 0; j < group.pageItems.length; j++) {
                                var child = group.pageItems[j];
                                if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0 && child.pathItems[0].clipping) {
                                    return child;
                                }
                            }
                        } catch(e) {}
                        return null;
                    };

                    var traceGroupSilhouette = function(item, bounds) {
                        var segs = [];
                        var dup = null;
                        var raster = null;
                        var traced = null;
                        var expanded = null;
                        var fillRect = null;
                        if (!item || item.typename !== "GroupItem" || !bounds) return segs;

                        try {
                            dup = item.duplicate(tempLayer, ElementPlacement.PLACEATBEGINNING);
                            dup.hidden = false;
                            dup.locked = false;

                            var clipItem = findPrimaryClipItem(dup);
                            if (!clipItem) {
                                if (dup) dup.remove();
                                return segs;
                            }

                            var toRemove = [];
                            for (var i = 0; i < dup.pageItems.length; i++) {
                                if (dup.pageItems[i] !== clipItem) toRemove.push(dup.pageItems[i]);
                            }
                            for (var r = 0; r < toRemove.length; r++) {
                                try { toRemove[r].remove(); } catch(e) {}
                            }

                            var b = bounds;
                            var left = b[0] - 2;
                            var top = b[1] + 2;
                            var width = Math.max(1, (b[2] - b[0]) + 4);
                            var height = Math.max(1, (b[1] - b[3]) + 4);

                            fillRect = doc.pathItems.rectangle(top, left, width, height);
                            fillRect.stroked = false;
                            fillRect.filled = true;
                            var black = new RGBColor();
                            black.red = 0; black.green = 0; black.blue = 0;
                            fillRect.fillColor = black;
                            fillRect.move(dup, ElementPlacement.PLACEATEND);

                            var rastOpts = new RasterizeOptions();
                            rastOpts.resolution = 300;
                            rastOpts.transparency = true;
                            rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                            rastOpts.convertSpotColors = true;
                            rastOpts.convertTextToOutlines = false;

                            raster = doc.rasterize(dup, bounds, rastOpts);
                            if (!raster) {
                                if (dup) dup.remove();
                                return segs;
                            }

                            traced = raster.trace();
                            try {
                                var tracingPresets = app.tracingPresetsList;
                                if (tracingPresets && tracingPresets.length > 0) {
                                    traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                                }
                            } catch(e) {}
                            app.redraw();

                            try {
                                expanded = traced.tracing.expandTracing();
                            } catch(e) {
                                expanded = traced;
                            }
                            app.redraw();

                            var tracedPaths = collectAllPaths(expanded);
                            var filteredPaths = [];
                            var candidates = [];
                            var baseW = Math.max(0.01, Math.abs(bounds[2] - bounds[0]));
                            var baseH = Math.max(0.01, Math.abs(bounds[1] - bounds[3]));
                            var hasInnerLarge = false;

                            for (var tp = 0; tp < tracedPaths.length; tp++) {
                                try {
                                    var pb = getTightBounds(tracedPaths[tp]);
                                    if (!pb) continue;
                                    var wRatio = Math.abs(pb[2] - pb[0]) / baseW;
                                    var hRatio = Math.abs(pb[1] - pb[3]) / baseH;
                                    var coverage = Math.min(wRatio, hRatio);
                                    candidates.push({ path: tracedPaths[tp], coverage: coverage });
                                    if (coverage >= 0.55 && coverage < 0.98) hasInnerLarge = true;
                                } catch(e) {}
                            }

                            for (var ci = 0; ci < candidates.length; ci++) {
                                if (hasInnerLarge && candidates[ci].coverage >= 0.98) continue;
                                filteredPaths.push(candidates[ci].path);
                            }

                            if (filteredPaths.length === 0) filteredPaths = tracedPaths;
                            for (var fp = 0; fp < filteredPaths.length; fp++) {
                                var p = getPts(filteredPaths[fp]);
                                if (p) segs.push(p);
                            }
                        } catch(e) {
                            segs = [];
                        }

                        try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                        try { if (traced) traced.remove(); } catch(e) {}
                        try { if (raster) raster.remove(); } catch(e) {}
                        try { if (dup) dup.remove(); } catch(e) {}
                        try { if (fillRect) fillRect.remove(); } catch(e) {}
                        return segs;
                    };

                    // --- 插入结束 ---

                    var calcLargestCoverageForItems = function(baseBounds, items) {
                        if (!baseBounds || !items || items.length === 0) return 0;
                        var best = 0;
                        for (var i = 0; i < items.length; i++) {
                            try {
                                var cov = calcLargestPathCoverage(baseBounds, items[i]);
                                if (cov > best) best = cov;
                            } catch(e) {}
                        }
                        return best;
                    };

                    var shouldUseFallbackExport = function(baseBounds, standardSegs, internalMasks) {
                        if (!standardSegs || standardSegs.length === 0) return true;
                        var segMetrics = calcSegArrayMetrics(baseBounds, standardSegs);
                        var maxMaskCoverage = calcLargestCoverageForItems(baseBounds, internalMasks);
                        if (segMetrics.totalCoverage < 0.18 && maxMaskCoverage < 0.35) return true;
                        return false;
                    };

	                    var jsonItems =[];
	                    var debugLines = [];
                    var strokeThicknessExportDetectedCount = 0;
                    var strokeThicknessSplitSuccessCount = 0;
                    var strokeThicknessFillObjectCount = 0;
	                    var strokeThicknessStrokeObjectCount = 0;
	                    var originalObjectSkippedCount = 0;
	                    var jsonHasStrokeFill = false;
			                    var jsonHasStrokeStroke = false;
			                    var finalJsonItemNames = [];
                            var usedJsonItemNames = {};
                            var strokeThicknessFillSegmentTotal = 0;
                            var strokeThicknessStrokeSegmentTotal = 0;
	                            var makeUniqueJsonItemName = function(name) {
	                                var clean = tools.cleanName(name || "Item");
	                                if (!usedJsonItemNames[clean]) {
	                                    usedJsonItemNames[clean] = 1;
	                                    return clean;
                                }
                                usedJsonItemNames[clean]++;
                                var n = usedJsonItemNames[clean];
                                var m = clean.match(/^(.*)(_d[0-9.]+(?:_t[^_]+)?)$/);
                                var candidate = m ? (m[1] + "_" + n + m[2]) : (clean + "_" + n);
                                while (usedJsonItemNames[candidate]) {
                                    n++;
                                    candidate = m ? (m[1] + "_" + n + m[2]) : (clean + "_" + n);
                                }
	                                usedJsonItemNames[candidate] = 1;
	                                return candidate;
	                            };

                                var boundsFromItems = function(items) {
                                    var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                                    var found = false;
                                    if (!items) return null;
                                    for (var bi = 0; bi < items.length; bi++) {
                                        try {
                                            var b = getTightBounds(items[bi]);
                                            if (!b) continue;
                                            found = true;
                                            left = Math.min(left, b[0]);
                                            top = Math.max(top, b[1]);
                                            right = Math.max(right, b[2]);
                                            bottom = Math.min(bottom, b[3]);
                                        } catch(e) {}
                                    }
                                    return found ? [left, top, right, bottom] : null;
                                };

                                var boundsFromSegmentTexts = function(segTexts) {
                                    var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                                    var found = false;
                                    if (!segTexts) return null;
                                    for (var bsi = 0; bsi < segTexts.length; bsi++) {
                                        try {
                                            var pts = eval("(" + segTexts[bsi] + ")");
                                            if (!pts || !pts.length) continue;
                                            for (var bp = 0; bp < pts.length; bp++) {
                                                var a = pts[bp].a || pts[bp].anchor;
                                                if (!a || a.length < 2) continue;
                                                left = Math.min(left, a[0]);
                                                right = Math.max(right, a[0]);
                                                top = Math.max(top, a[1]);
                                                bottom = Math.min(bottom, a[1]);
                                                found = true;
                                            }
                                        } catch(e) {}
                                    }
                                    return found ? [left, top, right, bottom] : null;
                                };

                                var exportStrokeFillTexture = function(source, textureBaseName, rasterBounds, textureBounds) {
                                    var result = { ok: false, fileName: "", bounds: textureBounds || rasterBounds || null, errorMessage: "" };
                                    var tempDup = null;
                                    var bakedItem = null;
                                    var exportDoc = null;
                                    var exportedItem = null;
                                    try {
                                        if (!source || !textureBaseName || !rasterBounds) {
                                            result.errorMessage = "missing_source_or_bounds";
                                            return result;
                                        }
                                        var tightW = rasterBounds[2] - rasterBounds[0];
                                        var tightH = rasterBounds[1] - rasterBounds[3];
                                        if (tightW <= 0 || tightH <= 0) {
                                            result.errorMessage = "invalid_bounds";
                                            return result;
                                        }

                                        tempDup = source.duplicate(tempLayer, ElementPlacement.PLACEATBEGINNING);
                                        tempDup.hidden = false;
                                        tempDup.locked = false;

                                        var rastOpts = new RasterizeOptions();
                                        rastOpts.resolution = dpi;
                                        rastOpts.transparency = true;
                                        rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                                        rastOpts.convertSpotColors = true;
                                        rastOpts.convertTextToOutlines = false;
                                        bakedItem = doc.rasterize(tempDup, rasterBounds, rastOpts);
                                        try { tempDup.remove(); } catch(removeDupErr) {}
                                        tempDup = null;
                                        if (!bakedItem) {
                                            result.errorMessage = "rasterize_failed";
                                            return result;
                                        }

                                        exportDoc = app.documents.add(doc.documentColorSpace);
                                        var exportLayer = exportDoc.layers[0];
                                        exportedItem = bakedItem.duplicate(exportLayer, ElementPlacement.PLACEATEND);
                                        try { bakedItem.remove(); } catch(removeBakedErr) {}
                                        bakedItem = null;

                                        exportDoc.artboards[0].artboardRect = [0, 0, tightW, -tightH];
                                        var itemCenter = [exportedItem.left + exportedItem.width / 2, exportedItem.top - exportedItem.height / 2];
                                        var boardCenter = [tightW / 2, -tightH / 2];
                                        exportedItem.translate(boardCenter[0] - itemCenter[0], boardCenter[1] - itemCenter[1]);

                                        var textureFormat = format === "jpg" ? "jpg" : "png";
                                        var exportType = textureFormat === "jpg" ? ExportType.JPEG : ExportType.PNG24;
                                        var exportScale = (dpi / 72.0) * 100.0;
                                        if (exportScale > 776.0) exportScale = 776.0;
                                        var opts;
                                        if (textureFormat === "jpg") {
                                            opts = new ExportOptionsJPEG();
                                            opts.antiAliasing = true;
                                            opts.artBoardClipping = true;
                                            opts.qualitySetting = 100;
                                            opts.horizontalScale = exportScale;
                                            opts.verticalScale = exportScale;
                                        } else {
                                            opts = new ExportOptionsPNG24();
                                            opts.antiAliasing = true;
                                            opts.transparency = true;
                                            opts.artBoardClipping = true;
                                            opts.horizontalScale = exportScale;
                                            opts.verticalScale = exportScale;
                                        }

                                        var safeBase = makeTextureOutputName(textureBaseName, "stroke_fill_texture_" + textureBaseName);
                                        var finalFile = new File(texFolder.fsName + "/" + safeBase + "." + textureFormat);
                                        var staleOtherFile = new File(texFolder.fsName + "/" + safeBase + "." + (textureFormat === "jpg" ? "png" : "jpg"));
                                        try { if (staleOtherFile.exists) staleOtherFile.remove(); } catch(removeStaleStrokeTextureErr) {}
                                        try { if (finalFile.exists) finalFile.remove(); } catch(removeOldTextureErr) {}
                                        updateExportProgress(65, "正在导出贴图 " + finalFile.name);
                                        exportDoc.exportFile(finalFile, exportType, opts);
                                        result.ok = true;
                                        result.fileName = finalFile.name;
                                        result.bounds = textureBounds || rasterBounds;
                                        exportedTextureNames.push(finalFile.name);
                                        imgCount++;
                                    } catch(e) {
                                        result.errorMessage = e.message;
                                    } finally {
                                        try { if (exportedItem) exportedItem.remove(); } catch(e0) {}
                                        try { if (exportDoc) exportDoc.close(SaveOptions.DONOTSAVECHANGES); } catch(e1) {}
                                        try { if (bakedItem) bakedItem.remove(); } catch(e2) {}
                                        try { if (tempDup) tempDup.remove(); } catch(e3) {}
                                    }
	                                    return result;
	                                };

	                                var exportSolidFillTexture = function(rgbColor, textureBaseName, drawingBounds, solidRects, textureBounds) {
	                                    var result = { ok: false, fileName: "", bounds: textureBounds || drawingBounds || null, errorMessage: "" };
                                    var exportDoc = null;
                                    try {
                                        if (!rgbColor || rgbColor.length < 3 || !textureBaseName) {
                                            result.errorMessage = "missing_solid_color_or_name";
                                            return result;
                                        }
                                        var sizePt = 512;
                                        exportDoc = app.documents.add(doc.documentColorSpace, sizePt, sizePt);
                                        var exportLayer = exportDoc.layers[0];
                                        exportDoc.artboards[0].artboardRect = [0, sizePt, sizePt, 0];
                                        var drawnCount = 0;
                                        var drawMappedRect = function(rectBounds, rectColor) {
                                            try {
	                                                if (!drawingBounds || drawingBounds.length < 4 || !rectBounds || rectBounds.length < 4) return;
	                                                var cropLeft = drawingBounds[0], cropTop = drawingBounds[1], cropRight = drawingBounds[2], cropBottom = drawingBounds[3];
                                                var cropW = cropRight - cropLeft;
                                                var cropH = cropTop - cropBottom;
                                                if (cropW <= 0 || cropH <= 0) return;
                                                var left = Math.max(rectBounds[0], cropLeft);
                                                var top = Math.min(rectBounds[1], cropTop);
                                                var right = Math.min(rectBounds[2], cropRight);
                                                var bottom = Math.max(rectBounds[3], cropBottom);
                                                if (right <= left || top <= bottom) return;
                                                var mappedLeft = ((left - cropLeft) / cropW) * sizePt;
                                                var mappedTop = sizePt - (((cropTop - top) / cropH) * sizePt);
                                                var mappedWidth = ((right - left) / cropW) * sizePt;
                                                var mappedHeight = ((top - bottom) / cropH) * sizePt;
                                                if (mappedWidth <= 0 || mappedHeight <= 0) return;
                                                var r = exportLayer.pathItems.rectangle(mappedTop, mappedLeft, mappedWidth, mappedHeight);
                                                r.stroked = false;
                                                r.filled = true;
                                                r.fillColor = makeRgb(rectColor[0], rectColor[1], rectColor[2]);
                                                drawnCount++;
                                            } catch(drawErr) {}
                                        };
                                        if (solidRects && solidRects.length) {
                                            for (var sr = 0; sr < solidRects.length; sr++) {
                                                drawMappedRect(solidRects[sr].bounds, solidRects[sr].color);
                                            }
                                        }
                                        if (drawnCount <= 0) {
	                                            drawMappedRect(drawingBounds, rgbColor);
                                        }

	                                        var textureFormat = format === "jpg" ? "jpg" : "png";
	                                        var exportType = textureFormat === "jpg" ? ExportType.JPEG : ExportType.PNG24;
	                                        var opts;
	                                        if (textureFormat === "jpg") {
	                                            opts = new ExportOptionsJPEG();
	                                            opts.antiAliasing = true;
	                                            opts.artBoardClipping = true;
	                                            opts.qualitySetting = 100;
	                                            opts.horizontalScale = 100;
	                                            opts.verticalScale = 100;
	                                        } else {
	                                            opts = new ExportOptionsPNG24();
	                                            opts.antiAliasing = true;
	                                            opts.transparency = true;
	                                            opts.artBoardClipping = true;
	                                            opts.horizontalScale = 100;
	                                            opts.verticalScale = 100;
	                                        }

	                                        var safeBase = makeTextureOutputName(textureBaseName, "solid_fill_texture_" + textureBaseName);
	                                        var finalFile = new File(texFolder.fsName + "/" + safeBase + "." + textureFormat);
	                                        var staleOtherFile = new File(texFolder.fsName + "/" + safeBase + "." + (textureFormat === "jpg" ? "png" : "jpg"));
	                                        try { if (staleOtherFile.exists) staleOtherFile.remove(); } catch(removeStaleSolidTextureErr) {}
	                                        try { if (finalFile.exists) finalFile.remove(); } catch(removeOldTextureErr) {}
	                                        updateExportProgress(65, "正在导出贴图 " + finalFile.name);
	                                        exportDoc.exportFile(finalFile, exportType, opts);
                                        result.ok = true;
                                        result.fileName = finalFile.name;
                                        exportedTextureNames.push(finalFile.name);
                                        imgCount++;
                                    } catch(e) {
                                        result.errorMessage = e.message;
                                    } finally {
                                        try { if (exportDoc) exportDoc.close(SaveOptions.DONOTSAVECHANGES); } catch(e1) {}
                                    }
                                    return result;
                                };

						                    var processStrokeThicknessExportItem = function(d) {
			                        if (!d || !d.source) return false;
			                        strokeThicknessExportDetectedCount++;
	                                splitStrokeFillAttemptCount++;
                                    ensureStrokeTaskIdentity(d, d.name || d.group || "StrokePart");
	                                if (d.groupMergeStrokeExport && d.mergeTargets && d.mergeTargets.length > 0) {
	                                    var groupFillDepthMm = tools.getTagD(d.name);
	                                    var groupStrokeDepthMm = d.strokeThicknessDepthMm !== null && d.strokeThicknessDepthMm !== undefined ? d.strokeThicknessDepthMm : null;
	                                    var groupStrokeDepthDefaultUsed = false;
	                                    if (groupStrokeDepthMm === null || isNaN(parseFloat(groupStrokeDepthMm)) || parseFloat(groupStrokeDepthMm) <= 0) {
	                                        groupStrokeDepthMm = DEFAULT_STROKE_THICKNESS_DEPTH_MM;
	                                        groupStrokeDepthDefaultUsed = true;
	                                    }
	                                    if (groupFillDepthMm === null || groupFillDepthMm === undefined || isNaN(parseFloat(groupFillDepthMm))) {
	                                        groupFillDepthMm = 0;
	                                    }
	                                    groupFillDepthMm = Math.round(parseFloat(groupFillDepthMm) * 100) / 100;
	                                    groupStrokeDepthMm = Math.round(parseFloat(groupStrokeDepthMm) * 100) / 100;
	                                    var groupStrokeTypeSuffix = tools.getTagT(d.name);
	                                    var groupBaseName = tools.cleanName(tools.getPureName(d.name) || d.name || "StrokeGroup");
	                                    var groupFillName = makeUniqueJsonItemName(groupBaseName + "_fill_d" + groupFillDepthMm + (groupStrokeTypeSuffix ? "_t" + groupStrokeTypeSuffix : ""));
	                                    var groupStrokeName = makeUniqueJsonItemName(groupBaseName + "_stroke_d" + groupStrokeDepthMm + (groupStrokeTypeSuffix ? "_t" + groupStrokeTypeSuffix : ""));
	                                    var mergedFillSegs = [];
	                                    var mergedStrokeSegs = [];
	                                    var mergedHasFill = false;
	                                    var mergedFillColor = getStrokeFillRgb(d.source);
	                                    var mergedStrokeColor = getStrokeStrokeRgb(d.source);
	                                    var mergedTextureRects = [];
		                                    var mergedTextureSource = findStrokeFillTextureSource(d.source);
		                                    var groupSourceStrokeAlignment = getStrokeAlignmentFromSource(d.source);
		                                    var mergedChildSuccess = 0;
                                        var mergedDuplicateStrokeSegmentsRemoved = 0;
                                        var mergedFillEchoSegmentsRemoved = 0;
                                        var mergedInnerHoleSegmentsSkippedAsDuplicate = 0;
                                        var mergedInnerHoleSegmentsActuallyAdded = 0;
                                        var mergedProtectedInnerBoundaryKept = 0;
                                        var mergedProtectedInnerBoundaryRemoved = 0;
                                        var mergedStrokeRingItems = [];
                                        var mergedStrokeRingSegmentCounts = [];
                                        var mergedStrokeRingOuterSegmentCounts = [];
                                        var mergedStrokeRingInnerSegmentCounts = [];
                                        var mergedStrokeRingProtectedInnerBoundaryCounts = [];
                                        var mergedRingSegmentsBeforeFillEchoClean = [];
                                        var mergedRingSegmentsAfterFillEchoClean = [];
	                                        var mergedRingFillEchoSegmentsRemoved = [];
	                                        var mergedRingOriginalFillSegmentsRemoved = [];
	                                        var mergedRingSegmentRoles = [];
	                                        var mergedRingSourceFillSegmentIndexes = [];
	                                        var mergedRingInnerBoundarySources = [];
	                                        var mergedRingFallbackOffsetInnerUsed = [];
	                                        var mergedRingInnerMatchesFillSegment = [];
	                                        var mergedRingInnerBoundsDiff = [];
	                                        var mergedRingFillSegmentContourRoles = [];
	                                        var mergedRingOuterBoundarySources = [];
	                                        var mergedRingOuterBoundaryDirections = [];
	                                        var mergedRingOuterBoundaryBoundsRelations = [];
	                                        var mergedRingHoleOuterBoundarySelected = [];
	                                        var mergedRingOuterBoundaryIsHoleSide = [];
	                                        var mergedRingHoleOuterBoundaryGenerated = [];
	                                        var mergedRingHoleOuterBoundaryGenerationMethods = [];
	                                        var mergedRingExtraContourCounts = [];
	                                        var mergedRingCompoundHoleContourSuppressed = [];
	                                        var mergedRingRedRegionHoleCandidateCounts = [];
	                                        var mergedRingRedRegionHoleAppliedCounts = [];
	                                        var mergedRingRedRegionHoleRejectedCounts = [];
	                                        var mergedRingRedRegionHoleRejectedReasons = [];
	                                        var mergedRingRedRegionHoleAreas = [];
	                                        var mergedRingRedRegionHoleDirectionFixed = [];
	                                        var mergedRingLooksLikeComplexGlyphBody = [];
	                                        var mergedRingCandidateMatchesAnyHoleFillSeg = [];
	                                        var mergedRingCandidateMatchesAnyOtherFillSeg = [];
	                                        var mergedRingCandidateInsideCurrentOuter = [];
	                                        var mergedRingCandidateInsideCurrentFill = [];
	                                        var mergedRingCandidateAreaRatioToOuter = [];
	                                        var mergedRingCandidateAreaRatioToFill = [];
	                                        var mergedRingRedRegionHoleApplyDecisions = [];
	                                        var mergedRingRedRegionHoleApplyReasons = [];
	                                    for (var mt = 0; mt < d.mergeTargets.length; mt++) {
	                                        var target = d.mergeTargets[mt];
	                                        try {
	                                            var childFillSource = target;
	                                            var childStrokeSource = findStrokePathForClippingGroup(childFillSource);
                                                try {
                                                    if (!(childFillSource && childFillSource.typename === "GroupItem" && childFillSource.clipped)) {
                                                        var childReadablePaths = collectStrokeReadablePaths(childFillSource);
                                                        if (childReadablePaths && childReadablePaths.length > 1) childStrokeSource = childFillSource;
                                                    }
                                                } catch(childReadableErr) {}
	                                            if (!childStrokeSource) childStrokeSource = childFillSource;
	                                            var childSolidRects = collectSolidColorRectsInsideClippingGroup(childFillSource);
	                                            for (var csr = 0; csr < childSolidRects.length; csr++) mergedTextureRects.push(childSolidRects[csr]);
	                                            var childSolidColor = detectSolidColorInsideClippingGroup(childFillSource);
	                                            var childFillColor = childSolidColor ? childSolidColor : getStrokeFillRgb(childFillSource);
	                                            var childStrokeColor = getStrokeStrokeRgb(childStrokeSource);
	                                            if (!mergedFillColor || (mergedFillColor[0] === 128 && mergedFillColor[1] === 128 && mergedFillColor[2] === 128)) mergedFillColor = childFillColor;
	                                            if (childStrokeColor) mergedStrokeColor = childStrokeColor;
	                                            var childTextureSource = findStrokeFillTextureSource(childFillSource);
	                                            var childHasTextureFill = !!childTextureSource;
	                                            var childHasFill = !!childSolidColor || hasEffectiveFillColor(childFillSource) || childHasTextureFill;
	                                            var childStrokeFillColor = makeRgb(childFillColor[0], childFillColor[1], childFillColor[2]);
	                                            var childStrokeRegionColor = makeRgb(childStrokeColor[0], childStrokeColor[1], childStrokeColor[2]);
		                                            var childSourceStrokeAlignment = getStrokeAlignmentFromSource(childStrokeSource || childFillSource);
		                                            if (!childSourceStrokeAlignment || childSourceStrokeAlignment.alignmentKnown === false || !childSourceStrokeAlignment.kind || childSourceStrokeAlignment.kind === "unknown") {
		                                                childSourceStrokeAlignment = cloneStrokeAlignmentWithGroupInheritance(childSourceStrokeAlignment, groupSourceStrokeAlignment);
		                                            }
		                                            if (!childSourceStrokeAlignment || !childSourceStrokeAlignment.kind || childSourceStrokeAlignment.kind === "unknown") childSourceStrokeAlignment = groupSourceStrokeAlignment;
		                                            var childStrokeResult = buildStrokeThicknessPreviewItems(childStrokeSource, tempLayer, childStrokeRegionColor, childStrokeFillColor, childSourceStrokeAlignment);
	                                            if (!childStrokeResult.ok) continue;
	                                            var childStrokeSegs = [];
	                                            var childInnerHoleSegs = [];
	                                            for (var cr = 0; cr < childStrokeResult.redItems.length; cr++) {
	                                                var crs = getSegsFromItem(childStrokeResult.redItems[cr]);
	                                                for (var crsj = 0; crsj < crs.length; crsj++) childStrokeSegs.push(crs[crsj]);
	                                            }
	                                            for (var cb = 0; cb < childStrokeResult.blueItems.length; cb++) {
	                                                var cbs = getSegsFromItem(childStrokeResult.blueItems[cb]);
	                                                for (var cbsj = 0; cbsj < cbs.length; cbsj++) childInnerHoleSegs.push(cbs[cbsj]);
	                                            }
	                                            var childFillBaseIndex = mergedFillSegs.length;
		                                            if (childHasFill) {
		                                                mergedHasFill = true;
		                                                for (var mf = 0; mf < childInnerHoleSegs.length; mf++) mergedFillSegs.push(childInnerHoleSegs[mf]);
		                                            }
                                                var childProtectedInnerBoundarySegs = reverseSegmentList(childInnerHoleSegs);
                                                if (childInnerHoleSegs.length > 0) {
                                                    var childAppendStats = appendMissingReversedSegments(childStrokeSegs, childInnerHoleSegs, 0.75);
                                                    mergedInnerHoleSegmentsActuallyAdded += childAppendStats.added;
                                                    mergedInnerHoleSegmentsSkippedAsDuplicate += childAppendStats.skippedDuplicate;
                                                }
                                                var childCleanStats = cleanStrokeSegmentsForExport(childStrokeSegs, childInnerHoleSegs, {
                                                    tolerance: 0.75,
                                                    protectedInnerBoundarySegs: childProtectedInnerBoundarySegs
                                                });
                                                childStrokeSegs = childCleanStats.segments;
                                                mergedDuplicateStrokeSegmentsRemoved += childCleanStats.duplicateStrokeSegmentsRemoved;
                                                mergedFillEchoSegmentsRemoved += childCleanStats.fillEchoSegmentsRemoved;
                                                mergedProtectedInnerBoundaryKept += childCleanStats.protectedInnerBoundaryKept;
                                                mergedProtectedInnerBoundaryRemoved += childCleanStats.protectedInnerBoundaryRemoved;
	                                            for (var ms = 0; ms < childStrokeSegs.length; ms++) mergedStrokeSegs.push(childStrokeSegs[ms]);
		                                                var childRingParts = childStrokeResult.strokeRingParts || [];
		                                                var childMergedFillRoles = classifyFillSegmentRoles(mergedFillSegs, 0.75);
		                                                if (childStrokeResult.alignment === "inside") {
		                                                    correctInsideHoleFillSegsForRingParts(mergedFillSegs, childMergedFillRoles, childRingParts, childFillBaseIndex, 0.75);
		                                                    childMergedFillRoles = classifyFillSegmentRoles(mergedFillSegs, 0.75);
		                                                }
	                                                for (var childRingIdx = 0; childRingIdx < childRingParts.length; childRingIdx++) {
                                                    try {
                                                        var childRingPart = childRingParts[childRingIdx];
                                                        var childRingOuterSegs = [];
                                                        var childRingInnerSegs = [];
                                                        for (var cri = 0; cri < childRingPart.redItems.length; cri++) {
                                                            var childRrs = getSegsFromItem(childRingPart.redItems[cri]);
                                                            for (var childRrsj = 0; childRrsj < childRrs.length; childRrsj++) childRingOuterSegs.push(childRrs[childRrsj]);
                                                        }
                                                        for (var cbi = 0; cbi < childRingPart.blueItems.length; cbi++) {
                                                            var childRbs = getSegsFromItem(childRingPart.blueItems[cbi]);
                                                            for (var childRbsj = 0; childRbsj < childRbs.length; childRbsj++) childRingInnerSegs.push(childRbs[childRbsj]);
                                                        }
	                                                        if (childRingOuterSegs.length <= 0) continue;
	                                                        var childSourceFillSegmentIndex = childFillBaseIndex + (typeof childRingPart.sourceFillSegmentIndex === "number" ? childRingPart.sourceFillSegmentIndex : childRingIdx);
		                                                        var childRingBuildStats = buildStrokeRingSegmentsFromOuterAndFill(childRingOuterSegs, mergedFillSegs, childMergedFillRoles, childSourceFillSegmentIndex, childRingInnerSegs, 0.75, childRingPart.alignmentMode, childRingPart.originalSegs, childRingPart.strokeAlignmentRaw, childRingPart.sourceStrokeAlignmentResolved, childRingPart.ringStrokeAlignmentResolved, childRingPart.alignmentInheritedFromSource, childRingPart.alignmentFallbackUsed, childRingPart.alignmentFallbackReason, childRingPart.debugSourceObjectId || "", childRingPart.debugLocalFillSegmentIndex, childSourceFillSegmentIndex);
	                                                        var childRingSegs = childRingBuildStats.segments;
	                                                        mergedFillEchoSegmentsRemoved += childRingBuildStats.fillOriginalSegmentsRemoved;
	                                                        if (childRingSegs.length <= 0) continue;
                                                        var mergedRingIndex = mergedStrokeRingItems.length + 1;
                                                        var mergedRingName = makeUniqueJsonItemName(groupStrokeName + "_ring_" + mergedRingIndex);
                                                        mergedStrokeRingItems.push({
	                                                            name: mergedRingName,
	                                                            index: mergedRingIndex,
	                                                            sourceFillSegmentIndex: childRingBuildStats.sourceFillSegmentIndex,
	                                                            fillSegmentUsedAsInner: childRingBuildStats.fillSegmentUsedAsInner,
	                                                            innerBoundarySource: childRingBuildStats.innerBoundarySource,
	                                                            offsetInnerIgnored: childRingBuildStats.offsetInnerSegmentsIgnored,
	                                                            fallbackOffsetInnerUsed: childRingBuildStats.fallbackOffsetInnerUsed,
	                                                            ringInnerMatchesFillSegment: childRingBuildStats.ringInnerMatchesFillSegment,
	                                                            ringInnerBoundsDiff: childRingBuildStats.ringInnerBoundsDiff,
	                                                            fillSegmentContourRole: childRingBuildStats.fillSegmentContourRole,
	                                                            outerBoundarySource: childRingBuildStats.outerBoundarySource,
	                                                            outerBoundaryDirection: childRingBuildStats.outerBoundaryDirection,
	                                                            outerBoundaryBoundsRelation: childRingBuildStats.outerBoundaryBoundsRelation,
	                                                            holeOuterBoundarySelected: childRingBuildStats.holeOuterBoundarySelected,
	                                                            outerBoundaryIsHoleSide: childRingBuildStats.outerBoundaryIsHoleSide,
	                                                            holeOuterBoundaryGenerated: childRingBuildStats.holeOuterBoundaryGenerated,
	                                                            holeOuterBoundaryGenerationMethod: childRingBuildStats.holeOuterBoundaryGenerationMethod,
	                                                            extraContourCount: childRingBuildStats.extraContourCount,
	                                                            compoundHoleContourSuppressed: childRingBuildStats.compoundHoleContourSuppressed,
	                                                            redRegionHoleCandidateCount: childRingBuildStats.redRegionHoleCandidateCount,
	                                                            redRegionHoleAppliedCount: childRingBuildStats.redRegionHoleAppliedCount,
	                                                            redRegionHoleRejectedCount: childRingBuildStats.redRegionHoleRejectedCount,
	                                                            redRegionHoleRejectedReasons: childRingBuildStats.redRegionHoleRejectedReasons,
	                                                            redRegionHoleArea: childRingBuildStats.redRegionHoleArea,
	                                                            redRegionHoleDirectionFixed: childRingBuildStats.redRegionHoleDirectionFixed,
	                                                            ringLooksLikeComplexGlyphBody: childRingBuildStats.ringLooksLikeComplexGlyphBody,
	                                                            candidateMatchesAnyHoleFillSeg: childRingBuildStats.candidateMatchesAnyHoleFillSeg,
	                                                            candidateMatchesAnyOtherFillSeg: childRingBuildStats.candidateMatchesAnyOtherFillSeg,
	                                                            candidateInsideCurrentOuter: childRingBuildStats.candidateInsideCurrentOuter,
	                                                            candidateInsideCurrentFill: childRingBuildStats.candidateInsideCurrentFill,
		                                                            candidateAreaRatioToOuter: childRingBuildStats.candidateAreaRatioToOuter,
		                                                            candidateAreaRatioToFill: childRingBuildStats.candidateAreaRatioToFill,
		                                                            redRegionHoleApplyDecision: childRingBuildStats.redRegionHoleApplyDecision,
		                                                            redRegionHoleApplyReason: childRingBuildStats.redRegionHoleApplyReason,
		                                                            strokeAlignmentRaw: childRingBuildStats.strokeAlignmentRaw,
		                                                            strokeAlignmentResolved: childRingBuildStats.strokeAlignmentResolved,
		                                                            sourceStrokeAlignmentResolved: childRingBuildStats.sourceStrokeAlignmentResolved,
		                                                            ringStrokeAlignmentResolved: childRingBuildStats.ringStrokeAlignmentResolved,
	                                                            alignmentInheritedFromSource: childRingBuildStats.alignmentInheritedFromSource,
	                                                            alignmentFallbackUsed: childRingBuildStats.alignmentFallbackUsed,
	                                                            alignmentFallbackReason: childRingBuildStats.alignmentFallbackReason,
	                                                            alignmentSourceType: childRingPart.alignmentSourceType || "",
	                                                            alignmentSourceItemName: childRingPart.alignmentSourceItemName || "",
	                                                            alignmentSourceTypename: childRingPart.alignmentSourceTypename || "",
	                                                            alignmentSourcePathCount: childRingPart.alignmentSourcePathCount || 0,
	                                                            alignmentCandidateCount: childRingPart.alignmentCandidateCount || 0,
	                                                            alignmentKnown: childRingPart.alignmentKnown !== false,
	                                                            alignmentUnknownCandidateCount: childRingPart.alignmentUnknownCandidateCount || 0,
	                                                            alignmentKnownCandidateCount: childRingPart.alignmentKnownCandidateCount || childRingPart.alignmentCandidateCount || 0,
	                                                            alignmentCandidateResolvedValues: childRingPart.alignmentCandidateResolvedValues || "",
	                                                            alignmentCandidateRawValues: childRingPart.alignmentCandidateRawValues || "",
	                                                            alignmentResolvedFromChildPath: !!childRingPart.alignmentResolvedFromChildPath,
	                                                            alignmentResolvedFromGroupChildren: !!childRingPart.alignmentResolvedFromGroupChildren,
	                                                            alignmentInheritedFromGroup: !!childRingPart.alignmentInheritedFromGroup,
	                                                            alignmentGroupResolvedValue: childRingPart.alignmentGroupResolvedValue || "",
	                                                            alignmentGroupKnownCandidateCount: childRingPart.alignmentGroupKnownCandidateCount || 0,
	                                                            alignmentGroupUnknownCandidateCount: childRingPart.alignmentGroupUnknownCandidateCount || 0,
	                                                            alignmentFinalDecisionReason: childRingPart.alignmentFinalDecisionReason || "",
	                                                            debugTaskSourceAlignment: childRingPart.debugTaskSourceAlignment || "",
	                                                            debugTaskSourceAlignmentKnown: childRingPart.debugTaskSourceAlignmentKnown !== false,
	                                                            debugTaskSourceAlignmentReason: childRingPart.debugTaskSourceAlignmentReason || "",
	                                                            debugOriginalSourceObjectId: childRingPart.debugOriginalSourceObjectId || "",
	                                                            debugAlignmentInheritedFromTask: !!childRingPart.debugAlignmentInheritedFromTask,
	                                                            debugAlignmentInheritedFromSourceObject: !!childRingPart.debugAlignmentInheritedFromSourceObject,
	                                                            debugSourceObjectAlignmentCacheHit: !!childRingPart.debugSourceObjectAlignmentCacheHit,
	                                                            alignmentFallbackScope: childRingPart.alignmentFallbackScope || "",
	                                                            alignmentMode: childRingBuildStats.alignmentMode,
		                                                            fillBoundarySource: childRingBuildStats.fillBoundarySource,
		                                                            strokeOuterBoundarySource: childRingBuildStats.strokeOuterBoundarySource,
		                                                            strokeInnerBoundarySource: childRingBuildStats.strokeInnerBoundarySource,
		                                                            insideFillInsetApplied: childRingBuildStats.insideFillInsetApplied,
		                                                            insideStrokeUsesOriginalAsOuter: childRingBuildStats.insideStrokeUsesOriginalAsOuter,
		                                                            insideStrokeUsesInnerOffsetAsInner: childRingBuildStats.insideStrokeUsesInnerOffsetAsInner,
		                                                            insideOverlapPreventionApplied: childRingBuildStats.insideOverlapPreventionApplied,
		                                                            insideHoleOffsetDirection: childRingBuildStats.insideHoleOffsetDirection,
		                                                            insideHoleFillExpandsHole: childRingBuildStats.insideHoleFillExpandsHole,
	                                                            insideHoleBoundsRelation: childRingBuildStats.insideHoleBoundsRelation,
	                                                            insideHoleOffsetCorrected: childRingBuildStats.insideHoleOffsetCorrected,
	                                                            insideHoleOriginalBounds: childRingBuildStats.insideHoleOriginalBounds,
	                                                            insideHoleFillBounds: childRingBuildStats.insideHoleFillBounds,
	                                                            debugSourceObjectId: childRingBuildStats.debugSourceObjectId,
	                                                            debugLocalFillSegmentIndex: childRingBuildStats.debugLocalFillSegmentIndex,
	                                                            debugGlobalFillSegmentIndex: childRingBuildStats.debugGlobalFillSegmentIndex,
	                                                            debugRingUsesLocalInnerSeg: childRingBuildStats.debugRingUsesLocalInnerSeg,
	                                                            debugRingInnerFallbackUsed: childRingBuildStats.debugRingInnerFallbackUsed,
	                                                            debugRingInnerFallbackReason: childRingBuildStats.debugRingInnerFallbackReason,
	                                                            debugInnerSegSourceObjectId: childRingBuildStats.debugInnerSegSourceObjectId,
	                                                            debugFillSegSourceObjectId: childRingBuildStats.debugFillSegSourceObjectId,
	                                                            debugOriginalSegBounds: childRingBuildStats.debugOriginalSegBounds,
	                                                            debugInnerOffsetSegBounds: childRingBuildStats.debugInnerOffsetSegBounds,
	                                                            debugFillSegBounds: childRingBuildStats.debugFillSegBounds,
	                                                            debugRingInnerBounds: childRingBuildStats.debugRingInnerBounds,
	                                                            segments: childRingSegs
	                                                        });
                                                        mergedStrokeRingSegmentCounts.push(String(childRingSegs.length));
                                                        mergedStrokeRingOuterSegmentCounts.push(String(childRingOuterSegs.length));
                                                        mergedStrokeRingInnerSegmentCounts.push(String(childRingInnerSegs.length));
                                                        mergedStrokeRingProtectedInnerBoundaryCounts.push(String(childRingBuildStats.fillOriginalSegmentsFound));
                                                        mergedRingSegmentsBeforeFillEchoClean.push(String(childRingBuildStats.before));
                                                        mergedRingSegmentsAfterFillEchoClean.push(String(childRingBuildStats.after));
                                                        mergedRingFillEchoSegmentsRemoved.push(String(childRingBuildStats.fillOriginalSegmentsRemoved));
	                                                        mergedRingOriginalFillSegmentsRemoved.push(String(childRingBuildStats.fillOriginalSegmentsRemoved));
	                                                        mergedRingSegmentRoles.push(childRingBuildStats.roles);
	                                                        mergedRingSourceFillSegmentIndexes.push(String(childRingBuildStats.sourceFillSegmentIndex));
	                                                        mergedRingInnerBoundarySources.push(String(childRingBuildStats.innerBoundarySource));
	                                                        mergedRingFallbackOffsetInnerUsed.push(String(childRingBuildStats.fallbackOffsetInnerUsed));
	                                                        mergedRingInnerMatchesFillSegment.push(String(childRingBuildStats.ringInnerMatchesFillSegment));
	                                                        mergedRingInnerBoundsDiff.push(String(Math.round(childRingBuildStats.ringInnerBoundsDiff * 1000) / 1000));
	                                                        mergedRingFillSegmentContourRoles.push(String(childRingBuildStats.fillSegmentContourRole));
	                                                        mergedRingOuterBoundarySources.push(String(childRingBuildStats.outerBoundarySource));
	                                                        mergedRingOuterBoundaryDirections.push(String(childRingBuildStats.outerBoundaryDirection));
	                                                        mergedRingOuterBoundaryBoundsRelations.push(String(childRingBuildStats.outerBoundaryBoundsRelation));
	                                                        mergedRingHoleOuterBoundarySelected.push(String(childRingBuildStats.holeOuterBoundarySelected));
	                                                        mergedRingOuterBoundaryIsHoleSide.push(String(childRingBuildStats.outerBoundaryIsHoleSide));
	                                                        mergedRingHoleOuterBoundaryGenerated.push(String(childRingBuildStats.holeOuterBoundaryGenerated));
	                                                        mergedRingHoleOuterBoundaryGenerationMethods.push(String(childRingBuildStats.holeOuterBoundaryGenerationMethod));
	                                                        mergedRingExtraContourCounts.push(String(childRingBuildStats.extraContourCount));
	                                                        mergedRingCompoundHoleContourSuppressed.push(String(childRingBuildStats.compoundHoleContourSuppressed));
	                                                        mergedRingRedRegionHoleCandidateCounts.push(String(childRingBuildStats.redRegionHoleCandidateCount));
	                                                        mergedRingRedRegionHoleAppliedCounts.push(String(childRingBuildStats.redRegionHoleAppliedCount));
	                                                        mergedRingRedRegionHoleRejectedCounts.push(String(childRingBuildStats.redRegionHoleRejectedCount));
	                                                        mergedRingRedRegionHoleRejectedReasons.push(String(childRingBuildStats.redRegionHoleRejectedReasons));
	                                                        mergedRingRedRegionHoleAreas.push(String(childRingBuildStats.redRegionHoleArea));
	                                                        mergedRingRedRegionHoleDirectionFixed.push(String(childRingBuildStats.redRegionHoleDirectionFixed));
	                                                        mergedRingLooksLikeComplexGlyphBody.push(String(childRingBuildStats.ringLooksLikeComplexGlyphBody));
	                                                        mergedRingCandidateMatchesAnyHoleFillSeg.push(String(childRingBuildStats.candidateMatchesAnyHoleFillSeg));
	                                                        mergedRingCandidateMatchesAnyOtherFillSeg.push(String(childRingBuildStats.candidateMatchesAnyOtherFillSeg));
	                                                        mergedRingCandidateInsideCurrentOuter.push(String(childRingBuildStats.candidateInsideCurrentOuter));
	                                                        mergedRingCandidateInsideCurrentFill.push(String(childRingBuildStats.candidateInsideCurrentFill));
	                                                        mergedRingCandidateAreaRatioToOuter.push(String(childRingBuildStats.candidateAreaRatioToOuter));
	                                                        mergedRingCandidateAreaRatioToFill.push(String(childRingBuildStats.candidateAreaRatioToFill));
	                                                        mergedRingRedRegionHoleApplyDecisions.push(String(childRingBuildStats.redRegionHoleApplyDecision));
	                                                        mergedRingRedRegionHoleApplyReasons.push(String(childRingBuildStats.redRegionHoleApplyReason));
	                                                    } catch(childRingBuildErr) {}
	                                                }
	                                            mergedChildSuccess++;
	                                        } catch(mergeTargetErr) {}
	                                    }
                                        var mergedProtectedInnerBoundarySegs = reverseSegmentList(mergedFillSegs);
                                        var mergedCleanStats = cleanStrokeSegmentsForExport(mergedStrokeSegs, mergedFillSegs, {
                                            tolerance: 0.75,
                                            protectedInnerBoundarySegs: mergedProtectedInnerBoundarySegs
                                        });
                                        mergedStrokeSegs = mergedCleanStats.segments;
                                        mergedDuplicateStrokeSegmentsRemoved += mergedCleanStats.duplicateStrokeSegmentsRemoved;
                                        mergedFillEchoSegmentsRemoved += mergedCleanStats.fillEchoSegmentsRemoved;
                                        mergedProtectedInnerBoundaryKept += mergedCleanStats.protectedInnerBoundaryKept;
                                        mergedProtectedInnerBoundaryRemoved += mergedCleanStats.protectedInnerBoundaryRemoved;
	                                    if ((mergedStrokeRingItems.length > 0 || mergedStrokeSegs.length > 0) && (mergedHasFill ? mergedFillSegs.length > 0 : true)) {
	                                        var groupFillTextureResult = { ok: false, fileName: "", bounds: null, errorMessage: "" };
	                                        var groupFillGeometryBounds = boundsFromSegmentTexts(mergedFillSegs) || getTightBounds(d.source);
	                                        var groupTextureDrawingBounds = getTightBounds(d.source) || groupFillGeometryBounds;
	                                        if (mergedHasFill) {
	                                            if (mergedTextureSource && mergedFillSegs.length > 0) {
	                                                groupFillTextureResult = exportStrokeFillTexture(mergedTextureSource, groupFillName, groupTextureDrawingBounds, groupFillGeometryBounds);
	                                            } else if (mergedTextureRects.length > 0 && mergedFillSegs.length > 0) {
	                                                groupFillTextureResult = exportSolidFillTexture(mergedFillColor, groupFillName, groupTextureDrawingBounds, mergedTextureRects, groupFillGeometryBounds);
	                                            }
	                                        }
	                                        strokeThicknessSplitSuccessCount++;
	                                        originalObjectSkippedCount += Math.max(1, d.mergeTargets.length);
	                                        if (mergedHasFill) {
	                                            strokeThicknessFillObjectCount++;
	                                            strokeThicknessFillSegmentTotal += mergedFillSegs.length;
	                                            var groupFillTextureFields = "";
	                                            if (groupFillTextureResult.ok) {
	                                                groupFillTextureFields += ',"texture":"'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"textureFile":"'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"textureFileName":"'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"texturePath":"tex/'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"textureRelPath":"tex/'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"image":"'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"imageFile":"'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"imagePath":"tex/'+groupFillTextureResult.fileName+'"';
	                                                groupFillTextureFields += ',"textureBounds":[' + [
	                                                    Math.round(groupFillTextureResult.bounds[0]*100)/100,
	                                                    Math.round(groupFillTextureResult.bounds[1]*100)/100,
	                                                    Math.round(groupFillTextureResult.bounds[2]*100)/100,
	                                                    Math.round(groupFillTextureResult.bounds[3]*100)/100
	                                                ].join(",") + ']';
	                                                groupFillTextureFields += ',"material":{"type":"texture","texture":"'+groupFillTextureResult.fileName+'","texturePath":"tex/'+groupFillTextureResult.fileName+'"}';
	                                                groupFillTextureFields += ',"materialType":"texture","textureEnabled":true,"isTexture":true,"textureMode":"standard"';
	                                            }
	                                            jsonItems.push(appendCraftFieldsToJsonItem(
	                                                '{"name":"'+groupFillName+'","group":"'+d.group+'","color":{"r":'+mergedFillColor[0]+',"g":'+mergedFillColor[1]+',"b":'+mergedFillColor[2]+'}' +
	                                                ',"depthMm":'+groupFillDepthMm+
                                                    buildIdentityJsonFields(d.identityMeta, "fill", groupFillDepthMm, null, mergedFillColor, null)+
	                                                ',"hasTexture":'+(groupFillTextureResult.ok ? "true" : "false")+
	                                                groupFillTextureFields+
	                                                ',"segments":[' + mergedFillSegs.join(",") + '],"closed":true}'
                                            , d.source));
	                                            finalJsonItemNames.push(groupFillName);
	                                            strokeSplitFillObjectNames.push(groupFillName);
	                                        }
                                            var groupUsedStrokeRingItems = mergedStrokeRingItems.length > 0;
                                            if (groupUsedStrokeRingItems) {
                                                for (var mergedRingOutIdx = 0; mergedRingOutIdx < mergedStrokeRingItems.length; mergedRingOutIdx++) {
                                                    var mergedRingItem = mergedStrokeRingItems[mergedRingOutIdx];
                                                    strokeThicknessStrokeSegmentTotal += mergedRingItem.segments.length;
                                                    strokeThicknessStrokeObjectCount++;
	                                                    jsonItems.push(appendCraftFieldsToJsonItem(
		                                                        '{"name":"'+mergedRingItem.name+'","group":"'+d.group+'/'+groupStrokeName+'","color":{"r":'+mergedStrokeColor[0]+',"g":'+mergedStrokeColor[1]+',"b":'+mergedStrokeColor[2]+'}' +
	                                                        ',"depthMm":'+groupStrokeDepthMm+
	                                                        buildStrokeRingIdentityJsonFields(d.identityMeta, mergedRingItem.index, null, groupStrokeDepthMm, null, mergedStrokeColor)+
	                                                        ',"sourceFillSegmentIndex":'+mergedRingItem.sourceFillSegmentIndex+
	                                                        ',"fillSegmentUsedAsInner":'+(mergedRingItem.fillSegmentUsedAsInner ? "true" : "false")+
	                                                        ',"innerBoundarySource":"'+safeDebugText(mergedRingItem.innerBoundarySource)+'"'+
	                                                        ',"offsetInnerIgnored":'+mergedRingItem.offsetInnerIgnored+
	                                                        ',"fallbackOffsetInnerUsed":'+(mergedRingItem.fallbackOffsetInnerUsed ? "true" : "false")+
	                                                        ',"ringInnerMatchesFillSegment":'+(mergedRingItem.ringInnerMatchesFillSegment ? "true" : "false")+
	                                                        ',"ringInnerBoundsDiff":'+(Math.round(mergedRingItem.ringInnerBoundsDiff * 1000) / 1000)+
	                                                        ',"fillSegmentContourRole":"'+safeDebugText(mergedRingItem.fillSegmentContourRole)+'"'+
	                                                        ',"outerBoundarySource":"'+safeDebugText(mergedRingItem.outerBoundarySource)+'"'+
	                                                        ',"outerBoundaryDirection":"'+safeDebugText(mergedRingItem.outerBoundaryDirection)+'"'+
	                                                        ',"outerBoundaryBoundsRelation":"'+safeDebugText(mergedRingItem.outerBoundaryBoundsRelation)+'"'+
	                                                        ',"holeOuterBoundarySelected":'+(mergedRingItem.holeOuterBoundarySelected ? "true" : "false")+
	                                                        ',"outerBoundaryIsHoleSide":'+(mergedRingItem.outerBoundaryIsHoleSide ? "true" : "false")+
	                                                        ',"holeOuterBoundaryGenerated":'+(mergedRingItem.holeOuterBoundaryGenerated ? "true" : "false")+
	                                                        ',"holeOuterBoundaryGenerationMethod":"'+safeDebugText(mergedRingItem.holeOuterBoundaryGenerationMethod)+'"'+
	                                                        ',"ringSegmentCount":'+mergedRingItem.segments.length+
	                                                        ',"outerSegmentCount":'+Math.max(0, mergedRingItem.segments.length - 1)+
	                                                        ',"innerSegmentCount":1'+
	                                                        ',"extraContourCount":'+mergedRingItem.extraContourCount+
	                                                        ',"compoundHoleContourSuppressed":'+mergedRingItem.compoundHoleContourSuppressed+
	                                                        ',"compoundHoleContourApplied":'+mergedRingItem.redRegionHoleAppliedCount+
	                                                        ',"redRegionHoleCandidateCount":'+mergedRingItem.redRegionHoleCandidateCount+
	                                                        ',"redRegionHoleAppliedCount":'+mergedRingItem.redRegionHoleAppliedCount+
	                                                        ',"redRegionHoleRejectedCount":'+mergedRingItem.redRegionHoleRejectedCount+
	                                                        ',"redRegionHoleRejectedReasons":"'+safeDebugText(mergedRingItem.redRegionHoleRejectedReasons)+'"'+
	                                                        ',"redRegionHoleArea":"'+safeDebugText(mergedRingItem.redRegionHoleArea)+'"'+
	                                                        ',"redRegionHoleDirectionFixed":'+mergedRingItem.redRegionHoleDirectionFixed+
	                                                        ',"ringLooksLikeComplexGlyphBody":'+(mergedRingItem.ringLooksLikeComplexGlyphBody ? "true" : "false")+
	                                                        ',"candidateMatchesAnyHoleFillSeg":'+(mergedRingItem.candidateMatchesAnyHoleFillSeg ? "true" : "false")+
	                                                        ',"candidateMatchesAnyOtherFillSeg":'+(mergedRingItem.candidateMatchesAnyOtherFillSeg ? "true" : "false")+
	                                                        ',"candidateInsideCurrentOuter":'+(mergedRingItem.candidateInsideCurrentOuter ? "true" : "false")+
	                                                        ',"candidateInsideCurrentFill":'+(mergedRingItem.candidateInsideCurrentFill ? "true" : "false")+
	                                                        ',"candidateAreaRatioToOuter":"'+safeDebugText(mergedRingItem.candidateAreaRatioToOuter)+'"'+
		                                                ',"candidateAreaRatioToFill":"'+safeDebugText(mergedRingItem.candidateAreaRatioToFill)+'"'+
		                                                ',"redRegionHoleApplyDecision":"'+safeDebugText(mergedRingItem.redRegionHoleApplyDecision)+'"'+
		                                                ',"redRegionHoleApplyReason":"'+safeDebugText(mergedRingItem.redRegionHoleApplyReason)+'"'+
		                                                ',"strokeAlignmentRaw":"'+safeDebugText(mergedRingItem.strokeAlignmentRaw)+'"'+
		                                                ',"strokeAlignmentResolved":"'+safeDebugText(mergedRingItem.strokeAlignmentResolved)+'"'+
		                                                ',"sourceStrokeAlignmentResolved":"'+safeDebugText(mergedRingItem.sourceStrokeAlignmentResolved)+'"'+
		                                                ',"ringStrokeAlignmentResolved":"'+safeDebugText(mergedRingItem.ringStrokeAlignmentResolved)+'"'+
		                                                ',"alignmentInheritedFromSource":'+(mergedRingItem.alignmentInheritedFromSource ? "true" : "false")+
		                                                ',"alignmentFallbackUsed":'+(mergedRingItem.alignmentFallbackUsed ? "true" : "false")+
		                                                ',"alignmentFallbackReason":"'+safeDebugText(mergedRingItem.alignmentFallbackReason)+'"'+
		                                                ',"alignmentSourceType":"'+safeDebugText(mergedRingItem.alignmentSourceType)+'"'+
		                                                ',"alignmentSourceItemName":"'+safeDebugText(mergedRingItem.alignmentSourceItemName)+'"'+
		                                                ',"alignmentSourceTypename":"'+safeDebugText(mergedRingItem.alignmentSourceTypename)+'"'+
		                                                ',"alignmentSourcePathCount":'+mergedRingItem.alignmentSourcePathCount+
		                                                ',"alignmentCandidateCount":'+mergedRingItem.alignmentCandidateCount+
		                                                ',"alignmentKnown":'+(mergedRingItem.alignmentKnown ? "true" : "false")+
		                                                ',"alignmentUnknownCandidateCount":'+mergedRingItem.alignmentUnknownCandidateCount+
		                                                ',"alignmentKnownCandidateCount":'+mergedRingItem.alignmentKnownCandidateCount+
		                                                ',"alignmentCandidateResolvedValues":"'+safeDebugText(mergedRingItem.alignmentCandidateResolvedValues)+'"'+
		                                                ',"alignmentCandidateRawValues":"'+safeDebugText(mergedRingItem.alignmentCandidateRawValues)+'"'+
		                                                ',"alignmentResolvedFromChildPath":'+(mergedRingItem.alignmentResolvedFromChildPath ? "true" : "false")+
		                                                ',"alignmentResolvedFromGroupChildren":'+(mergedRingItem.alignmentResolvedFromGroupChildren ? "true" : "false")+
		                                                ',"alignmentInheritedFromGroup":'+(mergedRingItem.alignmentInheritedFromGroup ? "true" : "false")+
		                                                ',"alignmentGroupResolvedValue":"'+safeDebugText(mergedRingItem.alignmentGroupResolvedValue)+'"'+
		                                                ',"alignmentGroupKnownCandidateCount":'+mergedRingItem.alignmentGroupKnownCandidateCount+
		                                                ',"alignmentGroupUnknownCandidateCount":'+mergedRingItem.alignmentGroupUnknownCandidateCount+
		                                                ',"alignmentFinalDecisionReason":"'+safeDebugText(mergedRingItem.alignmentFinalDecisionReason)+'"'+
		                                                ',"debugTaskSourceAlignment":"'+safeDebugText(mergedRingItem.debugTaskSourceAlignment)+'"'+
		                                                ',"debugTaskSourceAlignmentKnown":'+(mergedRingItem.debugTaskSourceAlignmentKnown ? "true" : "false")+
		                                                ',"debugTaskSourceAlignmentReason":"'+safeDebugText(mergedRingItem.debugTaskSourceAlignmentReason)+'"'+
		                                                ',"debugOriginalSourceObjectId":"'+safeDebugText(mergedRingItem.debugOriginalSourceObjectId)+'"'+
		                                                ',"debugAlignmentInheritedFromTask":'+(mergedRingItem.debugAlignmentInheritedFromTask ? "true" : "false")+
		                                                ',"debugAlignmentInheritedFromSourceObject":'+(mergedRingItem.debugAlignmentInheritedFromSourceObject ? "true" : "false")+
		                                                ',"debugSourceObjectAlignmentCacheHit":'+(mergedRingItem.debugSourceObjectAlignmentCacheHit ? "true" : "false")+
		                                                ',"alignmentFallbackScope":"'+safeDebugText(mergedRingItem.alignmentFallbackScope)+'"'+
		                                                ',"alignmentMode":"'+safeDebugText(mergedRingItem.alignmentMode)+'"'+
		                                                ',"fillBoundarySource":"'+safeDebugText(mergedRingItem.fillBoundarySource)+'"'+
		                                                ',"strokeOuterBoundarySource":"'+safeDebugText(mergedRingItem.strokeOuterBoundarySource)+'"'+
		                                                ',"strokeInnerBoundarySource":"'+safeDebugText(mergedRingItem.strokeInnerBoundarySource)+'"'+
		                                                ',"insideFillInsetApplied":'+(mergedRingItem.insideFillInsetApplied ? "true" : "false")+
		                                                ',"insideStrokeUsesOriginalAsOuter":'+(mergedRingItem.insideStrokeUsesOriginalAsOuter ? "true" : "false")+
		                                                ',"insideStrokeUsesInnerOffsetAsInner":'+(mergedRingItem.insideStrokeUsesInnerOffsetAsInner ? "true" : "false")+
		                                                ',"insideOverlapPreventionApplied":'+(mergedRingItem.insideOverlapPreventionApplied ? "true" : "false")+
		                                                ',"insideHoleOffsetDirection":"'+safeDebugText(mergedRingItem.insideHoleOffsetDirection)+'"'+
		                                                ',"insideHoleFillExpandsHole":'+(mergedRingItem.insideHoleFillExpandsHole ? "true" : "false")+
		                                                ',"insideHoleBoundsRelation":"'+safeDebugText(mergedRingItem.insideHoleBoundsRelation)+'"'+
		                                                ',"insideHoleOffsetCorrected":'+(mergedRingItem.insideHoleOffsetCorrected ? "true" : "false")+
		                                                ',"insideHoleOriginalBounds":"'+safeDebugText(mergedRingItem.insideHoleOriginalBounds)+'"'+
		                                                ',"insideHoleFillBounds":"'+safeDebugText(mergedRingItem.insideHoleFillBounds)+'"'+
		                                                ',"debugSourceObjectId":"'+safeDebugText(mergedRingItem.debugSourceObjectId)+'"'+
		                                                ',"debugLocalFillSegmentIndex":'+mergedRingItem.debugLocalFillSegmentIndex+
		                                                ',"debugGlobalFillSegmentIndex":'+mergedRingItem.debugGlobalFillSegmentIndex+
		                                                ',"debugRingUsesLocalInnerSeg":'+(mergedRingItem.debugRingUsesLocalInnerSeg ? "true" : "false")+
		                                                ',"debugRingInnerFallbackUsed":'+(mergedRingItem.debugRingInnerFallbackUsed ? "true" : "false")+
		                                                ',"debugRingInnerFallbackReason":"'+safeDebugText(mergedRingItem.debugRingInnerFallbackReason)+'"'+
		                                                ',"debugInnerSegSourceObjectId":"'+safeDebugText(mergedRingItem.debugInnerSegSourceObjectId)+'"'+
		                                                ',"debugFillSegSourceObjectId":"'+safeDebugText(mergedRingItem.debugFillSegSourceObjectId)+'"'+
		                                                ',"debugOriginalSegBounds":"'+safeDebugText(mergedRingItem.debugOriginalSegBounds)+'"'+
		                                                ',"debugInnerOffsetSegBounds":"'+safeDebugText(mergedRingItem.debugInnerOffsetSegBounds)+'"'+
		                                                ',"debugFillSegBounds":"'+safeDebugText(mergedRingItem.debugFillSegBounds)+'"'+
		                                                ',"debugRingInnerBounds":"'+safeDebugText(mergedRingItem.debugRingInnerBounds)+'"'+
		                                                ',"hasTexture":false,"segments":[' + mergedRingItem.segments.join(",") + '],"closed":true}'
	                                                , d.source));
                                                    finalJsonItemNames.push(mergedRingItem.name);
                                                    strokeSplitStrokeObjectNames.push(mergedRingItem.name);
                                                }
                                            } else {
	                                            strokeThicknessStrokeSegmentTotal += mergedStrokeSegs.length;
	                                            strokeThicknessStrokeObjectCount++;
	                                            jsonItems.push(appendCraftFieldsToJsonItem(
	                                                '{"name":"'+groupStrokeName+'","group":"'+d.group+'","color":{"r":'+mergedStrokeColor[0]+',"g":'+mergedStrokeColor[1]+',"b":'+mergedStrokeColor[2]+'}' +
	                                                ',"depthMm":'+groupStrokeDepthMm+
                                                    buildIdentityJsonFields(d.identityMeta, "stroke", null, groupStrokeDepthMm, null, mergedStrokeColor)+
	                                                ',"hasTexture":false,"segments":[' + mergedStrokeSegs.join(",") + '],"closed":true}'
                                            , d.source));
	                                            finalJsonItemNames.push(groupStrokeName);
	                                            strokeSplitStrokeObjectNames.push(groupStrokeName);
                                            }
	                                        debugLines.push(
	                                            "name=" + d.name +
	                                            " | group=" + d.group +
	                                            " | strokeThicknessExport=true" +
	                                            " | groupMergeStrokeExport=true" +
	                                            " | mergeTargetCount=" + d.mergeTargets.length +
	                                            " | mergeChildSuccess=" + mergedChildSuccess +
	                                            " | fillName=" + groupFillName +
	                                            " | strokeName=" + groupStrokeName +
	                                            " | sourceHasFill=" + mergedHasFill +
	                                            " | fillTextureExported=" + groupFillTextureResult.ok +
	                                            " | fillTextureFile=" + groupFillTextureResult.fileName +
	                                            " | fillTextureError=" + safeDebugText(groupFillTextureResult.errorMessage) +
	                                            " | fillDepthMm=" + groupFillDepthMm +
	                                            " | strokeDepthMm=" + groupStrokeDepthMm +
	                                            " | strokeDepthDefaultUsed=" + groupStrokeDepthDefaultUsed +
	                                            " | strokeSegmentCount=" + mergedStrokeSegs.length +
	                                            " | fillSegmentCount=" + mergedFillSegs.length +
                                                " | groupUsedStrokeRingItems=" + groupUsedStrokeRingItems +
                                                " | strokeRingCount=" + mergedStrokeRingItems.length +
                                                " | strokeRingItemsCreated=" + mergedStrokeRingItems.length +
                                                " | strokeRingSegmentCounts=" + mergedStrokeRingSegmentCounts.join(",") +
                                                " | strokeRingOuterSegmentCounts=" + mergedStrokeRingOuterSegmentCounts.join(",") +
                                                " | strokeRingInnerSegmentCounts=" + mergedStrokeRingInnerSegmentCounts.join(",") +
                                                " | strokeRingProtectedInnerBoundaryCounts=" + mergedStrokeRingProtectedInnerBoundaryCounts.join(",") +
                                                " | ringSegmentsBeforeFillEchoClean=" + mergedRingSegmentsBeforeFillEchoClean.join(",") +
                                                " | ringSegmentsAfterFillEchoClean=" + mergedRingSegmentsAfterFillEchoClean.join(",") +
	                                                " | ringFillEchoSegmentsRemoved=" + mergedRingFillEchoSegmentsRemoved.join(",") +
	                                                " | ringOriginalFillSegmentsRemoved=" + mergedRingOriginalFillSegmentsRemoved.join(",") +
	                                                " | ringSegmentRoles=" + mergedRingSegmentRoles.join(";") +
	                                                " | sourceFillSegmentIndex=" + mergedRingSourceFillSegmentIndexes.join(",") +
	                                                " | innerBoundarySource=" + mergedRingInnerBoundarySources.join(",") +
	                                                " | fallbackOffsetInnerUsed=" + mergedRingFallbackOffsetInnerUsed.join(",") +
	                                                " | ringInnerMatchesFillSegment=" + mergedRingInnerMatchesFillSegment.join(",") +
	                                                " | ringInnerBoundsDiff=" + mergedRingInnerBoundsDiff.join(",") +
	                                                " | fillSegmentContourRole=" + mergedRingFillSegmentContourRoles.join(",") +
	                                                " | outerBoundarySource=" + mergedRingOuterBoundarySources.join(",") +
	                                                " | outerBoundaryDirection=" + mergedRingOuterBoundaryDirections.join(",") +
	                                                " | outerBoundaryBoundsRelation=" + mergedRingOuterBoundaryBoundsRelations.join(",") +
	                                                " | holeOuterBoundarySelected=" + mergedRingHoleOuterBoundarySelected.join(",") +
	                                                " | outerBoundaryIsHoleSide=" + mergedRingOuterBoundaryIsHoleSide.join(",") +
	                                                " | holeOuterBoundaryGenerated=" + mergedRingHoleOuterBoundaryGenerated.join(",") +
	                                                " | holeOuterBoundaryGenerationMethod=" + mergedRingHoleOuterBoundaryGenerationMethods.join(",") +
	                                                " | extraContourCount=" + mergedRingExtraContourCounts.join(",") +
	                                                " | compoundHoleContourSuppressed=" + mergedRingCompoundHoleContourSuppressed.join(",") +
	                                                " | redRegionHoleCandidateCount=" + mergedRingRedRegionHoleCandidateCounts.join(",") +
	                                                " | redRegionHoleAppliedCount=" + mergedRingRedRegionHoleAppliedCounts.join(",") +
	                                                " | redRegionHoleRejectedCount=" + mergedRingRedRegionHoleRejectedCounts.join(",") +
	                                                " | redRegionHoleRejectedReasons=" + mergedRingRedRegionHoleRejectedReasons.join(",") +
	                                                " | redRegionHoleArea=" + mergedRingRedRegionHoleAreas.join(",") +
	                                                " | redRegionHoleDirectionFixed=" + mergedRingRedRegionHoleDirectionFixed.join(",") +
	                                                " | ringLooksLikeComplexGlyphBody=" + mergedRingLooksLikeComplexGlyphBody.join(",") +
	                                                " | candidateMatchesAnyHoleFillSeg=" + mergedRingCandidateMatchesAnyHoleFillSeg.join(",") +
	                                                " | candidateMatchesAnyOtherFillSeg=" + mergedRingCandidateMatchesAnyOtherFillSeg.join(",") +
	                                                " | candidateInsideCurrentOuter=" + mergedRingCandidateInsideCurrentOuter.join(",") +
	                                                " | candidateInsideCurrentFill=" + mergedRingCandidateInsideCurrentFill.join(",") +
	                                                " | candidateAreaRatioToOuter=" + mergedRingCandidateAreaRatioToOuter.join(",") +
	                                                " | candidateAreaRatioToFill=" + mergedRingCandidateAreaRatioToFill.join(",") +
	                                                " | redRegionHoleApplyDecision=" + mergedRingRedRegionHoleApplyDecisions.join(",") +
	                                                " | redRegionHoleApplyReason=" + mergedRingRedRegionHoleApplyReasons.join(",") +
	                                                " | preserveSeparateStrokeRingCount=" + mergedStrokeRingItems.length +
                                                " | duplicateStrokeSegmentsRemoved=" + mergedDuplicateStrokeSegmentsRemoved +
                                                " | fillEchoSegmentsRemoved=" + mergedFillEchoSegmentsRemoved +
                                                " | innerHoleSegmentsSkippedAsDuplicate=" + mergedInnerHoleSegmentsSkippedAsDuplicate +
                                                " | innerHoleSegmentsActuallyAdded=" + mergedInnerHoleSegmentsActuallyAdded +
                                                " | protectedInnerBoundarySegCount=" + mergedProtectedInnerBoundarySegs.length +
                                                " | protectedInnerBoundaryKept=" + mergedProtectedInnerBoundaryKept +
                                                " | protectedInnerBoundaryRemoved=" + mergedProtectedInnerBoundaryRemoved +
	                                            " | originalObjectSkipped=true" +
	                                            " | normalExportSkipped=true" +
	                                            " | finalJsonHasFill=" + mergedHasFill +
	                                            " | finalJsonHasStroke=true"
	                                        );
	                                        return true;
	                                    }
	                                    originalObjectSkippedCount++;
	                                    strokeSplitFailReasons.push(
	                                        "source=" + safeDebugText(d.name) +
	                                        " | groupMergeStrokeExport=true" +
	                                        " | mergeTargetCount=" + d.mergeTargets.length +
	                                        " | fillSegmentCount=" + mergedFillSegs.length +
	                                        " | strokeSegmentCount=" + mergedStrokeSegs.length +
	                                        " | reason=missing_merged_fill_or_stroke_segments"
	                                    );
	                                    return false;
	                                }
				                        var strokeLayer = tempLayer;
			                        var fillSource = d.refItem ? d.refItem : d.source;
			                        var strokeSource = findStrokePathForClippingGroup(fillSource);
                                    try {
                                        if (!(fillSource && fillSource.typename === "GroupItem" && fillSource.clipped)) {
                                            var readableStrokePaths = collectStrokeReadablePaths(fillSource);
                                            if (readableStrokePaths && readableStrokePaths.length > 1) strokeSource = fillSource;
                                        }
                                    } catch(readableStrokeErr) {}
			                        if (!strokeSource) strokeSource = fillSource;
			                        var strokeSegs = [];
			                        var fillSegs = [];
                                var innerHoleSegs = [];
	                        var fillDepthMm = tools.getTagD(d.name);
	                        var strokeDepthMm = d.strokeThicknessDepthMm !== null && d.strokeThicknessDepthMm !== undefined ? d.strokeThicknessDepthMm : null;
	                        var strokeDepthDefaultUsed = false;
	                        if (strokeDepthMm === null || isNaN(parseFloat(strokeDepthMm)) || parseFloat(strokeDepthMm) <= 0) {
	                            strokeDepthMm = DEFAULT_STROKE_THICKNESS_DEPTH_MM;
	                            strokeDepthDefaultUsed = true;
	                        }
	                        if (fillDepthMm === null || fillDepthMm === undefined || isNaN(parseFloat(fillDepthMm))) {
	                            fillDepthMm = 0;
	                        }
	                        fillDepthMm = Math.round(parseFloat(fillDepthMm) * 100) / 100;
	                        strokeDepthMm = Math.round(parseFloat(strokeDepthMm) * 100) / 100;
	                        var strokeTypeSuffix = tools.getTagT(d.name);
	                        var baseStrokeSplitName = tools.cleanName(tools.getPureName(d.name) || d.name || "StrokePart");
		                        var fillName = makeUniqueJsonItemName(baseStrokeSplitName + "_fill_d" + fillDepthMm + (strokeTypeSuffix ? "_t" + strokeTypeSuffix : ""));
		                        var strokeName = makeUniqueJsonItemName(baseStrokeSplitName + "_stroke_d" + strokeDepthMm + (strokeTypeSuffix ? "_t" + strokeTypeSuffix : ""));
                                var clippingSolidFillRects = collectSolidColorRectsInsideClippingGroup(fillSource);
		                            var clippingSolidFillColor = detectSolidColorInsideClippingGroup(fillSource);
			                        var fillColor = clippingSolidFillColor ? clippingSolidFillColor : getStrokeFillRgb(fillSource);
		                        var strokeColor = getStrokeStrokeRgb(strokeSource);
		                        var strokeFillColor = makeRgb(fillColor[0], fillColor[1], fillColor[2]);
		                        var strokeRegionColor = makeRgb(strokeColor[0], strokeColor[1], strokeColor[2]);
		                                    var fillTextureSource = findStrokeFillTextureSource(fillSource);
			                                var sourceHasTextureFill = !!fillTextureSource;
		                                var sourceHasFill = !!clippingSolidFillColor || hasEffectiveFillColor(fillSource) || sourceHasTextureFill;
                                var fillTextureResult = { ok: false, fileName: "", errorMessage: "" };
			                        var sourceStrokeAlignment = getStrokeAlignmentFromSource(strokeSource || fillSource);
			                        var strokeResult = buildStrokeThicknessPreviewItems(strokeSource, strokeLayer, strokeRegionColor, strokeFillColor, sourceStrokeAlignment);
                                var strokeSegsBeforeClean = 0;
                                var innerHoleSegmentsAdded = 0;
                                var innerHoleSegmentsSkippedAsDuplicate = 0;
                                var duplicateStrokeSegmentsRemoved = 0;
                                var fillEchoSegmentsRemoved = 0;
                                var protectedInnerBoundarySegs = [];
                                var protectedInnerBoundaryKept = 0;
                                var protectedInnerBoundaryRemoved = 0;
                                var strokeRingItems = [];
                                var strokeRingSegmentCounts = [];
                                var strokeRingOuterSegmentCounts = [];
                                var strokeRingInnerSegmentCounts = [];
                                var strokeRingProtectedInnerBoundaryCounts = [];
                                var ringSegmentsBeforeFillEchoClean = [];
                                var ringSegmentsAfterFillEchoClean = [];
	                                var ringFillEchoSegmentsRemoved = [];
	                                var ringOriginalFillSegmentsRemoved = [];
	                                var ringSegmentRoles = [];
	                                var ringSourceFillSegmentIndexes = [];
	                                var ringInnerBoundarySources = [];
	                                var ringFallbackOffsetInnerUsed = [];
	                                var ringInnerMatchesFillSegment = [];
	                                var ringInnerBoundsDiff = [];
	                                var ringFillSegmentContourRoles = [];
	                                var ringOuterBoundarySources = [];
	                                var ringOuterBoundaryDirections = [];
	                                var ringOuterBoundaryBoundsRelations = [];
	                                var ringHoleOuterBoundarySelected = [];
	                                var ringOuterBoundaryIsHoleSide = [];
	                                var ringHoleOuterBoundaryGenerated = [];
	                                var ringHoleOuterBoundaryGenerationMethods = [];
	                                var ringExtraContourCounts = [];
	                                var ringCompoundHoleContourSuppressed = [];
	                                var ringRedRegionHoleCandidateCounts = [];
	                                var ringRedRegionHoleAppliedCounts = [];
	                                var ringRedRegionHoleRejectedCounts = [];
	                                var ringRedRegionHoleRejectedReasons = [];
	                                var ringRedRegionHoleAreas = [];
	                                var ringRedRegionHoleDirectionFixed = [];
	                                var ringLooksLikeComplexGlyphBody = [];
	                                var ringCandidateMatchesAnyHoleFillSeg = [];
	                                var ringCandidateMatchesAnyOtherFillSeg = [];
	                                var ringCandidateInsideCurrentOuter = [];
	                                var ringCandidateInsideCurrentFill = [];
	                                var ringCandidateAreaRatioToOuter = [];
	                                var ringCandidateAreaRatioToFill = [];
	                                var ringRedRegionHoleApplyDecisions = [];
	                                var ringRedRegionHoleApplyReasons = [];
	                                var strokeRingCount = 0;
		                        if (strokeResult.ok) {
		                            renameStrokeThicknessExportItems(strokeResult.redItems, strokeName);
		                            if (sourceHasFill) renameStrokeThicknessExportItems(strokeResult.blueItems, fillName);
		                            for (var sri = 0; sri < strokeResult.redItems.length; sri++) {
		                                var rs = getSegsFromItem(strokeResult.redItems[sri]);
		                                for (var rsj = 0; rsj < rs.length; rsj++) strokeSegs.push(rs[rsj]);
		                            }
                                    for (var sbi = 0; sbi < strokeResult.blueItems.length; sbi++) {
                                        var bs = getSegsFromItem(strokeResult.blueItems[sbi]);
                                        for (var bsj = 0; bsj < bs.length; bsj++) innerHoleSegs.push(bs[bsj]);
                                    }
	                                    if (sourceHasFill) {
		                                        for (var fsi = 0; fsi < innerHoleSegs.length; fsi++) fillSegs.push(innerHoleSegs[fsi]);
	                                                var fillGeometryBounds = boundsFromSegmentTexts(fillSegs) || boundsFromItems(strokeResult.blueItems) || getTightBounds(strokeSource);
		                                                var fillTextureDrawingBounds = boundsFromItems(strokeResult.blueItems) || getTightBounds(fillSource);
			                                        if (sourceHasTextureFill && fillSegs.length > 0) {
			                                            fillTextureResult = exportStrokeFillTexture(fillTextureSource, fillName, fillTextureDrawingBounds, fillGeometryBounds);
			                                        } else if (clippingSolidFillColor && fillSegs.length > 0) {
			                                            fillTextureResult = exportSolidFillTexture(clippingSolidFillColor, fillName, fillTextureDrawingBounds, clippingSolidFillRects, fillGeometryBounds);
			                                        }
	                                    }
                                    protectedInnerBoundarySegs = reverseSegmentList(innerHoleSegs);
                                    if (innerHoleSegs.length > 0) {
                                        var appendStats = appendMissingReversedSegments(strokeSegs, innerHoleSegs, 0.75);
                                        innerHoleSegmentsAdded = appendStats.added;
                                        innerHoleSegmentsSkippedAsDuplicate = appendStats.skippedDuplicate;
                                    }
	                                    var strokeCleanStats = cleanStrokeSegmentsForExport(strokeSegs, fillSegs, {
	                                        tolerance: 0.75,
	                                        protectedInnerBoundarySegs: protectedInnerBoundarySegs
	                                    });
                                    strokeSegs = strokeCleanStats.segments;
                                    duplicateStrokeSegmentsRemoved = strokeCleanStats.duplicateStrokeSegmentsRemoved;
                                    fillEchoSegmentsRemoved = strokeCleanStats.fillEchoSegmentsRemoved;
                                    protectedInnerBoundaryKept = strokeCleanStats.protectedInnerBoundaryKept;
                                    protectedInnerBoundaryRemoved = strokeCleanStats.protectedInnerBoundaryRemoved;
	                                    var ringParts = strokeResult.strokeRingParts || [];
		                                    var fillSegmentRoles = classifyFillSegmentRoles(fillSegs, 0.75);
		                                    if (strokeResult.alignment === "inside") {
		                                        correctInsideHoleFillSegsForRingParts(fillSegs, fillSegmentRoles, ringParts, 0, 0.75);
		                                        fillSegmentRoles = classifyFillSegmentRoles(fillSegs, 0.75);
		                                    }
	                                    for (var rpIdx = 0; rpIdx < ringParts.length; rpIdx++) {
                                        try {
                                            var ringPart = ringParts[rpIdx];
                                            var ringOuterSegs = [];
                                            var ringInnerSegs = [];
                                            for (var rri = 0; rri < ringPart.redItems.length; rri++) {
                                                var rrs = getSegsFromItem(ringPart.redItems[rri]);
                                                for (var rrsj = 0; rrsj < rrs.length; rrsj++) ringOuterSegs.push(rrs[rrsj]);
                                            }
                                            for (var rbi = 0; rbi < ringPart.blueItems.length; rbi++) {
                                                var rbs = getSegsFromItem(ringPart.blueItems[rbi]);
                                                for (var rbsj = 0; rbsj < rbs.length; rbsj++) ringInnerSegs.push(rbs[rbsj]);
                                            }
	                                            if (ringOuterSegs.length <= 0) continue;
	                                            var sourceFillSegmentIndex = (typeof ringPart.sourceFillSegmentIndex === "number") ? ringPart.sourceFillSegmentIndex : rpIdx;
			                                            var ringBuildStats = buildStrokeRingSegmentsFromOuterAndFill(ringOuterSegs, fillSegs, fillSegmentRoles, sourceFillSegmentIndex, ringInnerSegs, 0.75, ringPart.alignmentMode, ringPart.originalSegs, ringPart.strokeAlignmentRaw, ringPart.sourceStrokeAlignmentResolved, ringPart.ringStrokeAlignmentResolved, ringPart.alignmentInheritedFromSource, ringPart.alignmentFallbackUsed, ringPart.alignmentFallbackReason, ringPart.debugSourceObjectId || "", ringPart.debugLocalFillSegmentIndex, sourceFillSegmentIndex);
	                                            var ringSegs = ringBuildStats.segments;
	                                            fillEchoSegmentsRemoved += ringBuildStats.fillOriginalSegmentsRemoved;
	                                            if (ringSegs.length <= 0) continue;
                                            var ringIndex = strokeRingItems.length + 1;
                                            var ringName = makeUniqueJsonItemName(strokeName + "_ring_" + ringIndex);
                                            strokeRingItems.push({
	                                                name: ringName,
	                                                index: ringIndex,
	                                                sourceFillSegmentIndex: ringBuildStats.sourceFillSegmentIndex,
	                                                fillSegmentUsedAsInner: ringBuildStats.fillSegmentUsedAsInner,
	                                                innerBoundarySource: ringBuildStats.innerBoundarySource,
	                                                offsetInnerIgnored: ringBuildStats.offsetInnerSegmentsIgnored,
	                                                fallbackOffsetInnerUsed: ringBuildStats.fallbackOffsetInnerUsed,
	                                                ringInnerMatchesFillSegment: ringBuildStats.ringInnerMatchesFillSegment,
	                                                ringInnerBoundsDiff: ringBuildStats.ringInnerBoundsDiff,
	                                                fillSegmentContourRole: ringBuildStats.fillSegmentContourRole,
	                                                outerBoundarySource: ringBuildStats.outerBoundarySource,
	                                                outerBoundaryDirection: ringBuildStats.outerBoundaryDirection,
	                                                outerBoundaryBoundsRelation: ringBuildStats.outerBoundaryBoundsRelation,
	                                                holeOuterBoundarySelected: ringBuildStats.holeOuterBoundarySelected,
	                                                outerBoundaryIsHoleSide: ringBuildStats.outerBoundaryIsHoleSide,
	                                                holeOuterBoundaryGenerated: ringBuildStats.holeOuterBoundaryGenerated,
	                                                holeOuterBoundaryGenerationMethod: ringBuildStats.holeOuterBoundaryGenerationMethod,
	                                                extraContourCount: ringBuildStats.extraContourCount,
	                                                compoundHoleContourSuppressed: ringBuildStats.compoundHoleContourSuppressed,
	                                                redRegionHoleCandidateCount: ringBuildStats.redRegionHoleCandidateCount,
	                                                redRegionHoleAppliedCount: ringBuildStats.redRegionHoleAppliedCount,
	                                                redRegionHoleRejectedCount: ringBuildStats.redRegionHoleRejectedCount,
	                                                redRegionHoleRejectedReasons: ringBuildStats.redRegionHoleRejectedReasons,
	                                                redRegionHoleArea: ringBuildStats.redRegionHoleArea,
	                                                redRegionHoleDirectionFixed: ringBuildStats.redRegionHoleDirectionFixed,
	                                                ringLooksLikeComplexGlyphBody: ringBuildStats.ringLooksLikeComplexGlyphBody,
	                                                candidateMatchesAnyHoleFillSeg: ringBuildStats.candidateMatchesAnyHoleFillSeg,
	                                                candidateMatchesAnyOtherFillSeg: ringBuildStats.candidateMatchesAnyOtherFillSeg,
	                                                candidateInsideCurrentOuter: ringBuildStats.candidateInsideCurrentOuter,
	                                                candidateInsideCurrentFill: ringBuildStats.candidateInsideCurrentFill,
		                                                candidateAreaRatioToOuter: ringBuildStats.candidateAreaRatioToOuter,
		                                                candidateAreaRatioToFill: ringBuildStats.candidateAreaRatioToFill,
		                                                redRegionHoleApplyDecision: ringBuildStats.redRegionHoleApplyDecision,
		                                                redRegionHoleApplyReason: ringBuildStats.redRegionHoleApplyReason,
		                                                strokeAlignmentRaw: ringBuildStats.strokeAlignmentRaw,
		                                                strokeAlignmentResolved: ringBuildStats.strokeAlignmentResolved,
		                                                sourceStrokeAlignmentResolved: ringBuildStats.sourceStrokeAlignmentResolved,
		                                                ringStrokeAlignmentResolved: ringBuildStats.ringStrokeAlignmentResolved,
	                                                alignmentInheritedFromSource: ringBuildStats.alignmentInheritedFromSource,
	                                                alignmentFallbackUsed: ringBuildStats.alignmentFallbackUsed,
	                                                alignmentFallbackReason: ringBuildStats.alignmentFallbackReason,
	                                                alignmentSourceType: ringPart.alignmentSourceType || "",
	                                                alignmentSourceItemName: ringPart.alignmentSourceItemName || "",
	                                                alignmentSourceTypename: ringPart.alignmentSourceTypename || "",
	                                                alignmentSourcePathCount: ringPart.alignmentSourcePathCount || 0,
	                                                alignmentCandidateCount: ringPart.alignmentCandidateCount || 0,
	                                                alignmentKnown: ringPart.alignmentKnown !== false,
	                                                alignmentUnknownCandidateCount: ringPart.alignmentUnknownCandidateCount || 0,
	                                                alignmentKnownCandidateCount: ringPart.alignmentKnownCandidateCount || ringPart.alignmentCandidateCount || 0,
	                                                alignmentCandidateResolvedValues: ringPart.alignmentCandidateResolvedValues || "",
	                                                alignmentCandidateRawValues: ringPart.alignmentCandidateRawValues || "",
	                                                alignmentResolvedFromChildPath: !!ringPart.alignmentResolvedFromChildPath,
	                                                alignmentResolvedFromGroupChildren: !!ringPart.alignmentResolvedFromGroupChildren,
	                                                alignmentInheritedFromGroup: !!ringPart.alignmentInheritedFromGroup,
	                                                alignmentGroupResolvedValue: ringPart.alignmentGroupResolvedValue || "",
	                                                alignmentGroupKnownCandidateCount: ringPart.alignmentGroupKnownCandidateCount || 0,
	                                                alignmentGroupUnknownCandidateCount: ringPart.alignmentGroupUnknownCandidateCount || 0,
	                                                alignmentFinalDecisionReason: ringPart.alignmentFinalDecisionReason || "",
	                                                debugTaskSourceAlignment: ringPart.debugTaskSourceAlignment || "",
	                                                debugTaskSourceAlignmentKnown: ringPart.debugTaskSourceAlignmentKnown !== false,
	                                                debugTaskSourceAlignmentReason: ringPart.debugTaskSourceAlignmentReason || "",
	                                                debugOriginalSourceObjectId: ringPart.debugOriginalSourceObjectId || "",
	                                                debugAlignmentInheritedFromTask: !!ringPart.debugAlignmentInheritedFromTask,
	                                                debugAlignmentInheritedFromSourceObject: !!ringPart.debugAlignmentInheritedFromSourceObject,
	                                                debugSourceObjectAlignmentCacheHit: !!ringPart.debugSourceObjectAlignmentCacheHit,
	                                                alignmentFallbackScope: ringPart.alignmentFallbackScope || "",
	                                                alignmentMode: ringBuildStats.alignmentMode,
		                                                fillBoundarySource: ringBuildStats.fillBoundarySource,
		                                                strokeOuterBoundarySource: ringBuildStats.strokeOuterBoundarySource,
		                                                strokeInnerBoundarySource: ringBuildStats.strokeInnerBoundarySource,
		                                                insideFillInsetApplied: ringBuildStats.insideFillInsetApplied,
		                                                insideStrokeUsesOriginalAsOuter: ringBuildStats.insideStrokeUsesOriginalAsOuter,
		                                                insideStrokeUsesInnerOffsetAsInner: ringBuildStats.insideStrokeUsesInnerOffsetAsInner,
		                                                insideOverlapPreventionApplied: ringBuildStats.insideOverlapPreventionApplied,
		                                                insideHoleOffsetDirection: ringBuildStats.insideHoleOffsetDirection,
		                                                insideHoleFillExpandsHole: ringBuildStats.insideHoleFillExpandsHole,
	                                                insideHoleBoundsRelation: ringBuildStats.insideHoleBoundsRelation,
	                                                insideHoleOffsetCorrected: ringBuildStats.insideHoleOffsetCorrected,
	                                                insideHoleOriginalBounds: ringBuildStats.insideHoleOriginalBounds,
	                                                insideHoleFillBounds: ringBuildStats.insideHoleFillBounds,
	                                                debugSourceObjectId: ringBuildStats.debugSourceObjectId,
	                                                debugLocalFillSegmentIndex: ringBuildStats.debugLocalFillSegmentIndex,
	                                                debugGlobalFillSegmentIndex: ringBuildStats.debugGlobalFillSegmentIndex,
	                                                debugRingUsesLocalInnerSeg: ringBuildStats.debugRingUsesLocalInnerSeg,
	                                                debugRingInnerFallbackUsed: ringBuildStats.debugRingInnerFallbackUsed,
	                                                debugRingInnerFallbackReason: ringBuildStats.debugRingInnerFallbackReason,
	                                                debugInnerSegSourceObjectId: ringBuildStats.debugInnerSegSourceObjectId,
	                                                debugFillSegSourceObjectId: ringBuildStats.debugFillSegSourceObjectId,
	                                                debugOriginalSegBounds: ringBuildStats.debugOriginalSegBounds,
	                                                debugInnerOffsetSegBounds: ringBuildStats.debugInnerOffsetSegBounds,
	                                                debugFillSegBounds: ringBuildStats.debugFillSegBounds,
	                                                debugRingInnerBounds: ringBuildStats.debugRingInnerBounds,
	                                                segments: ringSegs
	                                            });
                                            strokeRingSegmentCounts.push(String(ringSegs.length));
                                            strokeRingOuterSegmentCounts.push(String(ringOuterSegs.length));
                                            strokeRingInnerSegmentCounts.push(String(ringInnerSegs.length));
                                            strokeRingProtectedInnerBoundaryCounts.push(String(ringBuildStats.fillOriginalSegmentsFound));
                                            ringSegmentsBeforeFillEchoClean.push(String(ringBuildStats.before));
                                            ringSegmentsAfterFillEchoClean.push(String(ringBuildStats.after));
	                                            ringFillEchoSegmentsRemoved.push(String(ringBuildStats.fillOriginalSegmentsRemoved));
	                                            ringOriginalFillSegmentsRemoved.push(String(ringBuildStats.fillOriginalSegmentsRemoved));
	                                            ringSegmentRoles.push(ringBuildStats.roles);
	                                            ringSourceFillSegmentIndexes.push(String(ringBuildStats.sourceFillSegmentIndex));
	                                            ringInnerBoundarySources.push(String(ringBuildStats.innerBoundarySource));
	                                            ringFallbackOffsetInnerUsed.push(String(ringBuildStats.fallbackOffsetInnerUsed));
	                                            ringInnerMatchesFillSegment.push(String(ringBuildStats.ringInnerMatchesFillSegment));
	                                            ringInnerBoundsDiff.push(String(Math.round(ringBuildStats.ringInnerBoundsDiff * 1000) / 1000));
	                                            ringFillSegmentContourRoles.push(String(ringBuildStats.fillSegmentContourRole));
	                                            ringOuterBoundarySources.push(String(ringBuildStats.outerBoundarySource));
	                                            ringOuterBoundaryDirections.push(String(ringBuildStats.outerBoundaryDirection));
	                                            ringOuterBoundaryBoundsRelations.push(String(ringBuildStats.outerBoundaryBoundsRelation));
	                                            ringHoleOuterBoundarySelected.push(String(ringBuildStats.holeOuterBoundarySelected));
	                                            ringOuterBoundaryIsHoleSide.push(String(ringBuildStats.outerBoundaryIsHoleSide));
	                                            ringHoleOuterBoundaryGenerated.push(String(ringBuildStats.holeOuterBoundaryGenerated));
	                                            ringHoleOuterBoundaryGenerationMethods.push(String(ringBuildStats.holeOuterBoundaryGenerationMethod));
	                                            ringExtraContourCounts.push(String(ringBuildStats.extraContourCount));
	                                            ringCompoundHoleContourSuppressed.push(String(ringBuildStats.compoundHoleContourSuppressed));
	                                            ringRedRegionHoleCandidateCounts.push(String(ringBuildStats.redRegionHoleCandidateCount));
	                                            ringRedRegionHoleAppliedCounts.push(String(ringBuildStats.redRegionHoleAppliedCount));
	                                            ringRedRegionHoleRejectedCounts.push(String(ringBuildStats.redRegionHoleRejectedCount));
	                                            ringRedRegionHoleRejectedReasons.push(String(ringBuildStats.redRegionHoleRejectedReasons));
	                                            ringRedRegionHoleAreas.push(String(ringBuildStats.redRegionHoleArea));
	                                            ringRedRegionHoleDirectionFixed.push(String(ringBuildStats.redRegionHoleDirectionFixed));
	                                            ringLooksLikeComplexGlyphBody.push(String(ringBuildStats.ringLooksLikeComplexGlyphBody));
	                                            ringCandidateMatchesAnyHoleFillSeg.push(String(ringBuildStats.candidateMatchesAnyHoleFillSeg));
	                                            ringCandidateMatchesAnyOtherFillSeg.push(String(ringBuildStats.candidateMatchesAnyOtherFillSeg));
	                                            ringCandidateInsideCurrentOuter.push(String(ringBuildStats.candidateInsideCurrentOuter));
	                                            ringCandidateInsideCurrentFill.push(String(ringBuildStats.candidateInsideCurrentFill));
	                                            ringCandidateAreaRatioToOuter.push(String(ringBuildStats.candidateAreaRatioToOuter));
	                                            ringCandidateAreaRatioToFill.push(String(ringBuildStats.candidateAreaRatioToFill));
	                                            ringRedRegionHoleApplyDecisions.push(String(ringBuildStats.redRegionHoleApplyDecision));
	                                            ringRedRegionHoleApplyReasons.push(String(ringBuildStats.redRegionHoleApplyReason));
	                                        } catch(ringBuildErr) {}
	                                    }
                                    strokeRingCount = strokeRingItems.length;
		                        }
			                        if (strokeRingItems.length > 0 && (sourceHasFill ? fillSegs.length > 0 : true)) {
			                            strokeThicknessSplitSuccessCount++;
			                            originalObjectSkippedCount++;
                                    if (sourceHasFill) {
				                            strokeThicknessFillObjectCount++;
	                                        strokeThicknessFillSegmentTotal += fillSegs.length;
                                            var fillTextureFields = "";
                                            if (fillTextureResult.ok) {
                                                fillTextureFields += ',"texture":"'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"textureFile":"'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"textureFileName":"'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"texturePath":"tex/'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"textureRelPath":"tex/'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"image":"'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"imageFile":"'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"imagePath":"tex/'+fillTextureResult.fileName+'"';
                                                fillTextureFields += ',"textureBounds":[' + [
                                                    Math.round(fillTextureResult.bounds[0]*100)/100,
                                                    Math.round(fillTextureResult.bounds[1]*100)/100,
                                                    Math.round(fillTextureResult.bounds[2]*100)/100,
                                                    Math.round(fillTextureResult.bounds[3]*100)/100
                                                ].join(",") + ']';
                                                fillTextureFields += ',"material":{"type":"texture","texture":"'+fillTextureResult.fileName+'","texturePath":"tex/'+fillTextureResult.fileName+'"}';
                                                fillTextureFields += ',"materialType":"texture","textureEnabled":true,"isTexture":true,"textureMode":"standard"';
                                            }
	                                        jsonItems.push(appendCraftFieldsToJsonItem(
	 				                                    '{"name":"'+fillName+'","group":"'+d.group+'","color":{"r":'+fillColor[0]+',"g":'+fillColor[1]+',"b":'+fillColor[2]+'}' +
				                                    ',"depthMm":'+fillDepthMm+
                                                        buildIdentityJsonFields(d.identityMeta, "fill", fillDepthMm, null, fillColor, null)+
				                                    ',"hasTexture":'+(fillTextureResult.ok ? "true" : "false")+
	                                                fillTextureFields+
		                                            ',"segments":[' + fillSegs.join(",") + '],"closed":true}'
			                                , fillSource || d.source));
			                                finalJsonItemNames.push(fillName);
                                        strokeSplitFillObjectNames.push(fillName);
                                    }
                                    for (var ringOutIdx = 0; ringOutIdx < strokeRingItems.length; ringOutIdx++) {
                                        var ringItem = strokeRingItems[ringOutIdx];
	                                    strokeThicknessStrokeSegmentTotal += ringItem.segments.length;
			                            strokeThicknessStrokeObjectCount++;
				                            jsonItems.push(appendCraftFieldsToJsonItem(
						                                '{"name":"'+ringItem.name+'","group":"'+d.group+'/'+strokeName+'","color":{"r":'+strokeColor[0]+',"g":'+strokeColor[1]+',"b":'+strokeColor[2]+'}' +
			                                ',"depthMm":'+strokeDepthMm+
	                                            buildStrokeRingIdentityJsonFields(d.identityMeta, ringItem.index, null, strokeDepthMm, null, strokeColor)+
	                                            ',"sourceFillSegmentIndex":'+ringItem.sourceFillSegmentIndex+
	                                            ',"fillSegmentUsedAsInner":'+(ringItem.fillSegmentUsedAsInner ? "true" : "false")+
	                                            ',"innerBoundarySource":"'+safeDebugText(ringItem.innerBoundarySource)+'"'+
	                                            ',"offsetInnerIgnored":'+ringItem.offsetInnerIgnored+
	                                            ',"fallbackOffsetInnerUsed":'+(ringItem.fallbackOffsetInnerUsed ? "true" : "false")+
	                                            ',"ringInnerMatchesFillSegment":'+(ringItem.ringInnerMatchesFillSegment ? "true" : "false")+
	                                            ',"ringInnerBoundsDiff":'+(Math.round(ringItem.ringInnerBoundsDiff * 1000) / 1000)+
	                                            ',"fillSegmentContourRole":"'+safeDebugText(ringItem.fillSegmentContourRole)+'"'+
	                                            ',"outerBoundarySource":"'+safeDebugText(ringItem.outerBoundarySource)+'"'+
	                                            ',"outerBoundaryDirection":"'+safeDebugText(ringItem.outerBoundaryDirection)+'"'+
	                                            ',"outerBoundaryBoundsRelation":"'+safeDebugText(ringItem.outerBoundaryBoundsRelation)+'"'+
	                                            ',"holeOuterBoundarySelected":'+(ringItem.holeOuterBoundarySelected ? "true" : "false")+
	                                            ',"outerBoundaryIsHoleSide":'+(ringItem.outerBoundaryIsHoleSide ? "true" : "false")+
	                                            ',"holeOuterBoundaryGenerated":'+(ringItem.holeOuterBoundaryGenerated ? "true" : "false")+
	                                            ',"holeOuterBoundaryGenerationMethod":"'+safeDebugText(ringItem.holeOuterBoundaryGenerationMethod)+'"'+
	                                            ',"ringSegmentCount":'+ringItem.segments.length+
	                                            ',"outerSegmentCount":'+Math.max(0, ringItem.segments.length - 1)+
	                                            ',"innerSegmentCount":1'+
	                                            ',"extraContourCount":'+ringItem.extraContourCount+
	                                            ',"compoundHoleContourSuppressed":'+ringItem.compoundHoleContourSuppressed+
	                                            ',"compoundHoleContourApplied":'+ringItem.redRegionHoleAppliedCount+
	                                            ',"redRegionHoleCandidateCount":'+ringItem.redRegionHoleCandidateCount+
	                                            ',"redRegionHoleAppliedCount":'+ringItem.redRegionHoleAppliedCount+
	                                            ',"redRegionHoleRejectedCount":'+ringItem.redRegionHoleRejectedCount+
	                                            ',"redRegionHoleRejectedReasons":"'+safeDebugText(ringItem.redRegionHoleRejectedReasons)+'"'+
	                                            ',"redRegionHoleArea":"'+safeDebugText(ringItem.redRegionHoleArea)+'"'+
	                                            ',"redRegionHoleDirectionFixed":'+ringItem.redRegionHoleDirectionFixed+
	                                            ',"ringLooksLikeComplexGlyphBody":'+(ringItem.ringLooksLikeComplexGlyphBody ? "true" : "false")+
	                                            ',"candidateMatchesAnyHoleFillSeg":'+(ringItem.candidateMatchesAnyHoleFillSeg ? "true" : "false")+
	                                            ',"candidateMatchesAnyOtherFillSeg":'+(ringItem.candidateMatchesAnyOtherFillSeg ? "true" : "false")+
	                                            ',"candidateInsideCurrentOuter":'+(ringItem.candidateInsideCurrentOuter ? "true" : "false")+
	                                            ',"candidateInsideCurrentFill":'+(ringItem.candidateInsideCurrentFill ? "true" : "false")+
	                                            ',"candidateAreaRatioToOuter":"'+safeDebugText(ringItem.candidateAreaRatioToOuter)+'"'+
		                                            ',"candidateAreaRatioToFill":"'+safeDebugText(ringItem.candidateAreaRatioToFill)+'"'+
		                                            ',"redRegionHoleApplyDecision":"'+safeDebugText(ringItem.redRegionHoleApplyDecision)+'"'+
		                                            ',"redRegionHoleApplyReason":"'+safeDebugText(ringItem.redRegionHoleApplyReason)+'"'+
		                                            ',"strokeAlignmentRaw":"'+safeDebugText(ringItem.strokeAlignmentRaw)+'"'+
		                                            ',"strokeAlignmentResolved":"'+safeDebugText(ringItem.strokeAlignmentResolved)+'"'+
		                                            ',"sourceStrokeAlignmentResolved":"'+safeDebugText(ringItem.sourceStrokeAlignmentResolved)+'"'+
		                                            ',"ringStrokeAlignmentResolved":"'+safeDebugText(ringItem.ringStrokeAlignmentResolved)+'"'+
		                                            ',"alignmentInheritedFromSource":'+(ringItem.alignmentInheritedFromSource ? "true" : "false")+
		                                            ',"alignmentFallbackUsed":'+(ringItem.alignmentFallbackUsed ? "true" : "false")+
		                                            ',"alignmentFallbackReason":"'+safeDebugText(ringItem.alignmentFallbackReason)+'"'+
		                                            ',"alignmentSourceType":"'+safeDebugText(ringItem.alignmentSourceType)+'"'+
		                                            ',"alignmentSourceItemName":"'+safeDebugText(ringItem.alignmentSourceItemName)+'"'+
		                                            ',"alignmentSourceTypename":"'+safeDebugText(ringItem.alignmentSourceTypename)+'"'+
		                                            ',"alignmentSourcePathCount":'+ringItem.alignmentSourcePathCount+
		                                            ',"alignmentCandidateCount":'+ringItem.alignmentCandidateCount+
		                                            ',"alignmentKnown":'+(ringItem.alignmentKnown ? "true" : "false")+
		                                            ',"alignmentUnknownCandidateCount":'+ringItem.alignmentUnknownCandidateCount+
		                                            ',"alignmentKnownCandidateCount":'+ringItem.alignmentKnownCandidateCount+
		                                            ',"alignmentCandidateResolvedValues":"'+safeDebugText(ringItem.alignmentCandidateResolvedValues)+'"'+
		                                            ',"alignmentCandidateRawValues":"'+safeDebugText(ringItem.alignmentCandidateRawValues)+'"'+
		                                            ',"alignmentResolvedFromChildPath":'+(ringItem.alignmentResolvedFromChildPath ? "true" : "false")+
		                                            ',"alignmentResolvedFromGroupChildren":'+(ringItem.alignmentResolvedFromGroupChildren ? "true" : "false")+
		                                            ',"alignmentInheritedFromGroup":'+(ringItem.alignmentInheritedFromGroup ? "true" : "false")+
		                                            ',"alignmentGroupResolvedValue":"'+safeDebugText(ringItem.alignmentGroupResolvedValue)+'"'+
		                                            ',"alignmentGroupKnownCandidateCount":'+ringItem.alignmentGroupKnownCandidateCount+
		                                            ',"alignmentGroupUnknownCandidateCount":'+ringItem.alignmentGroupUnknownCandidateCount+
		                                            ',"alignmentFinalDecisionReason":"'+safeDebugText(ringItem.alignmentFinalDecisionReason)+'"'+
		                                            ',"debugTaskSourceAlignment":"'+safeDebugText(ringItem.debugTaskSourceAlignment)+'"'+
		                                            ',"debugTaskSourceAlignmentKnown":'+(ringItem.debugTaskSourceAlignmentKnown ? "true" : "false")+
		                                            ',"debugTaskSourceAlignmentReason":"'+safeDebugText(ringItem.debugTaskSourceAlignmentReason)+'"'+
		                                            ',"debugOriginalSourceObjectId":"'+safeDebugText(ringItem.debugOriginalSourceObjectId)+'"'+
		                                            ',"debugAlignmentInheritedFromTask":'+(ringItem.debugAlignmentInheritedFromTask ? "true" : "false")+
		                                            ',"debugAlignmentInheritedFromSourceObject":'+(ringItem.debugAlignmentInheritedFromSourceObject ? "true" : "false")+
		                                            ',"debugSourceObjectAlignmentCacheHit":'+(ringItem.debugSourceObjectAlignmentCacheHit ? "true" : "false")+
		                                            ',"alignmentFallbackScope":"'+safeDebugText(ringItem.alignmentFallbackScope)+'"'+
		                                            ',"alignmentMode":"'+safeDebugText(ringItem.alignmentMode)+'"'+
		                                            ',"fillBoundarySource":"'+safeDebugText(ringItem.fillBoundarySource)+'"'+
		                                            ',"strokeOuterBoundarySource":"'+safeDebugText(ringItem.strokeOuterBoundarySource)+'"'+
		                                            ',"strokeInnerBoundarySource":"'+safeDebugText(ringItem.strokeInnerBoundarySource)+'"'+
		                                            ',"insideFillInsetApplied":'+(ringItem.insideFillInsetApplied ? "true" : "false")+
		                                            ',"insideStrokeUsesOriginalAsOuter":'+(ringItem.insideStrokeUsesOriginalAsOuter ? "true" : "false")+
		                                            ',"insideStrokeUsesInnerOffsetAsInner":'+(ringItem.insideStrokeUsesInnerOffsetAsInner ? "true" : "false")+
		                                            ',"insideOverlapPreventionApplied":'+(ringItem.insideOverlapPreventionApplied ? "true" : "false")+
		                                            ',"insideHoleOffsetDirection":"'+safeDebugText(ringItem.insideHoleOffsetDirection)+'"'+
		                                            ',"insideHoleFillExpandsHole":'+(ringItem.insideHoleFillExpandsHole ? "true" : "false")+
		                                            ',"insideHoleBoundsRelation":"'+safeDebugText(ringItem.insideHoleBoundsRelation)+'"'+
		                                            ',"insideHoleOffsetCorrected":'+(ringItem.insideHoleOffsetCorrected ? "true" : "false")+
		                                            ',"insideHoleOriginalBounds":"'+safeDebugText(ringItem.insideHoleOriginalBounds)+'"'+
		                                            ',"insideHoleFillBounds":"'+safeDebugText(ringItem.insideHoleFillBounds)+'"'+
		                                            ',"debugSourceObjectId":"'+safeDebugText(ringItem.debugSourceObjectId)+'"'+
		                                            ',"debugLocalFillSegmentIndex":'+ringItem.debugLocalFillSegmentIndex+
		                                            ',"debugGlobalFillSegmentIndex":'+ringItem.debugGlobalFillSegmentIndex+
		                                            ',"debugRingUsesLocalInnerSeg":'+(ringItem.debugRingUsesLocalInnerSeg ? "true" : "false")+
		                                            ',"debugRingInnerFallbackUsed":'+(ringItem.debugRingInnerFallbackUsed ? "true" : "false")+
		                                            ',"debugRingInnerFallbackReason":"'+safeDebugText(ringItem.debugRingInnerFallbackReason)+'"'+
		                                            ',"debugInnerSegSourceObjectId":"'+safeDebugText(ringItem.debugInnerSegSourceObjectId)+'"'+
		                                            ',"debugFillSegSourceObjectId":"'+safeDebugText(ringItem.debugFillSegSourceObjectId)+'"'+
		                                            ',"debugOriginalSegBounds":"'+safeDebugText(ringItem.debugOriginalSegBounds)+'"'+
		                                            ',"debugInnerOffsetSegBounds":"'+safeDebugText(ringItem.debugInnerOffsetSegBounds)+'"'+
		                                            ',"debugFillSegBounds":"'+safeDebugText(ringItem.debugFillSegBounds)+'"'+
		                                            ',"debugRingInnerBounds":"'+safeDebugText(ringItem.debugRingInnerBounds)+'"'+
					                                ',"hasTexture":false,"segments":[' + ringItem.segments.join(",") + '],"closed":true}'
		                            , fillSource || strokeSource || d.source));
		                                finalJsonItemNames.push(ringItem.name);
                                        strokeSplitStrokeObjectNames.push(ringItem.name);
                                    }
	                            debugLines.push(
	                                "name=" + d.name +
	                                " | group=" + d.group +
	                                " | sourceType=" + (strokeSource ? strokeSource.typename : "None") +
	                                " | fillSourceType=" + (fillSource ? fillSource.typename : "None") +
	                                " | strokeSourceName=" + (strokeSource && strokeSource.name ? safeDebugText(strokeSource.name) : "None") +
	                                " | strokeSourceIsClippingPath=" + (strokeSource && strokeSource.clipping === true) +
	                                " | strokeThicknessExport=true" +
	                                " | directStrokeSplitTask=" + (!!d.directStrokeSplitTask) +
	                                " | splitStrokeFill=true" +
	                                " | strokeExportSource=exportFlowOriginalObject" +
	                                " | strokeAlignment=" + strokeResult.alignment +
	                                " | fillName=" + fillName +
		                                " | strokeName=" + strokeName +
		                                " | strokeRingCount=" + strokeRingCount +
		                                " | strokeRingItemsCreated=" + strokeRingItems.length +
		                                " | strokeRingSegmentCounts=" + strokeRingSegmentCounts.join(",") +
		                                " | strokeRingOuterSegmentCounts=" + strokeRingOuterSegmentCounts.join(",") +
		                                " | strokeRingInnerSegmentCounts=" + strokeRingInnerSegmentCounts.join(",") +
		                                " | strokeRingProtectedInnerBoundaryCounts=" + strokeRingProtectedInnerBoundaryCounts.join(",") +
		                                " | ringSegmentsBeforeFillEchoClean=" + ringSegmentsBeforeFillEchoClean.join(",") +
		                                " | ringSegmentsAfterFillEchoClean=" + ringSegmentsAfterFillEchoClean.join(",") +
			                                " | ringFillEchoSegmentsRemoved=" + ringFillEchoSegmentsRemoved.join(",") +
			                                " | ringOriginalFillSegmentsRemoved=" + ringOriginalFillSegmentsRemoved.join(",") +
			                                " | ringSegmentRoles=" + ringSegmentRoles.join(";") +
			                                " | sourceFillSegmentIndex=" + ringSourceFillSegmentIndexes.join(",") +
			                                " | innerBoundarySource=" + ringInnerBoundarySources.join(",") +
			                                " | fallbackOffsetInnerUsed=" + ringFallbackOffsetInnerUsed.join(",") +
			                                " | ringInnerMatchesFillSegment=" + ringInnerMatchesFillSegment.join(",") +
			                                " | ringInnerBoundsDiff=" + ringInnerBoundsDiff.join(",") +
			                                " | fillSegmentContourRole=" + ringFillSegmentContourRoles.join(",") +
			                                " | outerBoundarySource=" + ringOuterBoundarySources.join(",") +
			                                " | outerBoundaryDirection=" + ringOuterBoundaryDirections.join(",") +
			                                " | outerBoundaryBoundsRelation=" + ringOuterBoundaryBoundsRelations.join(",") +
			                                " | holeOuterBoundarySelected=" + ringHoleOuterBoundarySelected.join(",") +
			                                " | outerBoundaryIsHoleSide=" + ringOuterBoundaryIsHoleSide.join(",") +
			                                " | holeOuterBoundaryGenerated=" + ringHoleOuterBoundaryGenerated.join(",") +
			                                " | holeOuterBoundaryGenerationMethod=" + ringHoleOuterBoundaryGenerationMethods.join(",") +
			                                " | extraContourCount=" + ringExtraContourCounts.join(",") +
			                                " | compoundHoleContourSuppressed=" + ringCompoundHoleContourSuppressed.join(",") +
			                                " | redRegionHoleCandidateCount=" + ringRedRegionHoleCandidateCounts.join(",") +
			                                " | redRegionHoleAppliedCount=" + ringRedRegionHoleAppliedCounts.join(",") +
			                                " | redRegionHoleRejectedCount=" + ringRedRegionHoleRejectedCounts.join(",") +
			                                " | redRegionHoleRejectedReasons=" + ringRedRegionHoleRejectedReasons.join(",") +
			                                " | redRegionHoleArea=" + ringRedRegionHoleAreas.join(",") +
			                                " | redRegionHoleDirectionFixed=" + ringRedRegionHoleDirectionFixed.join(",") +
			                                " | ringLooksLikeComplexGlyphBody=" + ringLooksLikeComplexGlyphBody.join(",") +
			                                " | candidateMatchesAnyHoleFillSeg=" + ringCandidateMatchesAnyHoleFillSeg.join(",") +
			                                " | candidateMatchesAnyOtherFillSeg=" + ringCandidateMatchesAnyOtherFillSeg.join(",") +
			                                " | candidateInsideCurrentOuter=" + ringCandidateInsideCurrentOuter.join(",") +
			                                " | candidateInsideCurrentFill=" + ringCandidateInsideCurrentFill.join(",") +
			                                " | candidateAreaRatioToOuter=" + ringCandidateAreaRatioToOuter.join(",") +
			                                " | candidateAreaRatioToFill=" + ringCandidateAreaRatioToFill.join(",") +
			                                " | redRegionHoleApplyDecision=" + ringRedRegionHoleApplyDecisions.join(",") +
			                                " | redRegionHoleApplyReason=" + ringRedRegionHoleApplyReasons.join(",") +
			                                " | preserveSeparateStrokeRingCount=" + strokeRingItems.length +
	                                        " | sourceHasFill=" + sourceHasFill +
                                            " | clippingSolidFillColor=" + (clippingSolidFillColor ? clippingSolidFillColor.join(",") : "none") +
	                                        " | sourceHasTextureFill=" + sourceHasTextureFill +
                                        " | fillTextureSourceType=" + (fillTextureSource ? fillTextureSource.typename : "None") +
                                        " | fillTextureExported=" + fillTextureResult.ok +
                                        " | fillTextureFile=" + fillTextureResult.fileName +
                                        " | fillTextureError=" + safeDebugText(fillTextureResult.errorMessage) +
		                                " | fillDepthMm=" + fillDepthMm +
		                                " | strokeDepthMm=" + strokeDepthMm +
	                                " | strokeDepthDefaultUsed=" + strokeDepthDefaultUsed +
	                                " | strokeSegmentCount=" + strokeSegs.length +
	                                " | fillSegmentCount=" + fillSegs.length +
	                                " | strokeSegsBeforeClean=" + strokeSegsBeforeClean +
	                                " | strokeSegsAfterClean=" + strokeSegs.length +
	                                " | duplicateStrokeSegmentsRemoved=" + duplicateStrokeSegmentsRemoved +
	                                " | fillEchoSegmentsRemoved=" + fillEchoSegmentsRemoved +
	                                " | strokeReadablePathCount=" + (strokeResult.strokeReadablePathCount || 0) +
	                                " | strokeReadablePathPoints=" + safeDebugText(strokeResult.strokeReadablePathPoints || "") +
	                                " | blueInnerBoundaryPathCount=" + (strokeResult.blueInnerBoundaryPathCount || 0) +
	                                " | redItemsCount=" + (strokeResult.redItems ? strokeResult.redItems.length : 0) +
	                                " | blueItemsCount=" + (strokeResult.blueItems ? strokeResult.blueItems.length : 0) +
	                                " | redPathCount=" + (strokeResult.redPathCount || 0) +
	                                " | bluePathCount=" + (strokeResult.bluePathCount || 0) +
	                                " | innerHoleSegmentCount=" + innerHoleSegs.length +
	                                " | innerBoundarySegCount=" + innerHoleSegs.length +
	                                " | fillSegsCount=" + fillSegs.length +
	                                " | strokeOuterSegsCount=" + strokeSegsBeforeClean +
	                                " | protectedInnerBoundarySegCount=" + protectedInnerBoundarySegs.length +
	                                " | protectedInnerBoundaryKept=" + protectedInnerBoundaryKept +
	                                " | protectedInnerBoundaryRemoved=" + protectedInnerBoundaryRemoved +
	                                " | innerHoleSegmentsAdded=" + innerHoleSegmentsAdded +
	                                " | innerHoleSegmentsSkippedAsDuplicate=" + innerHoleSegmentsSkippedAsDuplicate +
	                                " | strokeOutlined=true" +
	                                " | strokeRegionSource=tempOutlinedStrokeFillObject" +
	                                " | fillRegionSource=tempFillObject" +
	                                " | tempLayer=" + (strokeLayer ? strokeLayer.name : STROKE_EXPORT_TEMP_LAYER) +
	                                " | exportUsesStrokePreviewLogic=true" +
	                                " | originalObjectSkipped=true" +
	                                " | normalExportSkipped=true" +
		                                " | finalJsonHasFill=" + sourceHasFill +
		                                " | finalJsonHasStroke=true"
		                            );
		                            return true;
		                        }
		                        originalObjectSkippedCount++;
                                strokeSplitFailReasons.push(
	                                    "source=" + safeDebugText(d.name) +
                                        " | sourceHasFill=" + sourceHasFill +
	                                    " | fillSegmentCount=" + fillSegs.length +
	                                    " | strokeSegmentCount=" + strokeSegs.length +
                                    " | reason=" + safeDebugText(strokeResult.errorMessage || "missing_fill_or_stroke_segments")
                                );
		                        debugLines.push(
	                            "name=" + d.name +
	                            " | group=" + d.group +
	                            " | sourceType=" + (strokeSource ? strokeSource.typename : "None") +
	                            " | strokeThicknessExport=true" +
	                            " | directStrokeSplitTask=" + (!!d.directStrokeSplitTask) +
	                            " | splitStrokeFill=false" +
	                            " | strokeExportSource=exportFlowOriginalObject" +
	                            " | exportUsesStrokePreviewLogic=false" +
	                            " | fallbackToNormalExport=false" +
	                            " | originalObjectSkipped=true" +
	                            " | strokeSegmentCount=" + strokeSegs.length +
	                            " | fillSegmentCount=" + fillSegs.length +
	                            " | reason=" + (strokeResult.errorMessage || "missing_fill_or_stroke_segments")
	                        );
	                        return false;
	                    };
	                    for (var stTask = 0; stTask < strokeSplitExportTasks.length; stTask++) {
	                        processStrokeThicknessExportItem(strokeSplitExportTasks[stTask]);
	                    }
	                    for (var j=0; j<scanList.length; j++) {
                        var d = scanList[j];
                        var segStr = "[]";
                        var debugMode = "none";
                        var debugCoverage = -1;
                        var largestCoverage = -1;
                        var debugSegmentCount = -1;
                        var debugSmallRatio = -1;
                        var debugAreaUniformity = -1;
                        var debugBoardLike = false;
                        var debugMissingMain = false;
                        var debugTraceSegmentCount = -1;
                        var debugUseTrace = false;
                        var debugFallbackSource = "standard";
                        var debugUsedWhiteFillPaths = false;
                        var debugExportUsesPreviewLogic = false;
                        var debugExportedRectFallback = false;
                        var debugWhitePathCount = -1;
                        var debugBlackPathCount = -1;
                        var debugPreviewLikeSegmentCount = -1;
                        var debugFallbackReverse = false;
                        var debugTargetColor = "white";

	                        if (d.strokeThicknessExport && d.source) {
	                            processStrokeThicknessExportItem(d);
	                            continue;
	                        }

                        if (d.customSegments) {
                            debugMode = "group_custom_segments";
                            segStr = "[" + d.customSegments.join(",") + "]";
                        } else if (d.forceRectPath && d.bounds) {
                            debugMode = "outer_bounds_rect";
                            segStr = makeRect(d.bounds);
                        } else if (d.source) {
		                            if (d.isMask) {
	                                var allowFallback = enableFallback || !!d.fallbackExport;
		                                var standardSource = d.maskSource ? d.maskSource : d.source;
		                                var standardSegs = getSegsFromItem(standardSource);
	                                var standardAnalysis = analyzeStandardSegments(d.bounds, standardSegs);
                                largestCoverage = standardAnalysis.largestCoverage;
                                debugCoverage = standardAnalysis.unionCoverage;
                                debugSegmentCount = standardAnalysis.segmentCount;
                                debugSmallRatio = standardAnalysis.smallSegmentRatio;
                                debugAreaUniformity = standardAnalysis.areaUniformity;
                                debugBoardLike = standardAnalysis.hasLargeBoardLikePath;
                                debugMissingMain = standardAnalysis.looksLikeMissingMainShape;

	                                var shouldTraceRepair = false;
	                                var tracedSegsCache = [];
	                                var previewLikeFallback = null;
	                                if (!!d.fallbackExport && d.refItem && d.bounds) {
	                                    debugFallbackReverse = !!d.fallbackReverse;
	                                    debugTargetColor = debugFallbackReverse ? "black" : "white";
	                                    previewLikeFallback = buildFallbackTraceSegments(d.refItem, d.bounds, tempLayer, debugTargetColor);
	                                    debugWhitePathCount = previewLikeFallback.whitePathCount;
	                                    debugBlackPathCount = previewLikeFallback.blackPathCount;
	                                    debugPreviewLikeSegmentCount = previewLikeFallback.segmentCount;
	                                    if (previewLikeFallback.ok && previewLikeFallback.segments.length > 0) {
	                                        debugFallbackSource = debugTargetColor === "black" ? "previewLikeBlackFill" : "previewLikeWhiteFill";
	                                        debugUsedWhiteFillPaths = debugTargetColor === "white";
	                                        debugExportUsesPreviewLogic = true;
	                                    }
	                                }
	                                var nestedClippedCount = 0;
                                var isVectorOnlySingleClip = false;
                                var isVectorOnlyArtClip = false;
                                if (d.refItem && d.refItem.typename === "GroupItem") {
                                    nestedClippedCount = collectChildClippedGroups(d.refItem).length;
                                }
                                if (d.refItem && d.refItem.typename === "GroupItem" &&
                                    d.exportMode === "single_clipped_group" &&
                                    nestedClippedCount === 0) {
                                    isVectorOnlySingleClip = !d.hasRasterDescendant;
                                    isVectorOnlyArtClip = isVectorOnlySingleClip && countNestedTextFrames(d.refItem) === 0;
                                    var looksSuspicious = standardAnalysis.looksLikeMissingMainShape ||
                                        (isVectorOnlySingleClip &&
                                         standardAnalysis.segmentCount > 0 &&
                                         standardAnalysis.segmentCount <= 32 &&
                                         standardAnalysis.largestCoverage < 0.30) ||
                                        (standardAnalysis.segmentCount > 0 &&
                                         standardAnalysis.segmentCount <= 12 &&
                                         standardAnalysis.largestCoverage < 0.12 &&
                                         standardAnalysis.smallSegmentRatio >= 0.7);
	                                    if (allowFallback && looksSuspicious) {
                                        tracedSegsCache = traceGroupSilhouette(d.refItem, d.bounds);
                                        if (tracedSegsCache.length > 0) {
                                            var tracedAnalysis = analyzeStandardSegments(d.bounds, tracedSegsCache);
                                            debugTraceSegmentCount = tracedAnalysis.segmentCount;
                                            if (isVectorOnlyArtClip &&
                                                tracedAnalysis.segmentCount >= Math.max(standardAnalysis.segmentCount + 2, Math.ceil(standardAnalysis.segmentCount * 1.5))) {
                                                shouldTraceRepair = true;
                                            } else if (!tracedAnalysis.hasLargeBoardLikePath) {
                                                if (standardAnalysis.looksLikeMissingMainShape) {
                                                    shouldTraceRepair = true;
                                                } else if (isVectorOnlySingleClip &&
                                                           tracedAnalysis.segmentCount >= Math.max(standardAnalysis.segmentCount + 2, Math.ceil(standardAnalysis.segmentCount * 1.25))) {
                                                    shouldTraceRepair = true;
                                                } else if (isVectorOnlySingleClip &&
                                                           tracedAnalysis.largestCoverage > standardAnalysis.largestCoverage + 0.10) {
                                                    shouldTraceRepair = true;
                                                } else if (tracedAnalysis.segmentCount >= Math.max(standardAnalysis.segmentCount + 2, Math.ceil(standardAnalysis.segmentCount * 1.5))) {
                                                    shouldTraceRepair = true;
                                                } else if (standardAnalysis.segmentCount <= 2 && tracedAnalysis.segmentCount > standardAnalysis.segmentCount) {
                                                    shouldTraceRepair = true;
                                                }
                                            }
                                        }
                                    }
                                }

	                                if (previewLikeFallback && previewLikeFallback.ok && previewLikeFallback.segments.length > 0) {
	                                    debugMode = debugTargetColor === "black" ? "group_preview_like_black_fill_fallback" : "group_preview_like_white_fill_fallback";
	                                    debugUseTrace = true;
	                                    debugTraceSegmentCount = previewLikeFallback.segmentCount;
	                                    segStr = "[" + previewLikeFallback.segments.join(",") + "]";
	                                } else if (standardSegs.length > 0 && !shouldTraceRepair) {
	                                    debugMode = "group_standard_export";
	                                    segStr = "[" + standardSegs.join(",") + "]";
	                                } else if (allowFallback && tracedSegsCache.length > 0) {
                                    debugMode = "group_clip_trace_repair";
                                    debugUseTrace = true;
                                    segStr = "[" + tracedSegsCache.join(",") + "]";
	                                } else if (allowFallback && d.refItem && d.refItem.typename === "GroupItem" && standardSegs.length === 0) {
                                    var tracedSegs = traceGroupSilhouette(d.refItem, d.bounds);
                                    if (tracedSegs.length > 0) {
                                        debugMode = "group_clip_trace_repair";
                                        debugUseTrace = true;
                                        segStr = "[" + tracedSegs.join(",") + "]";
	                                    } else {
	                                        debugMode = "group_rect_bounds_only";
	                                        debugExportedRectFallback = true;
	                                        segStr = makeRect(d.bounds);
	                                    }
	                                } else if (standardSegs.length > 0) {
	                                    debugMode = "group_standard_export_fallback";
	                                    segStr = "[" + standardSegs.join(",") + "]";
		                                } else if (allowFallback) {
	                                    debugMode = "group_rect_bounds_only";
	                                    debugExportedRectFallback = true;
	                                    segStr = makeRect(d.bounds);
                                } else {
                                    debugMode = "group_standard_empty";
                                    segStr = "[]";
                                }
                            } else {
                                debugMode = "direct_source_paths";
                                var allSegs = getSegsFromItem(d.source);
                                if (allSegs.length > 0) {
                                    segStr = "[" + allSegs.join(",") + "]";
                                }
                            }
                        } else if (d.isMask) {
                            debugMode = "rect_bounds_only";
                            segStr = makeRect(d.bounds);
                        }

                        if (segStr === "[]" || segStr === "") continue;
                        var cStr = d.color ? '{"r":'+d.color[0]+',"g":'+d.color[1]+',"b":'+d.color[2]+'}' : "null";
                        
                        // ===== 新增：精准检测当前对象有没有真的带贴图 =====
                        var textureSourceName = d.sharedTextureName ? d.sharedTextureName : d.name;
                        var textureName = d.sharedTextureOutputName || d.textureOutputName || findTextureOutputName(textureSourceName);
                        var hasTex = !!textureName;
                        if (!hasTex) {
                            for (var imgIdx=0; imgIdx < imgList.length; imgIdx++) {
                                if (imgList[imgIdx].name === textureSourceName) {
                                    textureName = imgList[imgIdx].textureOutputName || imgList[imgIdx].name;
                                    hasTex = true;
                                    break;
                                }
                            }
                        }
                        var textureFields = "";
                        if (hasTex) {
                            var textureExt = format === "jpg" ? "jpg" : "png";
                            textureFields += ',"texture":"' + textureName + "." + textureExt + '"';
                            textureFields += ',"textureFile":"' + textureName + "." + textureExt + '"';
                            textureFields += ',"textureFileName":"' + textureName + "." + textureExt + '"';
                            textureFields += ',"texturePath":"tex/' + textureName + "." + textureExt + '"';
                            textureFields += ',"textureRelPath":"tex/' + textureName + "." + textureExt + '"';
                            textureFields += ',"image":"' + textureName + "." + textureExt + '"';
                            textureFields += ',"imageFile":"' + textureName + "." + textureExt + '"';
                            textureFields += ',"imagePath":"tex/' + textureName + "." + textureExt + '"';
                            var textureBoundsSource = d.sharedTextureBounds ? d.sharedTextureBounds : d.bounds;
                            if (textureBoundsSource && textureBoundsSource.length >= 4) {
                                textureFields += ',"textureBounds":[' + [
                                    Math.round(textureBoundsSource[0]*100)/100,
                                    Math.round(-textureBoundsSource[3]*100)/100,
                                    Math.round(textureBoundsSource[2]*100)/100,
                                    Math.round(-textureBoundsSource[1]*100)/100
                                ].join(",") + ']';
                            }
                            textureFields += ',"material":{"type":"texture","texture":"' + textureName + "." + textureExt + '","texturePath":"tex/' + textureName + "." + textureExt + '"}';
                            textureFields += ',"materialType":"texture","textureEnabled":true,"isTexture":true,"textureMode":"standard"';
                        }

	                        // 把 hasTexture 的标记写入文件，通知 C4D
                            var normalDepthMm = null;
                            try { normalDepthMm = tools.getTagD(d.name); } catch(normalDepthErr) {}
                            var normalPartType = "fill";
                            try {
                                if (debugFallbackReverse || d.fallbackReverse) {
                                    normalPartType = "reverseFallback";
                                } else if (enableFallback || d.fallbackExport) {
                                    normalPartType = "fallback";
                                } else if (hasTex) {
                                    normalPartType = "texture";
                                }
                            } catch(normalPartTypeErr) {}
	                        jsonItems.push(appendCraftFieldsToJsonItem(
	                            '{"name":"'+d.name+'","group":"'+d.group+'","color":'+cStr+
                                buildIdentityJsonFields(d.identityMeta, normalPartType, normalDepthMm, null, d.color, null)+
	                            ',"hasTexture":'+hasTex+
	                            textureFields+
	                            ',"segments":'+segStr+',"closed":true}'
                        , d.refItem || d.source || d.maskSource));
                        debugLines.push(
                            "name=" + d.name +
                            " | group=" + d.group +
                            " | sourceType=" + (d.source ? d.source.typename : "None") +
                            " | maskType=" + (d.maskSource ? d.maskSource.typename : "None") +
                            " | isMask=" + d.isMask +
	                            " | fallbackExport=" + (enableFallback || !!d.fallbackExport) +
	                            " | fallbackReverse=" + debugFallbackReverse +
	                            " | targetMode=" + (debugFallbackReverse ? "reverse" : "normal") +
	                            " | targetColor=" + debugTargetColor +
	                            " | fallbackSource=" + debugFallbackSource +
	                            " | usedWhiteFillPaths=" + debugUsedWhiteFillPaths +
	                            " | whitePathCount=" + debugWhitePathCount +
	                            " | blackPathCount=" + debugBlackPathCount +
	                            " | exportSegmentCount=" + debugPreviewLikeSegmentCount +
	                            " | exportUsesPreviewLogic=" + debugExportUsesPreviewLogic +
	                            " | exportedRectFallback=" + debugExportedRectFallback +
	                            " | mode=" + debugMode +
                            " | coverage=" + debugCoverage +
                            " | largestPathCoverage=" + largestCoverage +
                            " | segmentCount=" + debugSegmentCount +
                            " | traceSegmentCount=" + debugTraceSegmentCount +
                            " | useTrace=" + debugUseTrace +
                            " | smallSegmentRatio=" + debugSmallRatio +
                            " | areaUniformity=" + debugAreaUniformity +
                            " | boardLike=" + debugBoardLike +
                            " | missingMain=" + debugMissingMain +
                            (function() {
                                try {
                                    if (!d.bounds) return " | exportBounds=None";
                                    return " | exportBounds=[" + [
                                        Math.round(d.bounds[0]*100)/100,
                                        Math.round(d.bounds[1]*100)/100,
                                        Math.round(d.bounds[2]*100)/100,
                                        Math.round(d.bounds[3]*100)/100
                                    ].join(",") + "]";
                                } catch (e) {
                                    return " | exportBounds=ERR";
                                }
                            })() +
                            (function() {
                                try {
                                    if (!d.maskSource || !d.maskSource.geometricBounds) return " | maskBounds=None";
                                    var mb = d.maskSource.geometricBounds;
                                    return " | maskBounds=[" + [
                                        Math.round(mb[0]*100)/100,
                                        Math.round(mb[1]*100)/100,
                                        Math.round(mb[2]*100)/100,
                                        Math.round(mb[3]*100)/100
                                    ].join(",") + "]";
                                } catch (e) {
                                    return " | maskBounds=ERR";
                                }
                            })() +
	                            " | hasTex=" + hasTex +
	                            " | textureName=" + textureName +
	                            " | sharedTextureName=" + (d.sharedTextureName ? d.sharedTextureName : "None") +
	                            " | segStrLen=" + segStr.length
                        );
                    }
	                    debugLines.push(
	                        "strokeThicknessExportDetectedCount=" + strokeThicknessExportDetectedCount +
	                        " | strokeThicknessSplitSuccessCount=" + strokeThicknessSplitSuccessCount +
	                        " | strokeThicknessFillObjectCount=" + strokeThicknessFillObjectCount +
	                        " | strokeThicknessStrokeObjectCount=" + strokeThicknessStrokeObjectCount +
	                        " | originalObjectSkippedCount=" + originalObjectSkippedCount +
	                        " | finalJsonHasFill=" + (jsonItems.join(",").indexOf("_fill") !== -1) +
	                        " | finalJsonHasStroke=" + (jsonItems.join(",").indexOf("_stroke") !== -1) +
	                        " | finalJsonItemNames=" + finalJsonItemNames.join(",")
	                    );
                    debugLines.push(
                        "skipExportCount=" + skipExportCount +
                        " | strokeExportPartsFoundCount=" + strokeExportPartsFoundCount +
                        " | fillObjectsFound=" + fillObjectsFoundCount +
                        " | strokeObjectsFound=" + strokeObjectsFoundCount +
                        " | finalJsonItemCount=" + jsonItems.length +
                        " | exportedItemNames=" + exportedItemNames.join(",") +
                        " | skippedItemNames=" + skippedItemNames.join(",")
                    );
                    debugLines.push("textureCount=" + imgCount);
                    if (typeof exportedTextureNames !== "undefined") {
                        for (var ti = 0; ti < exportedTextureNames.length; ti++) {
                            debugLines.push("textureFile=" + exportedTextureNames[ti]);
                        }
                    }
                    try {
                        var seenItemIds = {};
                        var seenUngroupedStrokeGroups = {};
                        var identityWarnings = [];
                        for (var idCheckIdx = 0; idCheckIdx < jsonItems.length; idCheckIdx++) {
                            var parsedItem = null;
                            try { parsedItem = JSON.parse(jsonItems[idCheckIdx]); } catch(parseIdentityErr) {}
                            if (!parsedItem) continue;
                            var parsedName = parsedItem.name || ("item_" + idCheckIdx);
                            var parsedPartType = parsedItem.partType || "";
                            var parsedObjectId = parsedItem.objectId || "";
                            var parsedItemId = parsedItem.itemId || "";
                            var parsedGroupId = parsedItem.groupId || null;
                            var parsedGroupKey = parsedItem.groupKey || "";
                            var parsedGroupPath = parsedItem.groupPath || [];
                            var parsedGroup = parsedItem.group || "";
                            if (!parsedObjectId) identityWarnings.push("missing_objectId name=" + parsedName);
                            if (!parsedItemId) identityWarnings.push("missing_itemId name=" + parsedName);
                            if (!parsedPartType) identityWarnings.push("missing_partType name=" + parsedName);
                            if (parsedItemId) {
                                if (seenItemIds[parsedItemId]) identityWarnings.push("duplicate_itemId itemId=" + parsedItemId + " names=" + seenItemIds[parsedItemId] + "," + parsedName);
                                else seenItemIds[parsedItemId] = parsedName;
                            }
                            var isUngrouped = !parsedGroupId && !parsedGroupKey && (!parsedGroupPath || parsedGroupPath.length === 0);
                            if (isUngrouped && parsedPartType === "stroke") {
                                if (parsedGroup === "StrokePart") identityWarnings.push("ungrouped_stroke_group_is_StrokePart name=" + parsedName);
                                if (parsedGroup) {
                                    if (seenUngroupedStrokeGroups[parsedGroup]) identityWarnings.push("duplicate_ungrouped_stroke_group group=" + parsedGroup + " names=" + seenUngroupedStrokeGroups[parsedGroup] + "," + parsedName);
                                    else seenUngroupedStrokeGroups[parsedGroup] = parsedName;
                                }
                            }
                        }
                        debugLines.push("identitySelfCheckWarnings=" + identityWarnings.length);
                        for (var idWarnIdx = 0; idWarnIdx < identityWarnings.length; idWarnIdx++) {
                            debugLines.push("identitySelfCheckWarning=" + identityWarnings[idWarnIdx]);
                        }
                    } catch(identitySelfCheckErr) {
                        debugLines.push("identitySelfCheckError=" + safeDebugText(identitySelfCheckErr.message));
                    }
                    try {
                        var stackSortResult = sortJsonItemsBySourceStack(jsonItems);
                        jsonItems = stackSortResult.items || jsonItems;
                        finalJsonItemNames = stackSortResult.names || finalJsonItemNames;
                        debugLines.push("sourceStackSortApplied=true");
                    } catch(stackSortErr) {
                        debugLines.push("sourceStackSortApplied=false | error=" + safeDebugText(stackSortErr.message));
                    }
                    updateExportProgress(80, "写入 JSON 文件...");
		                    var finalJson = '{"version":"v28.236","items":[' + jsonItems.join(',') + ']}';
	                    jsonHasStrokeFill = finalJson.indexOf("_fill") !== -1;
	                    jsonHasStrokeStroke = finalJson.indexOf("_stroke") !== -1;
	                    baseFile.encoding = "UTF-8"; baseFile.open("w"); baseFile.write(finalJson); baseFile.close();
	                }
                    var finalJsonHasOriginal = false;
                    for (var origDbg = 0; origDbg < originalSelectionPureNames.length; origDbg++) {
                        for (var finalDbg = 0; finalDbg < finalJsonItemNames.length; finalDbg++) {
                            if (finalJsonItemNames[finalDbg] === originalSelectionPureNames[origDbg] ||
                                finalJsonItemNames[finalDbg] === originalSelectionNames[origDbg]) {
                                finalJsonHasOriginal = true;
                            }
                        }
                    }
                    try {
                        exportDebugLines.push("");
                        exportDebugLines.push("=== Scan Debug ===");
                        for (var sdl = 0; sdl < scanDebugLines.length; sdl++) exportDebugLines.push(scanDebugLines[sdl]);
                        exportDebugLines.push("");
                        exportDebugLines.push("=== Stroke Split Summary ===");
                        exportDebugLines.push("autoMarkStrokeThicknessExport=" + (autoMarkedStrokeThicknessCount > 0));
                        exportDebugLines.push("autoMarkedStrokeThicknessCount=" + autoMarkedStrokeThicknessCount);
                        exportDebugLines.push("autoMarkedStrokeThicknessNames=" + autoMarkedStrokeThicknessNames.join(","));
                        exportDebugLines.push("totalStrokeOwnersFound=" + totalStrokeOwnersFound);
                        exportDebugLines.push("processedStrokeOwnerCount=" + processedStrokeOwnerCount);
                        exportDebugLines.push("skippedDuplicateOwnerCount=" + skippedDuplicateOwnerCount);
                        exportDebugLines.push("strokeSplitExportTasks.length=" + strokeSplitExportTasks.length);
                        exportDebugLines.push("strokeThicknessExportDetectedCount=" + strokeThicknessExportDetectedCount);
                        exportDebugLines.push("splitStrokeFillAttemptCount=" + splitStrokeFillAttemptCount);
                        exportDebugLines.push("splitStrokeFillSuccessCount=" + strokeThicknessSplitSuccessCount);
                        exportDebugLines.push("splitStrokeFillFailReason=" + (strokeSplitFailReasons.length ? strokeSplitFailReasons.join(" || ") : ""));
                        exportDebugLines.push("fillObjectName=" + strokeSplitFillObjectNames.join(","));
                        exportDebugLines.push("strokeObjectName=" + strokeSplitStrokeObjectNames.join(","));
                        exportDebugLines.push("fillDepthMm=" + (strokeSplitFillObjectNames.length ? strokeSplitFillObjectNames.join(",").replace(/.*_d([0-9.]+).*/, "$1") : ""));
                        exportDebugLines.push("strokeDepthMm=" + (strokeSplitStrokeObjectNames.length ? strokeSplitStrokeObjectNames.join(",").replace(/.*_d([0-9.]+).*/, "$1") : ""));
                        exportDebugLines.push("fillSegmentCount=" + strokeThicknessFillSegmentTotal);
                        exportDebugLines.push("strokeSegmentCount=" + strokeThicknessStrokeSegmentTotal);
                        exportDebugLines.push("originalObjectName=" + originalSelectionNames.join(","));
                        exportDebugLines.push("originalObjectSkipped=" + (originalObjectSkippedCount > 0));
                        exportDebugLines.push("originalObjectSkipReason=" + (originalObjectSkippedCount > 0 ? "strokeThicknessSplitExport" : ""));
                        exportDebugLines.push("");
                        exportDebugLines.push("=== Export Item Debug ===");
                        for (var dl = 0; dl < debugLines.length; dl++) exportDebugLines.push(debugLines[dl]);
                        exportDebugLines.push("");
                        exportDebugLines.push("=== Final JSON Summary ===");
                        exportDebugLines.push("finalJsonItemCount=" + jsonItems.length);
                        exportDebugLines.push("finalJsonItemNames=" + finalJsonItemNames.join(","));
                        exportDebugLines.push("finalJsonHasFill=" + jsonHasStrokeFill);
                        exportDebugLines.push("finalJsonHasStroke=" + jsonHasStrokeStroke);
                        exportDebugLines.push("finalJsonHasOriginal=" + finalJsonHasOriginal);
                        exportDebugLines.push("items.length=" + jsonItems.length);
                        exportDebugLines.push("items[0].name=" + (finalJsonItemNames.length > 0 ? finalJsonItemNames[0] : ""));
                        exportDebugLines.push("items[1].name=" + (finalJsonItemNames.length > 1 ? finalJsonItemNames[1] : ""));
                        if (exportDebugFile) {
                            exportDebugFile.encoding = "UTF-8";
                            exportDebugFile.open("w");
                            exportDebugFile.write(exportDebugLines.join("\n"));
                            exportDebugFile.close();
                        }
                    } catch(writeDebugErr) {
                        try { alert("写入导出 debug 文件失败: " + writeDebugErr.message); } catch(alertDebugErr) {}
                    }
	                var strokeSummary = "";
	                if (strokeThicknessExportDetectedCount > 0 || skipExportCount > 0 || strokeExportPartsFoundCount > 0) {
                    strokeSummary =
	                        "\n描边厚度导出:" +
                            "\nOwner检测: " + totalStrokeOwnersFound +
                            "\nOwner处理: " + processedStrokeOwnerCount +
                            "\n重复Owner跳过: " + skippedDuplicateOwnerCount +
	                        "\n检测: " + strokeThicknessExportDetectedCount +
                        "\n拆分成功: " + strokeThicknessSplitSuccessCount +
                        "\nfill对象: " + strokeThicknessFillObjectCount +
                        "\nstroke对象: " + strokeThicknessStrokeObjectCount +
                        "\n跳过原对象: " + originalObjectSkippedCount +
                        "\nskipExportCount: " + skipExportCount +
                        "\npartsFound: " + strokeExportPartsFoundCount +
	                        "\nfillFound: " + fillObjectsFoundCount +
	                        "\nstrokeFound: " + strokeObjectsFoundCount +
	                        "\nfinalJsonItemCount: " + jsonItems.length +
	                        "\nfinalJsonItemNames: " + finalJsonItemNames.join(", ") +
	                        "\nexportedItemNames: " + exportedItemNames.join(", ") +
                        "\nskippedItemNames: " + skippedItemNames.join(", ") +
                        "\nJSON含_fill: " + (jsonHasStrokeFill ? "true" : "false") +
	                        "\nJSON含_stroke: " + (jsonHasStrokeStroke ? "true" : "false");
	                }
                    var noStrokeSplitHint = "";
                    if (!jsonHasStrokeFill && !jsonHasStrokeStroke) {
	                        noStrokeSplitHint =
	                            "\n⚠️ 没有检测到描边厚度导出拆分。" +
	                            "\n请检查对象是否已点击“标记描边厚度导出”。" +
	                            "\n若已设置描边厚度但未标记，本版本会尝试自动补写。";
                    }
                    var debugAlertLine = exportDebugFile ? ("\ndebug：" + exportDebugFile.fsName) : "";
                    var exportElapsedMs = new Date().getTime() - exportStartedAt;
                    updateExportProgress(100, "导出完成");
                    var textureDirForMessage = "";
                    try { textureDirForMessage = new Folder(baseFile.parent.fsName + "/tex").fsName; } catch(textureDirMessageErr) {}
                    var completionMessage =
                        "JSON 路径\n" + baseFile.fsName +
                        "\n\n贴图目录\n" + (textureDirForMessage || baseFile.parent.fsName + "/tex") +
                        "\n\n导出对象：" + (typeof jsonItems !== "undefined" ? jsonItems.length : 0) +
                        "\n贴图数量：" + imgCount + " 张" +
                        "\n导出耗时：" + (Math.round((exportElapsedMs / 1000) * 10) / 10) + " 秒";
                    showExportCompleteDialog(true, "导出完成", completionMessage, baseFile.parent.fsName);
                    if (silentExport) {
                        return 'EXPORT_RESULT:{"ok":true' +
                            ',"jsonPath":"' + resultJsonEscape(baseFile.fsName) + '"' +
                            ',"exportDir":"' + resultJsonEscape(baseFile.parent.fsName) + '"' +
                            ',"itemCount":' + (typeof jsonItems !== "undefined" ? jsonItems.length : 0) +
                            ',"textureCount":' + imgCount +
                            ',"elapsedMs":' + exportElapsedMs +
                            ',"hasFill":' + (jsonHasStrokeFill ? "true" : "false") +
                            ',"hasStroke":' + (jsonHasStrokeStroke ? "true" : "false") +
                            ',"itemNames":"' + resultJsonEscape(finalJsonItemNames.join(", ")) + '"' +
                            '}';
                    }
                    closeExportProgress();
	                alert("导出完成！\nitems=" + (typeof jsonItems !== "undefined" ? jsonItems.length : 0) +
	                            "\nfill=" + (jsonHasStrokeFill ? "true" : "false") +
	                            "\nstroke=" + (jsonHasStrokeStroke ? "true" : "false") +
	                            "\n文件：" + baseFile.fsName +
	                            debugAlertLine +
	                            noStrokeSplitHint +
	                            ((typeof jsonItems !== "undefined" && jsonItems.length === 1 && !jsonHasStrokeStroke) ? "\n⚠️ 警告：本次只导出了 1 个对象。" : "") +
	                            "\n路径对象: " + scanList.length + "\n贴图文件: " + imgCount + strokeSummary + "\n(文字边界完美脱水裁切成功)");
            } catch(e) { 
                var errorMessageForProgress = "原因：" + e.message;
                try { showExportCompleteDialog(false, "导出失败", errorMessageForProgress, ""); } catch(progressErrorDialogErr) {}
                if (silentExport) {
                    var errorDir = "";
                    try { errorDir = baseFile && baseFile.parent ? baseFile.parent.fsName : ""; } catch(errorDirErr) {}
                    return 'EXPORT_RESULT:{"ok":false,"error":"' + resultJsonEscape(e.message) + '","exportDir":"' + resultJsonEscape(errorDir) + '"}';
                }
                alert("错误: " + e.message); 
            } finally { 
                updateExportProgress(90, "清理临时对象...");
                if (tempLayer) {
                    try { tempLayer.remove(); } catch(e){}
                }
                if (progressUi) closeExportProgress();
                app.userInteractionLevel = origLevel; 
            }
        }

        if (action === "cut") {
            var sides = params.sides; var r = params.radius * 2.83464567; var k = 0.5522847; var handleLen = r * k;
            var openSides = [];
            try {
                if (sides && sides.top) openSides.push("top");
                if (sides && sides.bottom) openSides.push("bottom");
                if (sides && sides.left) openSides.push("left");
                if (sides && sides.right) openSides.push("right");
            } catch(openSideErr) {}
            if (openSides.length === 0) openSides.push("top");
            var acrylicCraftParams = {
                depthCm: 0.3,
                direction: "Z+",
                deleteSides: cloneCraftValue(openSides),
                openSides: cloneCraftValue(openSides),
                shellCm: 0.3
            };
            for (var i = originalSel.length - 1; i >= 0; i--) {
                var baseObj = originalSel[i];
                var hasFill = false, fillColor = null; var hasStroke = false, strokeColor = null, strokeWidth = 1.0;
                try { if (baseObj.filled) { hasFill = true; fillColor = baseObj.fillColor; } } catch (e1) {}
                try { if (baseObj.stroked) { hasStroke = true; strokeColor = baseObj.strokeColor; strokeWidth = baseObj.strokeWidth; } } catch (e2) {}
                var b = baseObj.geometricBounds;
                var L=b[0], T=b[1], R=b[2], B=b[3]; var cx=L+(R-L)/2, cy=T-(T-B)/2;
                var points =[];
                var addPt = function(ax, ay, ix, iy, ox, oy) {
                    if (ix === undefined) ix = ax; if (iy === undefined) iy = ay;
                    if (ox === undefined) ox = ax; if (oy === undefined) oy = ay;
                    points.push({ a:[ax, ay], i: [ix, iy], o:[ox, oy] });
                };
                addPt(L, T);
                if (sides.top) { addPt(cx - r, T, cx - r, T, cx - r, T - handleLen); addPt(cx, T - r, cx - handleLen, T - r, cx + handleLen, T - r); addPt(cx + r, T, cx + r, T - handleLen, cx + r, T); }
                addPt(R, T);
                if (sides.right) { addPt(R, cy + r, R, cy + r, R - handleLen, cy + r); addPt(R - r, cy, R - r, cy + handleLen, R - r, cy - handleLen); addPt(R, cy - r, R - handleLen, cy - r, R, cy - r); }
                addPt(R, B);
                if (sides.bottom) { addPt(cx + r, B, cx + r, B, cx + r, B + handleLen); addPt(cx, B + r, cx + handleLen, B + r, cx - handleLen, B + r); addPt(cx - r, B, cx - r, B + handleLen, cx - r, B); }
                addPt(L, B);
                if (sides.left) { addPt(L, cy - r, L, cy - r, L + handleLen, cy - r); addPt(L + r, cy, L + r, cy - handleLen, L + r, cy + handleLen); addPt(L, cy + r, L + handleLen, cy + r, L, cy + r); }
                var parent = baseObj.parent;
                var newPath = parent.pathItems.add();
                for (var pIndex = 0; pIndex < points.length; pIndex++) {
                    var p = newPath.pathPoints.add(); p.anchor = points[pIndex].a; p.leftDirection = points[pIndex].i; p.rightDirection = points[pIndex].o;
                }
                newPath.closed = true;
                if (hasFill) { newPath.filled = true; newPath.fillColor = fillColor; }
                if (hasStroke) { newPath.stroked = true; newPath.strokeColor = strokeColor; newPath.strokeWidth = strokeWidth; }
                try { newPath.name = baseObj.name || newPath.name; } catch(cutNameErr) {}
                try { newPath.note = baseObj.note || ""; } catch(cutNoteErr) {}
                setCraftMarker(newPath, "acrylic_slot", acrylicCraftParams);
                newPath.selected = true; baseObj.remove();
            }
            try { restoreSelection(doc.selection); } catch(cutRestoreErr) {}
            return "OK_ACRYLIC_SLOT_CUT craftType=acrylic_slot openSides=" + openSides.join(",");
        }

        if (action === "dim_box" || action === "dim_curve_text_below" || action === "label_material") {
            var color = getDimColor(doc);
            var dimL = null; try{dimL=doc.layers.getByName("自动标注");}catch(e){dimL=doc.layers.add();dimL.name="自动标注";}
            var tick = (params.tickLen||2)*2.83464567/2; var off = params.offset*2.83464567;
            if (action === "dim_box") {
                var gL=9e9, gT=-9e9, gR=-9e9, gB=9e9;
                for(var i=0;i<originalSel.length;i++){ var b=originalSel[i].geometricBounds; if(b[0]<gL)gL=b[0]; if(b[1]>gT)gT=b[1]; if(b[2]>gR)gR=b[2]; if(b[3]<gB)gB=b[3]; }
                var wStr = convertValue(gR-gL, params.scale, params.unit, params.decimal, params.isRound);
                var hStr = convertValue(gT-gB, params.scale, params.unit, params.decimal, params.isRound);
                var grp = dimL.groupItems.add();
                if(params.showW){
                    var y=gT+off; drawLine(grp, gL, y, gR, y, color, params.lineWeight); drawLine(grp, gL, y-tick, gL, y+tick, color, params.lineWeight); drawLine(grp, gR, y-tick, gR, y+tick, color, params.lineWeight);
                    var t = drawText(grp, wStr, gL, y+tick+1+params.fontSize, params.fontSize, color); t.left = gL + (gR-gL)/2 - t.width/2;
                }
                if(params.showH){
                    var x=gR+off; drawLine(grp, x, gT, x, gB, color, params.lineWeight); drawLine(grp, x-tick, gT, x+tick, gT, color, params.lineWeight); drawLine(grp, x-tick, gB, x+tick, gB, color, params.lineWeight);
                    var t = drawText(grp, hStr, x+tick+1, gT, params.fontSize, color); t.rotate(-90); t.top=(gT+gB)/2+t.height/2; t.left=x+tick+1;
                }
            }
            if (action === "dim_curve_text_below" || action === "label_material") {
                var txt = "";
                if(action==="label_material"){
                    if(params.sizeNote&&params.sizeNote!="无") txt+=params.sizeNote+" ";
                    if(params.mat&&params.mat!="无") txt+=params.mat+" ";
                    if(params.proc&&params.proc!="无") txt+=params.proc+" ";
                    if(params.thick&&params.thick!="无") txt+=params.thick;
                }
                for(var i=0; i<originalSel.length; i++){
                    var item=originalSel[i]; var b=item.geometricBounds; var cx=b[0]+(b[2]-b[0])/2; var by=b[3]-off; var content = txt;
                    if(action==="dim_curve_text_below"){
                        var len=0; if(item.typename=="PathItem") len=item.length; else if(item.typename=="GroupItem" && item.pathItems.length>0) len=item.pathItems[0].length;
                        content = "曲线长度: " + convertValue(len, params.scale, params.unit, params.decimal, params.isRound);
                    }
                    if(content){
                        var grp = dimL.groupItems.add(); var t = drawText(grp, content, cx, by, params.fontSize, color);
                        t.textRange.paragraphAttributes.justification = Justification.CENTER; t.top=by; t.left=cx-t.width/2;
                    }
                }
            }
        }
    } catch(err) { alert("执行错误:\n" + err.message); }
}



// ============================================================================
// CEP Host API
// ============================================================================
function HH_execute(action, params) {
    if (!params) params = {};
    return WORKER_FUNCTION(action, params);
}

function HH_safeJsonString(value) {
    try {
        return String(value === undefined || value === null ? "" : value)
            .replace(/\\/g, "\\\\")
            .replace(/"/g, '\\"')
            .replace(/\r/g, "\\r")
            .replace(/\n/g, "\\n");
    } catch(e) {}
    return "";
}

function HH_selectExportFolder(initialDir) {
    return "ERROR:C4D JSON 导出请使用保存 JSON 文件窗口";
}

function HH_selectExportJsonFile() {
    if(app.documents.length===0){
        return "ERROR:请先打开文档";
    }
    var defaultName = "Untitled.json";
    try {
        defaultName = app.documents[0].name.replace(/\.[^\.]+$/, "").replace(/[\\\/:\*\?"<>\|]/g, "_") + ".json";
    } catch(e0) {}
    var selectedFile = null;
    try { selectedFile = File.saveDialog("请选择导出文件名", "*.json"); } catch(saveDialogErr) {}
    if (!selectedFile) return "CANCEL";
    var filePath = selectedFile.fsName;
    if (!/\.json$/i.test(filePath)) filePath += ".json";
    return new File(filePath).fsName;
}

function HH_exportFolderExists(exportDir) {
    try {
        if (!exportDir) return "NO_DIR";
        var folder = new Folder(exportDir);
        return folder.exists ? "OK" : "NO_DIR";
    } catch(e) {
        return "NO_DIR";
    }
}

function HH_openExportFolder(exportDir) {
    try {
        if (!exportDir) return "NO_DIR";
        var folder = new Folder(exportDir);
        if (!folder.exists) return "NO_DIR";
        folder.execute();
        return "OK";
    } catch(e) {
        return "ERROR:" + e.message;
    }
}

function HH_exportToFilePath(mode, dpi, format, jsonPath) {
    if(app.documents.length===0){
        return 'EXPORT_RESULT:{"ok":false,"error":"请先打开文档"}';
    }
    try {
        if (!jsonPath) return 'EXPORT_RESULT:{"ok":false,"cancelled":true,"error":"已取消导出"}';
        var file = new File(jsonPath);
        if (!/\.json$/i.test(file.fsName)) file = new File(file.fsName + ".json");
        var parentFolder = file.parent;
        if (!parentFolder || !parentFolder.exists) {
            return 'EXPORT_RESULT:{"ok":false,"error":"导出目录不存在","exportDir":"' + HH_safeJsonString(parentFolder ? parentFolder.fsName : "") + '"}';
        }
        return WORKER_FUNCTION("export", {
            mode: mode || "both",
            dpi: parseInt(dpi, 10) || 300,
            format: format || "png",
            path: file.fsName,
            enableFallback: false,
            silentExport: true,
            showProgressWindow: true,
            exportEntry: "HH_exportToFilePath/exportBtn/save-as"
        });
    } catch(e) {
        return 'EXPORT_RESULT:{"ok":false,"error":"' + HH_safeJsonString(e.message) + '","jsonPath":"' + HH_safeJsonString(jsonPath || "") + '"}';
    }
}

function HH_exportC4DJsonWithSaveDialog(mode, dpi, format) {
    var jsonPath = HH_selectExportJsonFile();
    if (!jsonPath || jsonPath === "CANCEL" || jsonPath === "null") {
        return 'EXPORT_RESULT:{"ok":false,"cancelled":true,"error":"已取消导出"}';
    }
    if (String(jsonPath).indexOf("ERROR:") === 0) {
        return 'EXPORT_RESULT:{"ok":false,"error":"' + HH_safeJsonString(String(jsonPath).replace(/^ERROR:/, "")) + '"}';
    }
    return HH_exportToFilePath(mode, dpi, format, jsonPath);
}

function HH_exportToDirectory(mode, dpi, format, exportDir) {
    if(app.documents.length===0){
        return 'EXPORT_RESULT:{"ok":false,"error":"请先打开文档"}';
    }
    try {
        if (!exportDir) return 'EXPORT_RESULT:{"ok":false,"error":"未选择导出目录"}';
        var folder = new Folder(exportDir);
        if (!folder.exists) return 'EXPORT_RESULT:{"ok":false,"error":"导出目录不存在","exportDir":"' + HH_safeJsonString(exportDir) + '"}';
        var defaultName = "Untitled.json";
        try {
            defaultName = app.documents[0].name.replace(/\.[^\.]+$/, "").replace(/[\\\/:\*\?"<>\|]/g, "_") + ".json";
        } catch(e0) {}
        var file = new File(folder.fsName + "/" + defaultName);
        return WORKER_FUNCTION("export", {
            mode: mode || "both",
            dpi: parseInt(dpi, 10) || 300,
            format: format || "png",
            path: file.fsName,
            enableFallback: false,
            silentExport: true,
            showProgressWindow: true,
            exportEntry: "HH_exportToDirectory/exportBtn/progress-ui"
        });
    } catch(e) {
        return 'EXPORT_RESULT:{"ok":false,"error":"' + HH_safeJsonString(e.message) + '","exportDir":"' + HH_safeJsonString(exportDir || "") + '"}';
    }
}

function HH_exportWithDialog(mode, dpi, format) {
    return HH_exportC4DJsonWithSaveDialog(mode, dpi, format);
}

function HH_hotUpdate(mode, dpi, format) {
    if(app.documents.length===0){alert("请先打开文档");return null;}
    var f = new File(Folder.temp.fsName + "/hh_c4d_hot_update.json");
    return WORKER_FUNCTION("export", {
        mode: mode || "both",
        dpi: parseInt(dpi, 10) || 300,
        format: format || "png",
        path: f.fsName,
        enableFallback: false,
        exportEntry: "HH_hotUpdate/hotUpdateBtn"
    });
}

function HH_ping() {
    return "HH_HOST_READY_v28.236";
}
