#!/bin/bash
set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$SCRIPT_DIR/HH_AI_C4D_CEP"
USER_EXT="$HOME/Library/Application Support/Adobe/CEP/extensions"
DST="$USER_EXT/HH_AI_C4D_CEP"
mkdir -p "$USER_EXT"
rm -rf "$DST"
cp -R "$SRC" "$DST"
defaults write com.adobe.CSXS.6 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.7 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.8 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.9 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.10 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.11 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.12 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.13 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.14 PlayerDebugMode 1 2>/dev/null || true
defaults write com.adobe.CSXS.15 PlayerDebugMode 1 2>/dev/null || true
echo "花花 AI 辅助工具已安装到：$DST"
echo "请完全重启 Adobe Illustrator，然后在 窗口 > 扩展功能 中打开插件。"
read -n 1 -s -r -p "按任意键退出..."
echo
