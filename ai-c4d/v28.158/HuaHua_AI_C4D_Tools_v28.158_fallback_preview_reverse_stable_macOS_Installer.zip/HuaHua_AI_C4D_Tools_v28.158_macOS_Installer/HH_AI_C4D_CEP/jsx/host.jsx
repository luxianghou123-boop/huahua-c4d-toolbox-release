// AI_C4D_Tools_v28.158-preview-local_Defringe_TextBounds.jsx
// 作用：花花 AI 辅助工具全集 (AI 端) - 默认悬浮版
// 修复日志 v28.67：
// 1.[完美边界] 彻底攻克“文字边界空白”问题！当文字作为剪切蒙版时，导出贴图不再包含字体的透明排版区域（大白框）。脚本会智能测量“真实笔画墨水边界”，完美裁切贴图，确保和 C4D 路径 100% 严丝合缝贴合。
// 2.[调试清理] 导出时不再额外写出 _debug.txt，仅保留 JSON 和贴图文件。
// 3.[剪切组导出] 对剪切蒙版组不再只信任内部 mask，改为“内部 mask + 整组全部路径”合并去重导出，避免主体轮廓漏掉。
// 4.[轮廓追踪兜底] 当剪切组现有矢量路径面积明显偏小、疑似只剩花瓣时，自动把剪切结果转成黑色实心轮廓后图像描摹，回收主体外轮廓。
// 5.[外框过滤] 图像描摹兜底后，自动剔除“接近整张边界的大外框路径”，避免 C4D 导入成整块矩形。

#target illustrator
#targetengine "session_HH_Tools_v28_139_CEP"

// ============================================================================
// 1. JSON Polyfill
// ============================================================================
if (typeof JSON !== "object") { JSON = {}; }
(function () {
    "use strict";
    if (typeof JSON.stringify !== "function") {
        JSON.stringify = function (value) {
            var str = function(key, holder) {
                var value = holder[key];
                if (typeof value === "string") return "\"" + value.replace(/[\\"]/g, "\\$&") + "\"";
                if (typeof value === "number") return isFinite(value) ? String(value) : "null";
                if (typeof value === "boolean") return String(value);
                if (!value) return "null";
                if (Object.prototype.toString.call(value) === "[object Array]") {
                    var arr =[]; for (var i = 0; i < value.length; i++) arr[i] = str(i, value) || "null";
                    return "[" + arr.join(",") + "]";
                }
                if (typeof value === "object") {
                    var partial =[]; for (var k in value) {
                        if (Object.prototype.hasOwnProperty.call(value, k)) {
                            var v = str(k, value); if (v) partial.push("\"" + k + "\":" + v);
                        }
                    }
                    return "{" + partial.join(",") + "}";
                }
                return "null";
            };
            return str("", { "": value });
        };
    }
}());

// ============================================================================
// 2. 核心逻辑 (主线程运行)
// ============================================================================
function WORKER_FUNCTION(action, params) {
    try {
        var tools = {
            getTagD: function(name) {
                if (!name) return null;
                var idx = name.lastIndexOf("_d");
                if (idx !== -1) {
                    var part = name.substring(idx + 2);
                    var tIdx = part.indexOf("_t");
                    if (tIdx !== -1) part = part.substring(0, tIdx);
                    part = part.split(/[^0-9]/)[0];
                    var v = parseInt(part);
                    if (!isNaN(v)) return v;
                }
                return null;
            },
            getTagT: function(name) {
                if (!name) return null;
                var idx = name.lastIndexOf("_t");
                if (idx !== -1) {
                    var part = name.substring(idx + 2);
                    var fbrIdx = part.indexOf("_fbr");
                    if (fbrIdx !== -1) part = part.substring(0, fbrIdx);
                    var fbIdx = part.indexOf("_fb");
                    if (fbIdx !== -1) part = part.substring(0, fbIdx);
                    return part;
                }
                return null;
            },
            getFallbackExport: function(name) {
                if (!name) return false;
                return name.lastIndexOf("_fb") !== -1 || name.lastIndexOf("_fbr") !== -1;
            },
            getFallbackReverse: function(name) {
                if (!name) return false;
                return name.lastIndexOf("_fbr") !== -1;
            },
            getPureName: function(name) {
                if (!name) return "";
                var fbrIdx = name.lastIndexOf("_fbr");
                if (fbrIdx !== -1) name = name.substring(0, fbrIdx);
                var fbIdx = name.lastIndexOf("_fb");
                if (fbIdx !== -1) name = name.substring(0, fbIdx);
                var dIdx = name.lastIndexOf("_d");
                if (dIdx !== -1) name = name.substring(0, dIdx);
                var tIdx = name.lastIndexOf("_t");
                if (tIdx !== -1) name = name.substring(0, tIdx);
                return name;
            },
            getFullSuffix: function(name) {
                if (!name) return "";
                var suffix = "";
                var d = this.getTagD(name);
                var t = this.getTagT(name);
                if (d !== null) suffix += "_d" + d;
                if (t) suffix += "_t" + t;
                return suffix;
            },
            rebuildName: function(name, dVal, tVal, fallbackExport, fallbackReverse) {
                var base = this.getPureName(name || "Item");
                if (!base) base = "Obj_" + Math.round(Math.random()*1000);
                var newName = base;
                if (dVal !== null && dVal !== undefined) newName += "_d" + dVal;
                if (tVal) newName += "_t" + tVal;
                if (fallbackReverse) fallbackExport = true;
                if (fallbackExport) newName += "_fb";
                if (fallbackReverse) newName += "_fbr";
                return newName;
            },
            cleanName: function(name) {
                if (!name) name = "Untitled";
                var badCode =[92, 47, 58, 42, 63, 34, 60, 62, 124, 46]; 
                var res = "";
                for (var i = 0; i < name.length; i++) {
                    var c = name.charCodeAt(i);
                    var isBad = false;
                    for (var j = 0; j < badCode.length; j++) { if (c === badCode[j]) { isBad = true; break; } }
                    if (isBad) res += "_"; else res += name.charAt(i);
                }
                return res;
            },
            
            // --- 颜色解析 ---
            parseColor: function(c) {
                try {
                    if (!c) return null;
                    if (c.typename === "RGBColor") {
                        return[Math.round(c.red), Math.round(c.green), Math.round(c.blue)];
                    }
                    if (c.typename === "CMYKColor") {
                        try {
                            var srcVals =[c.cyan, c.magenta, c.yellow, c.black];
                            var dstVals = app.convertSampleColor(ImageColorSpace.CMYK, srcVals, ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose);
                            return[Math.round(dstVals[0]), Math.round(dstVals[1]), Math.round(dstVals[2])];
                        } catch(err) {
                            var k = c.black / 100;
                            var r = 255 * (1 - c.cyan / 100) * (1 - k);
                            var g = 255 * (1 - c.magenta / 100) * (1 - k);
                            var b = 255 * (1 - c.yellow / 100) * (1 - k);
                            return[Math.round(r), Math.round(g), Math.round(b)];
                        }
                    }
                    if (c.typename === "GrayColor") { 
                        try {
                            var dstVals = app.convertSampleColor(ImageColorSpace.GrayScale,[c.gray], ImageColorSpace.RGB, ColorConvertPurpose.defaultpurpose);
                            return[Math.round(dstVals[0]), Math.round(dstVals[1]), Math.round(dstVals[2])];
                        } catch(e) {
                            var v = 255 * (1 - c.gray / 100); 
                            return[Math.round(v), Math.round(v), Math.round(v)]; 
                        }
                    }
                    if (c.typename === "SpotColor") return this.parseColor(c.spot.color);
                    if (c.typename === "GradientColor") {
                        try { return this.parseColor(c.gradient.gradientStops[0].color); } catch(e) { return[200, 200, 200]; }
                    }
                    if (c.typename === "PatternColor") return[150, 150, 150]; 
                    return null;
                } catch(e) { return null; }
            },
            
            getRGB: function(item) {
                try {
                    if (!item) return null;
                    if (item.filled && item.fillColor) {
                        var c = this.parseColor(item.fillColor);
                        if (c) return c;
                    }
                    if (item.typename === "CompoundPathItem" && item.pathItems) {
                        for (var i = 0; i < item.pathItems.length; i++) {
                            var subPath = item.pathItems[i];
                            if (subPath.filled && subPath.fillColor) {
                                var c = this.parseColor(subPath.fillColor);
                                if (c) return c;
                            }
                        }
                    }
                    return null;
                } catch(e) { return null; }
            },

            findDeepColor: function(item) {
                if (!item) return null;
                if (item.clipping) return null; 
                var c = this.getRGB(item);
                if (c) return c;

                if (item.typename === "GroupItem" && item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        var child = item.pageItems[i];
                        var childColor = this.findDeepColor(child);
                        if (childColor) return childColor;
                    }
                }
                
                if (item.typename === "CompoundPathItem" && item.pathItems) {
                     for (var j = 0; j < item.pathItems.length; j++) {
                        var subC = this.getRGB(item.pathItems[j]);
                        if (subC) return subC;
                    }
                }
                return null;
            }
        };

        // 【重构核心】：脱水版真实边界测量（去除文字排版空白区域）
        var getTightBounds = function(item) {
            var getTrueBounds = function(obj) {
                if (obj.typename === "TextFrame") {
                    try {
                        // 提取真实物理边界核心：复制 -> 解除蒙版 -> 转曲 -> 拿尺寸 -> 销毁
                        var dup = obj.duplicate();
                        dup.clipping = false; 
                        var out = dup.createOutline(); 
                        var b = out.geometricBounds;
                        out.remove();
                        return [b[0], b[1], b[2], b[3]];
                    } catch(e) {}
                }
                return [obj.geometricBounds[0], obj.geometricBounds[1], obj.geometricBounds[2], obj.geometricBounds[3]];
            };

            if (item.typename === "GroupItem" && item.clipped) {
                var mask = null;
                try {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        if (item.pageItems[i].clipping === true) { mask = item.pageItems[i]; break; }
                    }
                    if (!mask && item.pageItems.length > 0) mask = item.pageItems[0];
                } catch(e){}
                
                if (mask) {
                    return getTrueBounds(mask);
                }
            }
            
            if (item.typename === "GroupItem" && !item.clipped) {
                var gL = 9999999999, gT = -9999999999, gR = -9999999999, gB = 9999999999;
                var found = false;
                for (var k = 0; k < item.pageItems.length; k++) {
                    var b = getTightBounds(item.pageItems[k]); 
                    if (b) {
                        found = true;
                        gL = Math.min(gL, b[0]); gT = Math.max(gT, b[1]);
                        gR = Math.max(gR, b[2]); gB = Math.min(gB, b[3]);
                    }
                }
                if (found) return[gL, gT, gR, gB];
            }
            return getTrueBounds(item);
        };

        var drawLine = function(container, x1, y1, x2, y2, color, strokeWidth) {
            var line = container.pathItems.add();
            line.setEntirePath([[x1, y1],[x2, y2]]);
            line.stroked = true; line.strokeColor = color; line.strokeWidth = strokeWidth; line.filled = false;
            return line;
        };
        var drawText = function(container, content, x, y, size, color) {
            var txt = container.textFrames.add();
            txt.contents = content;
            var attr = txt.textRange.characterAttributes;
            attr.size = size; attr.fillColor = color;
            try { attr.textFont = app.textFonts.getByName("SimHei"); } catch(e) { try{attr.textFont=app.textFonts.getByName("STHeiti");}catch(e2){} }
            txt.position =[x, y];
            return txt;
        };
        var convertValue = function(ptValue, scale, unitType, decimal, isRound) {
            var val = (ptValue / 2.83464567) * scale;
            var suffix = "mm";
            if (unitType === "cm") { val /= 10; suffix = "cm"; } else if (unitType === "m") { val /= 1000; suffix = "m"; }
            if (isRound) {
                var frac = val - Math.floor(val);
                val = (frac > 0.5) ? Math.ceil(val) : Math.floor(val);
                return val + suffix;
            }
            return val.toFixed(decimal) + suffix;
        };
        var getDimColor = function(docRef) {
            var c = new RGBColor(); c.red = 255; c.green = 0; c.blue = 0;
            try { if (docRef.documentColorSpace === DocumentColorSpace.CMYK) { c = new CMYKColor(); c.cyan=0; c.magenta=100; c.yellow=100; c.black=0; } } catch(e){}
            return c;
        };

        if (action === "check_status") {
            try {
                if (app.documents.length === 0) return "STATUS:未打开文档";
                var doc = app.activeDocument;
                var sel = doc.selection;
                if (!sel || sel.length === 0) return "STATUS:⚪ 请选中对象...";
                
                var missingCount = 0;
                var fallbackCount = 0;
                var fallbackReverseCount = 0;
                for (var m = 0; m < sel.length; m++) {
                    if (tools.getTagD(sel[m].name) === null) {
                        missingCount++;
                    }
                    if (tools.getFallbackReverse(sel[m].name)) {
                        fallbackReverseCount++;
                    } else if (tools.getFallbackExport(sel[m].name)) {
                        fallbackCount++;
                    }
                }
                
                var firstD = tools.getTagD(sel[0].name);
                var info = "STATUS:✅ 选中 " + sel.length + " 个";
                
                if (firstD !== null) {
                    info += " | 厚度: " + firstD + "mm";
                } else {
                    info += " | 无厚度";
                }

                if (missingCount > 0) {
                    info += " ⚠️ " + missingCount + "个漏设!";
                } else if (sel.length > 1) {
                    info += " (均已设)";
                }
                if (fallbackCount > 0) {
                    info += " | 兜底:" + fallbackCount;
                }
                if (fallbackReverseCount > 0) {
                    info += " | 反选兜底:" + fallbackReverseCount;
                }
                
                return info;
            } catch(e) { return "STATUS:读取错误"; }
        }

        var quickActions = {
            outline_stroke: true,
            offset_path: true,
            simplify_path: true,
            create_text_outlines: true,
            drop_shadow: true,
            drop_shadow_preview: true,
            drop_shadow_apply: true,
            drop_shadow_cancel: true,
            drop_shadow_native_preview: true,
            drop_shadow_native_apply: true,
            drop_shadow_native_cancel: true
        };

        var quickActionsNeedSelection = {
            outline_stroke: true,
            offset_path: true,
            simplify_path: true,
            create_text_outlines: true,
            drop_shadow: true,
            drop_shadow_preview: true,
            drop_shadow_apply: false,
            drop_shadow_cancel: false,
            drop_shadow_native_preview: true,
            drop_shadow_native_apply: false,
            drop_shadow_native_cancel: false
        };

        if (quickActions[action] && app.documents.length === 0) {
            alert("请先打开 Illustrator 文档");
            return "NO_DOC";
        }

        var artboardExportActions = {
            rename_artboards: true,
            create_artboards_from_selection: true,
            export_pdf_by_artboards: true,
            export_images: true
        };

        if (artboardExportActions[action] && app.documents.length === 0) {
            alert("请先打开 Illustrator 文档");
            return "NO_DOC";
        }

        if (app.documents.length === 0) { alert("错误: 没有打开的文档"); return; }
        var doc = app.documents[0];
        try { app.activeDocument = doc; } catch(e){} 
        var originalSel = doc.selection;

        var collectFallbackTracePaths = function(item) {
            var paths = [];
            if (!item) return paths;
            try {
                if (item.typename === "PathItem") {
                    paths.push(item);
                } else if (item.typename === "CompoundPathItem") {
                    for (var i = 0; i < item.pathItems.length; i++) paths.push(item.pathItems[i]);
                } else if (item.typename === "GroupItem") {
                    for (var j = 0; j < item.pageItems.length; j++) {
                        paths = paths.concat(collectFallbackTracePaths(item.pageItems[j]));
                    }
                }
            } catch(e) {}
            return paths;
        };

        var getFallbackFillKind = function(item) {
            try {
                if (!item || item.typename !== "PathItem") return "none";
                if (!item.filled || !item.fillColor || item.fillColor.typename === "NoColor") return "none";
                var color = item.fillColor;
                if (color.typename === "RGBColor") {
                    var r = Math.round(color.red), g = Math.round(color.green), b = Math.round(color.blue);
                    if (r >= 245 && g >= 245 && b >= 245) return "white";
                    if (r <= 10 && g <= 10 && b <= 10) return "black";
                    return "other";
                }
                if (color.typename === "GrayColor") {
                    if (color.gray >= 95) return "white";
                    if (color.gray <= 5) return "black";
                    return "other";
                }
                if (color.typename === "CMYKColor") {
                    if (color.black <= 5 && color.cyan <= 8 && color.magenta <= 8 && color.yellow <= 8) return "white";
                    if (color.black >= 90) return "black";
                    return "other";
                }
            } catch(e) {}
            return "none";
        };

        var collectFallbackPathsByFill = function(root) {
            var result = { whitePaths: [], blackPaths: [], otherPaths: [] };
            var paths = collectFallbackTracePaths(root);
            for (var i = 0; i < paths.length; i++) {
                var kind = getFallbackFillKind(paths[i]);
                if (kind === "white") result.whitePaths.push(paths[i]);
                else if (kind === "black") result.blackPaths.push(paths[i]);
                else if (kind === "other") result.otherPaths.push(paths[i]);
            }
            return result;
        };

        var fallbackPathToSegment = function(pth) {
            try {
                var pp = pth.pathPoints;
                if (!pp || pp.length < 2) return "";
                var arr = [];
                for (var i = 0; i < pp.length; i++) {
                    var pt = pp[i];
                    var ax = Math.round(pt.anchor[0] * 100) / 100;
                    var ay = Math.round(-pt.anchor[1] * 100) / 100;
                    var ix = Math.round(pt.leftDirection[0] * 100) / 100;
                    var iy = Math.round(-pt.leftDirection[1] * 100) / 100;
                    var ox = Math.round(pt.rightDirection[0] * 100) / 100;
                    var oy = Math.round(-pt.rightDirection[1] * 100) / 100;
                    arr.push('{"a":[' + ax + ',' + ay + '],"inT":[' + ix + ',' + iy + '],"outT":[' + ox + ',' + oy + ']}');
                }
                return "[" + arr.join(",") + "]";
            } catch(e) {}
            return "";
        };

        var findFallbackTraceClipItem = function(group) {
            if (!group || group.typename !== "GroupItem") return null;
            try {
                for (var i = 0; i < group.pageItems.length; i++) {
                    if (group.pageItems[i].clipping === true) return group.pageItems[i];
                }
                for (var j = 0; j < group.pageItems.length; j++) {
                    var child = group.pageItems[j];
                    if (child.typename === "CompoundPathItem" &&
                        child.pathItems &&
                        child.pathItems.length > 0 &&
                        child.pathItems[0].clipping) {
                        return child;
                    }
                }
            } catch(e) {}
            return null;
        };

        var buildFallbackTraceSegments = function(item, bounds, workLayer, targetColor) {
            var result = {
                ok: false,
                targetColor: targetColor || "white",
                whitePathCount: 0,
                blackPathCount: 0,
                otherPathCount: 0,
                expandedPathCount: 0,
                segmentCount: 0,
                segments: [],
                attempts: [],
                errorMessage: ""
            };
            if (!item || !bounds || !workLayer) {
                result.errorMessage = "missing_item_bounds_or_workLayer";
                return result;
            }

            var runAttempt = function(clipOnly) {
                var dup = null, raster = null, traced = null, expanded = null, fillRect = null;
                var attempt = clipOnly ? "clipFlow" : "wholeObjectFlow";
                try {
                    dup = item.duplicate(workLayer, ElementPlacement.PLACEATBEGINNING);
                    dup.hidden = false;
                    dup.locked = false;

                    if (clipOnly) {
                        if (!dup || dup.typename !== "GroupItem") {
                            result.attempts.push(attempt + ":not_group");
                            try { if (dup) dup.remove(); } catch(e) {}
                            return false;
                        }
                        var clipItem = findFallbackTraceClipItem(dup);
                        if (!clipItem) {
                            result.attempts.push(attempt + ":no_clip_item");
                            try { if (dup) dup.remove(); } catch(e) {}
                            return false;
                        }
                        var toRemove = [];
                        for (var ri = 0; ri < dup.pageItems.length; ri++) {
                            if (dup.pageItems[ri] !== clipItem) toRemove.push(dup.pageItems[ri]);
                        }
                        for (var rr = 0; rr < toRemove.length; rr++) {
                            try { toRemove[rr].remove(); } catch(e) {}
                        }

                        var left = bounds[0] - 2;
                        var top = bounds[1] + 2;
                        var width = Math.max(1, (bounds[2] - bounds[0]) + 4);
                        var height = Math.max(1, (bounds[1] - bounds[3]) + 4);
                        fillRect = doc.pathItems.rectangle(top, left, width, height);
                        fillRect.stroked = false;
                        fillRect.filled = true;
                        var black = new RGBColor();
                        black.red = 0; black.green = 0; black.blue = 0;
                        fillRect.fillColor = black;
                        fillRect.move(dup, ElementPlacement.PLACEATEND);
                    }

                    var rastOpts = new RasterizeOptions();
                    rastOpts.resolution = 300;
                    rastOpts.transparency = true;
                    rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                    rastOpts.convertSpotColors = true;
                    rastOpts.convertTextToOutlines = false;

                    raster = doc.rasterize(dup, bounds, rastOpts);
                    if (!raster) {
                        result.attempts.push(attempt + ":rasterize_empty");
                        return false;
                    }

                    traced = raster.trace();
                    if (!traced) {
                        result.attempts.push(attempt + ":trace_empty");
                        return false;
                    }
                    try {
                        var tracingPresets = app.tracingPresetsList;
                        if (tracingPresets && tracingPresets.length > 0) {
                            traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                        }
                    } catch(e) {}
                    app.redraw();

                    try {
                        expanded = traced.tracing.expandTracing();
                    } catch(expandErr) {
                        expanded = traced;
                        result.errorMessage = "expandFallback:" + expandErr.message;
                    }
                    app.redraw();

                    var expandedPaths = collectFallbackTracePaths(expanded);
                    result.expandedPathCount += expandedPaths.length;
                    var fillGroups = collectFallbackPathsByFill(expanded);
                    result.whitePathCount += fillGroups.whitePaths.length;
                    result.blackPathCount += fillGroups.blackPaths.length;
                    result.otherPathCount += fillGroups.otherPaths.length;

                    var targetPaths = result.targetColor === "black" ? fillGroups.blackPaths : fillGroups.whitePaths;
                    for (var pi = 0; pi < targetPaths.length; pi++) {
                        var seg = fallbackPathToSegment(targetPaths[pi]);
                        if (seg) result.segments.push(seg);
                    }
                    result.segmentCount = result.segments.length;
                    result.ok = result.segmentCount > 0;
                    result.attempts.push(attempt + ":segments=" + result.segmentCount);
                    return result.ok;
                } catch(e) {
                    result.errorMessage = e.message;
                    result.attempts.push(attempt + ":error=" + e.message);
                    return false;
                } finally {
                    try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                    try { if (traced) traced.remove(); } catch(e) {}
                    try { if (raster) raster.remove(); } catch(e) {}
                    try { if (dup) dup.remove(); } catch(e) {}
                    try { if (fillRect) fillRect.remove(); } catch(e) {}
                }
            };

            if (!runAttempt(true)) {
                runAttempt(false);
            }
            return result;
        };

        var safeExecuteMenuCommand = function(commandNames, label, failureMessage) {
            var names = commandNames;
            if (typeof names === "string") names = [names];
            for (var i = 0; i < names.length; i++) {
                try {
                    app.executeMenuCommand(names[i]);
                    return "OK";
                } catch(e) {}
            }
            alert(failureMessage || ("无法调用 Illustrator 原生命令：" + label + "\n请确认当前 Illustrator 版本是否支持该菜单命令。"));
            return "COMMAND_FAILED";
        };

        var safeExecuteMenuSequence = function(commandNames, label, failureMessage) {
            try {
                for (var i = 0; i < commandNames.length; i++) {
                    app.executeMenuCommand(commandNames[i]);
                }
                return "OK";
            } catch(e) {
                alert(failureMessage || ("无法执行 Illustrator 原生命令：" + label + "\n" + e.message));
                return "COMMAND_FAILED";
            }
        };

        var hexToRgb = function(hex) {
            var clean = String(hex || "#000000").replace("#", "");
            if (!/^[0-9a-fA-F]{6}$/.test(clean)) clean = "000000";
            return {
                r: parseInt(clean.substring(0, 2), 16),
                g: parseInt(clean.substring(2, 4), 16),
                b: parseInt(clean.substring(4, 6), 16),
                rn: Math.round((parseInt(clean.substring(0, 2), 16) / 255) * 1000) / 1000,
                gn: Math.round((parseInt(clean.substring(2, 4), 16) / 255) * 1000) / 1000,
                bn: Math.round((parseInt(clean.substring(4, 6), 16) / 255) * 1000) / 1000
            };
        };

        var isDropShadowPreview = function(item) {
            try {
                if (!item) return false;
                if (String(item.name || "").indexOf("HH_DROP_SHADOW_NATIVE_PREVIEW") >= 0) return true;
                if (String(item.note || "").indexOf("HH_DROP_SHADOW_NATIVE_PREVIEW") >= 0) return true;
                if (String(item.name || "").indexOf("HH_DROP_SHADOW_PREVIEW") >= 0) return true;
                if (String(item.note || "").indexOf("HH_DROP_SHADOW_PREVIEW") >= 0) return true;
            } catch(e) {}
            return false;
        };

        var isNativePreviewLayer = function(layer) {
            try {
                return layer && String(layer.name || "") === "HH_DROP_SHADOW_NATIVE_PREVIEW_LAYER";
            } catch(e) {}
            return false;
        };

        var readDropShadowParams = function(showAlert) {
            var ptPerMm = 2.83464567;
            var offsetX = parseFloat(params.offsetXmm);
            var offsetY = parseFloat(params.offsetYmm);
            var blurMm = parseFloat(params.blurMm);
            var opacityPct = parseFloat(params.opacity);
            var colorHex = String(params.colorHex || "#000000");
            var blendMode = String(params.blendMode || "multiply").toLowerCase();

            if (isNaN(offsetX)) offsetX = 2;
            if (isNaN(offsetY)) offsetY = 2;
            if (isNaN(blurMm)) blurMm = 2;
            if (isNaN(opacityPct)) opacityPct = 40;
            if (blendMode !== "normal") blendMode = "multiply";
            if (blurMm < 0 || opacityPct < 0 || opacityPct > 100 || !/^#[0-9a-fA-F]{6}$/.test(colorHex)) {
                if (showAlert) alert("请检查投影参数");
                return null;
            }

            var rgb = hexToRgb(colorHex);
            return {
                offsetXPt: offsetX * ptPerMm,
                offsetYPt: offsetY * ptPerMm,
                blurPt: blurMm * ptPerMm,
                opacityValue: opacityPct / 100,
                blendValue: blendMode === "normal" ? 0 : 1,
                red: rgb.r,
                green: rgb.g,
                blue: rgb.b,
                redNorm: rgb.rn,
                greenNorm: rgb.gn,
                blueNorm: rgb.bn,
                colorHex: colorHex,
                blendMode: blendMode,
                debugColor: colorHex + " rgb=" + rgb.r + "," + rgb.g + "," + rgb.b
            };
        };

        var removeDropShadowPreviews = function() {
            var removed = 0;
            try {
                for (var li = doc.layers.length - 1; li >= 0; li--) {
                    try {
                        var layer = doc.layers[li];
                        if (isNativePreviewLayer(layer)) {
                            layer.locked = false;
                            layer.visible = true;
                            layer.remove();
                            removed++;
                        }
                    } catch(layerErr) {}
                }
                for (var i = doc.pageItems.length - 1; i >= 0; i--) {
                    try {
                        var item = doc.pageItems[i];
                        if (isDropShadowPreview(item)) {
                            item.remove();
                            removed++;
                        }
                    } catch(e1) {}
                }
            } catch(e2) {}
            return removed;
        };

        var restoreSelection = function(items) {
            try {
                doc.selection = null;
                for (var i = 0; i < items.length; i++) {
                    try {
                        if (!isDropShadowPreview(items[i])) items[i].selected = true;
                    } catch(e1) {}
                }
            } catch(e2) {}
        };

        var buildDropShadowEffectXmls = function(parsed) {
            var data = 'I blnd ' + parsed.blendValue +
                ' R opac ' + parsed.opacityValue +
                ' R horz ' + parsed.offsetXPt +
                ' R vert ' + parsed.offsetYPt +
                ' R blur ' + parsed.blurPt +
                ' B usePSLBlur 1 I csrc 0 R dark 100 B pair 1 ';
            var rgbModelColor = "5 " + parsed.redNorm + " " + parsed.greenNorm + " " + parsed.blueNorm;
            var legacyRgbColor = parsed.red + " " + parsed.green + " " + parsed.blue;
            return [
                {
                    name: "sclr-rgb-model",
                    colorFragment: 'sclr=' + rgbModelColor,
                    xml: '<LiveEffect name="Adobe Drop Shadow"><Dict data="' + data + '"><Entry name="sclr" valueType="F"><Fill color="' + rgbModelColor + '"/></Entry></Dict></LiveEffect>'
                },
                {
                    name: "sclr-legacy-rgb",
                    colorFragment: 'sclr=' + legacyRgbColor,
                    xml: '<LiveEffect name="Adobe Drop Shadow"><Dict data="' + data + '"><Entry name="sclr" valueType="F"><Fill color="' + legacyRgbColor + '"/></Entry></Dict></LiveEffect>'
                },
                {
                    name: "simple-default-color",
                    colorFragment: "no-color-entry",
                    xml: '<LiveEffect name="Adobe Drop Shadow"><Dict data="' + data + '" /></LiveEffect>'
                }
            ];
        };

        var dropShadowLastCandidate = "";
        var dropShadowLastColorFragment = "";

        var applyNativeDropShadowLiveEffect = function(items, parsed) {
            var xmls = buildDropShadowEffectXmls(parsed);
            var count = 0;
            dropShadowLastCandidate = "";
            dropShadowLastColorFragment = "";
            for (var i = 0; i < items.length; i++) {
                var item = items[i];
                if (!item || !item.applyEffect) continue;
                for (var x = 0; x < xmls.length; x++) {
                    try {
                        item.applyEffect(xmls[x].xml);
                        if (!dropShadowLastCandidate) {
                            dropShadowLastCandidate = xmls[x].name;
                            dropShadowLastColorFragment = xmls[x].colorFragment;
                        }
                        count++;
                        break;
                    } catch(e) {
                        if (x === xmls.length - 1) {}
                    }
                }
            }
            return count;
        };

        var runNativeDropShadowPreview = function() {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }
            var parsed = readDropShadowParams(false);
            if (!parsed) return "BAD_PARAMS";
            var originals = [];
            for (var i = 0; i < originalSel.length; i++) {
                if (!isDropShadowPreview(originalSel[i])) originals.push(originalSel[i]);
            }
            if (originals.length === 0) {
                alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }
            removeDropShadowPreviews();
            var previewLayer = null;
            try {
                previewLayer = doc.layers.add();
                previewLayer.name = "HH_DROP_SHADOW_NATIVE_PREVIEW_LAYER";
            } catch(layerErr) {
                return "COMMAND_FAILED";
            }
            var previewItems = [];
            for (var p = 0; p < originals.length; p++) {
                try {
                    if (!originals[p] || !originals[p].duplicate) continue;
                    var dup = originals[p].duplicate(previewLayer, ElementPlacement.PLACEATEND);
                    dup.name = "HH_DROP_SHADOW_NATIVE_PREVIEW";
                    try { dup.note = "HH_DROP_SHADOW_NATIVE_PREVIEW"; } catch(noteErr) {}
                    previewItems.push(dup);
                } catch(dupErr) {}
            }
            if (previewItems.length === 0) {
                try { previewLayer.remove(); } catch(removeErr) {}
                restoreSelection(originals);
                return "COMMAND_FAILED";
            }
            try {
                doc.selection = null;
                for (var ps = 0; ps < previewItems.length; ps++) {
                    try { previewItems[ps].selected = true; } catch(selErr1) {}
                }
            } catch(selErr2) {}
            var count = applyNativeDropShadowLiveEffect(previewItems, parsed);
            if (count === 0) {
                try { previewLayer.remove(); } catch(removeErr2) {}
                restoreSelection(originals);
                return "COMMAND_FAILED";
            }
            try {
                for (var s = 0; s < previewItems.length; s++) {
                    try { previewItems[s].selected = false; } catch(selErr) {}
                }
            } catch(e3) {}
            restoreSelection(originals);
            return count > 0 ? ("OK_NATIVE_PREVIEW color=" + parsed.debugColor + " candidate=" + dropShadowLastCandidate + " " + dropShadowLastColorFragment) : "COMMAND_FAILED";
        };

        var runNativeDropShadowApply = function() {
            removeDropShadowPreviews();
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }
            var parsed = readDropShadowParams(true);
            if (!parsed) return "BAD_PARAMS";
            var count = applyNativeDropShadowLiveEffect(originalSel, parsed);
            if (count > 0) {
                try {
                    restoreSelection(originalSel);
                } catch(e2) {}
                alert("已添加原生投影，可在 Illustrator 外观面板中继续编辑");
                return "OK_NATIVE_LIVE_EFFECT color=" + parsed.debugColor + " candidate=" + dropShadowLastCandidate + " " + dropShadowLastColorFragment;
            }
            alert("当前 Illustrator 版本无法通过脚本添加原生投影，请手动使用：效果 > 风格化 > 投影");
            return "COMMAND_FAILED";
        };

        var runDropShadowPreview = function() {
            return runNativeDropShadowPreview();
        };

        var runDropShadowCancel = function() {
            removeDropShadowPreviews();
            return "OK_CANCEL";
        };

        if (quickActions[action]) {
            if (quickActionsNeedSelection[action] && (!originalSel || originalSel.length === 0)) {
                if (action === "outline_stroke") alert("请先选中需要处理的对象");
                if (action === "offset_path") alert("请先选中需要偏移的对象");
                if (action === "simplify_path") alert("请先选中需要简化的对象");
                if (action === "create_text_outlines") alert("请先选中需要转曲的文字");
                if (action === "drop_shadow" || action === "drop_shadow_preview" || action === "drop_shadow_native_preview") alert("请先选中需要添加投影的对象");
                return "NO_SEL";
            }

            if (action === "outline_stroke") {
                // 对象 > 路径 > 轮廓化描边：先调用 Illustrator 的 Live Outline Stroke，再扩展外观落成真实路径。
                return safeExecuteMenuSequence(["Live Outline Stroke", "expandStyle"], "轮廓描边");
            }
            if (action === "offset_path") {
                // 对象 > 路径 > 偏移路径：恢复 v28.140 中已可用的 Illustrator 原生 Offset Path 弹窗调用链。
                return safeExecuteMenuCommand(["OffsetPath v23", "OffsetPath v22", "OffsetPath v21", "OffsetPath v20", "OffsetPath v19", "OffsetPath v18", "OffsetPath"], "路径偏移");
            }
            if (action === "simplify_path") {
                // 对象 > 路径 > 简化：优先打开 Illustrator 原生 Simplify 弹窗。
                return safeExecuteMenuCommand(["Simplify menu item", "simplify menu item", "Simplify", "SimplifyUI", "Path Simplify"], "简化路径");
            }
            if (action === "create_text_outlines") {
                // 文字 > 创建轮廓：Illustrator executeMenuCommand('outline') 对应 Type > Create Outlines。
                return safeExecuteMenuCommand(["outline"], "文字转曲");
            }
            if (action === "drop_shadow") {
                // 效果 > 风格化 > 投影：使用 Illustrator 原生 Live Effect，外观面板可继续编辑。
                return runNativeDropShadowApply();
            }
            if (action === "drop_shadow_preview") {
                return runDropShadowPreview();
            }
            if (action === "drop_shadow_apply") {
                return runNativeDropShadowApply();
            }
            if (action === "drop_shadow_cancel") {
                return runDropShadowCancel();
            }
            if (action === "drop_shadow_native_preview") {
                return runNativeDropShadowPreview();
            }
            if (action === "drop_shadow_native_apply") {
                return runNativeDropShadowApply();
            }
            if (action === "drop_shadow_native_cancel") {
                return runDropShadowCancel();
            }
        }

        var parseArtboardRange = function(input, totalCount) {
            var raw = String(input || "全部").replace(/\s+/g, "");
            if (raw === "" || raw === "全部" || raw.toLowerCase() === "all") {
                return {
                    rangeString: "1-" + totalCount,
                    indexes: (function() {
                        var all = [];
                        for (var ai = 1; ai <= totalCount; ai++) all.push(ai);
                        return all;
                    })()
                };
            }
            if (!/^[0-9]+(-[0-9]+)?(,[0-9]+(-[0-9]+)?)*$/.test(raw)) return null;
            var parts = raw.split(",");
            var indexes = [];
            var seen = {};
            for (var pi = 0; pi < parts.length; pi++) {
                var part = parts[pi];
                var start;
                var end;
                if (part.indexOf("-") >= 0) {
                    var pair = part.split("-");
                    start = parseInt(pair[0], 10);
                    end = parseInt(pair[1], 10);
                } else {
                    start = parseInt(part, 10);
                    end = start;
                }
                if (isNaN(start) || isNaN(end) || start < 1 || end < start || end > totalCount) return null;
                for (var ri = start; ri <= end; ri++) {
                    if (!seen[ri]) {
                        seen[ri] = true;
                        indexes.push(ri);
                    }
                }
            }
            indexes.sort(function(a, b) { return a - b; });
            return {
                rangeString: raw,
                indexes: indexes
            };
        };

        var parseScaleRatio = function(value) {
            var raw = String(value || "1:1").replace(/\s+/g, "");
            var m = raw.match(/^1:([0-9]+(\.[0-9]+)?)$/);
            if (!m) return null;
            var scale = parseFloat(m[1]);
            if (isNaN(scale) || scale <= 0) return null;
            return scale;
        };

        var sanitizeFileName = function(name) {
            return String(name || "export").replace(/\.[^\.]+$/, "").replace(/[\\\/:\*\?"<>\|]/g, "_");
        };

        var unionBounds = function(a, b) {
            if (!a) return b;
            if (!b) return a;
            return [
                Math.min(a[0], b[0]),
                Math.max(a[1], b[1]),
                Math.max(a[2], b[2]),
                Math.min(a[3], b[3])
            ];
        };

        var validBounds = function(bounds) {
            return bounds && bounds.length === 4 && bounds[2] > bounds[0] && bounds[1] > bounds[3];
        };

        var findClippingMaskBounds = function(item) {
            if (!item) return null;
            try {
                if (item.typename === "PathItem" && item.clipping) return item.geometricBounds;
            } catch(e0) {}
            try {
                if (item.typename === "CompoundPathItem") {
                    for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                        try {
                            if (item.pathItems[cpi].clipping) return item.pathItems[cpi].geometricBounds;
                        } catch(e1) {}
                    }
                }
            } catch(e2) {}
            try {
                if (item.pageItems) {
                    for (var i = 0; i < item.pageItems.length; i++) {
                        var childBounds = findClippingMaskBounds(item.pageItems[i]);
                        if (childBounds) return childBounds;
                    }
                }
            } catch(e3) {}
            return null;
        };

        var getItemExportBounds = function(item) {
            if (!item) return null;
            try {
                if (item.typename === "GroupItem" && item.clipped) {
                    var clipB = findClippingMaskBounds(item);
                    if (validBounds(clipB)) return clipB;
                }
            } catch(e0) {}
            try {
                var nestedClip = findClippingMaskBounds(item);
                if (item.typename === "GroupItem" && validBounds(nestedClip)) return nestedClip;
            } catch(e1) {}
            try {
                if (item.visibleBounds && validBounds(item.visibleBounds)) return item.visibleBounds;
            } catch(e2) {}
            try {
                if (item.geometricBounds && validBounds(item.geometricBounds)) return item.geometricBounds;
            } catch(e3) {}
            return null;
        };

        var renameAllArtboardsSequential = function(docRef) {
            var count = docRef.artboards.length;
            for (var ai = 0; ai < count; ai++) {
                docRef.artboards[ai].name = String(ai + 1);
            }
            return count;
        };

        if (action === "rename_artboards") {
            var renamedCount = renameAllArtboardsSequential(doc);
            alert("已重新命名 " + renamedCount + " 个画板");
            return "OK_RENAME_ARTBOARDS:" + renamedCount;
        }

        if (action === "create_artboards_from_selection") {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选择需要生成画板的对象");
                return "NO_SEL";
            }
            var created = 0;
            for (var cab = 0; cab < originalSel.length; cab++) {
                var b = getItemExportBounds(originalSel[cab]);
                if (!validBounds(b)) continue;
                try {
                    doc.artboards.add([b[0], b[1], b[2], b[3]]);
                    created++;
                } catch(addErr) {}
            }
            if (created === 0) {
                alert("未能根据选中对象生成画板");
                return "NO_BOUNDS";
            }
            renameAllArtboardsSequential(doc);
            alert("已生成 " + created + " 个画板，并按顺序重命名");
            return "OK_CREATE_ARTBOARDS:" + created;
        }

        if (action === "export_pdf_by_artboards") {
            var pdfRange = parseArtboardRange(params.range, doc.artboards.length);
            var pdfDpi = parseFloat(params.dpi);
            if (isNaN(pdfDpi) || pdfDpi <= 0) {
                alert("分辨率请输入正数");
                return "BAD_DPI";
            }
            if (!pdfRange) {
                alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
                return "BAD_RANGE";
            }
            var pdfFile = File.saveDialog("保存 PDF", "*.pdf");
            if (!pdfFile) return "CANCEL";
            var pdfPath = String(pdfFile.fsName);
            if (!/\.pdf$/i.test(pdfPath)) pdfFile = new File(pdfPath + ".pdf");
            try {
                var pdfOptions = new PDFSaveOptions();
                pdfOptions.saveMultipleArtboards = true;
                pdfOptions.artboardRange = pdfRange.rangeString;
                try { pdfOptions.preserveEditability = true; } catch(pdfOptErr) {}
                try { pdfOptions.colorDownsampling = pdfDpi; } catch(pdfDpiErr1) {}
                try { pdfOptions.colorDownsamplingImageThreshold = pdfDpi; } catch(pdfDpiErr2) {}
                try { pdfOptions.grayscaleDownsampling = pdfDpi; } catch(pdfDpiErr3) {}
                try { pdfOptions.grayscaleDownsamplingImageThreshold = pdfDpi; } catch(pdfDpiErr4) {}
                try { pdfOptions.monochromeDownsampling = pdfDpi; } catch(pdfDpiErr5) {}
                try { pdfOptions.monochromeDownsamplingImageThreshold = pdfDpi; } catch(pdfDpiErr6) {}
                doc.saveAs(pdfFile, pdfOptions);
                alert("PDF 导出完成");
                return "OK_EXPORT_PDF";
            } catch(pdfErr) {
                alert("PDF 导出失败：" + pdfErr.message);
                return "EXPORT_PDF_FAILED";
            }
        }

        if (action === "export_images") {
            var imageMode = String(params.mode || "selection");
            var imageFormat = String(params.format || "png").toLowerCase();
            var colorMode = String(params.colorMode || "rgb").toLowerCase();
            var dpiValue = parseFloat(params.dpi);
            var scaleValue = parseScaleRatio(params.scale);
            if (isNaN(dpiValue) || dpiValue <= 0) {
                alert("分辨率请输入正数");
                return "BAD_DPI";
            }
            if (!scaleValue) {
                alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
                return "BAD_SCALE";
            }
            if (imageFormat !== "jpg") imageFormat = "png";
            var exportFolder = Folder.selectDialog("选择图片导出文件夹");
            if (!exportFolder) return "CANCEL";
            var dpiExportScale = (dpiValue / 72.0) * 100.0;
            var artboardExportScale = dpiExportScale * scaleValue;
            var maxExportScale = 776.0;
            var docBaseName = sanitizeFileName(doc.name);
            var exportType = imageFormat === "jpg" ? ExportType.JPEG : ExportType.PNG24;
            var makeOptions = function(scalePercent) {
                if (scalePercent > maxExportScale) {
                    throw new Error("导出比例或分辨率过大，请降低比例或分辨率");
                }
                if (imageFormat === "jpg") {
                    var jpgOptions = new ExportOptionsJPEG();
                    jpgOptions.antiAliasing = true;
                    jpgOptions.artBoardClipping = true;
                    jpgOptions.qualitySetting = 90;
                    jpgOptions.horizontalScale = scalePercent;
                    jpgOptions.verticalScale = scalePercent;
                    return jpgOptions;
                }
                var pngOptions = new ExportOptionsPNG24();
                pngOptions.antiAliasing = true;
                pngOptions.transparency = true;
                pngOptions.artBoardClipping = true;
                pngOptions.horizontalScale = scalePercent;
                pngOptions.verticalScale = scalePercent;
                return pngOptions;
            };

            if (colorMode === "cmyk") {
                alert("当前图片格式以 Illustrator 位图导出能力为准；CMYK 成品建议导出 PDF 或另存 AI/EPS。");
            }

            if (imageMode === "artboards") {
                var imageRange = parseArtboardRange(params.range, doc.artboards.length);
                if (!imageRange) {
                    alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
                    return "BAD_RANGE";
                }
                var originalIndex = doc.artboards.getActiveArtboardIndex();
                var exportedBoards = 0;
                try {
                    for (var abi = 0; abi < imageRange.indexes.length; abi++) {
                        var boardNumber = imageRange.indexes[abi];
                        doc.artboards.setActiveArtboardIndex(boardNumber - 1);
                        var outFile = new File(exportFolder.fsName + "/" + docBaseName + "_画板" + boardNumber + "." + imageFormat);
                        doc.exportFile(outFile, exportType, makeOptions(artboardExportScale));
                        exportedBoards++;
                    }
                    doc.artboards.setActiveArtboardIndex(originalIndex);
                    alert("图片导出完成，共 " + exportedBoards + " 张");
                    return "OK_EXPORT_IMAGES:" + exportedBoards;
                } catch(boardExportErr) {
                    try { doc.artboards.setActiveArtboardIndex(originalIndex); } catch(resetErr) {}
                    alert("图片导出失败：按画板导出 PNG/JPG 文件失败。\n" + boardExportErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }
            }

            if (!originalSel || originalSel.length === 0) {
                alert("请先选择需要导出的对象");
                return "NO_SEL";
            }
            var originalArtboardIndex = -1;
            var tempArtboardIndex = -1;
            var tempLayer = null;
            var hiddenItems = [];
            try {
                originalArtboardIndex = doc.artboards.getActiveArtboardIndex();
            } catch(indexErr) {}
            try {
                var originalBounds = null;
                for (var obi = 0; obi < originalSel.length; obi++) {
                    originalBounds = unionBounds(originalBounds, getItemExportBounds(originalSel[obi]));
                }
                if (!validBounds(originalBounds)) {
                    alert("图片导出失败：识别选中对象范围失败。");
                    return "NO_BOUNDS";
                }

                try {
                    tempLayer = doc.layers.add();
                    tempLayer.name = "HH_IMAGE_EXPORT_TEMP_LAYER";
                } catch(layerErr) {
                    alert("图片导出失败：准备临时图层失败。\n" + layerErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }

                var duplicated = [];
                for (var si = 0; si < originalSel.length; si++) {
                    try {
                        duplicated.push(originalSel[si].duplicate(tempLayer, ElementPlacement.PLACEATEND));
                    } catch(dupErr) {}
                }
                if (duplicated.length === 0) {
                    alert("图片导出失败：复制选中对象失败。");
                    return "EXPORT_IMAGES_FAILED";
                }

                for (var hi = 0; hi < originalSel.length; hi++) {
                    try {
                        hiddenItems.push({ item: originalSel[hi], hidden: originalSel[hi].hidden });
                        originalSel[hi].hidden = true;
                    } catch(hiddenErr) {}
                }

                if (scaleValue !== 1) {
                    for (var rs = 0; rs < duplicated.length; rs++) {
                        try {
                            duplicated[rs].resize(scaleValue * 100.0, scaleValue * 100.0, true, true, true, true, scaleValue * 100.0, Transformation.CENTER);
                        } catch(resizeErr) {}
                    }
                }

                var exportBounds = null;
                for (var dbi = 0; dbi < duplicated.length; dbi++) {
                    exportBounds = unionBounds(exportBounds, getItemExportBounds(duplicated[dbi]));
                }
                if (!validBounds(exportBounds)) {
                    alert("图片导出失败：设置导出画板前未能识别临时对象范围。");
                    return "NO_BOUNDS";
                }

                try {
                    doc.artboards.add([exportBounds[0], exportBounds[1], exportBounds[2], exportBounds[3]]);
                    tempArtboardIndex = doc.artboards.length - 1;
                    doc.artboards.setActiveArtboardIndex(tempArtboardIndex);
                } catch(artboardErr) {
                    alert("图片导出失败：设置导出画板失败。\n" + artboardErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }

                var selectionFile = new File(exportFolder.fsName + "/" + docBaseName + "_选中对象." + imageFormat);
                try {
                    doc.exportFile(selectionFile, exportType, makeOptions(dpiExportScale));
                } catch(exportErr) {
                    alert("图片导出失败：导出 PNG/JPG 文件失败。\n" + exportErr.message);
                    return "EXPORT_IMAGES_FAILED";
                }
                alert("图片导出完成，共 1 张");
                return "OK_EXPORT_IMAGES:1";
            } catch(selectionExportErr) {
                alert("图片导出失败：选中对象导出流程异常。\n" + selectionExportErr.message);
                return "EXPORT_IMAGES_FAILED";
            } finally {
                try {
                    if (tempArtboardIndex >= 0 && doc.artboards.length > 1) {
                        doc.artboards[tempArtboardIndex].remove();
                    }
                } catch(removeBoardErr) {}
                try {
                    if (originalArtboardIndex >= 0 && originalArtboardIndex < doc.artboards.length) {
                        doc.artboards.setActiveArtboardIndex(originalArtboardIndex);
                    }
                } catch(resetBoardErr) {}
                try {
                    for (var rh = 0; rh < hiddenItems.length; rh++) {
                        try { hiddenItems[rh].item.hidden = hiddenItems[rh].hidden; } catch(restoreHiddenErr) {}
                    }
                } catch(hiddenRestoreLoopErr) {}
                try {
                    if (tempLayer) {
                        tempLayer.locked = false;
                        tempLayer.visible = true;
                        tempLayer.remove();
                    }
                } catch(removeLayerErr) {}
                try { restoreSelection(originalSel); } catch(restoreSelErr) {}
            }
        }
        
        if (action === "filter_missing") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先框选需要检查的对象范围！"); return "NO_SEL"; }
            var missing =[];
            for (var i = 0; i < originalSel.length; i++) {
                if (tools.getTagD(originalSel[i].name) === null) {
                    missing.push(originalSel[i]);
                }
            }
            if (missing.length > 0) {
                doc.selection = null; 
                for (var j = 0; j < missing.length; j++) { missing[j].selected = true; }
                alert("🔍 已为您筛选出 " + missing.length + " 个【未设置厚度】的对象！\n您可以直接点击上方按钮为其设置厚度。");
            } else {
                alert("✅ 太棒了！当前选中的 " + originalSel.length + " 个对象都已经设置过厚度了。");
            }
            return "OK";
        }

        if (action === "set_thickness") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先选中对象"); return; }
            var dVal = params.val; 
            for (var i = 0; i < originalSel.length; i++) {
                var item = originalSel[i];
                var oldType = tools.getTagT(item.name);
                item.name = tools.rebuildName(item.name, dVal, oldType, tools.getFallbackExport(item.name), tools.getFallbackReverse(item.name));
            }
            return "OK"; 
        }

        if (action === "set_fallback_export") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先选中对象"); return; }
            var enabled = !!params.enabled;
            for (var fbi = 0; fbi < originalSel.length; fbi++) {
                var fbItem = originalSel[fbi];
                var itemD = tools.getTagD(fbItem.name);
                var itemT = tools.getTagT(fbItem.name);
                fbItem.name = tools.rebuildName(fbItem.name, itemD, itemT, enabled, false);
            }
            alert(enabled ? "✅ 已标记为【兜底导出】" : "✅ 已取消【兜底导出】标记");
            return "OK";
        }

        if (action === "set_fallback_reverse") {
            if (!originalSel || originalSel.length === 0) { alert("⚠️ 请先选中对象"); return; }
            var reverseEnabled = !!params.enabled;
            for (var fri = 0; fri < originalSel.length; fri++) {
                var frItem = originalSel[fri];
                var frD = tools.getTagD(frItem.name);
                var frT = tools.getTagT(frItem.name);
                frItem.name = tools.rebuildName(frItem.name, frD, frT, true, reverseEnabled);
            }
            alert(reverseEnabled ? "✅ 已标记为【反选兜底区域】" : "✅ 已取消【反选兜底区域】标记");
            return "OK";
        }

        if (action === "clear_fallback_preview") {
            var removedPreview = false;
            for (var cpl = doc.layers.length - 1; cpl >= 0; cpl--) {
                try {
                    if (doc.layers[cpl].name === "HH_FALLBACK_PREVIEW" ||
                        doc.layers[cpl].name === "HH_FALLBACK_PREVIEW_TEMP") {
                        doc.layers[cpl].locked = false;
                        doc.layers[cpl].visible = true;
                        doc.layers[cpl].remove();
                        removedPreview = true;
                    }
                } catch(e) {}
            }
            return removedPreview ? "OK_CLEAR_FALLBACK_PREVIEW" : "NO_FALLBACK_PREVIEW";
        }

        if (action === "preview_fallback_export") {
            if (!originalSel || originalSel.length === 0) {
                alert("请先选中需要预览兜底路径的对象");
                return "NO_SEL";
            }

            var removePreviewLayers = function() {
                for (var l = doc.layers.length - 1; l >= 0; l--) {
                    try {
                        if (doc.layers[l].name === "HH_FALLBACK_PREVIEW" ||
                            doc.layers[l].name === "HH_FALLBACK_PREVIEW_TEMP") {
                            doc.layers[l].locked = false;
                            doc.layers[l].visible = true;
                            doc.layers[l].remove();
                        }
                    } catch(e) {}
                }
            };

            var collectPreviewPaths = function(item) {
                var paths = [];
                if (!item) return paths;
                if (item.typename === "PathItem") {
                    paths.push(item);
                } else if (item.typename === "CompoundPathItem") {
                    for (var i = 0; i < item.pathItems.length; i++) paths.push(item.pathItems[i]);
                } else if (item.typename === "GroupItem") {
                    for (var j = 0; j < item.pageItems.length; j++) {
                        paths = paths.concat(collectPreviewPaths(item.pageItems[j]));
                    }
                }
                return paths;
            };

            var findPreviewClipItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        if (group.pageItems[i].clipping === true) return group.pageItems[i];
                    }
                    for (var j = 0; j < group.pageItems.length; j++) {
                        var child = group.pageItems[j];
                        if (child.typename === "CompoundPathItem" &&
                            child.pathItems &&
                            child.pathItems.length > 0 &&
                            child.pathItems[0].clipping) {
                            return child;
                        }
                    }
                } catch(e) {}
                return null;
            };

            var magenta = new RGBColor();
            magenta.red = 255; magenta.green = 0; magenta.blue = 255;

            var getPreviewFillKind = function(item) {
                try {
                    if (!item) return "none";
                    if (item.typename === "CompoundPathItem") {
                        var compoundKind = "none";
                        for (var cpi = 0; cpi < item.pathItems.length; cpi++) {
                            var subKind = getPreviewFillKind(item.pathItems[cpi]);
                            if (subKind === "white" || subKind === "black") return subKind;
                            if (subKind === "other") compoundKind = "other";
                        }
                        return compoundKind;
                    }
                    if (item.typename === "GroupItem") {
                        var groupKind = "none";
                        for (var gi = 0; gi < item.pageItems.length; gi++) {
                            var childKind = getPreviewFillKind(item.pageItems[gi]);
                            if (childKind === "white" || childKind === "black") return childKind;
                            if (childKind === "other") groupKind = "other";
                        }
                        return groupKind;
                    }
                    if (item.typename !== "PathItem") return "none";
                    if (!item.filled || !item.fillColor || item.fillColor.typename === "NoColor") return "none";
                    var color = item.fillColor;
                    if (color.typename === "RGBColor") {
                        var r = Math.round(color.red);
                        var g = Math.round(color.green);
                        var b = Math.round(color.blue);
                        if (r >= 245 && g >= 245 && b >= 245) return "white";
                        if (r <= 10 && g <= 10 && b <= 10) return "black";
                        return "other";
                    }
                    if (color.typename === "GrayColor") {
                        if (color.gray >= 95) return "white";
                        if (color.gray <= 5) return "black";
                        return "other";
                    }
                    if (color.typename === "CMYKColor") {
                        if (color.black <= 5 && color.cyan <= 8 && color.magenta <= 8 && color.yellow <= 8) return "white";
                        if (color.black >= 90) return "black";
                        return "other";
                    }
                } catch(e) {}
                return "none";
            };

            var collectPathsByFill = function(root) {
                var result = { whitePaths: [], blackPaths: [], otherPaths: [] };
                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "PathItem") {
                            var kind = getPreviewFillKind(node);
                            if (kind === "white") result.whitePaths.push(node);
                            else if (kind === "black") result.blackPaths.push(node);
                            else if (kind === "other") result.otherPaths.push(node);
                            return;
                        }
                        if (node.typename === "CompoundPathItem") {
                            for (var i = 0; i < node.pathItems.length; i++) walk(node.pathItems[i]);
                            return;
                        }
                        if (node.typename === "GroupItem") {
                            for (var j = 0; j < node.pageItems.length; j++) walk(node.pageItems[j]);
                        }
                    } catch(e) {}
                };
                walk(root);
                return result;
            };

            var copyPathToPreview = function(srcPath, previewParent) {
                try {
                    if (!srcPath || !srcPath.pathPoints || srcPath.pathPoints.length < 2) return false;
                    var dst = previewParent.pathItems.add();
                    for (var i = 0; i < srcPath.pathPoints.length; i++) {
                        var sp = srcPath.pathPoints[i];
                        var dp = dst.pathPoints.add();
                        dp.anchor = [sp.anchor[0], sp.anchor[1]];
                        dp.leftDirection = [sp.leftDirection[0], sp.leftDirection[1]];
                        dp.rightDirection = [sp.rightDirection[0], sp.rightDirection[1]];
                        try { dp.pointType = sp.pointType; } catch(e) {}
                    }
                    dst.closed = srcPath.closed;
                    dst.filled = false;
                    dst.stroked = true;
                    dst.strokeColor = magenta;
                    dst.strokeWidth = 2;
                    return true;
                } catch(e) {}
                return false;
            };

            var mergeOrGroupPreviewPaths = function(paths, previewLayer) {
                var stats = { groupCount: 0, pathCount: 0, merged: false };
                if (!paths || paths.length === 0) return stats;
                var previewGroup = previewLayer.groupItems.add();
                previewGroup.name = "HH_FALLBACK_PREVIEW_WHITE_GROUP";
                stats.groupCount = 1;
                stats.merged = true;
                for (var i = 0; i < paths.length; i++) {
                    if (copyPathToPreview(paths[i], previewGroup)) stats.pathCount++;
                }
                return stats;
            };

            var drawFallbackSegmentToPreview = function(segText, previewParent) {
                try {
                    if (!segText) return false;
                    var pts = eval("(" + segText + ")");
                    if (!pts || pts.length < 2) return false;
                    var dst = previewParent.pathItems.add();
                    for (var i = 0; i < pts.length; i++) {
                        var src = pts[i];
                        var p = dst.pathPoints.add();
                        p.anchor = [src.a[0], -src.a[1]];
                        p.leftDirection = [src.inT[0], -src.inT[1]];
                        p.rightDirection = [src.outT[0], -src.outT[1]];
                    }
                    dst.closed = true;
                    dst.filled = false;
                    dst.stroked = true;
                    dst.strokeColor = magenta;
                    dst.strokeWidth = 2;
                    return true;
                } catch(e) {}
                return false;
            };

            var drawFallbackSegmentsToPreview = function(segments, previewLayer) {
                var stats = { groupCount: 0, pathCount: 0, merged: false };
                if (!segments || segments.length === 0) return stats;
                var previewGroup = previewLayer.groupItems.add();
                previewGroup.name = "HH_FALLBACK_PREVIEW_WHITE_GROUP";
                stats.groupCount = 1;
                stats.merged = true;
                for (var i = 0; i < segments.length; i++) {
                    if (drawFallbackSegmentToPreview(segments[i], previewGroup)) stats.pathCount++;
                }
                return stats;
            };

            var tracePreviewForItem = function(item, bounds, previewLayer, tempLayer) {
                var totalCount = 0;
                var debug = {
                    selectedType: item ? item.typename : "None",
                    itemName: "",
                    bounds: bounds ? "[" + [
                        Math.round(bounds[0]*100)/100,
                        Math.round(bounds[1]*100)/100,
                        Math.round(bounds[2]*100)/100,
                        Math.round(bounds[3]*100)/100
                    ].join(",") + "]" : "None",
                    isGroupItem: item && item.typename === "GroupItem",
                    isClippingGroup: false,
                    isPlacedItem: item && item.typename === "PlacedItem",
                    isRasterItem: item && item.typename === "RasterItem",
                    traceStarted: false,
                    rasterizeSuccess: false,
                    traceSuccess: false,
                    expandSuccess: false,
                    expandedPathCount: 0,
                    whitePathCount: 0,
                    blackPathCount: 0,
                    otherPathCount: 0,
                    previewTargetColor: "white",
                    mergedPreview: false,
                    previewGroupCount: 0,
                    previewPathCount: 0,
                    collectedPathCount: 0,
                    segmentCount: 0,
                    errorMessage: "",
                    attempts: []
                };
                try { debug.itemName = item && item.name ? item.name : ""; } catch(e) {}
                try { debug.isClippingGroup = item && item.typename === "GroupItem" && item.clipped; } catch(e) {}

                var runAttempt = function(clipOnly) {
                    var count = 0;
                    var attempt = clipOnly ? "clipFlow" : "wholeObjectFlow";
                    var dup = null, raster = null, traced = null, expanded = null, fillRect = null;
                    if (!item || !bounds) {
                        debug.errorMessage = "missing_item_or_bounds";
                        return count;
                    }

                    try {
                        debug.traceStarted = true;
                        dup = item.duplicate(tempLayer, ElementPlacement.PLACEATBEGINNING);
                        dup.hidden = false;
                        dup.locked = false;

                        if (clipOnly) {
                            if (!dup || dup.typename !== "GroupItem") {
                                debug.attempts.push(attempt + ":not_group");
                                try { if (dup) dup.remove(); } catch(e) {}
                                return count;
                            }
                            var clipItem = findPreviewClipItem(dup);
                            if (!clipItem) {
                                debug.attempts.push(attempt + ":no_clip_item");
                                try { if (dup) dup.remove(); } catch(e) {}
                                return count;
                            }

                            var toRemove = [];
                            for (var i = 0; i < dup.pageItems.length; i++) {
                                if (dup.pageItems[i] !== clipItem) toRemove.push(dup.pageItems[i]);
                            }
                            for (var r = 0; r < toRemove.length; r++) {
                                try { toRemove[r].remove(); } catch(e) {}
                            }

                            var b = bounds;
                            var left = b[0] - 2;
                            var top = b[1] + 2;
                            var width = Math.max(1, (b[2] - b[0]) + 4);
                            var height = Math.max(1, (b[1] - b[3]) + 4);

                            fillRect = doc.pathItems.rectangle(top, left, width, height);
                            fillRect.stroked = false;
                            fillRect.filled = true;
                            var black = new RGBColor();
                            black.red = 0; black.green = 0; black.blue = 0;
                            fillRect.fillColor = black;
                            fillRect.move(dup, ElementPlacement.PLACEATEND);
                        }

                        var rastOpts = new RasterizeOptions();
                        rastOpts.resolution = 300;
                        rastOpts.transparency = true;
                        rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                        rastOpts.convertSpotColors = true;
                        rastOpts.convertTextToOutlines = false;

                        raster = doc.rasterize(dup, bounds, rastOpts);
                        if (!raster) {
                            debug.attempts.push(attempt + ":rasterize_empty");
                            return count;
                        }
                        debug.rasterizeSuccess = true;

                        traced = raster.trace();
                        if (!traced) {
                            debug.attempts.push(attempt + ":trace_empty");
                            return count;
                        }
                        debug.traceSuccess = true;
                        try {
                            var tracingPresets = app.tracingPresetsList;
                            if (tracingPresets && tracingPresets.length > 0) {
                                traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                            }
                        } catch(e) {}
                        app.redraw();

                        try {
                            expanded = traced.tracing.expandTracing();
                            debug.expandSuccess = true;
                        } catch(expandErr) {
                            expanded = traced;
                            debug.errorMessage = "expandFallback:" + expandErr.message;
                        }
                        app.redraw();

                        var tracedPaths = collectPreviewPaths(expanded);
                        debug.expandedPathCount += tracedPaths.length;
                        debug.collectedPathCount += tracedPaths.length;
                        var fillGroups = collectPathsByFill(expanded);
                        debug.whitePathCount += fillGroups.whitePaths.length;
                        debug.blackPathCount += fillGroups.blackPaths.length;
                        debug.otherPathCount += fillGroups.otherPaths.length;

                        if (fillGroups.whitePaths.length === 0) {
                            debug.attempts.push(attempt + ":no_white_fill");
                        } else {
                            var previewStats = mergeOrGroupPreviewPaths(fillGroups.whitePaths, previewLayer);
                            count += previewStats.pathCount;
                            debug.previewGroupCount += previewStats.groupCount;
                            debug.previewPathCount += previewStats.pathCount;
                            debug.mergedPreview = debug.mergedPreview || previewStats.merged;
                        }
                        debug.segmentCount += count;
                        debug.attempts.push(attempt + ":count=" + count);
                    } catch(e) {
                        debug.errorMessage = e.message;
                        debug.attempts.push(attempt + ":error=" + e.message);
                        count = 0;
                    }

                    try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                    try { if (traced) traced.remove(); } catch(e) {}
                    try { if (raster) raster.remove(); } catch(e) {}
                    try { if (dup) dup.remove(); } catch(e) {}
                    try { if (fillRect) fillRect.remove(); } catch(e) {}
                    return count;
                };

                // 先尝试 v28.157 的剪切组兜底 trace 流程；失败时强制对整个选中对象 trace。
                totalCount += runAttempt(true);
                if (totalCount <= 0) {
                    totalCount += runAttempt(false);
                }

                return { count: totalCount, debug: debug };
            };

            var legacyUnusedPreviewTrace = function(item, bounds, previewLayer, tempLayer) {
                var count = 0;
                var dup = null, raster = null, traced = null, expanded = null, fillRect = null;
                if (!item || item.typename !== "GroupItem" || !bounds) return count;

                try {
                    dup = item.duplicate(tempLayer, ElementPlacement.PLACEATBEGINNING);
                    dup.hidden = false;
                    dup.locked = false;

                    var clipItem = findPreviewClipItem(dup);
                    if (!clipItem) {
                        if (dup) dup.remove();
                        return count;
                    }

                    var toRemove = [];
                    for (var i = 0; i < dup.pageItems.length; i++) {
                        if (dup.pageItems[i] !== clipItem) toRemove.push(dup.pageItems[i]);
                    }
                    for (var r = 0; r < toRemove.length; r++) {
                        try { toRemove[r].remove(); } catch(e) {}
                    }

                    var b = bounds;
                    var left = b[0] - 2;
                    var top = b[1] + 2;
                    var width = Math.max(1, (b[2] - b[0]) + 4);
                    var height = Math.max(1, (b[1] - b[3]) + 4);

                    fillRect = doc.pathItems.rectangle(top, left, width, height);
                    fillRect.stroked = false;
                    fillRect.filled = true;
                    var black = new RGBColor();
                    black.red = 0; black.green = 0; black.blue = 0;
                    fillRect.fillColor = black;
                    fillRect.move(dup, ElementPlacement.PLACEATEND);

                    var rastOpts = new RasterizeOptions();
                    rastOpts.resolution = 300;
                    rastOpts.transparency = true;
                    rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                    rastOpts.convertSpotColors = true;
                    rastOpts.convertTextToOutlines = false;

                    raster = doc.rasterize(dup, bounds, rastOpts);
                    if (!raster) {
                        if (dup) dup.remove();
                        return count;
                    }

                    traced = raster.trace();
                    try {
                        var tracingPresets = app.tracingPresetsList;
                        if (tracingPresets && tracingPresets.length > 0) {
                            traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                        }
                    } catch(e) {}
                    app.redraw();

                    try {
                        expanded = traced.tracing.expandTracing();
                    } catch(e) {
                        expanded = traced;
                    }
                    app.redraw();

                    var tracedPaths = collectPreviewPaths(expanded);
                    var filteredPaths = [];
                    var candidates = [];
                    var baseW = Math.max(0.01, Math.abs(bounds[2] - bounds[0]));
                    var baseH = Math.max(0.01, Math.abs(bounds[1] - bounds[3]));
                    var hasInnerLarge = false;

                    for (var tp = 0; tp < tracedPaths.length; tp++) {
                        try {
                            var pb = getTightBounds(tracedPaths[tp]);
                            if (!pb) continue;
                            var wRatio = Math.abs(pb[2] - pb[0]) / baseW;
                            var hRatio = Math.abs(pb[1] - pb[3]) / baseH;
                            var coverage = Math.min(wRatio, hRatio);
                            candidates.push({ path: tracedPaths[tp], coverage: coverage });
                            if (coverage >= 0.55 && coverage < 0.98) hasInnerLarge = true;
                        } catch(e) {}
                    }

                    for (var ci = 0; ci < candidates.length; ci++) {
                        if (hasInnerLarge && candidates[ci].coverage >= 0.98) continue;
                        filteredPaths.push(candidates[ci].path);
                    }

                    if (filteredPaths.length === 0) filteredPaths = tracedPaths;
                    for (var fp = 0; fp < filteredPaths.length; fp++) {
                        if (copyPathToPreview(filteredPaths[fp], previewLayer)) count++;
                    }
                } catch(e) {
                    count = 0;
                }

                try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                try { if (traced) traced.remove(); } catch(e) {}
                try { if (raster) raster.remove(); } catch(e) {}
                try { if (dup) dup.remove(); } catch(e) {}
                try { if (fillRect) fillRect.remove(); } catch(e) {}
                return count;
            };

            removePreviewLayers();

            var previewLayer = doc.layers.add();
            previewLayer.name = "HH_FALLBACK_PREVIEW";
            previewLayer.visible = true;
            previewLayer.locked = false;

            var tempPreviewLayer = doc.layers.add();
            tempPreviewLayer.name = "HH_FALLBACK_PREVIEW_TEMP";
            tempPreviewLayer.visible = true;
            tempPreviewLayer.locked = false;

            var previewCount = 0;
            var previewDebug = [];
            var totalWhitePathCount = 0;
            var totalBlackPathCount = 0;
            try {
                for (var psi = 0; psi < originalSel.length; psi++) {
                    var previewReverse = tools.getFallbackReverse(originalSel[psi].name);
                    var previewTargetColor = previewReverse ? "black" : "white";
                    var fallbackResult = buildFallbackTraceSegments(originalSel[psi], getTightBounds(originalSel[psi]), tempPreviewLayer, previewTargetColor);
                    var previewStats = drawFallbackSegmentsToPreview(fallbackResult.segments, previewLayer);
                    previewCount += previewStats.pathCount;
                    totalWhitePathCount += fallbackResult.whitePathCount;
                    totalBlackPathCount += fallbackResult.blackPathCount;
                    previewDebug.push(
                        "selectedType=" + (originalSel[psi] ? originalSel[psi].typename : "None") +
                        " fallbackSource=previewLike" + (previewTargetColor === "black" ? "BlackFill" : "WhiteFill") +
                        " fallbackReverse=" + previewReverse +
                        " targetMode=" + (previewReverse ? "reverse" : "normal") +
                        " exportUsesPreviewLogic=true" +
                        " expandedPathCount=" + fallbackResult.expandedPathCount +
                        " whitePathCount=" + fallbackResult.whitePathCount +
                        " blackPathCount=" + fallbackResult.blackPathCount +
                        " otherPathCount=" + fallbackResult.otherPathCount +
                        " previewTargetColor=" + fallbackResult.targetColor +
                        " mergedPreview=" + previewStats.merged +
                        " previewGroupCount=" + previewStats.groupCount +
                        " previewPathCount=" + previewStats.pathCount +
                        " segmentCount=" + fallbackResult.segmentCount +
                        " attempts=" + fallbackResult.attempts.join(";") +
                        " errorMessage=" + fallbackResult.errorMessage
                    );
                }
            } finally {
                try { tempPreviewLayer.locked = false; tempPreviewLayer.visible = true; tempPreviewLayer.remove(); } catch(e) {}
            }

            if (previewCount <= 0) {
                try { previewLayer.remove(); } catch(e) {}
                var failMsg = (totalWhitePathCount <= 0 && totalBlackPathCount > 0 ?
                    "没有检测到白色填充路径，请检查 image trace expand 后的填充色。\n" :
                    "预览失败：\n") + previewDebug.join("\n");
                alert(failMsg);
                return "NO_FALLBACK_PREVIEW_PATH " + previewDebug.join(" | ");
            }

            alert("✅ 已生成兜底路径预览：" + previewCount + " 条路径\n" + previewDebug.join("\n"));
            return "OK_FALLBACK_PREVIEW count=" + previewCount + " " + previewDebug.join(" | ");
        }

        if (!originalSel || originalSel.length === 0) { alert("错误: 请先选中对象"); return; }

        if (action === "export") {
            var mode = params.mode; 
            var savePathStr = params.path;
            var dpi = params.dpi || 300;
            var format = params.format; 
            var enableFallback = !!params.enableFallback;

            // 防呆验证
            var missingCount = 0;
            for(var m = 0; m < originalSel.length; m++) {
                if(tools.getTagD(originalSel[m].name) === null) { missingCount++; }
            }
            if (missingCount > 0) {
                var msg = "⚠️ 导出警告：\n\n检测到选中的 " + originalSel.length + " 个对象中，有 " + missingCount + " 个【尚未设置厚度】（没有 _d 标签）。\n\n如果直接导出，这些对象在 C4D 中将失去挤压厚度！\n\n是否仍然要继续强制导出？";
                if (!confirm(msg)) { return; }
            }

            var baseFile = new File(savePathStr);
            var texFolder = new Folder(baseFile.parent.fsName + "/tex");
            if (!texFolder.exists) texFolder.create();

            var scanList =[]; 
            var imgList =[];  
            var imgCount = 0;
            var origLevel = app.userInteractionLevel;
            app.userInteractionLevel = UserInteractionLevel.DONTDISPLAYALERTS;

            // 建立干净无污染的临时工作区图层
            var tempLayer = null;
            try {
                tempLayer = doc.layers.add();
                tempLayer.name = "HH_TEMP_EXPORT_" + Math.round(Math.random()*10000);
                tempLayer.printable = false; 
            } catch(e) {
                alert("创建临时图层失败，请检查文档是否被锁定！");
                app.userInteractionLevel = origLevel; return;
            }

            // 安全拷贝对象
            for (var c = 0; c < originalSel.length; c++) {
                try { originalSel[c].duplicate(tempLayer, ElementPlacement.PLACEATEND); } catch(e) {}
            }

            var sel =[];
            for (var p = 0; p < tempLayer.pageItems.length; p++) {
                sel.push(tempLayer.pageItems[p]);
            }

            var globalClipCounter = 1;
            var globalObjCounter = 1;

            // =======================================================
            // 扫描分类逻辑
            // =======================================================
            var findLargestClipItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var best = null;
                var bestArea = -1;

                var consider = function(item) {
                    try {
                        var b = item.geometricBounds;
                        if (!b) return;
                        var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                        if (area > bestArea) {
                            bestArea = area;
                            best = item;
                        }
                    } catch (e) {}
                };

                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "PathItem" && node.clipping) {
                            consider(node);
                            return;
                        }
                        if (node.typename === "CompoundPathItem" && node.pathItems && node.pathItems.length > 0 && node.pathItems[0].clipping) {
                            consider(node);
                            return;
                        }
                        if (node.typename === "GroupItem") {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };

                walk(group);
                return best;
            };

            var collectAllClipItems = function(group) {
                var out = [];
                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "PathItem" && node.clipping) {
                            out.push(node);
                            return;
                        }
                        if (node.typename === "CompoundPathItem" && node.pathItems && node.pathItems.length > 0 && node.pathItems[0].clipping) {
                            out.push(node);
                            return;
                        }
                        if (node.typename === "GroupItem") {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };
                walk(group);
                return out;
            };

            var findBestMaskForGroup = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var candidates = collectAllClipItems(group);
                if (!candidates || candidates.length === 0) return null;

                var gb = null;
                try { gb = group.geometricBounds; } catch (e) {}
                if (!gb) return candidates[0];
                var gw = Math.max(0.01, Math.abs(gb[2] - gb[0]));
                var gh = Math.max(0.01, Math.abs(gb[1] - gb[3]));

                var best = candidates[0];
                var bestCoverage = -1;
                var bestArea = -1;

                for (var i = 0; i < candidates.length; i++) {
                    try {
                        var b = candidates[i].geometricBounds;
                        if (!b) continue;
                        var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                        var coverage = Math.min(Math.abs(b[2] - b[0]) / gw, Math.abs(b[1] - b[3]) / gh);
                        if (coverage > bestCoverage || (coverage === bestCoverage && area > bestArea)) {
                            bestCoverage = coverage;
                            bestArea = area;
                            best = candidates[i];
                        }
                    } catch (e) {}
                }
                return best;
            };

            var shouldSplitClippedContainer = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.clipped) return false;
                var candidates = collectAllClipItems(group);
                if (!candidates || candidates.length < 2) return false;

                var gb = null;
                try { gb = group.geometricBounds; } catch (e) {}
                if (!gb) return false;
                var gw = Math.max(0.01, Math.abs(gb[2] - gb[0]));
                var gh = Math.max(0.01, Math.abs(gb[1] - gb[3]));

                var bestCoverage = -1;
                for (var i = 0; i < candidates.length; i++) {
                    try {
                        var b = candidates[i].geometricBounds;
                        if (!b) continue;
                        var coverage = Math.min(Math.abs(b[2] - b[0]) / gw, Math.abs(b[1] - b[3]) / gh);
                        if (coverage > bestCoverage) bestCoverage = coverage;
                    } catch (e) {}
                }

                return bestCoverage > 0 && bestCoverage < 0.35;
            };

            var containsAnyClippedGroup = function(group) {
                if (!group || group.typename !== "GroupItem") return false;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename === "GroupItem") {
                            if (child.clipped) return true;
                            if (containsAnyClippedGroup(child)) return true;
                        }
                    }
                } catch (e) {}
                return false;
            };

            var getPrimaryDirectClipItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        if (group.pageItems[i].clipping === true) return group.pageItems[i];
                    }
                    for (var j = 0; j < group.pageItems.length; j++) {
                        var child = group.pageItems[j];
                        if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0 && child.pathItems[0].clipping) {
                            return child;
                        }
                    }
                } catch (e) {}
                return null;
            };

            var findLargestNestedClippedGroupMask = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var bestMask = null;
                var bestArea = -1;

                var areaOf = function(item) {
                    try {
                        var b = item.geometricBounds;
                        if (!b) return -1;
                        return Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                    } catch (e) {
                        return -1;
                    }
                };

                var walk = function(node, skipSelf) {
                    if (!node || node.typename !== "GroupItem") return;
                    try {
                        if (!skipSelf && node.clipped) {
                            var mask = getPrimaryDirectClipItem(node);
                            if (mask) {
                                var area = areaOf(mask);
                                if (area > bestArea) {
                                    bestArea = area;
                                    bestMask = mask;
                                }
                            }
                        }
                        for (var i = 0; i < node.pageItems.length; i++) {
                            if (node.pageItems[i].typename === "GroupItem") {
                                walk(node.pageItems[i], false);
                            }
                        }
                    } catch (e) {}
                };

                walk(group, true);
                return bestMask;
            };

            var findLargestDirectOutlineItem = function(group) {
                if (!group || group.typename !== "GroupItem") return null;
                var best = null;
                var bestArea = -1;

                var consider = function(item) {
                    try {
                        if (!item) return;
                        if (item.typename === "PathItem" && item.guides) return;
                        if (item.typename !== "PathItem" && item.typename !== "CompoundPathItem") return;
                        var b = item.geometricBounds;
                        if (!b) return;
                        var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                        if (area > bestArea) {
                            bestArea = area;
                            best = item;
                        }
                    } catch (e) {}
                };

                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        consider(group.pageItems[i]);
                    }
                } catch (e) {}

                return best;
            };

            var getItemArea = function(item) {
                try {
                    if (!item || !item.geometricBounds) return -1;
                    var b = item.geometricBounds;
                    return Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                } catch (e) {
                    return -1;
                }
            };

            var boundsArea = function(b) {
                if (!b || b.length < 4) return -1;
                return Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
            };

            var getGroupOwnBounds = function(group) {
                try {
                    if (!group || !group.geometricBounds) return null;
                    return [group.geometricBounds[0], group.geometricBounds[1], group.geometricBounds[2], group.geometricBounds[3]];
                } catch (e) {
                    return null;
                }
            };

            var getItemOuterBounds = function(item) {
                var result = null;
                var add = function(b) {
                    if (!b || b.length < 4) return;
                    result = unionTwoBounds(result, [b[0], b[1], b[2], b[3]]);
                };
                try { add(item.geometricBounds); } catch(e) {}
                try { add(item.visibleBounds); } catch(e) {}
                try { add(item.controlBounds); } catch(e) {}
                return result;
            };

            var isClipItem = function(item) {
                try {
                    if (!item) return false;
                    if (item.clipping === true) return true;
                    if (item.typename === "CompoundPathItem" && item.pathItems && item.pathItems.length > 0 && item.pathItems[0].clipping) return true;
                } catch (e) {}
                return false;
            };

            var countDirectRenderableChildren = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return 0;
                var count = 0;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (isClipItem(child)) continue;
                        if (child.guides) continue;
                        if (child.typename === "PathItem" || child.typename === "CompoundPathItem" ||
                            child.typename === "GroupItem" || child.typename === "TextFrame" ||
                            child.typename === "RasterItem" || child.typename === "PlacedItem" ||
                            child.typename === "MeshItem") {
                            count++;
                        }
                    }
                } catch (e) {}
                return count;
            };

            var countNestedTextFrames = function(item) {
                if (!item) return 0;
                var count = 0;
                var walk = function(node) {
                    if (!node) return;
                    try {
                        if (node.typename === "TextFrame") {
                            count++;
                            return;
                        }
                        if (node.pageItems) {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };
                walk(item);
                return count;
            };

            var containsAnyRasterDescendant = function(item) {
                var found = false;
                var walk = function(node) {
                    if (!node || found) return;
                    try {
                        if (node.typename === "RasterItem" || node.typename === "PlacedItem" || node.typename === "MeshItem") {
                            found = true;
                            return;
                        }
                        if (node.pageItems) {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                walk(node.pageItems[i]);
                                if (found) return;
                            }
                        }
                    } catch (e) {}
                };
                walk(item);
                return found;
            };

            var unionTwoBounds = function(a, b) {
                if (!a) return b;
                if (!b) return a;
                return [
                    Math.min(a[0], b[0]),
                    Math.max(a[1], b[1]),
                    Math.max(a[2], b[2]),
                    Math.min(a[3], b[3])
                ];
            };

            var getUnclippedChildrenBounds = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return null;
                var result = null;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (isClipItem(child)) continue;
                        var b = null;
                        try {
                            if (child.typename === "GroupItem") {
                                b = getUnclippedChildrenBounds(child);
                                if (!b && child.geometricBounds) {
                                    b = [child.geometricBounds[0], child.geometricBounds[1], child.geometricBounds[2], child.geometricBounds[3]];
                                }
                            } else if (child.geometricBounds) {
                                b = [child.geometricBounds[0], child.geometricBounds[1], child.geometricBounds[2], child.geometricBounds[3]];
                            }
                        } catch (e) {}
                        result = unionTwoBounds(result, b);
                    }
                } catch (e) {}
                return result;
            };

            var findLargestDirectClippedChild = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return null;
                var best = null;
                var bestArea = -1;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename !== "GroupItem" || !child.clipped) continue;
                        var b = getItemOuterBounds(child);
                        var a = boundsArea(b);
                        if (a > bestArea) {
                            bestArea = a;
                            best = child;
                        }
                    }
                } catch (e) {}
                return best;
            };

            var countDirectClippedChildren = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return 0;
                var count = 0;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename === "GroupItem" && child.clipped) count++;
                    }
                } catch (e) {}
                return count;
            };

            var collectDirectChildClippedGroups = function(group) {
                var groups = [];
                if (!group || group.typename !== "GroupItem" || !group.pageItems) return groups;
                try {
                    for (var i = 0; i < group.pageItems.length; i++) {
                        var child = group.pageItems[i];
                        if (child.typename === "GroupItem" && child.clipped) groups.push(child);
                    }
                } catch (e) {}
                return groups;
            };

            var findDominantDirectOutlineItem = function(group) {
                var largest = findLargestDirectOutlineItem(group);
                if (!largest) return null;
                try {
                    var largestArea = getItemArea(largest);
                    var groupBounds = getItemOuterBounds(group);
                    var groupArea = boundsArea(groupBounds);
                    if (largestArea > 0 && groupArea > 0 && largestArea > groupArea * 0.6) {
                        return largest;
                    }
                } catch (e) {}
                return null;
            };

            var chooseParentExportContainer = function(item) {
                try {
                    if (!item || !item.parent || item.parent.typename !== "GroupItem") return null;
                    var parent = item.parent;
                    if (parent.clipped) return null;
                    var parentBounds = getItemOuterBounds(parent);
                    var selfBounds = getItemOuterBounds(item);
                    if (boundsArea(parentBounds) <= 0 || boundsArea(selfBounds) <= 0) return null;
                    if (boundsArea(parentBounds) <= boundsArea(selfBounds) * 1.05) return null;
                    if (countDirectClippedChildren(parent) > 1) return null;
                    return parent;
                } catch (e) {
                    return null;
                }
            };

            var countDescendantClippedGroups = function(group) {
                var count = 0;
                var walk = function(node) {
                    if (!node || node.typename !== "GroupItem") return;
                    try {
                        if (node.clipped) count++;
                        if (node.pageItems) {
                            for (var i = 0; i < node.pageItems.length; i++) {
                                if (node.pageItems[i].typename === "GroupItem") walk(node.pageItems[i]);
                            }
                        }
                    } catch (e) {}
                };
                walk(group);
                return count;
            };

            var chooseAncestorExportContainer = function(item) {
                try {
                    if (!item) return null;
                    var selfBounds = getItemOuterBounds(item);
                    var selfArea = boundsArea(selfBounds);
                    if (selfArea <= 0) return null;
                    var node = item.parent;
                    while (node && node.typename === "GroupItem") {
                        var ancestorBounds = getItemOuterBounds(node);
                        var ancestorArea = boundsArea(ancestorBounds);
                        if (ancestorArea > selfArea * 1.05) {
                            if (countDescendantClippedGroups(node) <= 1) {
                                return node;
                            }
                            return null;
                        }
                        node = node.parent;
                    }
                } catch (e) {}
                return null;
            };

            var chooseOutermostClippedAncestor = function(item) {
                var best = item;
                try {
                    if (!item || item.typename !== "GroupItem" || !item.clipped) return item;
                    var node = item.parent;
                    while (node && node.typename === "GroupItem") {
                        if (node.clipped) {
                            best = node;
                            node = node.parent;
                            continue;
                        }
                        break;
                    }
                } catch (e) {}
                return best;
            };

            var shouldSplitLargeOuterClipContainer = function(group) {
                if (!group || group.typename !== "GroupItem" || !group.clipped) return false;
                var mask = getPrimaryDirectClipItem(group);
                if (!mask || mask.typename !== "PathItem") return false;
                var gb = getGroupOwnBounds(group);
                if (!gb) return false;
                var groupArea = boundsArea(gb);
                var maskArea = getItemArea(mask);
                if (groupArea <= 0 || maskArea <= 0) return false;
                var coverage = Math.min(
                    Math.abs(mask.geometricBounds[2] - mask.geometricBounds[0]) / Math.max(0.01, Math.abs(gb[2] - gb[0])),
                    Math.abs(mask.geometricBounds[1] - mask.geometricBounds[3]) / Math.max(0.01, Math.abs(gb[1] - gb[3]))
                );
                var maskW = Math.abs(mask.geometricBounds[2] - mask.geometricBounds[0]);
                var maskH = Math.abs(mask.geometricBounds[1] - mask.geometricBounds[3]);
                var isLargeSheet = maskW > 250 && maskH > 150;
                return coverage > 0.85 && (isLargeSheet || countDirectRenderableChildren(group) >= 2 || countNestedTextFrames(group) >= 2);
            };

            var chooseOuterMaskForClippedGroup = function(group) {
                var clipMask = getPrimaryDirectClipItem(group);
                if (!clipMask) clipMask = findBestMaskForGroup(group);

                var outerOutline = findLargestDirectOutlineItem(group);
                if (!outerOutline) return clipMask;
                if (!clipMask) return outerOutline;

                var clipArea = getItemArea(clipMask);
                var outlineArea = getItemArea(outerOutline);

                // 有些文件是“外层白框 + 内层图片剪切框”：真正用于 C4D 的尺寸应取外层白框。
                if (outlineArea > 0 && clipArea > 0 && outlineArea > clipArea * 1.05) {
                    return outerOutline;
                }
                return clipMask;
            };

            var chooseExportBoundsForClippedGroup = function(group, maskItem) {
                var maskBounds = maskItem ? getTightBounds(maskItem) : null;
                var tightGroupBounds = getTightBounds(group);
                var outerGroupBounds = getItemOuterBounds(group);
                var contentBounds = getUnclippedChildrenBounds(group);
                var bestBounds = tightGroupBounds;
                if (boundsArea(outerGroupBounds) > boundsArea(bestBounds)) bestBounds = outerGroupBounds;
                if (boundsArea(contentBounds) > boundsArea(bestBounds)) bestBounds = contentBounds;
                if (!bestBounds) return maskBounds ? maskBounds : getTightBounds(group);
                if (!maskBounds) return bestBounds;

                var gArea = boundsArea(bestBounds);
                var mArea = boundsArea(maskBounds);
                if (gArea > 0 && mArea > 0 && gArea > mArea * 1.02) {
                    return bestBounds;
                }
                return maskBounds;
            };

            var mergeSegArrays = function(segArrays) {
                var merged = [];
                var seen = {};
                for (var i = 0; i < segArrays.length; i++) {
                    var arr = segArrays[i];
                    if (!arr || arr.length === 0) continue;
                    for (var j = 0; j < arr.length; j++) {
                        var seg = arr[j];
                        if (!seg || seg === "") continue;
                        var key = String(seg);
                        if (seen[key]) continue;
                        seen[key] = true;
                        merged.push(seg);
                    }
                }
                return merged;
            };

            var getPts = function(pth) {
                var pp = pth.pathPoints; if (!pp || pp.length < 2) return "";
                var arr =[];
                for (var i=0; i<pp.length; i++) {
                    var pt=pp[i];
                    var ax=Math.round(pt.anchor[0]*100)/100, ay=Math.round(-pt.anchor[1]*100)/100;
                    var ix=Math.round(pt.leftDirection[0]*100)/100, iy=Math.round(-pt.leftDirection[1]*100)/100;
                    var ox=Math.round(pt.rightDirection[0]*100)/100, oy=Math.round(-pt.rightDirection[1]*100)/100;
                    arr.push('{"a":['+ax+','+ay+'],"inT":['+ix+','+iy+'],"outT":['+ox+','+oy+']}');
                }
                return "[" + arr.join(",") + "]";
            };

            var getSegsFromItem = function(obj) {
                var segs =[];
                if (!obj) return segs;

                if (obj.typename === "TextFrame") {
                    try {
                        var dup = obj.duplicate(doc.layers[0], ElementPlacement.PLACEATBEGINNING);
                        dup.clipping = false; 
                        dup.hidden = false;
                        dup.locked = false;
                        var out = dup.createOutline(); 
                        var pths = collectAllPaths(out);
                        for (var i=0; i<pths.length; i++) {
                            var p = getPts(pths[i]);
                            if (p) segs.push(p);
                        }
                        out.remove(); 
                    } catch(e) {}
                } else {
                    var pths = collectAllPaths(obj);
                    for (var j=0; j<pths.length; j++) {
                        var p2 = getPts(pths[j]);
                        if (p2) segs.push(p2);
                    }
                }
                return segs;
            };

            var getOutermostPathItem = function(item) {
                if (!item) return null;
                if (item.typename === "PathItem") return item;
                if (item.typename === "CompoundPathItem" && item.pathItems && item.pathItems.length > 0) {
                    var best = null;
                    var bestArea = -1;
                    for (var i = 0; i < item.pathItems.length; i++) {
                        try {
                            var p = item.pathItems[i];
                            var b = p.geometricBounds;
                            if (!b) continue;
                            var area = Math.abs(b[2] - b[0]) * Math.abs(b[1] - b[3]);
                            if (area > bestArea) {
                                bestArea = area;
                                best = p;
                            }
                        } catch (e) {}
                    }
                    return best;
                }
                return null;
            };

            var getPrimaryClipSegs = function(item) {
                var segs = [];
                var outer = getOutermostPathItem(item);
                if (!outer) return segs;
                var seg = getPts(outer);
                if (seg) segs.push(seg);
                return segs;
            };

            var collectAllPaths = function(item) {
                var paths =[];
                if (!item) return paths;
                if (item.typename === "PathItem") { paths.push(item); } 
                else if (item.typename === "CompoundPathItem") { 
                    for (var i = 0; i < item.pathItems.length; i++) { paths.push(item.pathItems[i]); } 
                } 
                else if (item.typename === "GroupItem") { 
                    for (var j = 0; j < item.pageItems.length; j++) { paths = paths.concat(collectAllPaths(item.pageItems[j])); } 
                }
                return paths;
            };

            var collectChildClippedGroups = function(group) {
                var groups = [];
                if (!group || group.typename !== "GroupItem") return groups;

                var walk = function(node, isRoot) {
                    if (!node || node.typename !== "GroupItem") return;
                    try {
                        if (!isRoot && node.clipped) {
                            groups.push(node);
                            return;
                        }
                        for (var i = 0; i < node.pageItems.length; i++) {
                            if (node.pageItems[i].typename === "GroupItem") {
                                walk(node.pageItems[i], false);
                            }
                        }
                    } catch (e) {}
                };

                walk(group, true);
                return groups;
            };

            var calcLargestPathCoverageForBounds = function(baseBounds, item) {
                if (!baseBounds || !item) return 0;
                var paths = collectAllPaths(item);
                if (!paths || paths.length === 0) return 0;
                var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                var best = 0;

                for (var i = 0; i < paths.length; i++) {
                    try {
                        var b = getTightBounds(paths[i]);
                        if (!b) continue;
                        var wRatio = Math.abs(b[2] - b[0]) / baseW;
                        var hRatio = Math.abs(b[1] - b[3]) / baseH;
                        var coverage = Math.min(wRatio, hRatio);
                        if (coverage > best) best = coverage;
                    } catch (e) {}
                }
                return best;
            };

	            var unionBounds = function(boundsList) {
	                if (!boundsList || boundsList.length === 0) return null;
                var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                var found = false;
                for (var i = 0; i < boundsList.length; i++) {
                    var b = boundsList[i];
                    if (!b || b.length < 4) continue;
                    found = true;
                    if (b[0] < left) left = b[0];
                    if (b[1] > top) top = b[1];
                    if (b[2] > right) right = b[2];
                    if (b[3] < bottom) bottom = b[3];
                }
	                return found ? [left, top, right, bottom] : null;
	            };

		            var containsFallbackDescendant = function(item) {
		                var found = false;
	                var walk = function(node) {
	                    if (!node || found) return;
	                    try {
	                        if (tools.getFallbackExport(node.name)) {
	                            found = true;
	                            return;
	                        }
	                        if (node.pageItems) {
	                            for (var i = 0; i < node.pageItems.length; i++) {
	                                walk(node.pageItems[i]);
	                                if (found) return;
	                            }
	                        }
	                    } catch(e) {}
	                };
		                walk(item);
		                return found;
		            };

		            var containsFallbackReverseDescendant = function(item) {
		                var found = false;
		                var walk = function(node) {
		                    if (!node || found) return;
		                    try {
		                        if (tools.getFallbackReverse(node.name)) {
		                            found = true;
		                            return;
		                        }
		                        if (node.pageItems) {
		                            for (var i = 0; i < node.pageItems.length; i++) {
		                                walk(node.pageItems[i]);
		                                if (found) return;
		                            }
		                        }
		                    } catch(e) {}
		                };
		                walk(item);
		                return found;
		            };

            var scan = function(item, parentSuffix, groupName, parentFallbackExport, parentFallbackReverse) {
                try {
                    if (item && item.layer && item.layer.name === "HH_FALLBACK_PREVIEW") return;
                } catch(e) {}
                var mySuffix = tools.getFullSuffix(item.name);
                var effectiveSuffix = mySuffix ? mySuffix : parentSuffix;
                var effectiveFallbackExport = tools.getFallbackExport(item.name) || !!parentFallbackExport || containsFallbackDescendant(item);
                var effectiveFallbackReverse = tools.getFallbackReverse(item.name) || !!parentFallbackReverse || containsFallbackReverseDescendant(item);

                if (item.typename === "GroupItem") {
                    var shouldFlatten = item.clipped;
                    if (!shouldFlatten) {
                        for (var cx = 0; cx < item.pageItems.length; cx++) {
                            var child = item.pageItems[cx];
                            if ((child.typename === "GroupItem" && child.clipped) ||
                                child.typename === "RasterItem" ||
                                child.typename === "PlacedItem" ||
                                child.typename === "MeshItem") {
                                shouldFlatten = true;
                                break;
                            }
                        }
                    }

                    if (shouldFlatten) {
                        var rawName = tools.getPureName(item.name) || "Clip_" + (globalClipCounter++);
                        var safeName = tools.cleanName(rawName + effectiveSuffix);
                        var foundColor = tools.findDeepColor(item) || [128, 128, 128];

                        var maskItem = null;
                        if (item.clipped) {
                            for (var i = 0; i < item.pageItems.length; i++) {
                                if (item.pageItems[i].clipping) { maskItem = item.pageItems[i]; break; }
                            }
                            if (!maskItem) {
                                for (var j = 0; j < item.pageItems.length; j++) {
                                    var cp = item.pageItems[j];
                                    if (cp.typename === "CompoundPathItem" && cp.pathItems && cp.pathItems.length > 0 && cp.pathItems[0].clipping) {
                                        maskItem = cp;
                                        break;
                                    }
                                }
                            }
                            if (!maskItem && item.pageItems.length > 0) maskItem = item.pageItems[0];
                        }

                        if (mode !== "curves") {
                            imgList.push({ item: item, name: safeName });
                        }
                        if (mode !== "images") {
                            var finalBounds = getTightBounds(item);
	                            scanList.push({
	                                name: safeName,
	                                group: groupName,
	                                color: foundColor,
	                                isMask: true,
	                                bounds: finalBounds,
	                                source: maskItem ? maskItem : item,
	                                maskSource: maskItem,
	                                isGroup: true,
	                                refItem: item,
		                                hasRasterDescendant: containsAnyRasterDescendant(item),
		                                exportMode: item.clipped ? "single_clipped_group" : "flatten_group_children",
		                                fallbackExport: effectiveFallbackExport,
		                                fallbackReverse: effectiveFallbackReverse
		                            });
                        }
                        return;
                    }

                    for (var k = 0; k < item.pageItems.length; k++) {
                        scan(item.pageItems[k], effectiveSuffix, groupName, effectiveFallbackExport, effectiveFallbackReverse);
                    }
                }
                else if (item.typename === "TextFrame") {
                    if (mode !== "images") {
                        var rawTxt = tools.getPureName(item.name) || "Text_" + (globalObjCounter++);
                        var safeTxt = tools.cleanName(rawTxt + effectiveSuffix);
                        var txtColor =[128, 128, 128];
                        try {
                            if (item.textRange && item.textRange.characterAttributes && item.textRange.characterAttributes.fillColor) {
                                var tc = tools.parseColor(item.textRange.characterAttributes.fillColor);
                                if (tc) txtColor = tc;
                            }
                        } catch(e) {}
                        
                        scanList.push({
                            name: safeTxt, group: groupName, color: txtColor, isMask: false, source: item, fallbackExport: effectiveFallbackExport, fallbackReverse: effectiveFallbackReverse
                        });
                    }
                }
                else if (item.typename === "RasterItem" || item.typename === "PlacedItem" || item.typename === "MeshItem") {
                    if (mode !== "curves") {
                        var rawNameImg = tools.getPureName(item.name) || "Img_" + (globalObjCounter++);
                        var safeNameImg = tools.cleanName(rawNameImg + effectiveSuffix);
                        imgList.push({item: item, name: safeNameImg});
                    }
                }
                else if (item.typename === "PathItem" || item.typename === "CompoundPathItem") {
                    if (item.typename==="PathItem" && item.guides) return; 
                    if (mode !== "images") {
                        var raw2 = tools.getPureName(item.name) || "Obj_" + (globalObjCounter++);
                        var safe2 = tools.cleanName(raw2 + effectiveSuffix);
                        var c = tools.getRGB(item) ||[128, 128, 128];
                        scanList.push({
                            name: safe2, group: groupName, color: c, isMask: false, source: item, fallbackExport: effectiveFallbackExport, fallbackReverse: effectiveFallbackReverse
                        });
                    }
                }
            };

            try {
	                for (var s = 0; s < sel.length; s++) {
	                    var root = sel[s];
	                    var rootFallback = tools.getFallbackExport(root.name);
	                    var rootReverse = tools.getFallbackReverse(root.name);
	                    var rootSuffix = tools.getFullSuffix(root.name);
	                    var pure = tools.getPureName(root.name);
	                    if (!pure || pure.indexOf("Part_") === -1) { pure = "Part_" + (s + 1); }
	                    try { root.name = pure + rootSuffix + (rootFallback ? "_fb" : "") + (rootReverse ? "_fbr" : ""); } catch(e) {}
	                    scan(root, rootSuffix, pure, rootFallback, rootReverse);
	                }

                // =======================================================
                // 3. 图片导出 (使用 getTightBounds，完美去白边裁切)
                // =======================================================
                if (imgList.length > 0) {
                    var exportScale = (dpi / 72.0) * 100.0;
                    if (exportScale > 776.0) exportScale = 776.0;

                    var opts, type;
                    if (format === "png") {
                        opts = new ExportOptionsPNG24(); 
                        opts.antiAliasing = true; opts.transparency = true; opts.artBoardClipping = true; 
                        opts.horizontalScale = exportScale; opts.verticalScale = exportScale;
                        type = ExportType.PNG24;
                    } else {
                        opts = new ExportOptionsJPEG(); 
                        opts.antiAliasing = true; opts.artBoardClipping = true; opts.qualitySetting = 100; 
                        opts.horizontalScale = exportScale; opts.verticalScale = exportScale;
                        type = ExportType.JPEG;
                    }
                    
                    var exportDoc = app.documents.add(doc.documentColorSpace);
                    var exportLayer = exportDoc.layers[0];
                    var defringe = 0.5;

                    var exportedTextureNames = [];
                    for (var k = 0; k < imgList.length; k++) {
                        var task = imgList[k];
                        var originalItem = task.item;
                        try {
                            var tempDup = originalItem.duplicate(originalItem, ElementPlacement.PLACEBEFORE);
                            
                            // 【脱水边界】：此处的 bakeBounds 是精准脱水的墨水边界，完美剪裁
	                            var bakeBounds = task.bounds ? task.bounds : getTightBounds(originalItem);
                            var tightW = bakeBounds[2] - bakeBounds[0];
                            var tightH = bakeBounds[1] - bakeBounds[3];
                            
                            var rastOpts = new RasterizeOptions();
                            rastOpts.resolution = dpi; 
                            rastOpts.transparency = true; 
                            rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                            rastOpts.convertSpotColors = true; 
                            rastOpts.convertTextToOutlines = false; 
                            
                            var bakedItem = doc.rasterize(tempDup, bakeBounds, rastOpts);
                            var exportedItem = bakedItem.duplicate(exportLayer, ElementPlacement.PLACEATEND);
                            bakedItem.remove(); 
                            
                            var finalW = tightW - defringe;
                            var finalH = tightH - defringe;
                            if (finalW < 1) finalW = tightW; 
                            if (finalH < 1) finalH = tightH;

                            exportDoc.artboards[0].artboardRect =[0, 0, finalW, -finalH];
                            
                            var itemCenter =[exportedItem.left + exportedItem.width/2, exportedItem.top - exportedItem.height/2];
                            var boardCenter =[finalW/2, -finalH/2];
                            exportedItem.translate(boardCenter[0] - itemCenter[0], boardCenter[1] - itemCenter[1]);
                            
                            var finalFile = new File(texFolder.fsName + "/" + task.name + "." + format);
                            var fIdx = 1;
                            var actualName = task.name;
                            
                            // 如果名字重复了，自动加 _1, _2 后缀
                            while(finalFile.exists) { 
                                actualName = task.name + "_" + fIdx;
                                finalFile = new File(texFolder.fsName + "/" + actualName + "." + format); 
                                fIdx++; 
                            }
                            
                            // ===== 核心修复：如果防重复改了文件名，立刻同步通知 JSON 更新名字 =====
	                            if (actualName !== task.name) {
	                                for (var sl = 0; sl < scanList.length; sl++) {
	                                    if (scanList[sl].name === task.name || scanList[sl].refItem === originalItem || scanList[sl].source === originalItem) {
	                                        scanList[sl].name = actualName;
	                                    }
	                                }
                                task.name = actualName; // 更新当前贴图任务的名字
                            }
                            // ==========================================================
                            
                            exportDoc.exportFile(finalFile, type, opts);
                            exportedTextureNames.push(finalFile.name);
                            imgCount++;
                            exportedItem.remove();
                        } catch(e) {}
                    }
                    exportDoc.close(SaveOptions.DONOTSAVECHANGES);
                }

                // =======================================================
                // 4. JSON 导出 (完美穿透提取文字笔画)
                // =======================================================
                if (scanList.length > 0) {
                    var makeRect = function(b) {
                        var L=b[0],T=b[1],R=b[2],B=b[3];
                        var f=function(u,v){return '{"a":['+(Math.round(u*100)/100)+','+(Math.round(-v*100)/100)+']}';};
                        return '[['+f(L,T)+','+f(R,T)+','+f(R,B)+','+f(L,B)+']]';
                    };

                    var calcBoundsCoverage = function(baseBounds, items) {
                        if (!baseBounds || !items || items.length === 0) return 0;
                        var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                        var found = false;
                        for (var i = 0; i < items.length; i++) {
                            try {
                                var b = getTightBounds(items[i]);
                                if (!b) continue;
                                found = true;
                                left = Math.min(left, b[0]);
                                top = Math.max(top, b[1]);
                                right = Math.max(right, b[2]);
                                bottom = Math.min(bottom, b[3]);
                            } catch(e) {}
                        }
                        if (!found) return 0;
                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var curW = Math.max(0.0, Math.abs(right - left));
                        var curH = Math.max(0.0, Math.abs(top - bottom));
                        var wRatio = curW / baseW;
                        var hRatio = curH / baseH;
                        return Math.min(wRatio, hRatio);
                    };

// --- 开始插入：找回 28.37 的群组深入遍历方法 ---
                    var collectInternalMasks = function(item) {
                        var masks = [];
                        var seen = {};

                        var addMask = function(maskItem) {
                            if (!maskItem) return;
                            try {
                                var key = maskItem.typename + "|" + maskItem.name + "|" + String(maskItem.pageItems ? maskItem.pageItems.length : maskItem.pathPoints ? maskItem.pathPoints.length : 0);
                                if (seen[key]) return;
                                seen[key] = true;
                            } catch(e) {}
                            masks.push(maskItem);
                        };

                        var walk = function(node) {
                            if (!node || node.typename !== "GroupItem") return;
                            if (node.clipped) {
                                var m = null;
                                try {
                                    for (var i = 0; i < node.pageItems.length; i++) {
                                        if (node.pageItems[i].clipping) { m = node.pageItems[i]; break; }
                                    }
                                    if (!m) {
                                        for (var j = 0; j < node.pageItems.length; j++) {
                                            var child = node.pageItems[j];
                                            if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0 && child.pathItems[0].clipping) {
                                                m = child;
                                                break;
                                            }
                                        }
                                    }
                                } catch(e) {}
                                addMask(m);
                            }
                            for (var k = 0; k < node.pageItems.length; k++) {
                                if (node.pageItems[k].typename === "GroupItem") {
                                    walk(node.pageItems[k]);
                                }
                            }
                        };

                        walk(item);
                        return masks;
                    };

                    var calcLargestPathCoverage = function(baseBounds, item) {
                        if (!baseBounds || !item) return 0;
                        var paths = collectAllPaths(item);
                        if (!paths || paths.length === 0) return 0;

                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var best = 0;

                        for (var i = 0; i < paths.length; i++) {
                            try {
                                var b = getTightBounds(paths[i]);
                                if (!b) continue;
                                var wRatio = Math.abs(b[2] - b[0]) / baseW;
                                var hRatio = Math.abs(b[1] - b[3]) / baseH;
                                var coverage = Math.min(wRatio, hRatio);
                                if (coverage > best) best = coverage;
                            } catch(e) {}
                        }
                        return best;
                    };

                    var parseSegPoints = function(segText) {
                        if (!segText || segText === "") return [];
                        try { return eval("(" + segText + ")"); } catch (e) {}
                        return [];
                    };

                    var calcSegArrayMetrics = function(baseBounds, segArrays) {
                        var result = { unionCoverage: 0, totalCoverage: 0, largestCoverage: 0 };
                        if (!baseBounds || !segArrays || segArrays.length === 0) return result;
                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var baseArea = Math.max(0.01, baseW * baseH);
                        var left = 9999999999, top = -9999999999, right = -9999999999, bottom = 9999999999;
                        var found = false;
                        var totalArea = 0;

                        for (var sa = 0; sa < segArrays.length; sa++) {
                            var pts = parseSegPoints(segArrays[sa]);
                            if (!pts || pts.length === 0) continue;
                            var sLeft = 9999999999, sTop = -9999999999, sRight = -9999999999, sBottom = 9999999999;
                            var segFound = false;
                            for (var sp = 0; sp < pts.length; sp++) {
                                if (!pts[sp] || !pts[sp].a) continue;
                                segFound = true;
                                found = true;
                                var ax = pts[sp].a[0], ay = pts[sp].a[1];
                                if (ax < sLeft) sLeft = ax;
                                if (ax > sRight) sRight = ax;
                                if (ay > sTop) sTop = ay;
                                if (ay < sBottom) sBottom = ay;
                            }
                            if (!segFound) continue;
                            if (sLeft < left) left = sLeft;
                            if (sRight > right) right = sRight;
                            if (sTop > top) top = sTop;
                            if (sBottom < bottom) bottom = sBottom;

                            var curW = Math.max(0, sRight - sLeft);
                            var curH = Math.max(0, sTop - sBottom);
                            var curArea = curW * curH;
                            totalArea += curArea;
                            var curLargest = Math.min(curW / baseW, curH / baseH);
                            if (curLargest > result.largestCoverage) result.largestCoverage = curLargest;
                        }

                        if (!found) return result;
                        var unionW = Math.max(0, right - left);
                        var unionH = Math.max(0, top - bottom);
                        result.unionCoverage = Math.min(unionW / baseW, unionH / baseH);
                        result.totalCoverage = Math.min(1, totalArea / baseArea);
                        return result;
                    };

                    var analyzeStandardSegments = function(baseBounds, segArrays) {
                        var result = {
                            segmentCount: 0,
                            unionCoverage: 0,
                            totalCoverage: 0,
                            largestCoverage: 0,
                            largestArea: 0,
                            secondLargestArea: 0,
                            medianArea: 0,
                            areaUniformity: 0,
                            smallSegmentCount: 0,
                            smallSegmentRatio: 0,
                            hasLargeBoardLikePath: false,
                            looksLikeMissingMainShape: false
                        };
                        if (!baseBounds || !segArrays || segArrays.length === 0) return result;

                        var baseW = Math.max(0.01, Math.abs(baseBounds[2] - baseBounds[0]));
                        var baseH = Math.max(0.01, Math.abs(baseBounds[1] - baseBounds[3]));
                        var baseArea = Math.max(0.01, baseW * baseH);
                        var metrics = calcSegArrayMetrics(baseBounds, segArrays);
                        result.unionCoverage = metrics.unionCoverage;
                        result.totalCoverage = metrics.totalCoverage;
                        result.largestCoverage = metrics.largestCoverage;

                        var areas = [];
                        for (var sa = 0; sa < segArrays.length; sa++) {
                            var pts = parseSegPoints(segArrays[sa]);
                            if (!pts || pts.length === 0) continue;
                            var sLeft = 9999999999, sTop = -9999999999, sRight = -9999999999, sBottom = 9999999999;
                            var segFound = false;
                            for (var sp = 0; sp < pts.length; sp++) {
                                if (!pts[sp] || !pts[sp].a) continue;
                                segFound = true;
                                var ax = pts[sp].a[0], ay = pts[sp].a[1];
                                if (ax < sLeft) sLeft = ax;
                                if (ax > sRight) sRight = ax;
                                if (ay > sTop) sTop = ay;
                                if (ay < sBottom) sBottom = ay;
                            }
                            if (!segFound) continue;
                            var curW = Math.max(0, sRight - sLeft);
                            var curH = Math.max(0, sTop - sBottom);
                            var curArea = curW * curH;
                            var curCoverage = Math.min(curW / baseW, curH / baseH);
                            areas.push(curArea);
                            result.segmentCount++;
                            if (curCoverage < 0.08) result.smallSegmentCount++;
                        }

                        if (areas.length > 0) {
                            areas.sort(function(a, b) { return b - a; });
                            result.largestArea = areas[0];
                            result.secondLargestArea = areas.length > 1 ? areas[1] : 0;
                            result.medianArea = areas[Math.floor(areas.length / 2)];
                            result.areaUniformity = result.largestArea / Math.max(0.01, result.medianArea);
                        }
                        if (result.segmentCount > 0) {
                            result.smallSegmentRatio = result.smallSegmentCount / result.segmentCount;
                        }

                        if (result.segmentCount === 1 && result.largestCoverage > 0.75) {
                            result.hasLargeBoardLikePath = true;
                        } else if (result.secondLargestArea > 0 && (result.largestArea / Math.max(0.01, result.secondLargestArea)) > 8 && result.largestCoverage > 0.55) {
                            result.hasLargeBoardLikePath = true;
                        }

                        if (!result.hasLargeBoardLikePath &&
                            result.largestCoverage < 0.18 &&
                            result.unionCoverage < 0.45 &&
                            result.segmentCount > 0 &&
                            result.segmentCount < 18 &&
                            result.smallSegmentRatio >= 0.55 &&
                            result.areaUniformity > 1.8) {
                            result.looksLikeMissingMainShape = true;
                        }

                        return result;
                    };

                    var findPrimaryClipItem = function(group) {
                        if (!group || group.typename !== "GroupItem") return null;
                        try {
                            for (var i = 0; i < group.pageItems.length; i++) {
                                if (group.pageItems[i].clipping === true) return group.pageItems[i];
                            }
                            for (var j = 0; j < group.pageItems.length; j++) {
                                var child = group.pageItems[j];
                                if (child.typename === "CompoundPathItem" && child.pathItems && child.pathItems.length > 0 && child.pathItems[0].clipping) {
                                    return child;
                                }
                            }
                        } catch(e) {}
                        return null;
                    };

                    var traceGroupSilhouette = function(item, bounds) {
                        var segs = [];
                        var dup = null;
                        var raster = null;
                        var traced = null;
                        var expanded = null;
                        var fillRect = null;
                        if (!item || item.typename !== "GroupItem" || !bounds) return segs;

                        try {
                            dup = item.duplicate(tempLayer, ElementPlacement.PLACEATBEGINNING);
                            dup.hidden = false;
                            dup.locked = false;

                            var clipItem = findPrimaryClipItem(dup);
                            if (!clipItem) {
                                if (dup) dup.remove();
                                return segs;
                            }

                            var toRemove = [];
                            for (var i = 0; i < dup.pageItems.length; i++) {
                                if (dup.pageItems[i] !== clipItem) toRemove.push(dup.pageItems[i]);
                            }
                            for (var r = 0; r < toRemove.length; r++) {
                                try { toRemove[r].remove(); } catch(e) {}
                            }

                            var b = bounds;
                            var left = b[0] - 2;
                            var top = b[1] + 2;
                            var width = Math.max(1, (b[2] - b[0]) + 4);
                            var height = Math.max(1, (b[1] - b[3]) + 4);

                            fillRect = doc.pathItems.rectangle(top, left, width, height);
                            fillRect.stroked = false;
                            fillRect.filled = true;
                            var black = new RGBColor();
                            black.red = 0; black.green = 0; black.blue = 0;
                            fillRect.fillColor = black;
                            fillRect.move(dup, ElementPlacement.PLACEATEND);

                            var rastOpts = new RasterizeOptions();
                            rastOpts.resolution = 300;
                            rastOpts.transparency = true;
                            rastOpts.antiAliasingMethod = AntiAliasingMethod.ARTOPTIMIZED;
                            rastOpts.convertSpotColors = true;
                            rastOpts.convertTextToOutlines = false;

                            raster = doc.rasterize(dup, bounds, rastOpts);
                            if (!raster) {
                                if (dup) dup.remove();
                                return segs;
                            }

                            traced = raster.trace();
                            try {
                                var tracingPresets = app.tracingPresetsList;
                                if (tracingPresets && tracingPresets.length > 0) {
                                    traced.tracing.tracingOptions.loadFromPreset(tracingPresets[3] || tracingPresets[0]);
                                }
                            } catch(e) {}
                            app.redraw();

                            try {
                                expanded = traced.tracing.expandTracing();
                            } catch(e) {
                                expanded = traced;
                            }
                            app.redraw();

                            var tracedPaths = collectAllPaths(expanded);
                            var filteredPaths = [];
                            var candidates = [];
                            var baseW = Math.max(0.01, Math.abs(bounds[2] - bounds[0]));
                            var baseH = Math.max(0.01, Math.abs(bounds[1] - bounds[3]));
                            var hasInnerLarge = false;

                            for (var tp = 0; tp < tracedPaths.length; tp++) {
                                try {
                                    var pb = getTightBounds(tracedPaths[tp]);
                                    if (!pb) continue;
                                    var wRatio = Math.abs(pb[2] - pb[0]) / baseW;
                                    var hRatio = Math.abs(pb[1] - pb[3]) / baseH;
                                    var coverage = Math.min(wRatio, hRatio);
                                    candidates.push({ path: tracedPaths[tp], coverage: coverage });
                                    if (coverage >= 0.55 && coverage < 0.98) hasInnerLarge = true;
                                } catch(e) {}
                            }

                            for (var ci = 0; ci < candidates.length; ci++) {
                                if (hasInnerLarge && candidates[ci].coverage >= 0.98) continue;
                                filteredPaths.push(candidates[ci].path);
                            }

                            if (filteredPaths.length === 0) filteredPaths = tracedPaths;
                            for (var fp = 0; fp < filteredPaths.length; fp++) {
                                var p = getPts(filteredPaths[fp]);
                                if (p) segs.push(p);
                            }
                        } catch(e) {
                            segs = [];
                        }

                        try { if (expanded && expanded !== traced) expanded.remove(); } catch(e) {}
                        try { if (traced) traced.remove(); } catch(e) {}
                        try { if (raster) raster.remove(); } catch(e) {}
                        try { if (dup) dup.remove(); } catch(e) {}
                        try { if (fillRect) fillRect.remove(); } catch(e) {}
                        return segs;
                    };

                    // --- 插入结束 ---

                    var calcLargestCoverageForItems = function(baseBounds, items) {
                        if (!baseBounds || !items || items.length === 0) return 0;
                        var best = 0;
                        for (var i = 0; i < items.length; i++) {
                            try {
                                var cov = calcLargestPathCoverage(baseBounds, items[i]);
                                if (cov > best) best = cov;
                            } catch(e) {}
                        }
                        return best;
                    };

                    var shouldUseFallbackExport = function(baseBounds, standardSegs, internalMasks) {
                        if (!standardSegs || standardSegs.length === 0) return true;
                        var segMetrics = calcSegArrayMetrics(baseBounds, standardSegs);
                        var maxMaskCoverage = calcLargestCoverageForItems(baseBounds, internalMasks);
                        if (segMetrics.totalCoverage < 0.18 && maxMaskCoverage < 0.35) return true;
                        return false;
                    };

                    var jsonItems =[];
                    var debugLines = [];
                    for (var j=0; j<scanList.length; j++) {
                        var d = scanList[j];
                        var segStr = "[]";
                        var debugMode = "none";
                        var debugCoverage = -1;
                        var largestCoverage = -1;
                        var debugSegmentCount = -1;
                        var debugSmallRatio = -1;
                        var debugAreaUniformity = -1;
                        var debugBoardLike = false;
                        var debugMissingMain = false;
                        var debugTraceSegmentCount = -1;
                        var debugUseTrace = false;
                        var debugFallbackSource = "standard";
                        var debugUsedWhiteFillPaths = false;
                        var debugExportUsesPreviewLogic = false;
                        var debugExportedRectFallback = false;
                        var debugWhitePathCount = -1;
                        var debugBlackPathCount = -1;
                        var debugPreviewLikeSegmentCount = -1;
                        var debugFallbackReverse = false;
                        var debugTargetColor = "white";

                        if (d.customSegments) {
                            debugMode = "group_custom_segments";
                            segStr = "[" + d.customSegments.join(",") + "]";
                        } else if (d.forceRectPath && d.bounds) {
                            debugMode = "outer_bounds_rect";
                            segStr = makeRect(d.bounds);
                        } else if (d.source) {
		                            if (d.isMask) {
	                                var allowFallback = enableFallback || !!d.fallbackExport;
		                                var standardSource = d.maskSource ? d.maskSource : d.source;
		                                var standardSegs = getSegsFromItem(standardSource);
	                                var standardAnalysis = analyzeStandardSegments(d.bounds, standardSegs);
                                largestCoverage = standardAnalysis.largestCoverage;
                                debugCoverage = standardAnalysis.unionCoverage;
                                debugSegmentCount = standardAnalysis.segmentCount;
                                debugSmallRatio = standardAnalysis.smallSegmentRatio;
                                debugAreaUniformity = standardAnalysis.areaUniformity;
                                debugBoardLike = standardAnalysis.hasLargeBoardLikePath;
                                debugMissingMain = standardAnalysis.looksLikeMissingMainShape;

	                                var shouldTraceRepair = false;
	                                var tracedSegsCache = [];
	                                var previewLikeFallback = null;
	                                if (!!d.fallbackExport && d.refItem && d.bounds) {
	                                    debugFallbackReverse = !!d.fallbackReverse;
	                                    debugTargetColor = debugFallbackReverse ? "black" : "white";
	                                    previewLikeFallback = buildFallbackTraceSegments(d.refItem, d.bounds, tempLayer, debugTargetColor);
	                                    debugWhitePathCount = previewLikeFallback.whitePathCount;
	                                    debugBlackPathCount = previewLikeFallback.blackPathCount;
	                                    debugPreviewLikeSegmentCount = previewLikeFallback.segmentCount;
	                                    if (previewLikeFallback.ok && previewLikeFallback.segments.length > 0) {
	                                        debugFallbackSource = debugTargetColor === "black" ? "previewLikeBlackFill" : "previewLikeWhiteFill";
	                                        debugUsedWhiteFillPaths = debugTargetColor === "white";
	                                        debugExportUsesPreviewLogic = true;
	                                    }
	                                }
	                                var nestedClippedCount = 0;
                                var isVectorOnlySingleClip = false;
                                var isVectorOnlyArtClip = false;
                                if (d.refItem && d.refItem.typename === "GroupItem") {
                                    nestedClippedCount = collectChildClippedGroups(d.refItem).length;
                                }
                                if (d.refItem && d.refItem.typename === "GroupItem" &&
                                    d.exportMode === "single_clipped_group" &&
                                    nestedClippedCount === 0) {
                                    isVectorOnlySingleClip = !d.hasRasterDescendant;
                                    isVectorOnlyArtClip = isVectorOnlySingleClip && countNestedTextFrames(d.refItem) === 0;
                                    var looksSuspicious = standardAnalysis.looksLikeMissingMainShape ||
                                        (isVectorOnlySingleClip &&
                                         standardAnalysis.segmentCount > 0 &&
                                         standardAnalysis.segmentCount <= 32 &&
                                         standardAnalysis.largestCoverage < 0.30) ||
                                        (standardAnalysis.segmentCount > 0 &&
                                         standardAnalysis.segmentCount <= 12 &&
                                         standardAnalysis.largestCoverage < 0.12 &&
                                         standardAnalysis.smallSegmentRatio >= 0.7);
	                                    if (allowFallback && looksSuspicious) {
                                        tracedSegsCache = traceGroupSilhouette(d.refItem, d.bounds);
                                        if (tracedSegsCache.length > 0) {
                                            var tracedAnalysis = analyzeStandardSegments(d.bounds, tracedSegsCache);
                                            debugTraceSegmentCount = tracedAnalysis.segmentCount;
                                            if (isVectorOnlyArtClip &&
                                                tracedAnalysis.segmentCount >= Math.max(standardAnalysis.segmentCount + 2, Math.ceil(standardAnalysis.segmentCount * 1.5))) {
                                                shouldTraceRepair = true;
                                            } else if (!tracedAnalysis.hasLargeBoardLikePath) {
                                                if (standardAnalysis.looksLikeMissingMainShape) {
                                                    shouldTraceRepair = true;
                                                } else if (isVectorOnlySingleClip &&
                                                           tracedAnalysis.segmentCount >= Math.max(standardAnalysis.segmentCount + 2, Math.ceil(standardAnalysis.segmentCount * 1.25))) {
                                                    shouldTraceRepair = true;
                                                } else if (isVectorOnlySingleClip &&
                                                           tracedAnalysis.largestCoverage > standardAnalysis.largestCoverage + 0.10) {
                                                    shouldTraceRepair = true;
                                                } else if (tracedAnalysis.segmentCount >= Math.max(standardAnalysis.segmentCount + 2, Math.ceil(standardAnalysis.segmentCount * 1.5))) {
                                                    shouldTraceRepair = true;
                                                } else if (standardAnalysis.segmentCount <= 2 && tracedAnalysis.segmentCount > standardAnalysis.segmentCount) {
                                                    shouldTraceRepair = true;
                                                }
                                            }
                                        }
                                    }
                                }

	                                if (previewLikeFallback && previewLikeFallback.ok && previewLikeFallback.segments.length > 0) {
	                                    debugMode = debugTargetColor === "black" ? "group_preview_like_black_fill_fallback" : "group_preview_like_white_fill_fallback";
	                                    debugUseTrace = true;
	                                    debugTraceSegmentCount = previewLikeFallback.segmentCount;
	                                    segStr = "[" + previewLikeFallback.segments.join(",") + "]";
	                                } else if (standardSegs.length > 0 && !shouldTraceRepair) {
	                                    debugMode = "group_standard_export";
	                                    segStr = "[" + standardSegs.join(",") + "]";
	                                } else if (allowFallback && tracedSegsCache.length > 0) {
                                    debugMode = "group_clip_trace_repair";
                                    debugUseTrace = true;
                                    segStr = "[" + tracedSegsCache.join(",") + "]";
	                                } else if (allowFallback && d.refItem && d.refItem.typename === "GroupItem" && standardSegs.length === 0) {
                                    var tracedSegs = traceGroupSilhouette(d.refItem, d.bounds);
                                    if (tracedSegs.length > 0) {
                                        debugMode = "group_clip_trace_repair";
                                        debugUseTrace = true;
                                        segStr = "[" + tracedSegs.join(",") + "]";
	                                    } else {
	                                        debugMode = "group_rect_bounds_only";
	                                        debugExportedRectFallback = true;
	                                        segStr = makeRect(d.bounds);
	                                    }
	                                } else if (standardSegs.length > 0) {
	                                    debugMode = "group_standard_export_fallback";
	                                    segStr = "[" + standardSegs.join(",") + "]";
		                                } else if (allowFallback) {
	                                    debugMode = "group_rect_bounds_only";
	                                    debugExportedRectFallback = true;
	                                    segStr = makeRect(d.bounds);
                                } else {
                                    debugMode = "group_standard_empty";
                                    segStr = "[]";
                                }
                            } else {
                                debugMode = "direct_source_paths";
                                var allSegs = getSegsFromItem(d.source);
                                if (allSegs.length > 0) {
                                    segStr = "[" + allSegs.join(",") + "]";
                                }
                            }
                        } else if (d.isMask) {
                            debugMode = "rect_bounds_only";
                            segStr = makeRect(d.bounds);
                        }

                        if (segStr === "[]" || segStr === "") continue;
                        var cStr = d.color ? '{"r":'+d.color[0]+',"g":'+d.color[1]+',"b":'+d.color[2]+'}' : "null";
                        
                        // ===== 新增：精准检测当前对象有没有真的带贴图 =====
                        var textureName = d.name;
                        var hasTex = false;
                        for (var imgIdx=0; imgIdx < imgList.length; imgIdx++) {
                            if (imgList[imgIdx].name === textureName) { hasTex = true; break; }
                        }

                        // 把 hasTexture 的标记写入文件，通知 C4D
                        jsonItems.push(
                            '{"name":"'+d.name+'","group":"'+d.group+'","color":'+cStr+
                            ',"hasTexture":'+hasTex+
                            ',"segments":'+segStr+',"closed":true}'
                        );
                        debugLines.push(
                            "name=" + d.name +
                            " | group=" + d.group +
                            " | sourceType=" + (d.source ? d.source.typename : "None") +
                            " | maskType=" + (d.maskSource ? d.maskSource.typename : "None") +
                            " | isMask=" + d.isMask +
	                            " | fallbackExport=" + (enableFallback || !!d.fallbackExport) +
	                            " | fallbackReverse=" + debugFallbackReverse +
	                            " | targetMode=" + (debugFallbackReverse ? "reverse" : "normal") +
	                            " | targetColor=" + debugTargetColor +
	                            " | fallbackSource=" + debugFallbackSource +
	                            " | usedWhiteFillPaths=" + debugUsedWhiteFillPaths +
	                            " | whitePathCount=" + debugWhitePathCount +
	                            " | blackPathCount=" + debugBlackPathCount +
	                            " | exportSegmentCount=" + debugPreviewLikeSegmentCount +
	                            " | exportUsesPreviewLogic=" + debugExportUsesPreviewLogic +
	                            " | exportedRectFallback=" + debugExportedRectFallback +
	                            " | mode=" + debugMode +
                            " | coverage=" + debugCoverage +
                            " | largestPathCoverage=" + largestCoverage +
                            " | segmentCount=" + debugSegmentCount +
                            " | traceSegmentCount=" + debugTraceSegmentCount +
                            " | useTrace=" + debugUseTrace +
                            " | smallSegmentRatio=" + debugSmallRatio +
                            " | areaUniformity=" + debugAreaUniformity +
                            " | boardLike=" + debugBoardLike +
                            " | missingMain=" + debugMissingMain +
                            (function() {
                                try {
                                    if (!d.bounds) return " | exportBounds=None";
                                    return " | exportBounds=[" + [
                                        Math.round(d.bounds[0]*100)/100,
                                        Math.round(d.bounds[1]*100)/100,
                                        Math.round(d.bounds[2]*100)/100,
                                        Math.round(d.bounds[3]*100)/100
                                    ].join(",") + "]";
                                } catch (e) {
                                    return " | exportBounds=ERR";
                                }
                            })() +
                            (function() {
                                try {
                                    if (!d.maskSource || !d.maskSource.geometricBounds) return " | maskBounds=None";
                                    var mb = d.maskSource.geometricBounds;
                                    return " | maskBounds=[" + [
                                        Math.round(mb[0]*100)/100,
                                        Math.round(mb[1]*100)/100,
                                        Math.round(mb[2]*100)/100,
                                        Math.round(mb[3]*100)/100
                                    ].join(",") + "]";
                                } catch (e) {
                                    return " | maskBounds=ERR";
                                }
                            })() +
                            " | hasTex=" + hasTex +
                            " | textureName=" + textureName +
                            " | segStrLen=" + segStr.length
                        );
                    }
                    debugLines.push("textureCount=" + imgCount);
                    if (typeof exportedTextureNames !== "undefined") {
                        for (var ti = 0; ti < exportedTextureNames.length; ti++) {
                            debugLines.push("textureFile=" + exportedTextureNames[ti]);
                        }
                    }
                    var finalJson = '{"version":"v28.158-preview-local","items":[' + jsonItems.join(',') + ']}';
                    baseFile.encoding = "UTF-8"; baseFile.open("w"); baseFile.write(finalJson); baseFile.close();
                }
                alert("导出完成！\n路径对象: " + scanList.length + "\n贴图文件: " + imgCount + "\n(文字边界完美脱水裁切成功)");
            } catch(e) { 
                alert("错误: " + e.message); 
            } finally { 
                if (tempLayer) {
                    try { tempLayer.remove(); } catch(e){}
                }
                app.userInteractionLevel = origLevel; 
            }
        }

        if (action === "cut") {
            var sides = params.sides; var r = params.radius * 2.83464567; var k = 0.5522847; var handleLen = r * k;
            for (var i = originalSel.length - 1; i >= 0; i--) {
                var baseObj = originalSel[i];
                var hasFill = false, fillColor = null; var hasStroke = false, strokeColor = null, strokeWidth = 1.0;
                try { if (baseObj.filled) { hasFill = true; fillColor = baseObj.fillColor; } } catch (e1) {}
                try { if (baseObj.stroked) { hasStroke = true; strokeColor = baseObj.strokeColor; strokeWidth = baseObj.strokeWidth; } } catch (e2) {}
                var b = baseObj.geometricBounds;
                var L=b[0], T=b[1], R=b[2], B=b[3]; var cx=L+(R-L)/2, cy=T-(T-B)/2;
                var points =[];
                var addPt = function(ax, ay, ix, iy, ox, oy) {
                    if (ix === undefined) ix = ax; if (iy === undefined) iy = ay;
                    if (ox === undefined) ox = ax; if (oy === undefined) oy = ay;
                    points.push({ a:[ax, ay], i: [ix, iy], o:[ox, oy] });
                };
                addPt(L, T);
                if (sides.top) { addPt(cx - r, T, cx - r, T, cx - r, T - handleLen); addPt(cx, T - r, cx - handleLen, T - r, cx + handleLen, T - r); addPt(cx + r, T, cx + r, T - handleLen, cx + r, T); }
                addPt(R, T);
                if (sides.right) { addPt(R, cy + r, R, cy + r, R - handleLen, cy + r); addPt(R - r, cy, R - r, cy + handleLen, R - r, cy - handleLen); addPt(R, cy - r, R - handleLen, cy - r, R, cy - r); }
                addPt(R, B);
                if (sides.bottom) { addPt(cx + r, B, cx + r, B, cx + r, B + handleLen); addPt(cx, B + r, cx + handleLen, B + r, cx - handleLen, B + r); addPt(cx - r, B, cx - r, B + handleLen, cx - r, B); }
                addPt(L, B);
                if (sides.left) { addPt(L, cy - r, L, cy - r, L + handleLen, cy - r); addPt(L + r, cy, L + r, cy - handleLen, L + r, cy + handleLen); addPt(L, cy + r, L + handleLen, cy + r, L, cy + r); }
                var parent = baseObj.parent;
                var newPath = parent.pathItems.add();
                for (var pIndex = 0; pIndex < points.length; pIndex++) {
                    var p = newPath.pathPoints.add(); p.anchor = points[pIndex].a; p.leftDirection = points[pIndex].i; p.rightDirection = points[pIndex].o;
                }
                newPath.closed = true;
                if (hasFill) { newPath.filled = true; newPath.fillColor = fillColor; }
                if (hasStroke) { newPath.stroked = true; newPath.strokeColor = strokeColor; newPath.strokeWidth = strokeWidth; }
                newPath.selected = true; baseObj.remove();
            }
        }

        if (action === "dim_box" || action === "dim_curve_text_below" || action === "label_material") {
            var color = getDimColor(doc);
            var dimL = null; try{dimL=doc.layers.getByName("自动标注");}catch(e){dimL=doc.layers.add();dimL.name="自动标注";}
            var tick = (params.tickLen||2)*2.83464567/2; var off = params.offset*2.83464567;
            if (action === "dim_box") {
                var gL=9e9, gT=-9e9, gR=-9e9, gB=9e9;
                for(var i=0;i<originalSel.length;i++){ var b=originalSel[i].geometricBounds; if(b[0]<gL)gL=b[0]; if(b[1]>gT)gT=b[1]; if(b[2]>gR)gR=b[2]; if(b[3]<gB)gB=b[3]; }
                var wStr = convertValue(gR-gL, params.scale, params.unit, params.decimal, params.isRound);
                var hStr = convertValue(gT-gB, params.scale, params.unit, params.decimal, params.isRound);
                var grp = dimL.groupItems.add();
                if(params.showW){
                    var y=gT+off; drawLine(grp, gL, y, gR, y, color, params.lineWeight); drawLine(grp, gL, y-tick, gL, y+tick, color, params.lineWeight); drawLine(grp, gR, y-tick, gR, y+tick, color, params.lineWeight);
                    var t = drawText(grp, wStr, gL, y+tick+1+params.fontSize, params.fontSize, color); t.left = gL + (gR-gL)/2 - t.width/2;
                }
                if(params.showH){
                    var x=gR+off; drawLine(grp, x, gT, x, gB, color, params.lineWeight); drawLine(grp, x-tick, gT, x+tick, gT, color, params.lineWeight); drawLine(grp, x-tick, gB, x+tick, gB, color, params.lineWeight);
                    var t = drawText(grp, hStr, x+tick+1, gT, params.fontSize, color); t.rotate(-90); t.top=(gT+gB)/2+t.height/2; t.left=x+tick+1;
                }
            }
            if (action === "dim_curve_text_below" || action === "label_material") {
                var txt = "";
                if(action==="label_material"){
                    if(params.sizeNote&&params.sizeNote!="无") txt+=params.sizeNote+" ";
                    if(params.mat&&params.mat!="无") txt+=params.mat+" ";
                    if(params.proc&&params.proc!="无") txt+=params.proc+" ";
                    if(params.thick&&params.thick!="无") txt+=params.thick;
                }
                for(var i=0; i<originalSel.length; i++){
                    var item=originalSel[i]; var b=item.geometricBounds; var cx=b[0]+(b[2]-b[0])/2; var by=b[3]-off; var content = txt;
                    if(action==="dim_curve_text_below"){
                        var len=0; if(item.typename=="PathItem") len=item.length; else if(item.typename=="GroupItem" && item.pathItems.length>0) len=item.pathItems[0].length;
                        content = "曲线长度: " + convertValue(len, params.scale, params.unit, params.decimal, params.isRound);
                    }
                    if(content){
                        var grp = dimL.groupItems.add(); var t = drawText(grp, content, cx, by, params.fontSize, color);
                        t.textRange.paragraphAttributes.justification = Justification.CENTER; t.top=by; t.left=cx-t.width/2;
                    }
                }
            }
        }
    } catch(err) { alert("执行错误:\n" + err.message); }
}



// ============================================================================
// CEP Host API
// ============================================================================
function HH_execute(action, params) {
    if (!params) params = {};
    return WORKER_FUNCTION(action, params);
}

function HH_exportWithDialog(mode, dpi, format) {
    if(app.documents.length===0){alert("请先打开文档");return null;}
    var defaultName = "Untitled.json";
    try{defaultName=app.documents[0].name.replace(/\.[^\.]+$/, "")+".json";}catch(e){}
    var f = File.saveDialog("保存 JSON", defaultName);
    if(!f) return null;
    return WORKER_FUNCTION("export", {
        mode: mode || "both",
        dpi: parseInt(dpi, 10) || 300,
        format: format || "png",
        path: f.fsName,
        enableFallback: false
    });
}

function HH_hotUpdate(mode, dpi, format) {
    if(app.documents.length===0){alert("请先打开文档");return null;}
    var f = new File(Folder.temp.fsName + "/hh_c4d_hot_update.json");
    return WORKER_FUNCTION("export", {
        mode: mode || "both",
        dpi: parseInt(dpi, 10) || 300,
        format: format || "png",
        path: f.fsName,
        enableFallback: false
    });
}

function HH_ping() {
    return "HH_HOST_READY_v28.158-preview-local";
}
