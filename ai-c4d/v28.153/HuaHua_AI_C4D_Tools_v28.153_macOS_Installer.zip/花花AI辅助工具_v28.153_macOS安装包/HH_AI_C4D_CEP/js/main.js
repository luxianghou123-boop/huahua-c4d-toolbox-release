(function () {
  const CURRENT_VERSION = "28.153";
  const UPDATE_URL = "https://raw.githubusercontent.com/luxianghou123-boop/huahua-c4d-toolbox-release/main/ai-c4d/update.json";
  const cs = new CSInterface();
  const state = {
    mode: "both",
    format: "png",
    updateInfo: null
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.prototype.slice.call(document.querySelectorAll(selector));
  let shadowPreviewTimer = null;

  function jsxString(value) {
    return JSON.stringify(String(value || ""));
  }

  function evalScript(script, callback) {
    cs.evalScript(script, function (result) {
      if (callback) callback(result);
    });
  }

  function loadHost() {
    const root = cs.getSystemPath(SystemPath.EXTENSION);
    const hostPath = root + "/jsx/host.jsx";
    evalScript("$.evalFile(" + jsxString(hostPath) + ")", function () {
      refreshStatus();
    });
  }

  function callHost(action, params, callback) {
    const script = "HH_execute(" + JSON.stringify(action) + "," + JSON.stringify(params || {}) + ")";
    evalScript(script, callback || refreshStatus);
  }

  function selectedValue(name) {
    const active = $('.segmented[data-name="' + name + '"] button.active');
    return active ? active.dataset.value : "";
  }

  function normalizeVersion(version) {
    return String(version || "").replace(/^v/i, "").split(".").map(function (part) {
      const value = parseInt(part, 10);
      return Number.isNaN(value) ? 0 : value;
    });
  }

  function compareVersions(left, right) {
    const a = normalizeVersion(left);
    const b = normalizeVersion(right);
    const size = Math.max(a.length, b.length);
    for (let i = 0; i < size; i += 1) {
      const av = a[i] || 0;
      const bv = b[i] || 0;
      if (av > bv) return 1;
      if (av < bv) return -1;
    }
    return 0;
  }

  function setUpdateStatus(message, isNotice) {
    const el = $("#updateStatus");
    if (!el) return;
    el.textContent = message || "";
    el.classList.toggle("show", !!message);
    const button = $("#checkUpdateBtn");
    if (button) button.classList.toggle("has-update", !!isNotice);
  }

  function requestUpdateJson(callback) {
    const xhr = new XMLHttpRequest();
    let done = false;
    const timer = window.setTimeout(function () {
      if (done) return;
      done = true;
      try {
        xhr.abort();
      } catch (error) {}
      callback(new Error("timeout"));
    }, 8000);
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4 || done) return;
      done = true;
      window.clearTimeout(timer);
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          callback(null, JSON.parse(xhr.responseText));
        } catch (error) {
          callback(error);
        }
      } else {
        callback(new Error("HTTP " + xhr.status));
      }
    };
    try {
      xhr.open("GET", UPDATE_URL + "?t=" + Date.now(), true);
      xhr.send();
    } catch (error) {
      window.clearTimeout(timer);
      callback(error);
    }
  }

  function currentPlatformKey() {
    const platform = String(navigator.platform || navigator.userAgent || "").toLowerCase();
    return platform.indexOf("win") >= 0 ? "windows" : "mac";
  }

  function downloadForPlatform(info) {
    const downloads = info && info.downloads ? info.downloads : {};
    return downloads[currentPlatformKey()] || downloads.mac || downloads.windows || {};
  }

  function openExternalUrl(url) {
    if (!url) return;
    try {
      if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
        window.cep.util.openURLInDefaultBrowser(url);
        return;
      }
    } catch (error) {}
    window.open(url, "_blank");
  }

  function showUpdateDialog(info) {
    state.updateInfo = info;
    const download = downloadForPlatform(info);
    $("#updateLatest").textContent = "v" + (info.latestVersion || "");
    $("#updateTitle").textContent = info.title || "花花 AI 辅助工具新版";
    $("#updateNotes").textContent = (info.notes || []).join("\n");
    $("#updateSha").textContent = download.sha256 ? "SHA256: " + download.sha256 : "";
    $("#updateModal").classList.add("open");
    $("#updateModal").setAttribute("aria-hidden", "false");
  }

  function closeUpdateDialog() {
    $("#updateModal").classList.remove("open");
    $("#updateModal").setAttribute("aria-hidden", "true");
  }

  function checkForUpdates(manual) {
    setUpdateStatus("正在检查更新...", false);
    requestUpdateJson(function (error, info) {
      if (error || !info || !info.latestVersion) {
        setUpdateStatus(manual ? "检查失败，请稍后重试" : "", false);
        if (manual) window.alert("检查更新失败，请稍后重试");
        return;
      }
      if (compareVersions(info.latestVersion, CURRENT_VERSION) > 0) {
        setUpdateStatus("发现新版本 v" + info.latestVersion, true);
        showUpdateDialog(info);
        return;
      }
      setUpdateStatus(manual ? "当前已是最新版本 v" + CURRENT_VERSION : "", false);
      if (manual) window.alert("当前已是最新版本");
    });
  }

  function exportOptions() {
    return {
      mode: selectedValue("mode") || state.mode,
      dpi: parseInt($("#dpiSelect").value, 10) || 300,
      format: selectedValue("format") || state.format
    };
  }

  function refreshStatus() {
    callHost("check_status", {}, function (message) {
      if (!message || message === "CEP_NOT_AVAILABLE") {
        $("#statusText").textContent = "等待 Illustrator CEP 环境";
        return;
      }
      $("#statusText").textContent = String(message).replace(/^STATUS:/, "");
    });
  }

  function applyTheme(theme) {
    const next = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("theme-light", next === "light");
    document.body.classList.toggle("theme-dark", next !== "light");
    const glyph = $("#themeToggle .theme-glyph");
    const label = $("#themeLabel");
    if (glyph) glyph.textContent = next === "light" ? "☀" : "☾";
    if (label) label.textContent = next === "light" ? "明亮" : "暗黑";
    try {
      window.localStorage.setItem("hhTheme", next);
    } catch (error) {}
  }

  function bindTheme() {
    let saved = "dark";
    try {
      saved = window.localStorage.getItem("hhTheme") || "dark";
    } catch (error) {}
    applyTheme(saved);
    $("#themeToggle").addEventListener("click", () => {
      applyTheme(document.body.classList.contains("theme-light") ? "dark" : "light");
    });
  }

  function dimParams() {
    return {
      offset: parseFloat($("#dimOffset").value) || 20,
      fontSize: parseFloat($("#fontSize").value) || 40,
      scale: parseFloat($("#scaleValue").value) || 1,
      unit: $("#unitSelect").value,
      isRound: $("#roundDim").checked,
      decimal: 1,
      showW: $("#showW").checked,
      showH: $("#showH").checked,
      lineWeight: 2,
      tickLen: 20,
      sizeNote: $("#sizeNote").value,
      mat: $("#matNote").value,
      proc: $("#procNote").value,
      thick: $("#thickNote").value
    };
  }

  function openDropShadowModal() {
    $("#dropShadowModal").classList.add("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "false");
    if ($("#shadowPreview").checked) {
      requestDropShadowPreview();
    }
  }

  function closeDropShadowModal() {
    $("#dropShadowModal").classList.remove("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "true");
  }

  function cancelDropShadowModal() {
    if (shadowPreviewTimer) {
      window.clearTimeout(shadowPreviewTimer);
      shadowPreviewTimer = null;
    }
    callHost("drop_shadow_native_cancel", {}, function () {
      closeDropShadowModal();
      refreshStatus();
    });
  }

  function readNumber(selector, fallback) {
    const raw = String($(selector).value || "").trim();
    if (!raw) return fallback;
    const value = parseFloat(raw);
    return Number.isNaN(value) ? fallback : value;
  }

  function shadowParams(silent) {
    const params = {
      offsetXmm: readNumber("#shadowX", 2),
      offsetYmm: readNumber("#shadowY", 2),
      blurMm: readNumber("#shadowBlur", 2),
      opacity: readNumber("#shadowOpacity", 40),
      colorHex: String($("#shadowColor").value || "#000000"),
      blendMode: String($("#shadowBlend").value || "multiply")
    };
    const colorOk = /^#[0-9a-fA-F]{6}$/.test(params.colorHex);
    if (params.blurMm < 0 || params.opacity < 0 || params.opacity > 100 || !colorOk) {
      if (!silent) window.alert("请检查投影参数");
      return null;
    }
    return params;
  }

  function requestDropShadowPreview() {
    const params = shadowParams(true);
    if (!params) return;
    callHost("drop_shadow_native_preview", params, refreshStatus);
  }

  function scheduleDropShadowPreview() {
    if (!$("#shadowPreview").checked) return;
    if (shadowPreviewTimer) window.clearTimeout(shadowPreviewTimer);
    shadowPreviewTimer = window.setTimeout(function () {
      shadowPreviewTimer = null;
      requestDropShadowPreview();
    }, 300);
  }

  function bindTabs() {
    $$(".tab").forEach((button) => {
      button.addEventListener("click", () => {
        $$(".tab").forEach((item) => item.classList.remove("active"));
        $$(".view").forEach((view) => view.classList.remove("active"));
        button.classList.add("active");
        $("#tab-" + button.dataset.tab).classList.add("active");
        refreshStatus();
      });
    });
  }

  function bindSegmented() {
    $$(".segmented").forEach((group) => {
      group.querySelectorAll("button").forEach((button) => {
        button.addEventListener("click", () => {
          group.querySelectorAll("button").forEach((item) => item.classList.remove("active"));
          button.classList.add("active");
          state[group.dataset.name] = button.dataset.value;
        });
      });
    });
  }

  function bindNotePresets() {
    $$(".note-select").forEach((select) => {
      select.addEventListener("change", () => {
        const target = document.getElementById(select.dataset.target);
        if (target) target.value = select.value;
      });
    });
  }

  function bindActions() {
    $("#exportBtn").addEventListener("click", () => {
      const options = exportOptions();
      evalScript("HH_exportWithDialog(" + JSON.stringify(options.mode) + "," + options.dpi + "," + JSON.stringify(options.format) + ")", refreshStatus);
    });

    $("#hotUpdateBtn").addEventListener("click", () => {
      const options = exportOptions();
      evalScript("HH_hotUpdate(" + JSON.stringify(options.mode) + "," + options.dpi + "," + JSON.stringify(options.format) + ")", refreshStatus);
    });

    $("#markFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: true }));
    $("#clearFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: false }));
    $("#filterMissingBtn").addEventListener("click", () => callHost("filter_missing", {}));

    $$("[data-thick]").forEach((button) => {
      button.addEventListener("click", () => callHost("set_thickness", { val: parseInt(button.dataset.thick, 10) }));
    });

    $("#customThicknessBtn").addEventListener("click", () => {
      const value = parseFloat($("#customThickness").value);
      if (Number.isNaN(value)) return;
      callHost("set_thickness", { val: Math.round(value * 10) });
    });

    $("#cutBtn").addEventListener("click", () => {
      callHost("cut", {
        sides: {
          top: $("#sideTop").checked,
          bottom: $("#sideBottom").checked,
          left: $("#sideLeft").checked,
          right: $("#sideRight").checked
        },
        radius: parseFloat($("#slotRadius").value) || 5
      });
    });

    $("#outlineStrokeBtn").addEventListener("click", () => callHost("outline_stroke", {}));
    $("#offsetPathBtn").addEventListener("click", () => callHost("offset_path", {}));
    $("#simplifyPathBtn").addEventListener("click", () => callHost("simplify_path", {}));
    $("#createTextOutlinesBtn").addEventListener("click", () => callHost("create_text_outlines", {}));
    $("#dropShadowBtn").addEventListener("click", openDropShadowModal);
    $("#checkUpdateBtn").addEventListener("click", () => checkForUpdates(true));
    $("#closeUpdateBtn").addEventListener("click", closeUpdateDialog);
    $("#downloadUpdateBtn").addEventListener("click", () => {
      const download = downloadForPlatform(state.updateInfo);
      openExternalUrl(download.url || (state.updateInfo && state.updateInfo.releasePage));
    });
    $("#updateModal").addEventListener("click", (event) => {
      if (event.target === $("#updateModal")) closeUpdateDialog();
    });
    $("#cancelShadowBtn").addEventListener("click", cancelDropShadowModal);
    $("#dropShadowModal").addEventListener("click", (event) => {
      if (event.target === $("#dropShadowModal")) cancelDropShadowModal();
    });
    ["#shadowX", "#shadowY", "#shadowBlur", "#shadowOpacity", "#shadowColor", "#shadowBlend"].forEach((selector) => {
      const input = $(selector);
      input.addEventListener("input", scheduleDropShadowPreview);
      input.addEventListener("change", scheduleDropShadowPreview);
    });
    $("#shadowPreview").addEventListener("change", () => {
      if ($("#shadowPreview").checked) {
        requestDropShadowPreview();
      } else {
        callHost("drop_shadow_native_cancel", {}, refreshStatus);
      }
    });
    $("#applyShadowBtn").addEventListener("click", () => {
      const params = shadowParams();
      if (!params) return;
      if (shadowPreviewTimer) {
        window.clearTimeout(shadowPreviewTimer);
        shadowPreviewTimer = null;
      }
      callHost("drop_shadow_native_apply", params, function () {
        closeDropShadowModal();
        refreshStatus();
      });
    });

    $("#dimBoxBtn").addEventListener("click", () => callHost("dim_box", dimParams()));
    $("#curveLenBtn").addEventListener("click", () => callHost("dim_curve_text_below", dimParams()));
    $("#labelBtn").addEventListener("click", () => callHost("label_material", dimParams()));
  }

  bindTabs();
  bindSegmented();
  bindNotePresets();
  bindTheme();
  bindActions();
  loadHost();
  window.setTimeout(function () {
    checkForUpdates(false);
  }, 1400);
  window.setInterval(refreshStatus, 1800);
}());
