#!/bin/bash
set -e
VERSION="28.153"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
SRC="$SCRIPT_DIR/HH_AI_C4D_CEP"
TARGET_ROOT="$HOME/Library/Application Support/Adobe/CEP/extensions"
TARGET="$TARGET_ROOT/HH_AI_C4D_CEP"
BACKUP="$TARGET_ROOT/HH_AI_C4D_CEP_backup_before_v28.153_public"
mkdir -p "$TARGET_ROOT"
if [ -d "$TARGET" ]; then
  rm -rf "$BACKUP"
  cp -R "$TARGET" "$BACKUP"
fi
rm -rf "$TARGET"
cp -R "$SRC" "$TARGET"
for ver in 6 7 8 9 10 11 12 13 14 15; do
  defaults write "com.adobe.CSXS.$ver" PlayerDebugMode 1 >/dev/null 2>&1 || true
done
echo "安装完成：$TARGET"
echo "如 Illustrator 已打开，请重启 Illustrator 后使用花花 AI 辅助工具 v$VERSION。"
read -n 1 -s -r -p "按任意键关闭窗口..."
