(function () {
  const CURRENT_VERSION = "28.186-group-texture-deduplicate-local";
  const UPDATE_URL = "https://raw.githubusercontent.com/luxianghou123-boop/huahua-c4d-toolbox-release/main/ai-c4d/update.json";
  const cs = new CSInterface();
  const state = {
    mode: "both",
    format: "png",
    updateInfo: null
  };

  const $ = (selector) => document.querySelector(selector);
  const $$ = (selector) => Array.prototype.slice.call(document.querySelectorAll(selector));
  let shadowPreviewTimer = null;

  function jsxString(value) {
    return JSON.stringify(String(value || ""));
  }

  function evalScript(script, callback) {
    cs.evalScript(script, function (result) {
      if (callback) callback(result);
    });
  }

  function loadHost() {
    const root = cs.getSystemPath(SystemPath.EXTENSION);
    const hostPath = root + "/jsx/host.jsx";
    evalScript("$.evalFile(" + jsxString(hostPath) + ")", function () {
      refreshStatus();
    });
  }

  function callHost(action, params, callback) {
    const script = "HH_execute(" + JSON.stringify(action) + "," + JSON.stringify(params || {}) + ")";
    evalScript(script, callback || refreshStatus);
  }

  function selectedValue(name) {
    const active = $('.segmented[data-name="' + name + '"] button.active');
    return active ? active.dataset.value : "";
  }

  function normalizeVersion(version) {
    return String(version || "").replace(/^v/i, "").split(".").map(function (part) {
      const value = parseInt(part, 10);
      return Number.isNaN(value) ? 0 : value;
    });
  }

  function compareVersions(left, right) {
    const a = normalizeVersion(left);
    const b = normalizeVersion(right);
    const size = Math.max(a.length, b.length);
    for (let i = 0; i < size; i += 1) {
      const av = a[i] || 0;
      const bv = b[i] || 0;
      if (av > bv) return 1;
      if (av < bv) return -1;
    }
    return 0;
  }

  function setUpdateStatus(message, isNotice) {
    const el = $("#updateStatus");
    if (!el) return;
    el.textContent = message || "";
    el.classList.toggle("show", !!message);
    const button = $("#checkUpdateBtn");
    if (button) button.classList.toggle("has-update", !!isNotice);
  }

  function requestUpdateJson(callback) {
    const xhr = new XMLHttpRequest();
    let done = false;
    const timer = window.setTimeout(function () {
      if (done) return;
      done = true;
      try {
        xhr.abort();
      } catch (error) {}
      callback(new Error("timeout"));
    }, 8000);
    xhr.onreadystatechange = function () {
      if (xhr.readyState !== 4 || done) return;
      done = true;
      window.clearTimeout(timer);
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          callback(null, JSON.parse(xhr.responseText));
        } catch (error) {
          callback(error);
        }
      } else {
        callback(new Error("HTTP " + xhr.status));
      }
    };
    try {
      xhr.open("GET", UPDATE_URL + "?t=" + Date.now(), true);
      xhr.send();
    } catch (error) {
      window.clearTimeout(timer);
      callback(error);
    }
  }

  function currentPlatformKey() {
    const platform = String(navigator.platform || navigator.userAgent || "").toLowerCase();
    return platform.indexOf("win") >= 0 ? "windows" : "mac";
  }

  function downloadForPlatform(info) {
    const downloads = info && info.downloads ? info.downloads : {};
    return downloads[currentPlatformKey()] || downloads.mac || downloads.windows || {};
  }

  function openExternalUrl(url) {
    if (!url) return;
    try {
      if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) {
        window.cep.util.openURLInDefaultBrowser(url);
        return;
      }
    } catch (error) {}
    window.open(url, "_blank");
  }

  function showUpdateDialog(info) {
    state.updateInfo = info;
    const download = downloadForPlatform(info);
    $("#updateLatest").textContent = "v" + (info.latestVersion || "");
    $("#updateTitle").textContent = info.title || "花花 AI 辅助工具新版";
    $("#updateNotes").textContent = (info.notes || []).join("\n");
    $("#updateSha").textContent = download.sha256 ? "SHA256: " + download.sha256 : "";
    $("#updateModal").classList.add("open");
    $("#updateModal").setAttribute("aria-hidden", "false");
  }

  function closeUpdateDialog() {
    $("#updateModal").classList.remove("open");
    $("#updateModal").setAttribute("aria-hidden", "true");
  }

  function checkForUpdates(manual) {
    setUpdateStatus("正在检查更新...", false);
    requestUpdateJson(function (error, info) {
      if (error || !info || !info.latestVersion) {
        setUpdateStatus(manual ? "检查失败，请稍后重试" : "", false);
        if (manual) window.alert("检查更新失败，请稍后重试");
        return;
      }
      if (compareVersions(info.latestVersion, CURRENT_VERSION) > 0) {
        setUpdateStatus("发现新版本 v" + info.latestVersion, true);
        showUpdateDialog(info);
        return;
      }
      setUpdateStatus(manual ? "当前已是最新版本 v" + CURRENT_VERSION : "", false);
      if (manual) window.alert("当前已是最新版本");
    });
  }

  function exportOptions() {
    return {
      mode: selectedValue("mode") || state.mode,
      dpi: parseInt($("#dpiSelect").value, 10) || 300,
      format: selectedValue("format") || state.format
    };
  }

  function refreshStatus() {
    callHost("check_status", {}, function (message) {
      if (!message || message === "CEP_NOT_AVAILABLE") {
        $("#statusText").textContent = "等待 Illustrator CEP 环境";
        return;
      }
      const cleanMessage = String(message).replace(/^STATUS:/, "");
      $("#statusText").textContent = cleanMessage;
      if (cleanMessage.indexOf("选中") >= 0) {
        refreshStrokeThicknessDepthInfo();
      } else {
        setStrokeThicknessDepthInfo("描边厚度导出厚度：未设置");
      }
    });
  }

  function setStrokeThicknessInfo(message) {
    const info = $("#strokeThicknessInfo");
    if (!info) return;
    info.textContent = message || "未读取描边信息";
  }

  function setStrokeThicknessDepthInfo(message) {
    const info = $("#strokeThicknessDepthInfo");
    if (!info) return;
    info.textContent = message || "描边厚度导出厚度：未设置";
  }

  function refreshStrokeThicknessDepthInfo() {
    if (!$("#strokeThicknessDepthInfo")) return;
    callHost("read_stroke_thickness_depth_info", {}, function (message) {
      setStrokeThicknessDepthInfo(String(message || "").replace(/^STROKE_DEPTH_INFO:/, ""));
    });
  }

  function setStrokeThicknessDepth(depthMm) {
    callHost("set_stroke_thickness_depth", { depthMm: depthMm }, function (message) {
      setStrokeThicknessDepthInfo(String(message || "").replace(/^STROKE_DEPTH_INFO:/, ""));
      refreshStatus();
    });
  }

  function applyTheme(theme) {
    const next = theme === "light" ? "light" : "dark";
    document.body.classList.toggle("theme-light", next === "light");
    document.body.classList.toggle("theme-dark", next !== "light");
    const glyph = $("#themeToggle .theme-glyph");
    const label = $("#themeLabel");
    if (glyph) glyph.textContent = next === "light" ? "☀" : "☾";
    if (label) label.textContent = next === "light" ? "明亮" : "暗黑";
    try {
      window.localStorage.setItem("hhTheme", next);
    } catch (error) {}
  }

  function bindTheme() {
    let saved = "dark";
    try {
      saved = window.localStorage.getItem("hhTheme") || "dark";
    } catch (error) {}
    applyTheme(saved);
    $("#themeToggle").addEventListener("click", () => {
      applyTheme(document.body.classList.contains("theme-light") ? "dark" : "light");
    });
  }

  function dimParams() {
    return {
      offset: parseFloat($("#dimOffset").value) || 20,
      fontSize: parseFloat($("#fontSize").value) || 40,
      scale: parseFloat($("#scaleValue").value) || 1,
      unit: $("#unitSelect").value,
      isRound: $("#roundDim").checked,
      decimal: 1,
      showW: $("#showW").checked,
      showH: $("#showH").checked,
      lineWeight: 2,
      tickLen: 20,
      sizeNote: $("#sizeNote").value,
      mat: $("#matNote").value,
      proc: $("#procNote").value,
      thick: $("#thickNote").value
    };
  }

  function openDropShadowModal() {
    $("#dropShadowModal").classList.add("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "false");
    if ($("#shadowPreview").checked) {
      requestDropShadowPreview();
    }
  }

  function closeDropShadowModal() {
    $("#dropShadowModal").classList.remove("open");
    $("#dropShadowModal").setAttribute("aria-hidden", "true");
  }

  function cancelDropShadowModal() {
    if (shadowPreviewTimer) {
      window.clearTimeout(shadowPreviewTimer);
      shadowPreviewTimer = null;
    }
    callHost("drop_shadow_native_cancel", {}, function () {
      closeDropShadowModal();
      refreshStatus();
    });
  }

  function openModal(selector) {
    $(selector).classList.add("open");
    $(selector).setAttribute("aria-hidden", "false");
  }

  function closeModal(selector) {
    $(selector).classList.remove("open");
    $(selector).setAttribute("aria-hidden", "true");
  }

  function readNumber(selector, fallback) {
    const raw = String($(selector).value || "").trim();
    if (!raw) return fallback;
    const value = parseFloat(raw);
    return Number.isNaN(value) ? fallback : value;
  }

  function shadowParams(silent) {
    const params = {
      offsetXmm: readNumber("#shadowX", 2),
      offsetYmm: readNumber("#shadowY", 2),
      blurMm: readNumber("#shadowBlur", 2),
      opacity: readNumber("#shadowOpacity", 40),
      colorHex: String($("#shadowColor").value || "#000000"),
      blendMode: String($("#shadowBlend").value || "multiply")
    };
    const colorOk = /^#[0-9a-fA-F]{6}$/.test(params.colorHex);
    if (params.blurMm < 0 || params.opacity < 0 || params.opacity > 100 || !colorOk) {
      if (!silent) window.alert("请检查投影参数");
      return null;
    }
    return params;
  }

  function artboardRangeValue(selector) {
    const value = String($(selector).value || "全部").trim();
    return value || "全部";
  }

  function isArtboardRangeInput(value) {
    return value === "全部" || value.toLowerCase() === "all" || /^[0-9]+(?:\s*-\s*[0-9]+)?(?:\s*,\s*[0-9]+(?:\s*-\s*[0-9]+)?)*$/.test(value);
  }

  function readImageDpi() {
    const preset = $("#imageDpi").value;
    const raw = preset === "custom" ? $("#imageDpiCustom").value : preset;
    const dpi = parseFloat(raw);
    if (Number.isNaN(dpi) || dpi <= 0) {
      window.alert("分辨率请输入正数");
      return null;
    }
    return dpi;
  }

  function readPdfDpi() {
    const preset = $("#pdfDpi").value;
    const raw = preset === "custom" ? $("#pdfDpiCustom").value : preset;
    const dpi = parseFloat(raw);
    if (Number.isNaN(dpi) || dpi <= 0) {
      window.alert("分辨率请输入正数");
      return null;
    }
    return dpi;
  }

  function readImageScale() {
    const preset = $("#imageScale").value;
    const raw = preset === "custom" ? $("#imageScaleCustom").value : preset;
    const match = String(raw || "").trim().match(/^1\s*:\s*([0-9]+(?:\.[0-9]+)?)$/);
    if (!match) {
      window.alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
      return null;
    }
    const scale = parseFloat(match[1]);
    if (Number.isNaN(scale) || scale <= 0) {
      window.alert("比例格式错误，请输入 1:1、1:10、1:100 或 1:20");
      return null;
    }
    return raw;
  }

  function pdfExportParams() {
    const range = artboardRangeValue("#pdfArtboardRange");
    const dpi = readPdfDpi();
    if (dpi === null) return null;
    if (!isArtboardRangeInput(range)) {
      window.alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
      return null;
    }
    return { range, dpi };
  }

  function imageExportParams() {
    const range = artboardRangeValue("#imageArtboardRange");
    const dpi = readImageDpi();
    const scale = readImageScale();
    if (dpi === null || scale === null) return null;
    if ($("#imageExportMode").value === "artboards" && !isArtboardRangeInput(range)) {
      window.alert("画板范围格式错误，请输入：全部、1-5、1,3,5 或 2-4,8");
      return null;
    }
    return {
      mode: $("#imageExportMode").value,
      format: $("#imageFormat").value,
      colorMode: $("#imageColorMode").value,
      dpi: dpi,
      scale: scale,
      range: range
    };
  }

  function requestDropShadowPreview() {
    const params = shadowParams(true);
    if (!params) return;
    callHost("drop_shadow_native_preview", params, refreshStatus);
  }

  function scheduleDropShadowPreview() {
    if (!$("#shadowPreview").checked) return;
    if (shadowPreviewTimer) window.clearTimeout(shadowPreviewTimer);
    shadowPreviewTimer = window.setTimeout(function () {
      shadowPreviewTimer = null;
      requestDropShadowPreview();
    }, 300);
  }

  function bindTabs() {
    $$(".tab").forEach((button) => {
      button.addEventListener("click", () => {
        $$(".tab").forEach((item) => item.classList.remove("active"));
        $$(".view").forEach((view) => view.classList.remove("active"));
        button.classList.add("active");
        $("#tab-" + button.dataset.tab).classList.add("active");
        refreshStatus();
      });
    });
  }

  function bindSegmented() {
    $$(".segmented").forEach((group) => {
      group.querySelectorAll("button").forEach((button) => {
        button.addEventListener("click", () => {
          group.querySelectorAll("button").forEach((item) => item.classList.remove("active"));
          button.classList.add("active");
          state[group.dataset.name] = button.dataset.value;
        });
      });
    });
  }

  function bindNotePresets() {
    $$(".note-select").forEach((select) => {
      select.addEventListener("change", () => {
        const target = document.getElementById(select.dataset.target);
        if (target) target.value = select.value;
      });
    });
  }

  function bindActions() {
    $("#exportBtn").addEventListener("click", () => {
      const options = exportOptions();
      evalScript("HH_exportWithDialog(" + JSON.stringify(options.mode) + "," + options.dpi + "," + JSON.stringify(options.format) + ")", refreshStatus);
    });

    $("#hotUpdateBtn").addEventListener("click", () => {
      const options = exportOptions();
      evalScript("HH_hotUpdate(" + JSON.stringify(options.mode) + "," + options.dpi + "," + JSON.stringify(options.format) + ")", refreshStatus);
    });

    $("#markFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: true }));
    $("#clearFallbackBtn").addEventListener("click", () => callHost("set_fallback_export", { enabled: false }));
    const previewFallbackBtn = $("#previewFallbackBtn");
    if (previewFallbackBtn) previewFallbackBtn.addEventListener("click", () => callHost("preview_fallback_export", {}));
    const clearFallbackPreviewBtn = $("#clearFallbackPreviewBtn");
    if (clearFallbackPreviewBtn) clearFallbackPreviewBtn.addEventListener("click", () => callHost("clear_fallback_preview", {}));
    const markFallbackReverseBtn = $("#markFallbackReverseBtn");
    if (markFallbackReverseBtn) markFallbackReverseBtn.addEventListener("click", () => callHost("set_fallback_reverse", { enabled: true }));
    const clearFallbackReverseBtn = $("#clearFallbackReverseBtn");
    if (clearFallbackReverseBtn) clearFallbackReverseBtn.addEventListener("click", () => callHost("set_fallback_reverse", { enabled: false }));
    $("#filterMissingBtn").addEventListener("click", () => callHost("filter_missing", {}));
    const readStrokeThicknessBtn = $("#readStrokeThicknessBtn");
    if (readStrokeThicknessBtn) {
      readStrokeThicknessBtn.addEventListener("click", () => {
        callHost("read_stroke_thickness_info", {}, function (message) {
          setStrokeThicknessInfo(String(message || "").replace(/^STROKE_INFO:/, ""));
          refreshStatus();
        });
      });
    }
    const previewStrokeThicknessBtn = $("#previewStrokeThicknessBtn");
    if (previewStrokeThicknessBtn) previewStrokeThicknessBtn.addEventListener("click", () => callHost("preview_stroke_thickness", {}));
    const clearStrokeThicknessPreviewBtn = $("#clearStrokeThicknessPreviewBtn");
    if (clearStrokeThicknessPreviewBtn) clearStrokeThicknessPreviewBtn.addEventListener("click", () => callHost("clear_stroke_thickness_preview", {}));
    const markStrokeThicknessExportBtn = $("#markStrokeThicknessExportBtn");
    if (markStrokeThicknessExportBtn) markStrokeThicknessExportBtn.addEventListener("click", () => callHost("set_stroke_thickness_export", { enabled: true }));
    const clearStrokeThicknessExportBtn = $("#clearStrokeThicknessExportBtn");
    if (clearStrokeThicknessExportBtn) clearStrokeThicknessExportBtn.addEventListener("click", () => callHost("set_stroke_thickness_export", { enabled: false }));
    const strokeDepthButtons = [
      ["#strokeThicknessDepth3mmBtn", 3],
      ["#strokeThicknessDepth5mmBtn", 5],
      ["#strokeThicknessDepth1cmBtn", 10],
      ["#strokeThicknessDepth2cmBtn", 20],
      ["#strokeThicknessDepth4cmBtn", 40],
      ["#strokeThicknessDepth5cmBtn", 50],
      ["#strokeThicknessDepth8cmBtn", 80],
      ["#strokeThicknessDepth10cmBtn", 100],
      ["#strokeThicknessDepth15cmBtn", 150],
      ["#strokeThicknessDepth20cmBtn", 200]
    ];
    strokeDepthButtons.forEach(([selector, depthMm]) => {
      const button = $(selector);
      if (button) button.addEventListener("click", () => setStrokeThicknessDepth(depthMm));
    });
    const applyStrokeThicknessDepthBtn = $("#applyStrokeThicknessDepthBtn");
    if (applyStrokeThicknessDepthBtn) {
      applyStrokeThicknessDepthBtn.addEventListener("click", () => {
        const valueCm = parseFloat($("#strokeThicknessCustomDepthInput").value);
        if (!Number.isFinite(valueCm) || valueCm <= 0) {
          window.alert("请输入有效的自定义厚度 cm");
          return;
        }
        setStrokeThicknessDepth(Math.round(valueCm * 10 * 100) / 100);
      });
    }

    $$("[data-thick]").forEach((button) => {
      button.addEventListener("click", () => callHost("set_thickness", { val: parseInt(button.dataset.thick, 10) }));
    });

    $("#customThicknessBtn").addEventListener("click", () => {
      const value = parseFloat($("#customThickness").value);
      if (Number.isNaN(value)) return;
      callHost("set_thickness", { val: Math.round(value * 10) });
    });

    $("#cutBtn").addEventListener("click", () => {
      callHost("cut", {
        sides: {
          top: $("#sideTop").checked,
          bottom: $("#sideBottom").checked,
          left: $("#sideLeft").checked,
          right: $("#sideRight").checked
        },
        radius: parseFloat($("#slotRadius").value) || 5
      });
    });

    $("#outlineStrokeBtn").addEventListener("click", () => callHost("outline_stroke", {}));
    $("#offsetPathBtn").addEventListener("click", () => callHost("offset_path", {}));
    $("#simplifyPathBtn").addEventListener("click", () => callHost("simplify_path", {}));
    $("#createTextOutlinesBtn").addEventListener("click", () => callHost("create_text_outlines", {}));
    $("#dropShadowBtn").addEventListener("click", openDropShadowModal);
    $("#renameArtboardsBtn").addEventListener("click", () => callHost("rename_artboards", {}));
    $("#createArtboardsBtn").addEventListener("click", () => callHost("create_artboards_from_selection", {}));
    $("#exportPdfBtn").addEventListener("click", () => openModal("#pdfExportModal"));
    $("#exportImagesBtn").addEventListener("click", () => openModal("#imageExportModal"));
    $("#cancelPdfExportBtn").addEventListener("click", () => closeModal("#pdfExportModal"));
    $("#cancelImageExportBtn").addEventListener("click", () => closeModal("#imageExportModal"));
    $("#pdfExportModal").addEventListener("click", (event) => {
      if (event.target === $("#pdfExportModal")) closeModal("#pdfExportModal");
    });
    $("#imageExportModal").addEventListener("click", (event) => {
      if (event.target === $("#imageExportModal")) closeModal("#imageExportModal");
    });
    $("#applyPdfExportBtn").addEventListener("click", () => {
      const params = pdfExportParams();
      if (!params) return;
      callHost("export_pdf_by_artboards", params, function (message) {
        closeModal("#pdfExportModal");
        refreshStatus();
      });
    });
    $("#applyImageExportBtn").addEventListener("click", () => {
      const params = imageExportParams();
      if (!params) return;
      callHost("export_images", params, function (message) {
        closeModal("#imageExportModal");
        refreshStatus();
      });
    });
    $("#checkUpdateBtn").addEventListener("click", () => checkForUpdates(true));
    $("#closeUpdateBtn").addEventListener("click", closeUpdateDialog);
    $("#downloadUpdateBtn").addEventListener("click", () => {
      const download = downloadForPlatform(state.updateInfo);
      openExternalUrl(download.url || (state.updateInfo && state.updateInfo.releasePage));
    });
    $("#updateModal").addEventListener("click", (event) => {
      if (event.target === $("#updateModal")) closeUpdateDialog();
    });
    $("#cancelShadowBtn").addEventListener("click", cancelDropShadowModal);
    $("#dropShadowModal").addEventListener("click", (event) => {
      if (event.target === $("#dropShadowModal")) cancelDropShadowModal();
    });
    ["#shadowX", "#shadowY", "#shadowBlur", "#shadowOpacity", "#shadowColor", "#shadowBlend"].forEach((selector) => {
      const input = $(selector);
      input.addEventListener("input", scheduleDropShadowPreview);
      input.addEventListener("change", scheduleDropShadowPreview);
    });
    $("#shadowPreview").addEventListener("change", () => {
      if ($("#shadowPreview").checked) {
        requestDropShadowPreview();
      } else {
        callHost("drop_shadow_native_cancel", {}, refreshStatus);
      }
    });
    $("#applyShadowBtn").addEventListener("click", () => {
      const params = shadowParams();
      if (!params) return;
      if (shadowPreviewTimer) {
        window.clearTimeout(shadowPreviewTimer);
        shadowPreviewTimer = null;
      }
      callHost("drop_shadow_native_apply", params, function () {
        closeDropShadowModal();
        refreshStatus();
      });
    });

    $("#dimBoxBtn").addEventListener("click", () => callHost("dim_box", dimParams()));
    $("#curveLenBtn").addEventListener("click", () => callHost("dim_curve_text_below", dimParams()));
    $("#labelBtn").addEventListener("click", () => callHost("label_material", dimParams()));
  }

  bindTabs();
  bindSegmented();
  bindNotePresets();
  bindTheme();
  bindActions();
  loadHost();
  window.setTimeout(function () {
    checkForUpdates(false);
  }, 1400);
  window.setInterval(refreshStatus, 1800);
}());
