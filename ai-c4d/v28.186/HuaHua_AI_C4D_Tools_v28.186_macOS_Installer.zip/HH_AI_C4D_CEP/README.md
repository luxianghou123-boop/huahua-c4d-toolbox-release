# 花花 AI 辅助工具 CEP 版

这是现有 `export_selected_paths.jsx` 的现代面板版本。界面由 HTML/CSS/JS 实现，Illustrator 逻辑由 `jsx/host.jsx` 调用。

## 结构

- `CSXS/manifest.xml`：CEP 插件声明
- `index.html`：插件面板界面
- `css/style.css`：现代深色 UI 样式
- `js/main.js`：按钮事件和 CEP 调用桥
- `jsx/host.jsx`：从现有 JSX 提取的核心 Illustrator 逻辑

## 安装位置

把整个 `HH_AI_C4D_CEP` 文件夹放到：

```text
~/Library/Application Support/Adobe/CEP/extensions/
```

然后在 Illustrator 中从“窗口 / 扩展”打开“花花 AI 辅助工具”。

## 调试模式

如果 Illustrator 不显示未签名扩展，需要开启 CEP 调试模式。不同 Adobe 版本使用不同 CSXS 编号，常见命令如下：

```bash
defaults write com.adobe.CSXS.11 PlayerDebugMode 1
defaults write com.adobe.CSXS.12 PlayerDebugMode 1
```

重启 Illustrator 后生效。
